// =========================================================================
// RUNTIME BINDING INITIALIZATION & PROGRAMMATIC VERIFICATION BLOCK
// Explicit Modules: express, node-telegram-bot-api, firebase-admin
// Root Credentials Token File: firebase-key.json
// =========================================================================
import express from 'express';
import admin from 'firebase-admin';
import { initializeApp as initAdminApp, getApps as getAdminApps, cert as adminCert } from 'firebase-admin/app';
import { getFirestore as getAdminFirestore } from 'firebase-admin/firestore';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const TelegramBot = require('node-telegram-bot-api');

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Programmatic Verification Block
console.log('======================================================================');
console.log('⚡ [SYSTEM CORE]: Formulating Programmatic Verification Layer...');
console.log('======================================================================');

// 1. Verify Explicit Module Imports
console.log('📦 [MODULE VERIFICATION]:');
console.log(`   - express: loaded successfully (v${express.version || '4.x'})`);
console.log(`   - node-telegram-bot-api: loaded successfully (${typeof TelegramBot === 'function' ? 'Constructor ready' : 'Ready'})`);
console.log(`   - firebase-admin: loaded successfully (SDK v${admin.SDK_VERSION || '14.x'})`);

// 2. Resolve Absolute Path for Root Credentials Token
export const FIREBASE_KEY_PATH = path.resolve(process.cwd(), 'firebase-key.json');
console.log(`🔑 [CREDENTIALS SIGNATURE CHECK]: Target Path -> ${FIREBASE_KEY_PATH}`);

export let adminApp = null;
export let firestoreDb = null;

// 3. Initialize or verify credentials binding
if (fs.existsSync(FIREBASE_KEY_PATH)) {
  try {
    const rawKey = fs.readFileSync(FIREBASE_KEY_PATH, 'utf8');
    const serviceAccount = JSON.parse(rawKey);
    const existingApps = getAdminApps();
    if (!existingApps.length) {
      adminApp = initAdminApp({
        credential: adminCert(serviceAccount),
        projectId: serviceAccount.project_id || 'ai-studio-apexcrashengine-c6ee56ea-d9f9-4bbb-b555-3f64c5728d2a'
      });
    } else {
      adminApp = existingApps[0];
    }
    firestoreDb = getAdminFirestore();
    console.log(`✅ [FIREBASE AUTH SUCCESS]: Successfully bound service account token from 'firebase-key.json'! Project: ${serviceAccount.project_id || 'active'}`);
  } catch (err) {
    console.error(`❌ [FIREBASE KEY ERROR]: Could not parse 'firebase-key.json': ${err.message}`);
  }
} else {
  console.log(`⚠️ [FIREBASE NOTICE]: 'firebase-key.json' not found at root path (${FIREBASE_KEY_PATH}).`);
  console.log(`💡 [SETUP GUIDANCE]: Place your downloaded Google Cloud Service Key inside this directory and rename it to 'firebase-key.json'.`);
  const existingApps = getAdminApps();
  if (!existingApps.length) {
    adminApp = initAdminApp({
      projectId: 'ringed-record-nxctm'
    });
  } else {
    adminApp = existingApps[0];
  }
  firestoreDb = getAdminFirestore('ai-studio-apexcrashengine-c6ee56ea-d9f9-4bbb-b555-3f64c5728d2a');
  console.log(`ℹ️ [FALLBACK ACTIVE]: Initialized default container environment (project: ringed-record-nxctm).`);
}

console.log('🚀 [RUNTIME BINDING]: Node.js server initialization footprint validated.');
console.log('======================================================================');

export { express, TelegramBot, admin };
export default {
  express,
  TelegramBot,
  admin,
  adminApp,
  firestoreDb,
  FIREBASE_KEY_PATH
};
