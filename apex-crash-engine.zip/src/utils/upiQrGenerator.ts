/**
 * ============================================================================
 * DYNAMIC AMOUNT-SPECIFIC UPI QR CODE GENERATOR (DECOUPLED UTILITY)
 * ============================================================================
 * Specification:
 * - Reads runtime numerical amount typed by user in deposit input field.
 * - Formats standard NPCI UPI URI: upi://pay?pa={current_upi_id}&pn=Merchant&am={amount}&cu=INR
 * - Produces reliable QR image matrix URL and deep-link payload.
 * - Decoupled: Does not modify or interfere with existing payment gates or UTR verification.
 * ============================================================================
 */

export interface DynamicUpiQrConfig {
  upiId: string;
  merchantName?: string;
  amount: number | string;
  currency?: string;
  note?: string;
  transactionRef?: string;
  size?: number;
}

export interface DynamicUpiQrResult {
  deepLinkUri: string;
  qrImageUrl: string;
  sanitizedAmount: number;
  formattedAmount: string;
  isValidAmount: boolean;
  upiId: string;
  merchantName: string;
}

/**
 * Generates a dynamic amount-specific UPI deep link and QR code matrix URL.
 * Automatically sanitizes inputs, ensures 2-decimal-place standard, and builds
 * compliant UPI deep link query parameters.
 */
export function generateDynamicUpiQr(config: DynamicUpiQrConfig): DynamicUpiQrResult {
  const rawUpiId = (config.upiId || '').trim();
  const upiId = rawUpiId || 'winnova.merchant@upi';
  const merchantName = (config.merchantName || 'WIN NOVA Merchant').trim();
  const currency = config.currency || 'INR';

  // Parse and sanitize the numerical amount
  let numAmount = 0;
  if (typeof config.amount === 'number') {
    numAmount = isNaN(config.amount) ? 0 : Math.max(0, config.amount);
  } else if (typeof config.amount === 'string') {
    const cleaned = config.amount.replace(/[^0-9.]/g, '');
    const parsed = parseFloat(cleaned);
    numAmount = isNaN(parsed) ? 0 : Math.max(0, parsed);
  }

  const isValidAmount = numAmount >= 100;
  const formattedAmount = numAmount.toFixed(2);
  const size = config.size || 280;

  // Build standard NPCI UPI parameters
  const params = new URLSearchParams();
  params.set('pa', upiId);
  params.set('pn', merchantName);
  params.set('am', formattedAmount);
  params.set('cu', currency);

  if (config.note) {
    params.set('tn', config.note.slice(0, 50));
  }
  if (config.transactionRef) {
    params.set('tr', config.transactionRef.slice(0, 35));
  }

  const deepLinkUri = `upi://pay?${params.toString()}`;

  // High-reliability QR Server with margin and high error correction level
  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(
    deepLinkUri
  )}&margin=12&format=svg`;

  return {
    deepLinkUri,
    qrImageUrl,
    sanitizedAmount: numAmount,
    formattedAmount,
    isValidAmount,
    upiId,
    merchantName
  };
}
