import type { Express, Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { createRequire } from 'module';
import axios from 'axios';
import mongoose from 'mongoose';
import { GoogleGenAI } from '@google/genai';
import admin from 'firebase-admin';
import { initializeApp as initAdminApp, getApps as getAdminApps, cert as adminCert } from 'firebase-admin/app';
import { getFirestore as getAdminFirestore, FieldValue as AdminFieldValue } from 'firebase-admin/firestore';
import QRCode from 'qrcode';

// 1. DATABASE CONFIGURATION (Universal Dynamic Logging Schema)
import { BotLog, BotUser, AdminSettings, SubAdmin } from '../server/database.ts';
export { BotLog, BotUser, AdminSettings, SubAdmin };

// Global Input State Lock Registry (Single Source of Truth)
export const botUserStates = new Map<number, string>();
export const userStates = botUserStates;
export const inMemorySubAdmins = new Map<string, any>();

// Active request tracking to prevent double tap/messages
export const activeRequests = new Set<string>();

// Active Polling Token Registry to prevent duplicate getUpdates listeners
const activePollingTokens = new Set<string>();

// Dynamic WinNova settings cache
export const winNovaSettingsCache = {
  get adminUpiId() {
    return adminUpiId;
  },
  set adminUpiId(val: string) {
    adminUpiId = val;
  },
  get globalVipPrice() {
    return globalVipPrice;
  },
  set globalVipPrice(val: number) {
    globalVipPrice = val;
  },
  get globalCreditRate() {
    return globalCreditRate;
  },
  set globalCreditRate(val: number) {
    globalCreditRate = val;
  }
};

// =========================================================================
// UPI QR CODE GENERATOR BUFFER UTILITY
// =========================================================================
export async function generateUpiQrCodeBuffer(upiId: string, amount: number, payeeName: string = "WinNova"): Promise<Buffer | null> {
  // Standard UPI Payment URL format with exact amount
  const upiUrl = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}&am=${amount.toFixed(2)}&cu=INR`;
  
  try {
    // Generate QR code as buffer image to send directly via Telegram bot
    const qrBuffer = await QRCode.toBuffer(upiUrl, { type: 'png', width: 300, margin: 2 });
    return qrBuffer;
  } catch (err) {
    console.error("QR Generation Error:", err);
    return null;
  }
}

// REAL WEIGHTED PROBABILITY ENGINE FOR TELEGRAM SIGNAL
export function getRealTelegramSignalMultiplier() {
  const rand = Math.random();
  let targetMultiplier: number;

  // ~60% rounds targeted between 1.35x to 1.93x (~93% consistency range)
  if (rand < 0.60) {
    targetMultiplier = parseFloat((1.35 + Math.random() * 0.58).toFixed(2));
  } 
  // ~40% rounds targeted between 1.58x to 3.50x
  else {
    targetMultiplier = parseFloat((1.58 + Math.random() * 1.92).toFixed(2));
  }

  // Safe cashout calculation (Target * 0.82, minimum 1.05x)
  const safeCashout = Math.max(1.05, parseFloat((targetMultiplier * 0.82).toFixed(2)));

  return {
    target: targetMultiplier,
    safe: safeCashout
  };
}

// State trigger karte waqt Cancel button add karein
export async function promptAdminForUpi(ctx: any) {
  userStates.set(ctx.from?.id, 'WAITING_FOR_UPI_ID');
  return ctx.reply("💳 Send your new Admin UPI ID:", {
    reply_markup: {
      inline_keyboard: [
        [{ text: "❌ Cancel Operation", callback_data: "cancel_state" }]
      ]
    }
  });
}

// =========================================================================
// HIGH-PERFORMANCE TELEGRAM BOT CLIENT (Native HTTP API + Polling + Anti-Forward)
// =========================================================================
export class TelegramBotClient {
  public token: string;
  private baseUrl: string;
  private messageHandlers: Array<(msg: any) => Promise<void> | void> = [];
  private textRegexHandlers: Array<{ regex: RegExp; handler: (msg: any) => Promise<void> | void }> = [];
  private photoHandlers: Array<(msg: any) => Promise<void> | void> = [];
  private textHandlers: Array<(ctx: any, next: () => Promise<void>) => Promise<void> | void> = [];
  private callbackQueryHandlers: Array<(query: any) => Promise<void> | void> = [];
  private actionHandlers: Array<{ trigger: string | RegExp; handler: (ctx: any) => Promise<void> | void }> = [];
  private hearsHandlers: Array<{ trigger: string | RegExp; handler: (ctx: any) => Promise<void> | void }> = [];
  private pollingErrorHandlers: Array<(err: any) => void> = [];
  private webhookErrorHandlers: Array<(err: any) => void> = [];
  private catchHandlers: Array<(err: any, ctx?: any) => void> = [];
  private middlewares: Array<(ctx: any, next: () => Promise<void>) => Promise<void> | void> = [];
  private startHandlers: Array<(ctx: any) => Promise<void> | void> = [];
  private isPolling = false;
  private isFetchingUpdates = false;
  private pollingOffset = 0;

  constructor(token: string, options?: any) {
    this.token = token;
    this.baseUrl = `https://api.telegram.org/bot${token}`;

    if (options?.polling?.autoStart || options?.polling === true) {
      const timeout = options?.polling?.params?.timeout || 10;
      this.startPolling(timeout);
    }
  }

  use(fn: (ctx: any, next: () => Promise<void>) => Promise<void> | void) {
    this.middlewares.push(fn);
    return this;
  }

  start(fn: (ctx: any) => Promise<void> | void) {
    this.startHandlers.push(fn);
    return this;
  }

  action(trigger: string | RegExp, handler: (ctx: any) => Promise<void> | void) {
    this.actionHandlers.push({ trigger, handler });
    return this;
  }

  hears(trigger: string | RegExp, handler: (ctx: any) => Promise<void> | void) {
    this.hearsHandlers.push({ trigger, handler });
    return this;
  }

  catch(fn: (err: any, ctx?: any) => void) {
    this.catchHandlers.push(fn);
    return this;
  }

  get telegram() {
    return {
      deleteWebhook: (options?: any) => this.deleteWebHook(options),
      setMyCommands: (commands: any[]) => this.setMyCommands(commands),
      sendMessage: (chatId: number | string, text: string, options?: any) => this.sendMessage(chatId, text, options),
      sendPhoto: (chatId: number | string, photo: string, options?: any) => this.sendPhoto(chatId, photo, options),
      deleteMessage: (chatId: number | string, messageId: number) => this.deleteMessage(chatId, messageId),
      answerCbQuery: (id: string, text?: string, options?: any) => this.answerCallbackQuery(id, { text, ...options }),
      answerCallbackQuery: (id: string, options?: any) => this.answerCallbackQuery(id, options),
      getChatMember: (channelId: string, userId: number | string) => this.getChatMember(channelId, userId),
      getMe: () => this.getMe()
    };
  }

  async setMyCommands(commands: any[]) {
    return this.callApi('setMyCommands', { commands });
  }

  async launch(options?: any): Promise<void> {
    const timeout = options?.polling?.timeout || 10;
    this.startPolling(timeout);
    return Promise.resolve();
  }

  stop(signal?: string) {
    this.stopPolling();
  }

  private async callApi(method: string, body?: any, timeoutMs: number = 25000) {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      const isFormData = typeof FormData !== 'undefined' && body instanceof FormData;
      const res = await fetch(`${this.baseUrl}/${method}`, {
        method: 'POST',
        headers: isFormData ? undefined : { 'Content-Type': 'application/json' },
        body: isFormData ? body : (body ? JSON.stringify(body) : undefined),
        signal: controller.signal
      });
      clearTimeout(timer);
      const data: any = await res.json().catch(() => ({}));
      return data;
    } catch (err: any) {
      return { ok: false, description: err.message };
    }
  }

  async sendMessage(chatId: number | string, text: string, options?: any) {
    return this.callApi('sendMessage', {
      chat_id: chatId,
      text,
      parse_mode: options?.parse_mode || 'HTML',
      protect_content: options?.protect_content,
      reply_markup: options?.reply_markup
    });
  }

  async sendPhoto(chatId: number | string, photo: string | Buffer, options?: any) {
    if (Buffer.isBuffer(photo)) {
      const formData = new FormData();
      formData.append('chat_id', String(chatId));
      formData.append('photo', new Blob([photo], { type: 'image/png' }), 'qrcode.png');
      if (options?.caption) formData.append('caption', options.caption);
      if (options?.parse_mode) formData.append('parse_mode', options.parse_mode || 'HTML');
      if (options?.protect_content) formData.append('protect_content', 'true');
      if (options?.reply_markup) {
        formData.append('reply_markup', typeof options.reply_markup === 'string' ? options.reply_markup : JSON.stringify(options.reply_markup));
      }
      return this.callApi('sendPhoto', formData);
    }
    return this.callApi('sendPhoto', {
      chat_id: chatId,
      photo,
      caption: options?.caption,
      parse_mode: options?.parse_mode || 'HTML',
      protect_content: options?.protect_content,
      reply_markup: options?.reply_markup
    });
  }

  async answerCallbackQuery(callbackQueryId: string, options?: { text?: string; show_alert?: boolean }) {
    return this.callApi('answerCallbackQuery', {
      callback_query_id: callbackQueryId,
      text: options?.text,
      show_alert: options?.show_alert
    });
  }

  async deleteMessage(chatId: number | string, messageId: number) {
    return this.callApi('deleteMessage', {
      chat_id: chatId,
      message_id: messageId
    });
  }

  async getChatMember(channelId: string, userId: number | string) {
    const res = await this.callApi('getChatMember', {
      chat_id: channelId,
      user_id: userId
    });
    if (res && res.ok && res.result) {
      return res.result;
    }
    return { status: 'left' };
  }

  async setWebHook(url: string) {
    return this.callApi('setWebhook', { url });
  }

  async deleteWebHook(options?: any) {
    return this.callApi('deleteWebhook', options);
  }

  async getMe() {
    return this.callApi('getMe');
  }

  async getFile(fileId: string) {
    const res = await this.callApi('getFile', { file_id: fileId });
    return res && res.ok ? res.result : null;
  }

  async getFileLink(fileId: string): Promise<string> {
    const file = await this.getFile(fileId);
    if (!file || !file.file_path) throw new Error('File not found');
    return `https://api.telegram.org/file/bot${this.token}/${file.file_path}`;
  }

  async editMessageCaption(caption: string, options?: any) {
    return this.callApi('editMessageCaption', {
      caption,
      chat_id: options?.chat_id,
      message_id: options?.message_id,
      parse_mode: options?.parse_mode || 'HTML'
    });
  }

  async editMessageText(text: string, options?: any) {
    return this.callApi('editMessageText', {
      text,
      chat_id: options?.chat_id,
      message_id: options?.message_id,
      parse_mode: options?.parse_mode || 'HTML'
    });
  }

  onText(regex: RegExp, handler: (msg: any) => Promise<void> | void) {
    this.textRegexHandlers.push({ regex, handler });
  }

  on(event: string, handler: (payload: any, next?: any) => Promise<void> | void) {
    if (event === 'message') this.messageHandlers.push(handler);
    else if (event === 'photo') this.photoHandlers.push(handler);
    else if (event === 'callback_query') this.callbackQueryHandlers.push(handler);
    else if (event === 'text') this.textHandlers.push(handler);
    else if (event === 'polling_error') this.pollingErrorHandlers.push(handler);
    else if (event === 'webhook_error') this.webhookErrorHandlers.push(handler);
  }

  startPolling(timeout = 10) {
    if (this.isPolling) return;
    if (activePollingTokens.has(this.token)) {
      console.log(`ℹ️ [BOT SINGLETON]: Polling instance already active for bot token (${this.token.slice(0, 10)}...). Skipping duplicate loop.`);
      return;
    }
    this.isPolling = true;
    activePollingTokens.add(this.token);

    const poll = async () => {
      while (this.isPolling) {
        if (this.isFetchingUpdates) {
          await new Promise(r => setTimeout(r, 1000));
          continue;
        }
        this.isFetchingUpdates = true;
        try {
          const res = await this.callApi('getUpdates', {
            offset: this.pollingOffset,
            timeout: timeout,
            allowed_updates: ['message', 'callback_query']
          }, (timeout + 5) * 1000);

          if (res && res.ok && Array.isArray(res.result)) {
            for (const update of res.result) {
              this.pollingOffset = Math.max(this.pollingOffset, update.update_id + 1);
              this.processUpdate(update).catch(() => {});
            }
          } else if (res && res.ok === false) {
            if (res.description && res.description.includes("can't use getUpdates method while webhook is active")) {
              console.log("💡 [AUTO-RESOLVE]: Clearing stale webhook so real-time polling can proceed...");
              await this.callApi('deleteWebhook', { drop_pending_updates: false });
              await new Promise(r => setTimeout(r, 2000));
              continue;
            }
            if (res.description && (res.description.includes("terminated by other getUpdates request") || res.description.includes("409 Conflict"))) {
              // Graceful cooperative standby: Another bot instance or process is currently polling
              // We quietly back off for 60s without emitting fatal errors to allow uninterrupted processing
              await new Promise(r => setTimeout(r, 60000));
              continue;
            }
            const err = new Error(res.description || 'Polling notice');
            for (const h of this.pollingErrorHandlers) {
              try { h(err); } catch {}
            }
            await new Promise(r => setTimeout(r, 8000));
          }
        } catch (e: any) {
          for (const h of this.pollingErrorHandlers) {
            try { h(e); } catch {}
          }
          await new Promise(r => setTimeout(r, 5000));
        } finally {
          this.isFetchingUpdates = false;
        }
      }
      activePollingTokens.delete(this.token);
    };
    poll();
  }

  stopPolling() {
    this.isPolling = false;
    activePollingTokens.delete(this.token);
  }

  async processUpdate(update: any) {
    if (!update || typeof update !== 'object') return;

    const msg = update.message || update.edited_message;
    const query = update.callback_query;
    const fromUser = msg?.from || query?.from;
    const chat = msg?.chat || query?.message?.chat;

    // Create a unified Telegraf-compatible context object
    const ctx: any = {
      update,
      message: msg,
      callbackQuery: query,
      from: fromUser,
      chat: chat,
      telegram: this.telegram,
      updateType: query ? 'callback_query' : (msg?.photo ? 'photo' : (msg?.text ? 'message' : 'unknown')),
      reply: (text: string, options?: any) => {
        const targetId = chat?.id || fromUser?.id;
        return this.sendMessage(targetId, text, options);
      },
      sendPhoto: (photo: string | Buffer, options?: any) => {
        const targetId = chat?.id || fromUser?.id;
        return this.sendPhoto(targetId, photo, options);
      },
      replyWithPhoto: (photo: any, options?: any) => {
        const targetId = chat?.id || fromUser?.id;
        const actualPhoto = photo?.source ? photo.source : photo;
        return this.sendPhoto(targetId, actualPhoto, options);
      }
    };

    // Run universal middleware chain (e.g. auto-saving database layer)
    if (this.middlewares.length > 0) {
      let idx = 0;
      const next = async () => {
        if (idx < this.middlewares.length) {
          const fn = this.middlewares[idx++];
          await fn(ctx, next);
        }
      };
      try {
        await next();
      } catch (err: any) {
        console.warn('⚙️ Silent Database Logging Error:', err);
      }
    }

    if (query) {
      const userId = fromUser?.id;
      const actionKey = `${userId}_${query.data}`;

      // Active request tracking to prevent double tap/duplicate queries
      if (activeRequests.has(actionKey)) {
        this.answerCallbackQuery(query.id, { text: "⚠️ Please wait, processing..." }).catch(() => {});
        return;
      }

      activeRequests.add(actionKey);
      setTimeout(() => {
        activeRequests.delete(actionKey);
      }, 1000);

      // Build Telegraf-style context for callback query
      const actionCtx: any = {
        update,
        callbackQuery: query,
        from: fromUser,
        chat: chat,
        telegram: this.telegram,
        updateType: 'callback_query',
        data: query.data,
        match: null,
        answerCbQuery: async (text?: string, options?: any) => {
          return this.answerCallbackQuery(query.id, { text, ...options });
        },
        editMessageText: async (text: string, options?: any) => {
          const chatId = chat?.id || fromUser?.id || query.message?.chat?.id;
          const messageId = query.message?.message_id;
          return this.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            ...options
          });
        },
        reply: (text: string, options?: any) => {
          const targetId = chat?.id || fromUser?.id;
          return this.sendMessage(targetId, text, options);
        },
        sendPhoto: (photo: string | Buffer, options?: any) => {
          const targetId = chat?.id || fromUser?.id;
          return this.sendPhoto(targetId, photo, options);
        },
        replyWithPhoto: (photo: any, options?: any) => {
          const targetId = chat?.id || fromUser?.id;
          const actualPhoto = photo?.source ? photo.source : photo;
          return this.sendPhoto(targetId, actualPhoto, options);
        }
      };

      for (const item of this.actionHandlers) {
        let isMatch = false;
        if (typeof item.trigger === 'string' && item.trigger === query.data) {
          isMatch = true;
        } else if (item.trigger instanceof RegExp && item.trigger.test(query.data || '')) {
          isMatch = true;
          actionCtx.match = (query.data || '').match(item.trigger);
        }
        if (isMatch) {
          try {
            await item.handler(actionCtx);
          } catch (e: any) {
            console.warn('[TELEGRAM BOT] Action handler error:', e.message);
            for (const ch of this.catchHandlers) {
              try { ch(e, actionCtx); } catch {}
            }
          }
        }
      }

      for (const h of this.callbackQueryHandlers) {
        try {
          await h(actionCtx);
        } catch (e: any) {
          console.warn('[TELEGRAM BOT] Callback query handler error:', e.message);
        }
      }
      return;
    }

    if (!msg) return;

    // Check if start handlers should execute
    if (msg.text && (msg.text === '/start' || msg.text.startsWith('/start ')) && this.startHandlers.length > 0) {
      for (const h of this.startHandlers) {
        try {
          await h(ctx);
        } catch (e: any) {
          console.warn('[TELEGRAM BOT] Start handler error:', e.message);
        }
      }
    }

    if (msg.photo && msg.photo.length > 0) {
      for (const h of this.photoHandlers) {
        try {
          await h(msg);
        } catch (e: any) {
          console.warn('[TELEGRAM BOT] Photo handler error:', e.message);
        }
      }
    }

    if (msg.text) {
      if (this.textHandlers.length > 0) {
        let shouldProceed = false;
        const dispatch = async (i: number): Promise<void> => {
          if (i >= this.textHandlers.length) {
            shouldProceed = true;
            return;
          }
          const fn = this.textHandlers[i];
          await fn(ctx, () => dispatch(i + 1));
        };
        try {
          await dispatch(0);
        } catch (e: any) {
          console.warn('[TELEGRAM BOT] Text handler error:', e.message);
        }
        if (!shouldProceed) return;
      }

      for (const h of this.hearsHandlers) {
        let isMatch = false;
        if (typeof h.trigger === 'string') {
          isMatch = msg.text.trim().toLowerCase() === h.trigger.toLowerCase() || msg.text.includes(h.trigger);
        } else if (h.trigger instanceof RegExp) {
          isMatch = h.trigger.test(msg.text);
        }
        if (isMatch) {
          try {
            await h.handler(ctx);
          } catch (e: any) {
            console.warn('[TELEGRAM BOT] Hears handler error:', e.message);
          }
        }
      }

      for (const reg of this.textRegexHandlers) {
        if (reg.regex.test(msg.text)) {
          try {
            await reg.handler(msg);
          } catch (e: any) {
            console.warn('[TELEGRAM BOT] Text regex handler error:', e.message);
          }
        }
      }
    }

    for (const h of this.messageHandlers) {
      try {
        await h(msg);
      } catch (e: any) {
        console.warn('[TELEGRAM BOT] Message handler error:', e.message);
      }
    }
  }
}

export const TelegramBot = TelegramBotClient;

// ==========================================
// 1. ABSOLUTE SYSTEM IDENTIFICATION & CORE CONSTANTS (ANONYMOUS MATRIX)
// ==========================================
export const ADMIN_ID = 7939005883; // Your Verified Telegram Admin User ID Locked
export const SUPREME_OWNER_ID = ADMIN_ID; // Your verified absolute control identity (@jackhype7)
export const HARDLOCKED_ADMIN_ID = ADMIN_ID;
export const DEPOSIT_LOGS_GROUP_ID = -1002147483647; // Your private corporate tracking group chat ID

export const TARGET_TOKEN = '8989808450:AAHC3Owc_y3a8WDKLnrGWCVLv_SXldFRlqw';
export const PREDICTION_BOT_TOKEN = process.env.BOT_TOKEN === TARGET_TOKEN ? process.env.BOT_TOKEN : TARGET_TOKEN;
export const MASTER_HUB_BOT_TOKEN = '8828254838:AAEDJDElJPa8ETmhHINPD7PezMrZ9IWgDDU'; // Master Gateway Hub
export const TELEGRAM_TOKEN = PREDICTION_BOT_TOKEN;

// Initialize Firebase Admin SDK for Firestore Persistence with root firebase-key.json expectation
const FIREBASE_KEY_PATH = path.resolve(process.cwd(), 'firebase-key.json');
if (!getAdminApps().length) {
  if (fs.existsSync(FIREBASE_KEY_PATH)) {
    try {
      const serviceAccount = JSON.parse(fs.readFileSync(FIREBASE_KEY_PATH, 'utf8'));
      initAdminApp({
        credential: adminCert(serviceAccount),
        projectId: serviceAccount.project_id || 'ai-studio-apexcrashengine-c6ee56ea-d9f9-4bbb-b555-3f64c5728d2a'
      });
      console.log(`✅ [FIREBASE ADMIN BOT]: Bound credentials from root '${FIREBASE_KEY_PATH}'`);
    } catch (err: any) {
      console.warn(`⚠️ [FIREBASE ADMIN BOT]: Error reading '${FIREBASE_KEY_PATH}':`, err.message);
      initAdminApp({ projectId: 'ringed-record-nxctm' });
    }
  } else {
    initAdminApp({ projectId: 'ringed-record-nxctm' });
  }
}
export const db = getAdminFirestore('ai-studio-apexcrashengine-c6ee56ea-d9f9-4bbb-b555-3f64c5728d2a');
try {
  db.settings({ ignoreUndefinedProperties: true });
} catch (_) {}
export const usersRef = db.collection('users');
export const depositsRef = db.collection('deposits');
export const settingsRef = db.collection('settings').doc('global_config');

// Initialize dual polling bots with error catchers
export const predictionBot = new TelegramBot(PREDICTION_BOT_TOKEN, { 
    polling: { autoStart: true, params: { timeout: 10 } } 
});
export const masterHubBot = new TelegramBot(MASTER_HUB_BOT_TOKEN, { 
    polling: { autoStart: true, params: { timeout: 10 } } 
});
export const mainBot = predictionBot;

// 3. THE MIDDLEWARE (Preserves existing code, acts as a silent helper)
predictionBot.use(async (ctx: any, next: () => Promise<void>) => {
  try {
    if (!ctx.from) return next();

    // Dynamically captures and saves/updates every user's details automatically if database is online
    if (mongoose.connection.readyState === 1) {
      try {
        await BotUser.findOneAndUpdate(
          { telegramId: ctx.from.id },
          { 
            telegramId: ctx.from.id, 
            username: ctx.from.username,
            firstName: ctx.from.first_name,
            lastName: ctx.from.last_name
          },
          { upsert: true, new: true }
        );

        // Dynamic logging of interaction paths for admin audits
        await BotLog.create({
          telegramId: ctx.from.id,
          username: ctx.from.username,
          actionType: ctx.message?.text ? 'bot_command' : ctx.updateType,
          rawData: ctx.update
        });
      } catch (_) {
        // Mongoose query failed; ignore silently to protect bot continuity
      }
    }

    // Hot RAM memory user sync ensures 100% uninterrupted uptime
    if (userDatabase && ctx.from.id) {
      if (!userDatabase[ctx.from.id]) {
        const isMasterAdmin = ctx.from.id === ADMIN_ID || ctx.from.id === SUPREME_OWNER_ID;
        userDatabase[ctx.from.id] = {
          credits: isMasterAdmin ? 999999 : 0,
          isPremium: isMasterAdmin,
          registeredAt: Date.now(),
          lastActiveAt: Date.now(),
          predictionsRequested: 0,
          role: isMasterAdmin ? 'super_admin' : 'user',
          activeSubscription: isMasterAdmin,
          username: ctx.from.username || '',
          firstName: ctx.from.first_name || 'Pilot',
          lastName: ctx.from.last_name || ''
        };
      } else {
        userDatabase[ctx.from.id].username = ctx.from.username || userDatabase[ctx.from.id].username;
        userDatabase[ctx.from.id].firstName = ctx.from.first_name || userDatabase[ctx.from.id].firstName;
        userDatabase[ctx.from.id].lastName = ctx.from.last_name || userDatabase[ctx.from.id].lastName;
      }
    }

    return next();
  } catch (_) {
    return next();
  }
});

// Polling Error Exception Catch Block Matrix listeners to keep connection alive
predictionBot.on('polling_error', (error: any) => {
    if (error?.message && (error.message.includes('409') || error.message.includes('Conflict') || error.message.includes('terminated by other getUpdates'))) {
        return; // Handled quietly in cooperative standby loop
    }
    console.log(`[TELEGRAM DIAGNOSTIC]: Polling notice: ${error?.message || error}`);
});
masterHubBot.on('polling_error', (err: any) => {
    if (err?.message && (err.message.includes('409') || err.message.includes('Conflict') || err.message.includes('terminated by other getUpdates'))) {
        return;
    }
    console.log(`[CONNECTION LOG - MASTER HUB]: ${err?.message || err}`);
});

predictionBot.on('webhook_error', (error: any) => {
    console.log(`❌ [WEBHOOK ERROR - PREDICTION BOT]: ${error.message}`);
});
masterHubBot.on('webhook_error', (error: any) => {
    console.log(`❌ [WEBHOOK ERROR - MASTER HUB]: ${error.message}`);
});

console.log("🚀 [SYSTEM CORE]: Telegram Bot Listener Handshake Initiated... Waiting for connection logs.");

// Fallback Default Parameters (Synchronized directly from cloud schema settings doc)
export let globalVipPrice = 144;
export let globalCreditRate = 10; 
export let adminUpiId = "yourupi@ybl";
export const BANNER_IMAGE = "https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=1000&auto=format&fit=crop";

export const REQUIRED_CHANNELS: Array<{ name: string; id: string; url: string; username?: string }> = [
  { name: "🎁 Free Loot & Codes", id: "@flyloots", url: "https://t.me/flyloots", username: "@flyloots" },
  { name: "💰 Free Live Deposit", id: "@winnovadeposit", url: "https://t.me/winnovadeposit", username: "@winnovadeposit" },
  { name: "🖨️ Work & Earn 77", id: "@workandearn77", url: "https://t.me/workandearn77", username: "@workandearn77" },
  { name: "💎 Work & Earn 777", id: "@workandearn777", url: "https://t.me/workandearn777", username: "@workandearn777" }
];

// Asynchronous background live parameters controller matrix
export async function syncGlobalSystemSettings() {
  try {
    const doc = await settingsRef.get();
    if (doc.exists) {
      const data = doc.data();
      globalVipPrice = data?.globalVipPrice || 144;
      globalCreditRate = data?.globalCreditRate || 10;
      adminUpiId = data?.adminUpiId || "yourupi@ybl";
      console.log(`⚙️ [SYSTEM LOG]: DB Core Parameters Synced. VIP: ₹${globalVipPrice}, Credit Rate: ₹${globalCreditRate}, UPI: ${adminUpiId}`);
    } else {
      await settingsRef.set({ globalVipPrice, globalCreditRate, adminUpiId }, { merge: true });
    }
  } catch (err: any) {
    console.error("⚠️ System dynamic settings synchronization failure:", err.message);
  }
}
syncGlobalSystemSettings();

// REAL AVIATOR WEIGHTED PROBABILITY ALGORITHM
export function generateRealAviatorMultiplier(): number {
  const rand = Math.random();
  // 6 rounds out of 10 (~60%) targeted around 1.50x to 1.93x range
  if (rand < 0.60) {
    return parseFloat((1.35 + Math.random() * 0.58).toFixed(2)); 
  } 
  // 4 rounds out of 10 (~40%) targeted around 1.58x to 3.50x range
  else if (rand < 1.00) {
    return parseFloat((1.58 + Math.random() * 2.00).toFixed(2)); 
  }
  return parseFloat((1.01 + Math.random() * 0.20).toFixed(2));
}

export async function refreshMemoryCache() {
  try {
    if (mongoose.connection.readyState === 1) {
      let settings = await AdminSettings.findOne({ id: 1 });
      if (!settings) {
        settings = await AdminSettings.create({
          id: 1,
          baseSubRate: globalVipPrice || 144,
          creditRate: globalCreditRate || 10,
          taxPercent: 5,
          commissionPercent: 10,
          adminUpiId: adminUpiId || "yourupi@ybl",
          dynamicWebsiteUrl: "http://localhost:3000"
        });
      }
      if (settings) {
        if (settings.baseSubRate != null) globalVipPrice = settings.baseSubRate;
        if (settings.creditRate != null) globalCreditRate = settings.creditRate;
        if (settings.adminUpiId) adminUpiId = settings.adminUpiId;
      }
    }
    await syncGlobalSystemSettings();
  } catch (err: any) {
    console.error("Cache Refresh Error:", err.message);
  }
}

// Secure Async Cloud Utility Services Storage Handlers
export async function getUser(chatId: string | number) {
  try {
    const doc = await usersRef.doc(String(chatId)).get();
    if (!doc.exists) {
      const newUser = {
        credits: 0,
        isPremium: false,
        context: null,
        role: 'user',
        createdAt: AdminFieldValue.serverTimestamp()
      };
      await usersRef.doc(String(chatId)).set(newUser).catch(() => {});
      return newUser;
    }
    return doc.data();
  } catch (_err: any) {
    if (!userDatabase[chatId]) {
      userDatabase[chatId] = {
        credits: 0,
        isPremium: false,
        context: null,
        role: 'user',
        registeredAt: Date.now(),
        lastActiveAt: Date.now(),
        predictionsRequested: 0,
        username: '',
        firstName: 'Pilot'
      };
    }
    return userDatabase[chatId];
  }
}

export async function updateUser(chatId: string | number, updateData: any) {
  try {
    await usersRef.doc(String(chatId)).set(updateData, { merge: true });
  } catch (_err: any) {
    if (userDatabase[chatId]) {
      Object.assign(userDatabase[chatId], updateData);
    }
  }
}

// Aggregated live accounting metric query engine
export async function getTotalUserCount(): Promise<number> {
  try {
    const snapshot = await usersRef.count().get();
    return snapshot.data().count;
  } catch (error: any) {
    console.error("❌ Aggregation failure count fetch:", error.message);
    return Object.keys(userDatabase).length;
  }
}

// Helper function to check if the user is an authorized Admin (Owner or DB verified)
export async function isAuthorizedAdmin(userId: number | string): Promise<boolean> {
  if (Number(userId) === SUPREME_OWNER_ID || String(userId) === String(SUPREME_OWNER_ID)) return true;

  try {
    // Check in Firestore if additional admin privileges exist
    const adminDoc = await db.collection('settings').doc('admins').get();
    if (adminDoc.exists) {
      const allowedAdmins = adminDoc.data()?.adminList || [];
      return allowedAdmins.includes(String(userId));
    }
  } catch (err: any) {
    console.warn('[ADMIN CHECK] Firestore lookup note:', err.message);
  }
  return false;
}

// 🔄 MULTI-KEY ARRAY: Active key at index 0, backup keys support
export const GOOGLE_AI_KEYS = [
  'AQ.Ab8RN6JKk5rCcPxQToMP1nK-JltRCn3jvrGt7PqDxf9RJXqVGQ', // Nayi Active Key (Index 0)
  process.env.GEMINI_API_KEY || 'YOUR_TOMORROW_RESET_KEY_HERE' // Backup key slot
];

let currentKeyIndex = 0;

export const OFFICIAL_NETWORKS = [
  { name: '🤖 VIP Prediction Bot', handle: '@Thakku67bot', url: 'https://t.me/Thakku67bot', color: '#45f3ff', tag: 'VIP Prediction Bot' },
  { name: '🎁 Free Loot & Codes', handle: '@flyloots', url: 'https://t.me/flyloots', color: '#28a745', tag: 'Join Channel' },
  { name: '💰 Free Live Deposit Logs', handle: '@winnovadeposit', url: 'https://t.me/winnovadeposit', color: '#ffc107', tag: 'View Trans' },
  { name: '💼 Work & Earn Alpha', handle: '@workandearn77', url: 'https://t.me/workandearn77', color: '#e94560', tag: 'Join Network' },
  { name: '🚀 Work & Earn Elite', handle: '@workandearn777', url: 'https://t.me/workandearn777', color: '#8a2be2', tag: 'Join Network' }
];

export interface TelegramUserData {
  credits: number;
  isPremium: boolean;
  registeredAt: number;
  lastActiveAt: number;
  predictionsRequested: number;
  username?: string;
  firstName?: string;
  lastName?: string;
  activeSubscription?: boolean;
  creditBalance?: number;
  totalCreditsEarned?: number;
  totalReferrals?: number;
  dailyReferralCount?: number;
  isBanned?: boolean;
  context?: string | null;
  role?: 'user' | 'super_admin' | 'banned' | 'admin';
  lastCalculatedRounds?: number;
  lastCalculatedTotal?: number;
}

export interface TelegramReceiptVerification {
  id: string;
  chatId: number | string;
  userId: number | string;
  username?: string;
  firstName?: string;
  demandType: string;
  roundsDemanded?: number;
  amount: number;
  fileId?: string;
  date: string;
  timestamp: number;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
}

// User Memory Store (Data Safe Protection Layer)
export const userDatabase: Record<string | number, TelegramUserData> = {};
export const pendingReceiptQueue: TelegramReceiptVerification[] = [];

let currentWebhookUrl = '';

// =========================================================================
// 🎭 MODULE 3: AUTO-HYPE TELEGRAM SYSTEM & EXHAUSTION WATCHDOG
// =========================================================================

// 1. DYNAMIC HYPE TEMPLATES (Jo real-time player trust build karega)
export const hypeTemplates = [
  "🔥 VIP Prediction Engine is running on 99.4% accuracy right now! Don't miss the current wave.",
  "Bhai @Thakku67bot ka 7-second advance prediction sach mein bawaal hai! Kal ₹200 lagaye the aur 5.5x par auto-cashout kiya! ₹1100 seedhe wallet mein! 🔥👑",
  "💰 ALERT: 3 players just unlocked VIP subscription pass and bagged 10x+ multipliers inside the private pool!",
  "Massive win reported by User ID: 4829XX! Turned ₹500 into ₹4,500 within 3 rounds using VIP advance signals. 🚀🚀",
  "System Update: 0% Lag reported in the last 100 rounds. Keep your 7-second target buffer active!"
];

// 3. STEALTH EMERGENCY WARNING (Saari keys exhaust hone par admin log notify karne ke liye)
export function triggerEmergencyKeyAlert() {
  console.log("\n=======================================================");
  console.log("🚨🚨🚨 EMERGENCY SYSTEM WARNING ALERT 🚨🚨🚨");
  console.log("🚨 STATUS: ALL GOOGLE API KEYS ARE EXHAUSTED!");
  console.log("🚨 ACTION: Create a new Google AI Studio account instantly");
  console.log("🚨         and update the GOOGLE_AI_KEYS array layer.");
  console.log("🚨 SECURITY: Fallback dynamic mathematical engine is ACTIVE.");
  console.log("=======================================================\n");
}

let autoHypeIntervalId: NodeJS.Timeout | null = null;

// =========================================================================
// 🎯 AUTOMATED DYNAMIC ROUNDS CALCULATOR LOGIC (SLAB MANAGER)
// =========================================================================
export function calculateTopupCost(rounds: number) {
  const basePrice = rounds * 3;
  let tax = 0;

  if (rounds < 10) {
    return { error: true, message: '⚠️ Minimum top-up requires at least 10 rounds!' };
  }

  // Dynamic Slabs Mapping formulation based on mastermind configurations
  if (rounds >= 10 && rounds < 30) {
    tax = 2; // e.g., 10 Rounds = ₹30 + ₹2 = ₹32 total
  } else if (rounds >= 30 && rounds < 100) {
    tax = 6; // e.g., 30 Rounds = ₹90 + ₹6 = ₹96 total
  } else if (rounds >= 100) {
    tax = 15; // e.g., 100 Rounds = ₹300 + ₹15 = ₹315 total
  }

  const finalAmount = basePrice + tax;
  return { error: false, base: basePrice, tax: tax, total: finalAmount };
}

// =========================================================================
// 🛠️ ADMINISTRATIVE LIVE INTERFACE FUNCTIONS (MANUAL RELEASE GATEWAY)
// =========================================================================
export function processAdminVipApproval(targetUserChatId: string | number) {
  const user = userDatabase[targetUserChatId];
  if (user) {
    user.isPremium = true;
    user.credits += 32; // 💎 UPGRADED: 32 Free Credits added directly on VIP approval!

    botInstance?.sendMessage(
      targetUserChatId,
      `🎉 <b>VIP MEMBERSHIP ACTIVATED SUCCESSFULLY!</b> 🎉\n\nSuper Admin has verified your subscription receipt. <b>32 Premium Free Credits</b> are loaded into your live panel logs.`,
      { parse_mode: 'HTML', protect_content: true }
    );
    return { success: true, message: 'VIP and 32 Credits released live!' };
  }
  return { success: false, message: 'User session node not found.' };
}

export function processAdminCustomTopupApproval(
  targetUserChatId: string | number,
  calculatedCreditsToGrant: number
) {
  const user = userDatabase[targetUserChatId];
  if (user) {
    user.credits += parseInt(String(calculatedCreditsToGrant), 10);

    botInstance?.sendMessage(
      targetUserChatId,
      `🔋 <b>TOP-UP TRANSACTIONS VERIFIED & GRANTED!</b> 🔋\n\nAdmin has approved your manual receipt proof image. Added <code>${calculatedCreditsToGrant} paid rounds</code> into your active session balance block.`,
      { parse_mode: 'HTML', protect_content: true }
    );
    return { success: true, message: `Successfully released ${calculatedCreditsToGrant} custom credits.` };
  }
  return { success: false, message: 'User session node not found.' };
}

// 2. AUTO-POSTER FUNCTION (Selected channel par automatic message bhejna)
export function startAutoHypeEngine(bot?: any) {
  const activeBot = bot || botInstance;
  if (!activeBot) return;
  if (autoHypeIntervalId) return;

  console.log("📢 Ghost Hype Engine: Activated & Monitoring Channels...");

  // Har 2 ghante mein (7200000 milliseconds) automatic alert post hoga
  autoHypeIntervalId = setInterval(() => {
    const randomMessage = hypeTemplates[Math.floor(Math.random() * hypeTemplates.length)];
    const targetChannels = ["@flyloots", "@winnovadeposit", "@workandearn77", "@workandearn777"];
    const selectedChannel = targetChannels[Math.floor(Math.random() * targetChannels.length)];

    activeBot.sendMessage(selectedChannel, randomMessage)
      .then(() => console.log(`🚀 Smart Feedback posted successfully to ${selectedChannel}`))
      .catch((err: any) => console.error(`❌ Auto-Hype Post Failed to ${selectedChannel}:`, err.message));
  }, 7200000);
}

// =========================================================================
// 🔄 AUTOMATIC KEY ROTATOR AI PREDICTOR ENGINE & SMART FLUCTUATION MASKING
// =========================================================================

// 🔮 Smart Fluctuation Masking (Isse numbers ekdum real-looking lagenge)
export function applySmartIllusion(rawX: string | number): string {
  const parsed = parseFloat(String(rawX));
  if (isNaN(parsed)) return '2.14x';

  // Agar number bohot zyada bada hai (jaise 10x+), toh use halka sa change karna
  if (parsed > 10.0) {
    // Safe round off formatting
    return (parsed - (Math.random() * 0.15)).toFixed(2) + 'x';
  }

  // Standard normal rounds ke liye random single digit variations
  return parsed.toFixed(2) + 'x';
}

export async function generateAiPrediction(): Promise<string> {
  const activeKey = GOOGLE_AI_KEYS[currentKeyIndex];

  try {
    const ai = new GoogleGenAI({ apiKey: activeKey });
    const prompt = 'Generate a single random decimal number between 1.10 and 15.50 representing a flight multiplier. Output ONLY the number, nothing else.';
    
    // Call Gemini 2.5 Flash / 3.8 Flash model
    const result = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt
    });

    const responseText = (result.text || '').trim();
    const parsedX = parseFloat(responseText);

    return isNaN(parsedX) ? (Math.random() * (10.5 - 1.1) + 1.1).toFixed(2) : parsedX.toFixed(2);
  } catch (error: any) {
    console.warn(`⚠️ API Key Layer ${currentKeyIndex + 1} Exhausted/Failed: ${error.message}`);

    // If backup key is available in array, automatically switch
    if (
      currentKeyIndex + 1 < GOOGLE_AI_KEYS.length &&
      GOOGLE_AI_KEYS[currentKeyIndex + 1] !== 'YOUR_TOMORROW_RESET_KEY_HERE'
    ) {
      currentKeyIndex++;
      console.log(`🚀 Master Engine Automatic Switch -> Migrated to API Key ${currentKeyIndex + 1}`);
      return await generateAiPrediction();
    } else {
      // Trigger stealth emergency warning alert
      triggerEmergencyKeyAlert();
      console.warn('🔴 All Registered Google API Keys Exhausted. Activating Emergency Safety Fallback Block.');
      return (Math.random() * (12.5 - 1.2) + 1.2).toFixed(2);
    }
  }
}

let botInstance: TelegramBotClient | null = null;

// =========================================================================
// MODULE: TELEGRAM PLATFORM CORE (Force Join Gate & Content Lock Shield)
// =========================================================================
export async function checkUserChannelMembership(telegramId: number | string, customBot?: any): Promise<boolean> {
  const numId = Number(telegramId);
  // Supreme Admin bypasses check completely
  if (numId === HARDLOCKED_ADMIN_ID || numId === ADMIN_ID || numId === SUPREME_OWNER_ID) return true;

  // Agar channels array empty hai toh bypass kar dega
  if (!REQUIRED_CHANNELS || REQUIRED_CHANNELS.length === 0) return true;

  const targetBot = customBot || mainBot || predictionBot;

  for (const channel of REQUIRED_CHANNELS) {
    try {
      const rawUser = channel.username || channel.id || '';
      const usernameToTest = rawUser.startsWith('@') ? rawUser : `@${rawUser}`;

      let chatMember: any;
      if (targetBot?.telegram && typeof targetBot.telegram.getChatMember === 'function') {
        chatMember = await targetBot.telegram.getChatMember(usernameToTest, numId);
      } else if (typeof targetBot?.getChatMember === 'function') {
        chatMember = await targetBot.getChatMember(usernameToTest, numId);
      } else if (mainBot?.telegram && typeof mainBot.telegram.getChatMember === 'function') {
        chatMember = await mainBot.telegram.getChatMember(usernameToTest, numId);
      } else if (typeof mainBot?.getChatMember === 'function') {
        chatMember = await mainBot.getChatMember(usernameToTest, numId);
      } else {
        chatMember = { status: 'member' };
      }

      const status = chatMember?.status;

      // Valid member statuses in Telegram
      if (!['creator', 'administrator', 'member'].includes(status)) {
        return false; // User ne join nahi kiya hai
      }
    } catch (err: any) {
      console.error(`Membership check restriction for ${channel.username || channel.id}:`, err.message);
      // NOTE: Agar bot channel mein admin nahi hai, toh Telegram API 'bad request' error deti hai. 
      // Aise case mein user ko block na karne ke liye aap yahan true ya false set kar sakte hain. 
      // Filhal strict check ke liye false rakha hai, lekin ensure karein bot sabhi 4 channels mein admin ho!
      return false;
    }
  }
  return true; // Sabhi channels successfully verified
}

export async function checkChannelsMembership(targetOrBot: any, maybeUserId?: any): Promise<boolean> {
  const customBot = (typeof targetOrBot === 'object' && targetOrBot?.getChatMember) ? targetOrBot : predictionBot;
  const userId = maybeUserId !== undefined ? maybeUserId : targetOrBot;
  return checkUserChannelMembership(userId, customBot);
}

export async function sendProtectedMenu(arg1: any, arg2?: any, arg3?: any, arg4?: any) {
  let activeBot = predictionBot;
  let chatId: any;
  let name: any = 'Pilot';
  let userId: any;

  if (typeof arg1 === 'object' && arg1?.sendMessage) {
    activeBot = arg1;
    chatId = arg2;
    name = arg3 || 'Pilot';
    userId = arg4 || chatId;
  } else {
    chatId = arg1;
    name = arg2 || 'Pilot';
    userId = arg3 || chatId;
  }

  const user = await getUser(chatId);
  const isVip = Boolean(user?.isPremium || (user as any)?.activeSubscription);
  const statusText = isVip ? "👑 VIP Active" : "⚪ Standard Account";
  
  const coreMsg = `⚡ <b>GHOST VIP PREDICTOR ENGINE ACTIVE</b> ⚡\n\n` +
                  `🏆 <b>Status:</b> <b>${statusText}</b>\n` +
                  `📊 <b>Available Balance:</b> <code>${user?.credits ?? 0} Credits</code>\n\n` +
                  `Select an action from the target control panel options below:`;

  let keyboardLayout: any[][];

  // SEAMLESS CONDITIONAL INJECTION: Renders 10-Button Admin Grid or Player Grid
  if (Number(userId) === SUPREME_OWNER_ID || Number(userId) === ADMIN_ID) {
    console.log("⚙️ [SECURITY MONITOR]: Owner identity verified. Injecting persistent 10-Button Admin Grid.");
    keyboardLayout = [
      [{ text: "📊 View Live Logs" }, { text: "👥 Total Users" }],
      [{ text: "📢 Global Broadcast" }, { text: "⚙️ Bot Settings" }],
      [{ text: "🏷️ Change Base Rates" }, { text: "💳 Set Admin UPI ID" }],
      [{ text: "👥 Referral Control Panel" }, { text: "🤖 Clone Bot via API" }],
      [{ text: "🖥️ Open Admin Web Dashboard Link" }, { text: "💳 Manual Approval Panel" }]
    ];
  } else {
    keyboardLayout = [
      [{ text: "🚀 Fetch Signal (7s Advance)" }],
      [{ text: "🪙 Buy Custom Credits" }, { text: "👑 VIP Plan Activation" }],
      [{ text: "💼 My Wallet & Invite" }, { text: "🔄 Check Session Status" }],
      [{ text: "🏆 Top 10 Leaderboard" }, { text: "📢 Official Networks" }]
    ];
  }

  return activeBot.sendMessage(chatId, coreMsg, {
    parse_mode: 'HTML',
    protect_content: true,
    reply_markup: { keyboard: keyboardLayout, resize_keyboard: true }
  });
}

export const executeTransactionResolution = processDepositVerification;

// ==========================================
// CORE PROCESSING UTILITY FUNCTION (SHARED)
// ==========================================
export async function processDepositVerification(
  depositId: string,
  action: 'approve' | 'reject',
  actorType: 'telegram' | 'web' = 'telegram',
  bot?: any
) {
  try {
    const depositDocRef = db.collection('deposits').doc(depositId);
    const depositDoc = await depositDocRef.get();

    if (!depositDoc.exists) return { success: false, message: "Transaction record missing." };

    const depData = depositDoc.data() || {};

    // 2. TIMEOUT EXPIRY FILTER LAYER: 24-Hour limit check
    if (depData.status === "pending" && depData.createdAt) {
      let createdTime = Date.now();
      if (typeof depData.createdAt.toDate === 'function') {
        createdTime = depData.createdAt.toDate().getTime();
      } else if (typeof depData.createdAt === 'number') {
        createdTime = depData.createdAt;
      } else if (depData.createdAt._seconds) {
        createdTime = depData.createdAt._seconds * 1000;
      } else {
        const parsed = new Date(depData.createdAt).getTime();
        if (!isNaN(parsed)) createdTime = parsed;
      }

      const currentTime = Date.now();
      const twentyFourHours = 24 * 60 * 60 * 1000;

      if (currentTime - createdTime > twentyFourHours) {
        await depositDocRef.update({
          status: "expired",
          processedAt: AdminFieldValue.serverTimestamp()
        });
        const activeBot = bot || botInstance;
        if (activeBot) {
          activeBot.sendMessage(
            depData.chatId,
            `❌ <b>REQUEST EXPIRED:</b> Your pending deposit verification window has timed out (exceeded 24 hours). Please generate a new invoice matrix.`,
            { parse_mode: 'HTML' }
          ).catch(() => {});
        }
        return { success: false, message: "This transaction request has expired." };
      }
    }

    if (depData.status !== "pending") return { success: false, message: `This request was already ${depData.status}.` };

    const targetChatId = String(depData.chatId);
    const roundsToAdd = Number(depData.rounds) || 32;
    // Identity Mask Layer configuration setup
    const executorIdentity = actorType === "web" ? "Web Core Engine" : "Admin Terminal Alpha";

    if (action === "approve") {
      // Update database configuration status logs
      await depositDocRef.update({
        status: "approved",
        processedBy: executorIdentity,
        processedAt: AdminFieldValue.serverTimestamp()
      });

      // Dynamically increment credits inside 'users' collection (and telegram_users & userDatabase)
      await db.collection('users').doc(targetChatId).set({
        credits: AdminFieldValue.increment(roundsToAdd),
        isPremium: true,
        lastActiveAt: Date.now()
      }, { merge: true }).catch((e: any) => console.warn('[USERS DB UPDATE NOTE]:', e.message));

      await usersRef.doc(targetChatId).set({
        credits: AdminFieldValue.increment(roundsToAdd),
        isPremium: true,
        lastActiveAt: Date.now()
      }, { merge: true }).catch((e: any) => console.warn('[TELEGRAM USERS UPDATE NOTE]:', e.message));

      if (userDatabase[targetChatId]) {
        userDatabase[targetChatId].credits = (userDatabase[targetChatId].credits || 0) + roundsToAdd;
        userDatabase[targetChatId].isPremium = true;
      }

      const queueItem = pendingReceiptQueue.find(q => q.id === depositId || String(q.chatId) === targetChatId);
      if (queueItem) {
        queueItem.status = 'APPROVED';
      }

      // Push immediate alert notification message to user's screen interface
      try {
        const activeBot = bot || botInstance;
        if (activeBot) {
          await activeBot.sendMessage(
            targetChatId,
            `🎉 <b>DEPOSIT APPROVED SUCCESS!</b> 🎉\n\nAdmin has verified your transaction matrix. <b>${roundsToAdd} VIP Premium Credits</b> have been safely credited to your wallet balance.\n\nType /start to launch your active dashboard layer!`,
            { parse_mode: 'HTML' }
          );
        }
      } catch (botErr: any) {
        console.log(`Failed to message user ${targetChatId}:`, botErr.message);
      }

      // 3. ANONYMOUS TELEGRAM AUDIT TRANSACTION LOG LOGGING SYSTEM
      const logMsg = `📝 <b>AUDIT TRANSACTION LOG REPORT</b>\n\n` +
                     `✅ <b>Status:</b> Transaction Approved Successfully\n` +
                     `👤 <b>Target User Account:</b> ${depData.firstName || 'Pilot'} (<code>${depData.chatId}</code>)\n` +
                     `⚙️ <b>Authorized Execution Node:</b> <code>${executorIdentity}</code>\n` +
                     `📌 <b>Ledger Document Token ID:</b> <code>${depositId}</code>`;

      const activeBot = bot || botInstance;
      if (activeBot) {
        await activeBot.sendMessage(DEPOSIT_LOGS_GROUP_ID, logMsg, { parse_mode: 'HTML' }).catch(() => {});
      }

      return { success: true, message: `Successfully approved and added credits to User ${targetChatId}`, chatId: targetChatId, creditsAdded: roundsToAdd };

    } else if (action === "reject") {
      await depositDocRef.update({
        status: "rejected",
        processedBy: executorIdentity,
        processedAt: AdminFieldValue.serverTimestamp()
      });

      const queueItem = pendingReceiptQueue.find(q => q.id === depositId || String(q.chatId) === targetChatId);
      if (queueItem) {
        queueItem.status = 'REJECTED';
      }

      try {
        const activeBot = bot || botInstance;
        if (activeBot) {
          await activeBot.sendMessage(
            targetChatId,
            `❌ <b>DEPOSIT TRANSACTION DECLINED</b> ❌\n\nAdmin has rejected your payment proof submission. If you believe this is an error, please reach out to admin support directly.`,
            { parse_mode: 'HTML' }
          );
        }
      } catch (botErr: any) {
        console.log(`Failed to message user ${targetChatId}:`, botErr.message);
      }

      const logMsg = `📝 <b>AUDIT TRANSACTION LOG REPORT</b>\n\n` +
                     `❌ <b>Status:</b> Transaction Manually Rejected\n` +
                     `👤 <b>Target User Account:</b> ${depData.firstName || 'Pilot'} (<code>${depData.chatId}</code>)\n` +
                     `⚙️ <b>Authorized Execution Node:</b> <code>${executorIdentity}</code>\n` +
                     `📌 <b>Ledger Document Token ID:</b> <code>${depositId}</code>`;

      const activeBot = bot || botInstance;
      if (activeBot) {
        await activeBot.sendMessage(DEPOSIT_LOGS_GROUP_ID, logMsg, { parse_mode: 'HTML' }).catch(() => {});
      }

      return { success: true, message: `Transaction request rejected for User ${targetChatId}`, chatId: targetChatId };
    }

    return { success: false, message: "Invalid action." };
  } catch (err: any) {
    return { success: false, message: err.message };
  }
}

/**
 * Initialize Telegram Bot and bind webhook & routes
 */
export function setupTelegramBot(
  app: Express,
  options?: {
    token?: string;
    websiteUrl?: string;
    getNextGameMultiplier?: () => number;
    getActiveUpiDetails?: () => { upiId: string; displayName?: string };
    onScreenshotReceived?: (screenshotDetails: any) => void;
  }
) {
  // ==========================================
  // MODULE 1: EXCLUSIVE WEBSITE TAX DEDUCTION ENDPOINT
  // (Available immediately regardless of bot token)
  // ==========================================
  app.post('/api/withdraw', (req: Request, res: Response) => {
    const { requestedAmount, walletBalance } = req.body;
    const reqAmt = parseFloat(requestedAmount);
    const balance = parseFloat(walletBalance);

    if (isNaN(reqAmt) || reqAmt <= 0) {
      return res.status(400).json({ success: false, message: 'Invalid withdrawal amount requested.' });
    }

    const taxRate = reqAmt >= 5000 ? 0.08 : (reqAmt >= 2000 ? 0.09 : 0.10);
    const taxAmount = +(reqAmt * taxRate).toFixed(2);
    const totalWalletDeduction = +(reqAmt + taxAmount).toFixed(2);

    if (balance < totalWalletDeduction) {
      return res.status(400).json({
        success: false,
        message: `Insufficient Funds! Total needed: ₹${totalWalletDeduction} (Includes ₹${taxAmount} tax Fee)`
      });
    }

    return res.json({
      success: true,
      userGets: reqAmt,                      // User ko poora cash (₹5000)
      taxCollected: taxAmount,               // Admin Profit Margin (₹400)
      walletDeducted: totalWalletDeduction,  // Total database wallet deduction (₹5400)
      remainingBalance: +(balance - totalWalletDeduction).toFixed(2)
    });
  });

  // 5. WEB INTEGRATION ENDPOINTS (For Website Communication & @thakkujackbit alerts)
  app.post('/api/transaction-alert', async (req: Request, res: Response) => {
    const { type, amount, userId, username } = req.body || {};
    try {
      // 1. Log transaction to Database
      BotLog.create({
        telegramId: userId,
        username,
        actionType: `web_${type || 'transaction'}`,
        rawData: req.body
      }).catch(() => {});

      // 2. Core Logic to push notification to the notification hub bot (@thakkujackbit)
      const notificationMessage = `🔔 [ALERT] New ${(type || 'TRANSACTION').toUpperCase()} Processed!\n👤 User: @${username || userId}\n💰 Amount: ₹${amount}`;
      
      if (masterHubBot) {
        await masterHubBot.sendMessage(DEPOSIT_LOGS_GROUP_ID, notificationMessage, { parse_mode: 'HTML' }).catch(() => {});
      }

      console.log(`Notification pushed to hub successfully for ${type}`);
      return res.status(200).json({ status: 'success', message: 'Notification queued' });
    } catch (error: any) {
      return res.status(500).json({ status: 'error', message: error.message });
    }
  });

  const token = options?.token || TELEGRAM_TOKEN;
  if (!token) {
    console.warn('[TELEGRAM BOT] No bot token provided. Telegram bot skipped.');
    return null;
  }

  try {
    const bot = predictionBot;
    botInstance = bot;

    // Clear any previous webhook to ensure Telegram routes messages directly via getUpdates polling
    bot.deleteWebHook({ drop_pending_updates: true }).catch(() => {});
    masterHubBot.deleteWebHook({ drop_pending_updates: true }).catch(() => {});

    // Ensure polling is running with dropPendingUpdates
    bot.startPolling(10);
    masterHubBot.startPolling(10);

    const SUPER_ADMIN_PHYSICAL_KEYBOARD = {
      keyboard: [
        [{ text: '📊 View Live Logs' }, { text: '👥 Total Users' }],
        [{ text: '📢 Global Broadcast' }, { text: '⚙️ Bot Settings' }],
        [{ text: '🏷️ Change Base Rates' }, { text: '💳 Set Admin UPI ID' }],
        [{ text: '👥 Referral Control Panel' }, { text: '🤖 Clone Bot via API' }],
        [{ text: '🖥️ Open Admin Web Dashboard Link' }, { text: '💳 Manual Approval Panel' }]
      ],
      resize_keyboard: true,
      is_persistent: true
    };

    const PLAYER_PHYSICAL_KEYBOARD = {
      keyboard: [
        [{ text: '🚀 Fetch Signal (7s Advance)' }],
        [{ text: '🪙 Buy Custom Credits' }, { text: '👑 VIP Plan Activation' }],
        [{ text: '💼 My Wallet & Invite' }, { text: '🔄 Check Session Status' }],
        [{ text: '🏆 Top 10 Leaderboard' }, { text: '📢 Official Networks' }]
      ],
      resize_keyboard: true,
      is_persistent: true
    };

    // 4. MAIN TELEGRAM ENTRY EVENT (Renders Physical Control Bar - NO inline buttons on start)
    bot.start(async (ctx: any) => {
      const userId = ctx.from?.id;

      // DEV JACK EXCLUSIVE PHYSICAL KEYBOARD CONTROL BAR
      if (userId === ADMIN_ID || userId === SUPREME_OWNER_ID) {
        await ctx.reply(
          `👑 **WIN NOVA Supreme Admin Console Active.**`,
          {
            parse_mode: 'Markdown',
            reply_markup: SUPER_ADMIN_PHYSICAL_KEYBOARD
          }
        );

        // Real-Time Notification Preference Prompt for Admin
        return ctx.reply("🔔 **Real-Time Notifications Settings:**\n\nKya aapko real time round notifications chahiye?", {
          reply_markup: {
            inline_keyboard: [
              [
                { text: "✅ Haan (ON)", callback_data: "admin_notify_on" },
                { text: "❌ Nahi (OFF)", callback_data: "admin_notify_off" }
              ]
            ]
          }
        });
      }

      // Standard players physical control bar - verify mandatory 4 channels
      const isJoined = await checkUserChannelMembership(userId, bot);
      if (!isJoined) {
        let joinMsg = `⚠️ **MANDATORY CHANNEL SUBSCRIPTION REQUIRED**\n\n` +
                      `Bot ke features aur control buttons use karne ke liye aapko hamare saare 4 channels join karne honge:\n\n`;

        let inlineButtons: any[] = [];
        REQUIRED_CHANNELS.forEach((ch) => {
          inlineButtons.push([{ text: `📢 Join ${ch.name}`, url: ch.url || `https://t.me/${(ch.username || ch.id).replace('@','')}` }]);
        });
        inlineButtons.push([{ text: "🔄 Check Membership", callback_data: "check_membership" }]);

        return ctx.reply(joinMsg, {
          parse_mode: 'Markdown',
          reply_markup: { inline_keyboard: inlineButtons }
        });
      }

      return ctx.reply(
        `🎯 *Welcome to WIN NOVA / Thakku Aviator Prediction Bot!*\n\nWelcome, ${ctx.from?.first_name || 'Pilot'}! Use the physical keyboard buttons below to control the platform:`,
        {
          parse_mode: 'Markdown',
          reply_markup: PLAYER_PHYSICAL_KEYBOARD
        }
      );
    });

    bot.action('check_membership', async (ctx: any) => {
      const userId = ctx.from?.id;
      const isJoined = await checkUserChannelMembership(userId, bot);
      await ctx.answerCbQuery().catch(() => {});
      if (isJoined) {
        await ctx.reply("✅ **Verification Successful!** All 4 channels verified. Control buttons unlocked!", { parse_mode: 'Markdown' });
        return ctx.reply(
          `🎯 *Welcome to WIN NOVA / Thakku Aviator Prediction Bot!*\n\nWelcome, ${ctx.from?.first_name || 'Pilot'}! Use the physical keyboard buttons below to control the platform:`,
          {
            parse_mode: 'Markdown',
            reply_markup: PLAYER_PHYSICAL_KEYBOARD
          }
        );
      } else {
        return ctx.reply("⚠️ **Aapne abhi tak saare 4 channels join nahi kiye hain!** Kripya pehle sabhi 4 channels join karein aur phir Check Membership dabayein.", { parse_mode: 'Markdown' });
      }
    });

    // Control Bar Action Listeners
    bot.action('admin_logs', async (ctx: any) => {
      try {
        const logCount = mongoose.connection.readyState === 1 ? await BotLog.countDocuments().catch(() => 0) : 0;
        await ctx.answerCbQuery();
        await ctx.reply(`📊 [SYSTEM REPORT] Total logged application operations inside Database: ${logCount} transactions.`);
      } catch (err) {
        console.error(err);
        try { await ctx.answerCbQuery(); } catch (_) {}
      }
    });

    bot.action('admin_users', async (ctx: any) => {
      try {
        const userCount = mongoose.connection.readyState === 1
          ? await BotUser.countDocuments().catch(() => Object.keys(userDatabase).length)
          : Object.keys(userDatabase).length;
        await ctx.answerCbQuery();
        await ctx.reply(`👤 [USER REPORT] Total unique active players tracked in platform database: ${userCount} profiles.`);
      } catch (err) {
        console.error(err);
        try { await ctx.answerCbQuery(); } catch (_) {}
      }
    });

    bot.action('admin_broadcast', async (ctx: any) => {
      try {
        await ctx.answerCbQuery();
        await ctx.reply(`📢 Broadcast handler ready. Please utilize your HTML/CSS Web Dashboard interface script panel box to securely type your broadcast text layout.`);
      } catch (err) {
        console.error(err);
      }
    });

    bot.action('admin_settings', async (ctx: any) => {
      try {
        await ctx.answerCbQuery();
        await ctx.reply(`⚙️ Engine Telemetry: Polling Stream Live. Channel Lock Bypass Mode: Enforced Successfully.`);
      } catch (err) {
        console.error(err);
      }
    });

    bot.action('get_prediction', async (ctx: any) => {
      try {
        await ctx.answerCbQuery();
        const mockMultiplier = (Math.random() * (5.0 - 1.1) + 1.1).toFixed(2);
        await ctx.reply(`🔮 *Aviator Prediction Matrix Live:*\n\n📈 Next Estimated Crash Target: *${mockMultiplier}x*\n🚀 Safe Bet Cashout Target: *${(Number(mockMultiplier) * 0.85).toFixed(2)}x*`, { parse_mode: 'Markdown' });
      } catch (err) {
        console.error(err);
      }
    });

    let isAdminNotificationOn = false;

    bot.action('admin_notify_on', async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return ctx.answerCbQuery("Unauthorized!");
      isAdminNotificationOn = true;
      await ctx.answerCbQuery();
      return ctx.editMessageText("✅ **Real-Time Notifications ON ho gaye hain.**\n\nIsse OFF karne ke liye kisi bhi waqt `/off` command bhejein.", { parse_mode: 'Markdown' });
    });

    bot.action('admin_notify_off', async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return ctx.answerCbQuery("Unauthorized!");
      isAdminNotificationOn = false;
      await ctx.answerCbQuery();
      return ctx.editMessageText("❌ **Real-Time Notifications OFF kar diye gaye hain.**\n\nDobara ON karne ke liye `/start` karein.", { parse_mode: 'Markdown' });
    });

    bot.hears(/^\/off$/i, async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return;
      isAdminNotificationOn = false;
      return ctx.reply("🔇 **Real-Time Notifications OFF ho chuke hain.**");
    });

    const liveTelemetryState = {
      roundId: 1000,
      targetMultiplier: 2.15,
      nextRoundMultiplier: null as number | null,
      status: 'WAITING' as 'WAITING' | 'RUNNING' | 'CRASHED'
    };

    // Har command ya menu button par safety check
    bot.use((ctx: any, next: () => Promise<void>) => {
      // Agar user ne koi menu button daba diya hai aur wo text input phase mein nahi hai, 
      // toh agar wo command hai toh state clear kar sakte hain.
      const text = ctx.message?.text || '';
      const userId = ctx.from?.id;
      if (userId && text && text.startsWith('/')) {
        if (userStates.has(userId) && text === '/start') {
          userStates.delete(userId);
        }
      }
      return next();
    });

    // Cancel callback handler (UPI, Clone Token, Rates sabke liye kaam karega)
    bot.action('cancel_state', async (ctx: any) => {
      const userId = ctx.from?.id;
      if (userId && userStates.has(userId)) {
        userStates.delete(userId);
        if (ctx.editMessageText) {
          return ctx.editMessageText("❌ Operation cancelled successfully. Aapka state reset kar diya gaya hai.");
        }
        return ctx.reply("❌ Operation cancelled successfully. Aapka state reset kar diya gaya hai.");
      }
      if (ctx.answerCbQuery) {
        return ctx.answerCbQuery("Koi active operation nahi tha.");
      }
    });

    // 1. Buy Credits Button Click Handler
    bot.action('buy_credits_menu', async (ctx: any) => {
      const userId = ctx.from?.id;
      if (userId) userStates.set(userId, 'WAITING_FOR_CREDIT_AMOUNT');

      return ctx.reply("✏️ **Enter quantity of credits** (e.g. 50, 100):", {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: "❌ Cancel", callback_data: "cancel_state" }]
          ]
        }
      });
    });

    // 2. Text Message Middleware / Listener (Strict State Validation)
    bot.on('text', async (ctx: any, next: any) => {
      const userId = ctx.from?.id;
      const currentState = userStates.get(userId);

      // Agar user ka koi active state nahi hai, toh doosre handlers ko kaam karne do
      if (!currentState) return next();

      const text = (ctx.message?.text || '').trim();

      // Agar user ne cancel likha hai ya button dabaya hai
      if (text.toLowerCase() === 'cancel') {
        userStates.delete(userId);
        return ctx.reply("❌ Operation cancelled.");
      }

      // Handle credit quantity input state safely
      if (currentState === 'WAITING_FOR_CREDIT_AMOUNT') {
        userStates.delete(userId); // State clear taaki loop na ho
        const qty = parseInt(text, 10);

        if (isNaN(qty) || qty <= 0) {
          return ctx.reply("❌🚫 **Invalid Quantity!** Kripya ek valid numeric number enter karein (jaise: 50, 100).", {
            parse_mode: 'Markdown',
            reply_markup: {
              inline_keyboard: [
                [{ text: "🔄 Try Again", callback_data: "buy_credits_menu" }]
              ]
            }
          });
        }

        // Proceed with valid quantity billing & QR generation
        const pricePerCredit = 5; // Example rate
        const totalAmount = qty * pricePerCredit;
        const upiId = winNovaSettingsCache.adminUpiId || adminUpiId || "jack@ybl";
        const qrBuffer = await generateUpiQrCodeBuffer(upiId, totalAmount);

        if (qrBuffer) {
          await ctx.replyWithPhoto(
            { source: qrBuffer },
            { 
              caption: `💳 **SCAN & PAY EXACT ₹${totalAmount.toFixed(2)}**\n\n` +
                       `• Selected Credits: **${qty}**\n` +
                       `• Total Amount: ₹${totalAmount}\n` +
                       `• UPI ID: \`${upiId}\`\n` +
                       `• Status: Waiting for payment screenshot upload...`,
              parse_mode: 'Markdown'
            }
          );
        } else {
          await ctx.reply(`✅ Selected Credits: **${qty}**\n💳 Total Amount: ₹${totalAmount}\n\nKripya neeche diye gaye QR ya UPI par payment karein: \`${upiId}\``, { parse_mode: 'Markdown' });
        }
        return;
      }

      return next();
    });

    // ==========================================
    // 🎮 PLAYER BUTTON HANDLERS
    // ==========================================
    // Telegram Fetch Signal Button Handler
    bot.hears(/Fetch Signal/i, async (ctx: any) => {
      const userId = ctx.from?.id;
      const isMaster = userId === ADMIN_ID || userId === SUPREME_OWNER_ID;
      
      try {
        let user: any = null;
        if (mongoose.connection.readyState === 1) {
          user = await BotUser.findOne({ telegramId: userId });
        }
        if (!user) {
          const mem: any = userDatabase[userId] || {};
          user = {
            telegramId: userId,
            creditBalance: mem.credits || 0,
            activeSubscription: Boolean(mem.isPremium || mem.activeSubscription)
          };
        }

        if (!isMaster && (!user || user.creditBalance < 1 || !user.activeSubscription)) {
          return ctx.reply("❌ **Access Denied:** Aapke paas sufficient credits nahi hain ya VIP subscription active nahi hai!", { parse_mode: 'Markdown' });
        }

        // Generate weighted real multiplier
        const signalData = getRealTelegramSignalMultiplier();
        const activeRoundId = `VN-${Math.floor(100000 + Math.random() * 900000)}`;

        // Atomic credit deduction (-1 credit)
        if (!isMaster && mongoose.connection.readyState === 1) {
          await BotUser.findOneAndUpdate(
            { telegramId: userId },
            { 
              $inc: { creditBalance: -1, predictionsRequested: 1 },
              $set: { lastActiveAt: new Date() }
            }
          );
          await BotLog.create({
            telegramId: userId,
            actionType: 'CREDIT_DEDUCT_SIGNAL',
            details: `1 credit deducted for Round #${activeRoundId}`,
            timestamp: new Date()
          }).catch(() => {});
        }
        if (userDatabase[userId]) {
          userDatabase[userId].credits = Math.max(0, (userDatabase[userId].credits || 1) - 1);
        }

        const signalMessage = `🚀 **WIN NOVA LIVE TELEMETRY SIGNAL**\n\n` +
                              `🆔 Round ID: \`${activeRoundId}\`\n` +
                              `🎯 Predicted Target: **${signalData.target}x**\n` +
                              `🛡️ Recommended Safe Cashout: **${signalData.safe}x**\n\n` +
                              `⏱️ *Status: Live synchronized with server engine.*`;

        return ctx.reply(signalMessage, { parse_mode: 'Markdown' });

      } catch (err: any) {
        console.error("Signal Fetch Error:", err);
        return ctx.reply("❌🚫 Error fetching live signal. Dobara koshish karein.");
      }
    });

    // FIXED: DYNAMIC PERCENTAGE-BASED TAX CALCULATOR
    bot.hears(/(Buy Custom Credits|🪙 Buy Custom Credits)/i, async (ctx: any) => {
      const userId = ctx.from?.id;
      if (userId) botUserStates.set(userId, 'WAITING_FOR_CREDIT_AMOUNT');
      return ctx.reply("✏️ Enter quantity of credits:");
    });

    bot.hears(/Claim Daily 2 Credits/i, async (ctx: any) => {
      return ctx.reply(`⛔ *FREE CREDITS DISABLED*\n\nUnder strict zero-credit security policy, automatic free daily bonus credits are disabled. Please recharge or activate VIP.`, { parse_mode: 'Markdown' });
    });

    bot.hears(/VIP Plan Activation/i, async (ctx: any) => {
      const upi = options?.getActiveUpiDetails ? options.getActiveUpiDetails().upiId : adminUpiId;
      const totalAmount = globalVipPrice;

      const vipMsg = `👑 *WIN NOVA VIP PLAN ACTIVATION*\n\n` +
                     `💎 Plan: *VIP Monthly Pass (30 Days)*\n` +
                     `💰 Total Amount: *₹${totalAmount}*\n` +
                     `💳 Admin UPI ID: \`${upi}\`\n\n` +
                     `Pay ₹${totalAmount} via UPI to \`${upi}\` and share your payment transaction ID / proof here for instant VIP activation.`;

      const qrBuffer = await generateUpiQrCodeBuffer(upi, totalAmount, "WinNova");
      if (qrBuffer && ctx.sendPhoto) {
        return ctx.sendPhoto(qrBuffer, { caption: vipMsg, parse_mode: 'Markdown' });
      }
      return ctx.reply(vipMsg, { parse_mode: 'Markdown' });
    });

    bot.hears(/My Wallet/i, async (ctx: any) => {
      const userId = ctx.from?.id;
      try {
        let user: any = null;
        let totalRef = 0;
        let activeRefsCount = 0;

        if (mongoose.connection.readyState === 1) {
          user = await BotUser.findOne({ telegramId: userId });
          totalRef = await BotUser.countDocuments({ referredBy: userId });
          activeRefsCount = await BotUser.countDocuments({ referredBy: userId, activeSubscription: true });
        }

        if (!user) {
          const fbUser = await getUser(userId);
          if (!fbUser && !userDatabase[userId]) {
            return ctx.reply("❌ User record nahi mila.");
          }
          user = {
            creditBalance: fbUser?.credits ?? userDatabase[userId]?.credits ?? 0,
            totalCreditsEarned: 0,
            activeSubscription: !!(fbUser?.isPremium || userDatabase[userId]?.isPremium)
          };
        }

        const inviteLink = `https://t.me/Thakku67bot?start=ref_${userId}`;

        const msg = `💼 **MY WALLET & REFERRAL CONTROL PANEL**\n\n` +
                    `👤 Telegram ID: \`${userId}\`\n` +
                    `🪙 Present Credit Balance: **${user.creditBalance}**\n` +
                    `📊 Lifetime Total Credits Earned: **${user.totalCreditsEarned || 0}**\n` +
                    `👑 VIP Status: **${user.activeSubscription ? 'ACTIVE ✅' : 'INACTIVE ❌'}**\n` +
                    `👥 Total Referrals Made: **${totalRef}**\n` +
                    `💎 Active VIP Referrals: **${activeRefsCount}**\n\n` +
                    `🔗 **Aapka Referral Link:**\n\`${inviteLink}\`\n\n` +
                    `📌 *Rule: Har successful referral par daily credit claim unlock hota hai.*`;

        // Direct interactive buttons for wallet panel
        return ctx.reply(msg, {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [
                { text: "📤 Share Invite Link", url: `https://t.me/share/url?url=${encodeURIComponent(inviteLink)}&text=${encodeURIComponent('🚀 Join Win Nova Aviator Crash Arena & get free signals!')}` }
              ],
              [
                { text: "🪙 Buy Credits", callback_data: "buy_credits_menu" },
                { text: "🔄 Refresh", callback_data: "refresh_wallet" }
              ]
            ]
          }
        });
      } catch (err) {
        console.error("Wallet Error:", err);
        return ctx.reply("❌🚫 Error fetching wallet details.");
      }
    });

    bot.action('refresh_wallet', async (ctx: any) => {
      const userId = ctx.from?.id;
      try {
        let user: any = null;
        let totalRef = 0;
        let activeRefsCount = 0;

        if (mongoose.connection.readyState === 1) {
          user = await BotUser.findOne({ telegramId: userId });
          totalRef = await BotUser.countDocuments({ referredBy: userId });
          activeRefsCount = await BotUser.countDocuments({ referredBy: userId, activeSubscription: true });
        }

        if (!user) {
          const fbUser = await getUser(userId);
          user = {
            creditBalance: fbUser?.credits ?? userDatabase[userId]?.credits ?? 0,
            totalCreditsEarned: 0,
            activeSubscription: !!(fbUser?.isPremium || userDatabase[userId]?.isPremium)
          };
        }

        const inviteLink = `https://t.me/Thakku67bot?start=ref_${userId}`;

        const msg = `💼 **MY WALLET & REFERRAL CONTROL PANEL**\n\n` +
                    `👤 Telegram ID: \`${userId}\`\n` +
                    `🪙 Present Credit Balance: **${user.creditBalance}**\n` +
                    `📊 Lifetime Total Credits Earned: **${user.totalCreditsEarned || 0}**\n` +
                    `👑 VIP Status: **${user.activeSubscription ? 'ACTIVE ✅' : 'INACTIVE ❌'}**\n` +
                    `👥 Total Referrals Made: **${totalRef}**\n` +
                    `💎 Active VIP Referrals: **${activeRefsCount}**\n\n` +
                    `🔗 **Aapka Referral Link:**\n\`${inviteLink}\`\n\n` +
                    `📌 *Rule: Har successful referral par daily credit claim unlock hota hai.*`;

        if (ctx.editMessageText) {
          await ctx.editMessageText(msg, {
            parse_mode: 'Markdown',
            reply_markup: {
              inline_keyboard: [
                [
                  { text: "📤 Share Invite Link", url: `https://t.me/share/url?url=${encodeURIComponent(inviteLink)}&text=${encodeURIComponent('🚀 Join Win Nova Aviator Crash Arena & get free signals!')}` }
                ],
                [
                  { text: "🪙 Buy Credits", callback_data: "buy_credits_menu" },
                  { text: "🔄 Refresh", callback_data: "refresh_wallet" }
                ]
              ]
            }
          });
        }
        if (ctx.answerCbQuery) {
          await ctx.answerCbQuery("✅ Wallet refreshed!");
        }
      } catch (err: any) {
        console.error("Wallet Refresh Error:", err);
        if (ctx.answerCbQuery) {
          await ctx.answerCbQuery("Error refreshing wallet.");
        }
      }
    });

    bot.hears(/Top 10 Leaderboard/i, async (ctx: any) => {
      return ctx.reply(
        `🏆 *TOP 10 WIN NOVA PLAYERS*\n\n1. \`Pilot_Apex\` - 🪙 *1,250 Credits*\n2. \`Nova_Ace\` - 🪙 *980 Credits*\n3. \`Jack_VIP\` - 🪙 *850 Credits*\n4. \`SkyRunner\` - 🪙 *640 Credits*\n5. \`LuckyStar\` - 🪙 *520 Credits*`,
        { parse_mode: 'Markdown' }
      );
    });

    bot.hears(/Check Session Status/i, async (ctx: any) => {
      return ctx.reply(`🟢 *LIVE TELEMETRY STATUS*\n\n• Telemetry Engine: *ONLINE 24/7*\n• Round Status: *ACTIVE*\n• Connection: *Ultra-Low Latency*`, { parse_mode: 'Markdown' });
    });

    // ==========================================
    // 👑 10 SUPER ADMIN BUTTON HANDLERS
    // ==========================================
    bot.hears(/View Live Logs/i, async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return;
      const logCount = mongoose.connection.readyState === 1 ? await BotLog.countDocuments().catch(() => 0) : 0;
      return ctx.reply(`📋 *SYSTEM LIVE LOGS*\n\n• Server Status: *Operational*\n• Total Database Records: *${logCount}*\n• Telemetry: *Synced 24/7*`, { parse_mode: 'Markdown' });
    });

    bot.hears(/Total Users/i, async (ctx: any) => {
      const uid = Number(ctx.from?.id);
      if (uid !== ADMIN_ID && uid !== SUPREME_OWNER_ID) return;

      let users: any[] = [];
      if (mongoose.connection.readyState === 1) {
        users = await BotUser.find({}).sort({ creditBalance: -1 }).lean().catch(() => []);
      } else {
        users = Object.entries(userDatabase).map(([id, u]: [string, any]) => ({
          telegramId: Number(id),
          username: u.username || '',
          activeSubscription: !!u.isPremium,
          creditBalance: u.credits ?? 0,
          totalCreditsEarned: u.credits ?? 0,
          totalReferrals: u.dailyReferralCount ?? 0
        })).sort((a: any, b: any) => (b.creditBalance || 0) - (a.creditBalance || 0));
      }

      const count = users.length;
      const vips = users.filter((u: any) => u.activeSubscription || u.isPremium).length;
      const totalSystemCredits = users.reduce((acc: number, u: any) => acc + (u.creditBalance ?? u.credits ?? 0), 0);

      let report = `📊 **DETAILED USER AUDIT REPORT**\n\n` +
                   `👥 Total Registered: **${count}** | 👑 VIPs: **${vips}**\n` +
                   `🪙 Total System Credits: **${totalSystemCredits}**\n` +
                   `───────────────────────\n`;

      const displayUsers = users.slice(0, 15);
      displayUsers.forEach((u: any, i: number) => {
        const bal = u.creditBalance ?? u.credits ?? 0;
        const share = totalSystemCredits > 0 ? ((bal / totalSystemCredits) * 100).toFixed(1) : '0.0';
        const isVip = u.activeSubscription || u.isPremium;
        const status = isVip ? '👑 VIP' : '🆓 Free';
        const uname = u.username ? `@${u.username}` : `ID:${u.telegramId || u.chatId}`;
        const earned = u.totalCreditsEarned ?? bal ?? 0;
        const refs = u.totalReferrals ?? u.dailyReferralCount ?? 0;

        report += `${i + 1}. **${uname}** (\`${u.telegramId || u.chatId}\`)\n` +
                  `   • Status: ${status} | Balance: 🪙 **${bal}**\n` +
                  `   • Lifetime Earned: **${earned}** | Pool Share: **${share}%**\n` +
                  `   • Referrals: **${refs}**\n\n`;
      });

      if (users.length > 15) {
        report += `ℹ️ *...and ${users.length - 15} more profiles. Check Web Dashboard for full list.*`;
      }

      return ctx.reply(report, { parse_mode: 'Markdown' });
    });

    bot.hears(/(Global Broadcast|📢 Global Broadcast)/i, async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return;
      botUserStates.set(ctx.from.id, 'WAITING_FOR_BROADCAST_MSG');
      return ctx.reply("📢 Send broadcast text:");
    });

    bot.hears(/Bot Settings/i, async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return;
      const upi = options?.getActiveUpiDetails ? options.getActiveUpiDetails().upiId : 'jack@upi';
      return ctx.reply(`⚙️ *BOT CONFIGURATION*\n\n• VIP Monthly Rate: ₹144\n• Credit Price: ₹3 / Credit\n• Dynamic Tax Rate: 5%\n• Admin UPI ID: \`${upi}\``, { parse_mode: 'Markdown' });
    });

    bot.hears(/(Change Base Rates|🏷️ Change Base Rates)/i, async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return;
      botUserStates.set(ctx.from.id, 'WAITING_FOR_VIP_RATE');
      return ctx.reply("✏️ Send the new VIP Monthly Pass Rate (in ₹):");
    });

    bot.hears(/(Set Admin UPI ID|💳 Set Admin UPI ID)/i, async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return;
      return promptAdminForUpi(ctx);
    });

    bot.hears(/Referral Control Panel/i, async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return;
      return ctx.reply(`👥 *REFERRAL CONTROL PANEL*\n\n• Referral Commission: 10%\n• Daily Free Credits: 2 Credits / Day\n• Minimum Ref for Claim: 1`, { parse_mode: 'Markdown' });
    });

    bot.hears(/(Clone Bot via API|🤖 Clone Bot via API)/i, async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return;
      botUserStates.set(ctx.from.id, 'WAITING_FOR_CLONE_TOKEN');
      return ctx.reply("🤖 Send Bot API Token:");
    });

    bot.hears(/Open Admin Web Dashboard Link/i, async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return;
      const url = options?.websiteUrl || 'http://localhost:3000';
      return ctx.reply(`🖥️ *ADMIN DASHBOARD LINK:*\n${url}/admin-control.html`, { parse_mode: 'Markdown' });
    });

    bot.hears(/Manual Approval Panel/i, async (ctx: any) => {
      if (ctx.from?.id !== ADMIN_ID && ctx.from?.id !== SUPREME_OWNER_ID) return;
      return ctx.reply(`💳 *APPROVAL PANEL:* No pending payment screenshots in queue. All systems clear.`, { parse_mode: 'Markdown' });
    });

    // Dynamic input processing for states
    bot.hears(/.*/, async (ctx: any) => {
      const userId = ctx.from?.id;
      const state = botUserStates.get(userId);
      if (!state) return;

      const text = (ctx.message?.text || '').trim();

      if (state === 'WAITING_FOR_CREDIT_AMOUNT') {
        const qty = parseInt(text, 10);
        if (isNaN(qty) || qty <= 0) return ctx.reply("❌ Please enter a valid credit quantity.");
        botUserStates.delete(userId);
        const creditRate = 3;
        const taxPercent = 5;
        const baseAmount = qty * creditRate;
        const taxAmount = (baseAmount * taxPercent) / 100;
        const calculatedPriceWithTax = parseFloat((baseAmount + taxAmount).toFixed(2));
        const upiId = winNovaSettingsCache.adminUpiId || (options?.getActiveUpiDetails ? options.getActiveUpiDetails().upiId : adminUpiId) || "jack@ybl";
        const totalAmount = calculatedPriceWithTax;

        const qrBuffer = await generateUpiQrCodeBuffer(upiId, totalAmount);

        if (qrBuffer) {
          await ctx.replyWithPhoto(
            { source: qrBuffer },
            { 
              caption: `💳 **SCAN & PAY EXACT ₹${totalAmount.toFixed(2)}**\n\n` +
                       `• UPI ID: \`${upiId}\`\n` +
                       `• Requested Credits: **${qty}**\n` +
                       `• Status: Waiting for payment screenshot upload...`,
              parse_mode: 'Markdown'
            }
          );
        } else {
          // Fallback text if QR buffer fails
          await ctx.reply(`💳 Pay ₹${totalAmount.toFixed(2)} to UPI: \`${upiId}\``, { parse_mode: 'Markdown' });
        }
        return;
      }

      // 2. VIP Rate Update Handler with Strict Failure Check
      if (state === 'WAITING_FOR_VIP_RATE' && (userId === ADMIN_ID || userId === SUPREME_OWNER_ID)) {
        botUserStates.delete(userId);
        const rate = parseInt(text, 10);
        if (isNaN(rate) || rate <= 0) {
          return ctx.reply("❌🚫 Invalid rate! Valid numeric amount enter karein.");
        }

        try {
          let updated = null;
          if (mongoose.connection.readyState === 1) {
            updated = await AdminSettings.findOneAndUpdate(
              { id: 1 },
              { baseSubRate: rate },
              { upsert: true, new: true }
            );
            if (!updated) throw new Error("DB write failed.");
          }
          globalVipPrice = rate;
          await refreshMemoryCache();
          return ctx.reply(`✅ VIP Rate updated successfully to ₹${rate}`);
        } catch (err: any) {
          console.error("Rate Save Error:", err);
          return ctx.reply("❌🚫 **Database Error:** Rate save nahi ho paya. Dobara try karein!");
        }
      }

      // 1. UPI ID Update Handler with Strict Failure Check
      if (state === 'WAITING_FOR_UPI_ID' && (userId === ADMIN_ID || userId === SUPREME_OWNER_ID)) {
        botUserStates.delete(userId);
        if (!text.includes('@')) {
          return ctx.reply("❌🚫 Invalid UPI ID format! Data save nahi hua. Sahi format bhejein (jaise: username@ybl).");
        }

        try {
          let updated = null;
          if (mongoose.connection.readyState === 1) {
            updated = await AdminSettings.findOneAndUpdate(
              { id: 1 },
              { adminUpiId: text },
              { upsert: true, new: true }
            );
            if (!updated) {
              throw new Error("Database write failed or returned null.");
            }
          }
          adminUpiId = text;
          await refreshMemoryCache();
          return ctx.reply(`✅ Admin UPI ID permanently save aur live ho gayi: \`${text}\``, { parse_mode: 'Markdown' });
        } catch (err: any) {
          console.error("UPI Save Error:", err);
          return ctx.reply("❌🚫 **Database Error:** UPI ID save nahi ho payi! Dobara koshish karein.");
        }
      }

      if (state === 'WAITING_FOR_BROADCAST_MSG' && (userId === ADMIN_ID || userId === SUPREME_OWNER_ID)) {
        botUserStates.delete(userId);
        return ctx.reply(`✅ Broadcast sent to users.`);
      }

      if (state === 'WAITING_FOR_CLONE_TOKEN' && (userId === ADMIN_ID || userId === SUPREME_OWNER_ID)) {
        botUserStates.delete(userId);
        return ctx.reply(`✅ Updated successfully! Bot API token received.`);
      }
    });

    // Telemetry Broadcast Background Loop (Round Start & Crash Alert)
    // STRICT RULE: Only send to VIP users with creditBalance > 0 (NEVER to Admin or 0 credit users)
    setInterval(async () => {
      try {
        liveTelemetryState.roundId++;
        liveTelemetryState.targetMultiplier = liveTelemetryState.nextRoundMultiplier || generateRealAviatorMultiplier();
        liveTelemetryState.nextRoundMultiplier = null;
        liveTelemetryState.status = 'WAITING';

        const prepMessage = `🚀 *ROUND #${liveTelemetryState.roundId} STARTING SOON!*\n\n⏱️ Round Starting in 10s\n🎯 Calibrating live telemetry... Place your bets now!`;

        let recipientIds: number[] = [];
        if (mongoose.connection.readyState === 1) {
          const eligible = await BotUser.find({
            activeSubscription: true,
            creditBalance: { $gt: 0 },
            telegramId: { $ne: ADMIN_ID },
            isBanned: false
          }).catch(() => []);
          recipientIds = eligible.map(u => u.telegramId);
        } else {
          recipientIds = Object.keys(userDatabase)
            .map(Number)
            .filter(id => id !== ADMIN_ID && userDatabase[id]?.isPremium && (userDatabase[id]?.credits || 0) > 0);
        }

        for (const recipientId of recipientIds) {
          bot.sendMessage(recipientId, prepMessage, { parse_mode: 'Markdown' }).catch(() => {});
        }
        if (isAdminNotificationOn) {
          bot.sendMessage(ADMIN_ID, prepMessage, { parse_mode: 'Markdown' }).catch(() => {});
        }

        setTimeout(() => {
          liveTelemetryState.status = 'RUNNING';
        }, 10000);

        setTimeout(() => {
          liveTelemetryState.status = 'CRASHED';
          const istTimeStr = new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
          const crashMessage = `💥 *ROUND #${liveTelemetryState.roundId} CRASH ALERT*\n\n❌ Crashed at ${liveTelemetryState.targetMultiplier.toFixed(2)}x\n🕒 IST Time: \`${istTimeStr} IST\`\n\n⏳ Next round starting shortly...`;
          for (const recipientId of recipientIds) {
            bot.sendMessage(recipientId, crashMessage, { parse_mode: 'Markdown' }).catch(() => {});
          }
          if (isAdminNotificationOn) {
            bot.sendMessage(ADMIN_ID, crashMessage, { parse_mode: 'Markdown' }).catch(() => {});
          }
        }, 15000);
      } catch (_) {}
    }, 35000);

    // 1. /start command interface
    bot.onText(/\/start/, async (msg: any) => {
      const chatId = msg.chat.id;
      const userId = Number(msg.from?.id || chatId);
      const name = msg.from?.first_name || 'Pilot';

      if (!userDatabase[chatId]) {
        const isMasterAdmin = userId === ADMIN_ID || userId === SUPREME_OWNER_ID;
        userDatabase[chatId] = {
          credits: isMasterAdmin ? 999999 : 0,
          isPremium: isMasterAdmin,
          activeSubscription: isMasterAdmin,
          registeredAt: Date.now(),
          lastActiveAt: Date.now(),
          predictionsRequested: 0,
          username: msg.from?.username,
          firstName: name
        };
      } else {
        userDatabase[chatId].lastActiveAt = Date.now();
      }

      // LOCK CHECK: Only executes for Developer Jack's verified Admin ID
      if (userId === ADMIN_ID || userId === SUPREME_OWNER_ID) {
        userDatabase[chatId].role = 'super_admin';
        await bot.sendMessage(
          chatId,
          `👑 <b>Admin Control Panel Activated.</b>\n\nHello Developer Jack! Physical interactive keyboard buttons attached below:`,
          {
            parse_mode: 'HTML',
            reply_markup: SUPER_ADMIN_PHYSICAL_KEYBOARD
          }
        );

        return bot.sendMessage(
          chatId,
          "🔔 <b>Real-Time Notifications Settings:</b>\n\nKya aapko real time round notifications chahiye?",
          {
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [
                [
                  { text: "✅ Haan (ON)", callback_data: "admin_notify_on" },
                  { text: "❌ Nahi (OFF)", callback_data: "admin_notify_off" }
                ]
              ]
            }
          }
        );
      }

      sendProtectedMenu(bot, chatId, name);
    });

    // =================================================================
    // 👑 THE 24/7 AUTO-RECOVERY RUN ENGINE (REPLACES OLD BOT.LAUNCH)
    // =================================================================
    async function startStableBotEngine() {
      try {
        await bot.telegram.deleteWebhook({ drop_pending_updates: true });
        console.log('🔄 Telegram webhook cache cleaned successfully.');

        await bot.telegram.setMyCommands([
          { command: 'start', description: '🚀 Open Control Panel / Control Bar Menu' }
        ]);
        console.log('🔘 Physical Chat Menu Button Synchronized.');

        bot.launch({ dropPendingUpdates: true })
          .then(() => console.log('🤖 Bot Engine is now 24/7 LIVE via Active Polling Loops!'))
          .catch((err: any) => {
             console.error('⚠️ Session Interrupted! Initializing Auto-Recovery Loop in 5s...', err?.message || err);
             setTimeout(startStableBotEngine, 5000);
          });
      } catch (err: any) {
        console.error('❌ Critical Boot Loop Fault. Retrying in 10s...', err?.message || err);
        setTimeout(startStableBotEngine, 10000);
      }
    }

    startStableBotEngine();

    bot.catch((err: any, ctx: any) => {
      console.error(`🚨 Handled dynamic error for update type: ${ctx?.updateType}`, err?.message || err);
    });

    // ==========================================
    // 📢 ADMIN BROADCAST COMMAND: /promo_blast
    // (Sirf Super Admin ke chalane ke liye)
    // ==========================================
    bot.onText(/\/promo_blast/, async (msg: any) => {
      const chatId = msg.chat.id;

      // 2. Runtime Backend Crash Fix: Server-side role check instead of localStorage
      const isSuperAdmin =
        userDatabase[chatId]?.role === 'super_admin' ||
        msg.from?.username?.toLowerCase() === 'thakku67' ||
        msg.from?.username?.toLowerCase() === 'mdfaisalraza9771' ||
        msg.from?.username?.toLowerCase().includes('admin') ||
        process.env.NODE_ENV !== 'production';

      if (!isSuperAdmin) {
        return bot.sendMessage(
          chatId,
          '⛔ <b>Access Denied:</b> This command is restricted to Super Admin only.',
          { parse_mode: 'HTML' }
        );
      }

      // Saare users ki list par automatic message bhejega
      let count = 0;
      const userKeys = Object.keys(userDatabase);

      for (const userChatId of userKeys) {
        // Un bando ko target karna jinke credits 0 hain
        if (userDatabase[userChatId].credits === 0) {
          try {
            await bot.sendMessage(
              userChatId,
              `🎁 <b>MASTERMIND WEEKEND BONUS FLASH!</b> 🎁\n──────────────────────────\nHi Player! We noticed your prediction panel is inactive.\n\nAdmin has credited <b>2 FREE BONUS CREDITS</b> into your account for the next 2 hours only! Go test the 7-second advance accuracy right now!\n──────────────────────────\n🚀 Type /start to activate your dashboard.`,
              { parse_mode: 'HTML', protect_content: true }
            );

            // Unhe 2 free credit dekar dubara aadat lagana
            userDatabase[userChatId].credits = 2;
            count++;
          } catch (e: any) {
            console.warn(`[PROMO BLAST] Failed to send to ${userChatId}:`, e.message);
          }
        }
      }

      bot.sendMessage(
        chatId,
        `✅ <b>Promo Blast executed successfully!</b> Credited 2 bonus credits to ${count} inactive users.`,
        { parse_mode: 'HTML' }
      );
    });

    // 2. Callback query handler
    bot.on('callback_query', async (query: any) => {
      const data = query.data;
      if (!data) return;

      // Handle Manual Deposit Approval / Rejection from Supreme Owner
      if (data.startsWith('app_dep:') || data.startsWith('rej_dep:') || data.startsWith('approve_dep_') || data.startsWith('reject_dep_')) {
        let action: 'approve' | 'reject' = 'approve';
        let depositId = '';

        if (data.startsWith('app_dep:')) {
          action = 'approve';
          depositId = data.replace('app_dep:', '');
        } else if (data.startsWith('rej_dep:')) {
          action = 'reject';
          depositId = data.replace('rej_dep:', '');
        } else if (data.startsWith('approve_dep_')) {
          action = 'approve';
          depositId = data.replace('approve_dep_', '');
        } else if (data.startsWith('reject_dep_')) {
          action = 'reject';
          depositId = data.replace('reject_dep_', '');
        }

        const senderId = Number(query.from?.id);
        const authorized = await isAuthorizedAdmin(senderId);
        if (senderId !== SUPREME_OWNER_ID && !authorized) {
          return bot.answerCallbackQuery(query.id, { text: "❌ Unauthorized control attempts blocked.", show_alert: true });
        }

        const evaluationResult = await processDepositVerification(depositId, action, 'telegram', bot);

        if (query.message) {
          const originalText = query.message.caption || query.message.text || '';
          const updatedNotice = `${originalText}\n\n📢 <b>LOG PROTOCOL: Request processed via [Admin Terminal Alpha].</b>`;
          if (query.message.caption !== undefined) {
            await bot.editMessageCaption(updatedNotice, {
              chat_id: query.message.chat.id,
              message_id: query.message.message_id,
              parse_mode: 'HTML'
            }).catch(() => {});
          } else {
            await bot.editMessageText(updatedNotice, {
              chat_id: query.message.chat.id,
              message_id: query.message.message_id,
              parse_mode: 'HTML'
            }).catch(() => {});
          }
        }

        return bot.answerCallbackQuery(query.id, { text: evaluationResult.message, show_alert: true });
      }

      if (!query.message) return;
      const chatId = query.message.chat.id;
      const userId = query.from?.id;
      const name = query.from?.first_name || 'Pilot';

      if (query.data === 'check_gate' || query.data === 'verify_membership' || query.data === 'verify_status') {
        const verified = await checkChannelsMembership(bot, userId);
        if (verified) {
          await bot.answerCallbackQuery(query.id, { text: '🎉 Access Granted! All channels verified.', show_alert: true });
          await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});
          sendProtectedMenu(bot, chatId, name);
        } else {
          await bot.answerCallbackQuery(query.id, { text: '❌ Verification Failed! Please join all 4 channels first.', show_alert: true });
        }
      }
    });

    // 3. New Asynchronous Stream Handler (Deadlock Eliminated & Unrestricted /start Routing)
    bot.on('message', async (msg: any) => {
      const chatId = msg.chat.id;
      const text = msg.text;
      const userId = msg.from?.id || chatId;

      if (!text) return;

      // STRICT STATE LOCK: If user or admin is locked in an input state, let state processor handle and halt secondary triggers
      if (botUserStates.has(Number(userId))) {
        return;
      }

      // 1. Dynamic user registration to safe-guard state access parameters
      if (!userDatabase[chatId]) {
        userDatabase[chatId] = {
          credits: 0,
          isPremium: false,
          context: null,
          role: 'user',
          registeredAt: Date.now(),
          lastActiveAt: Date.now(),
          predictionsRequested: 0,
          username: msg.from?.username,
          firstName: msg.from?.first_name || 'Pilot'
        };
      } else {
        userDatabase[chatId].lastActiveAt = Date.now();
      }

      // Auto-assign super_admin role for administrative accounts
      if (
        Number(userId) === SUPREME_OWNER_ID ||
        String(userId) === String(SUPREME_OWNER_ID) ||
        msg.from?.username?.toLowerCase() === 'thakku67' ||
        msg.from?.username?.toLowerCase() === 'mdfaisalraza9771' ||
        msg.from?.username?.toLowerCase().includes('superadmin')
      ) {
        userDatabase[chatId].role = 'super_admin';
      }

      // Background sync user document to Firestore
      try {
        usersRef.doc(String(chatId)).set({
          chatId: String(chatId),
          credits: userDatabase[chatId].credits ?? 0,
          isPremium: !!userDatabase[chatId].isPremium,
          context: userDatabase[chatId].context ?? null,
          role: userDatabase[chatId].role || 'user',
          registeredAt: userDatabase[chatId].registeredAt || Date.now(),
          lastActiveAt: Date.now(),
          username: msg.from?.username || '',
          firstName: msg.from?.first_name || 'Pilot'
        }, { merge: true }).catch((err: any) => console.warn('[FIRESTORE USER SYNC NOTE]:', err.message));
      } catch (err: any) {
        console.warn('[FIRESTORE SYNC CAUGHT]:', err.message);
      }

      // Check Admin permissions
      const hasAccess = await isAuthorizedAdmin(userId);

      // Administrative Control Buttons mapping inside Client window
      if ((text === "📊 View Live Logs" || text === "📊 Live Analytics Monitor") && (Number(userId) === SUPREME_OWNER_ID || hasAccess)) {
        const liveCount = await getTotalUserCount();
        const logCount = await BotLog.countDocuments().catch(() => 0);
        return bot.sendMessage(chatId, `👑 <b>GHOST ADMIN CORE: LIVE ANALYTICS</b>\n\n👥 <b>Total Registered Players:</b>\n<code>${liveCount} Active Users</code>\n\n📝 <b>Logged Operations:</b>\n<code>${logCount} Database Records</code>\n\n🛡️ <b>Security Status:</b> <code>100% Operational</code>`, { parse_mode: 'HTML' });
      }

      if ((text === "👥 Total Users") && (Number(userId) === SUPREME_OWNER_ID || hasAccess)) {
        let users: any[] = [];
        if (mongoose.connection.readyState === 1) {
          users = await BotUser.find({}).sort({ creditBalance: -1 }).lean().catch(() => []);
        } else {
          users = Object.entries(userDatabase).map(([id, u]: [string, any]) => ({
            telegramId: Number(id),
            username: u.username || '',
            activeSubscription: !!u.isPremium,
            creditBalance: u.credits ?? 0,
            totalCreditsEarned: u.credits ?? 0,
            totalReferrals: u.dailyReferralCount ?? 0
          })).sort((a: any, b: any) => (b.creditBalance || 0) - (a.creditBalance || 0));
        }

        const count = users.length;
        const vips = users.filter((u: any) => u.activeSubscription || u.isPremium).length;
        const totalSystemCredits = users.reduce((acc: number, u: any) => acc + (u.creditBalance ?? u.credits ?? 0), 0);

        let report = `📊 <b>DETAILED USER AUDIT REPORT</b>\n\n` +
                     `👥 Total Registered: <b>${count}</b> | 👑 VIPs: <b>${vips}</b>\n` +
                     `🪙 Total System Credits: <b>${totalSystemCredits}</b>\n` +
                     `───────────────────────\n`;

        const displayUsers = users.slice(0, 15);
        displayUsers.forEach((u: any, i: number) => {
          const bal = u.creditBalance ?? u.credits ?? 0;
          const share = totalSystemCredits > 0 ? ((bal / totalSystemCredits) * 100).toFixed(1) : '0.0';
          const isVip = u.activeSubscription || u.isPremium;
          const status = isVip ? '👑 VIP' : '🆓 Free';
          const uname = u.username ? `@${u.username}` : `ID:${u.telegramId || u.chatId}`;
          const earned = u.totalCreditsEarned ?? bal ?? 0;
          const refs = u.totalReferrals ?? u.dailyReferralCount ?? 0;

          report += `${i + 1}. <b>${uname}</b> (<code>${u.telegramId || u.chatId}</code>)\n` +
                    `   • Status: ${status} | Balance: 🪙 <b>${bal}</b>\n` +
                    `   • Lifetime Earned: <b>${earned}</b> | Pool Share: <b>${share}%</b>\n` +
                    `   • Referrals: <b>${refs}</b>\n\n`;
        });

        if (users.length > 15) {
          report += `ℹ️ <i>...and ${users.length - 15} more profiles. Check Web Dashboard for full list.</i>`;
        }

        return bot.sendMessage(chatId, report, { parse_mode: 'HTML' });
      }

      if ((text === "📢 Global Broadcast" || text === "🚀 Global Promo Blast") && (Number(userId) === SUPREME_OWNER_ID || hasAccess)) {
        botUserStates.set(Number(userId), 'WAITING_FOR_BROADCAST_MSG');
        return bot.sendMessage(chatId, "📢 Send broadcast text:");
      }

      if ((text === "⚙️ Bot Settings") && (Number(userId) === SUPREME_OWNER_ID || hasAccess)) {
        return bot.sendMessage(
          chatId,
          `⚙️ <b>ENGINE TELEMETRY & CONFIGURATION</b>\n\n• <b>VIP Pass Price:</b> ₹${globalVipPrice}\n• <b>Credit Rate:</b> ₹${globalCreditRate}/credit\n• <b>Merchant UPI:</b> <code>${adminUpiId}</code>\n• <b>Stream:</b> 24/7 Long Polling Active`,
          { parse_mode: 'HTML' }
        );
      }

      if ((text === "🏷️ Change Base Rates") && (Number(userId) === SUPREME_OWNER_ID || hasAccess)) {
        botUserStates.set(Number(userId), 'WAITING_FOR_VIP_RATE');
        return bot.sendMessage(chatId, "✏️ Send the new VIP Monthly Pass Rate (in ₹):");
      }

      if ((text === "💳 Set Admin UPI ID") && (Number(userId) === SUPREME_OWNER_ID || hasAccess)) {
        botUserStates.set(Number(userId), 'WAITING_FOR_UPI_ID');
        return bot.sendMessage(chatId, "💳 Send your new Admin UPI ID:");
      }

      if ((text === "🤖 Clone Bot via API") && (Number(userId) === SUPREME_OWNER_ID || hasAccess)) {
        botUserStates.set(Number(userId), 'WAITING_FOR_CLONE_TOKEN');
        return bot.sendMessage(chatId, "🤖 Send Bot API Token:");
      }

      if (text === "🪙 Buy Custom Credits" || text === "Buy Custom Credits") {
        botUserStates.set(Number(userId), 'WAITING_FOR_CREDIT_AMOUNT');
        return bot.sendMessage(chatId, "✏️ Enter quantity of credits:");
      }

      if ((text === "🖥️ Open Admin Web Dashboard Link" || text === "🖥️ Open Dashboard") && (Number(userId) === SUPREME_OWNER_ID || hasAccess)) {
        const dashUrl = `${options?.websiteUrl || 'http://localhost:3000'}/admin-control.html`;
        return bot.sendMessage(chatId, `🖥️ <b>ADMIN CONTROL DASHBOARD:</b>\n<a href="${dashUrl}">Click Here to Open Real-Time Admin Dashboard</a>`, { parse_mode: 'HTML' });
      }

      if (text === "⚙️ User Credit Manager" && (Number(userId) === SUPREME_OWNER_ID || hasAccess)) {
        const commandsGuidance = `🔧 <b>ADMIN MANAGEMENT DISPATCH TERMINAL</b>\n\n` +
                                 `Use these formats directly inside this text interface:\n\n` +
                                 `🔹 <i>Check status:</i>\n<code>/check [User_Chat_ID]</code>\n\n` +
                                 `🔹 <i>Add credits:</i>\n<code>/give_credit [User_Chat_ID] [Amount]</code>\n\n` +
                                 `🔹 <i>VIP tier adjustments:</i>\n<code>/set_vip [User_Chat_ID] [true/false]</code>`;
        return bot.sendMessage(chatId, commandsGuidance, { parse_mode: 'HTML' });
      }

      // Regular Consumer Workflow buttons trigger control
      if (text === "👑 Buy VIP Subscription Pass" || text === "👑 VIP Plan Activation" || text.includes("VIP Subscription Pass") || text.includes("VIP Plan Activation") || text.includes("Buy VIP")) {
        userDatabase[chatId].context = "awaiting_sub_proof";
        usersRef.doc(String(chatId)).set({ context: "awaiting_sub_proof" }, { merge: true }).catch(() => {});
        
        const vipMsg = `👑 <b>WIN NOVA VIP PLAN ACTIVATION</b> 👑\n──────────────────────────\n` +
                       `💎 <b>Plan:</b> VIP Monthly Pass (30 Days)\n` +
                       `💰 <b>Amount:</b> ₹${globalVipPrice}\n` +
                       `🏛️ <b>Merchant UPI ID:</b> <code>${adminUpiId}</code>\n──────────────────────────\n` +
                       `Pay ₹${globalVipPrice} via UPI to <code>${adminUpiId}</code> and reply with your UTR or payment proof here for instant approval.`;
        
        const qrBuffer = await generateUpiQrCodeBuffer(adminUpiId, globalVipPrice, "WinNova");
        if (qrBuffer) {
          return bot.sendPhoto(chatId, qrBuffer, { caption: vipMsg, parse_mode: 'HTML' });
        }
        return bot.sendMessage(chatId, vipMsg, { parse_mode: 'HTML' });
      }

      if (text === "🪙 Top-up (Credits)" || text === "📱 Dynamic Top-up Calculator" || text.includes("Top-up")) {
        userDatabase[chatId].context = "awaiting_rounds_count";
        usersRef.doc(String(chatId)).set({ context: "awaiting_rounds_count" }, { merge: true }).catch(() => {});
        return bot.sendMessage(
          chatId,
          `🪙 <b>WALLET TOP-UP (TIERED SLABS ENABLED)</b>\n\n• <b>10 Credits:</b> ₹32\n• <b>100 Credits:</b> ₹315\n\nOr enter custom rounds count (minimum 10 rounds):\n<b>Type just the number (e.g. 10, 30, 100):</b>`,
          { parse_mode: 'HTML' }
        );
      }

      if (text === "🚀 Fetch Signal (7s Advance)" || text === "🎯 Fetch Signal (7s Advance)" || text.includes("Fetch Signal")) {
        const isJoined = await checkUserChannelMembership(userId, bot);
        if (!isJoined) {
          let joinMsg = `⚠️ <b>MANDATORY CHANNEL SUBSCRIPTION REQUIRED</b>\n\n` +
                        `Bot ke features aur control buttons use karne ke liye aapko hamare saare 4 channels join karne honge:\n\n`;
          let inlineButtons: any[] = [];
          REQUIRED_CHANNELS.forEach((ch) => {
            inlineButtons.push([{ text: `📢 Join ${ch.name}`, url: ch.url || `https://t.me/${(ch.username || ch.id).replace('@','')}` }]);
          });
          inlineButtons.push([{ text: "🔄 Check Membership", callback_data: "check_membership" }]);
          return bot.sendMessage(chatId, joinMsg, { parse_mode: 'HTML', reply_markup: { inline_keyboard: inlineButtons } });
        }

        const isMaster = Number(userId) === ADMIN_ID || Number(userId) === SUPREME_OWNER_ID;
        const isVip = Boolean(userDatabase[chatId]?.activeSubscription || userDatabase[chatId]?.isPremium);
        const balance = userDatabase[chatId]?.credits ?? 0;

        // STRICT ZERO FREE CREDITS & ACCESS CONTROL
        if (!isMaster && (!isVip || balance < 1)) {
          return bot.sendMessage(
            chatId,
            `⛔ <b>ACCESS DENIED: ZERO CREDITS & NO VIP ACCESS</b>\n──────────────────────────\n` +
            `Aapke paas active signals ke liye credits ya VIP subscription nahi hai.\n\n` +
            `• <b>Current Balance:</b> <code>${balance} Credits</code>\n` +
            `• <b>VIP Subscription:</b> <code>${isVip ? "ACTIVE" : "INACTIVE"}</code>\n\n` +
            `💳 Niche diye gaye menu se credits recharge karein ya VIP Plan activate karein.`,
            { parse_mode: 'HTML' }
          );
        }

        // STRICT LIVE TELEMETRY: Force wait if round just crashed
        if (liveTelemetryState.status === 'CRASHED') {
          return bot.sendMessage(
            chatId,
            `⚠️ <b>ROUND RE-CALIBRATING</b>\n\nRound #${liveTelemetryState.roundId} has crashed. Please wait 3 seconds for the next live telemetry round to initialize!`,
            { parse_mode: 'HTML' }
          );
        }

        const activeRoundId = liveTelemetryState.roundId;
        const targetMult = Number((liveTelemetryState.targetMultiplier || 2.15).toFixed(2));
        const safeCashout = Math.max(1.05, Number((targetMult * 0.82).toFixed(2)));

        // ATOMIC TRANSACTION SNAPSHOT & DEDUCTION IN MONGODB
        if (!isMaster && balance > 0) {
          userDatabase[chatId].credits = Math.max(0, balance - 1);
          if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate(
              { telegramId: Number(userId) },
              { 
                $inc: { creditBalance: -1, predictionsRequested: 1 },
                $set: { lastActiveAt: new Date() }
              },
              { new: true }
            ).catch(() => {});

            await BotLog.create({
              telegramId: Number(userId),
              actionType: 'CREDIT_DEDUCT_SIGNAL',
              details: `1 credit deducted for Round #${activeRoundId}`,
              timestamp: new Date()
            }).catch(() => {});
          }
        }

        const signalMsg =
          `🎯 <b>WIN NOVA REAL-TIME TELEMETRY SIGNAL</b> 🎯\n` +
          `──────────────────────────\n` +
          `🆔 <b>Telemetry Round ID:</b> <code>#${activeRoundId}</code>\n` +
          `⚡ <b>Active Target Multiplier:</b> <code>${targetMult.toFixed(2)}x</code>\n` +
          `🛡️ <b>Safe Cashout:</b> <code>${safeCashout.toFixed(2)}x</code> <i>(82% Telemetry Safety, min 1.05x)</i>\n` +
          `🔋 <b>Remaining Quota:</b> <code>${Math.max(0, userDatabase[chatId].credits ?? 0)} Credits</code>\n` +
          `──────────────────────────\n` +
          `💡 <i>Dispatched in direct synchronization with live telemetry engine.</i>`;

        return bot.sendMessage(chatId, signalMsg, { parse_mode: 'HTML' });
      }

      if (text === "🔄 Check Session Status" || text === "📟 Check Session Status" || text.includes("Check Session Status")) {
        const u = userDatabase[chatId] || { credits: 0, isPremium: false, activeSubscription: false };
        const isVip = Boolean(u.isPremium || u.activeSubscription);
        const status = isVip ? "👑 VIP Active" : "⚪ Standard Account";
        return bot.sendMessage(
          chatId,
          `👤 <b>USER ACCOUNT METRIC LOGS</b>\n───────────────────\n🆔 <b>Session Chat ID:</b> <code>${chatId}</code>\n🏆 <b>Verification Level:</b> <b>${status}</b>\n🔋 <b>Wallet Quota:</b> <code>${u.credits ?? 0} Credits</code>\n🛡️ <b>Engine Health:</b> <code>Optimal (99.8%)</code>\n───────────────────`,
          { parse_mode: 'HTML', protect_content: true }
        );
      }

      if (text === "🌐 Official Networks" || text.includes("Official Networks")) {
        let netMsg = `<b>📢 WIN NOVA OFFICIAL TELEGRAM NETWORKS:</b>\n\n`;
        OFFICIAL_NETWORKS.forEach(net => {
          netMsg += `• <a href="${net.url}"><b>${net.name}</b></a>: ${net.handle}\n`;
        });
        netMsg += `\n🌐 <b>Live Platform:</b> ${options?.websiteUrl || 'http://localhost:3000'}\n<i>Join all networks for loot codes, live deposit logs, and instant VIP support!</i>`;
        return bot.sendMessage(chatId, netMsg, { parse_mode: 'HTML' });
      }

      // ==========================================
      // OWNER & ADMIN TELEGRAM INLINE ROUTER
      // ==========================================
      if (hasAccess && text.startsWith('/')) {
        const args = text.trim().split(/\s+/);
        const command = args[0];

        // Command 1: /check <userChatId>
        if (command === '/check') {
          const targetId = args[1];
          if (!targetId) return bot.sendMessage(chatId, "❌ Usage: /check <userChatId>");

          let userDoc = await usersRef.doc(String(targetId)).get();
          if (!userDoc.exists) {
            if (userDatabase[targetId]) {
              await usersRef.doc(String(targetId)).set({
                chatId: String(targetId),
                credits: userDatabase[targetId].credits ?? 0,
                isPremium: !!userDatabase[targetId].isPremium,
                context: userDatabase[targetId].context || null,
                role: userDatabase[targetId].role || 'user',
                registeredAt: userDatabase[targetId].registeredAt || Date.now(),
                lastActiveAt: userDatabase[targetId].lastActiveAt || Date.now(),
                predictionsRequested: userDatabase[targetId].predictionsRequested || 0,
                username: userDatabase[targetId].username || '',
                firstName: userDatabase[targetId].firstName || 'Pilot'
              }, { merge: true });
              userDoc = await usersRef.doc(String(targetId)).get();
            } else {
              return bot.sendMessage(chatId, "❌ User not found in Firestore database.");
            }
          }

          const uData = userDoc.data() || {};
          const regTime = uData.registeredAt || (uData.createdAt ? new Date(uData.createdAt).getTime() : Date.now());
          const ageMs = Math.max(0, Date.now() - regTime);
          const ageDays = Math.floor(ageMs / 86400000);
          const ageHours = Math.floor((ageMs % 86400000) / 3600000);
          const ageMinutes = Math.floor((ageMs % 3600000) / 60000);
          const accountAge = ageDays > 0 ? `${ageDays}d ${ageHours}h` : ageHours > 0 ? `${ageHours}h ${ageMinutes}m` : `${ageMinutes} mins`;

          const report = `👤 <b>USER LIVE DATA REPORT</b> 👤\n\n` +
                         `🆔 <b>Chat ID:</b> <code>${targetId}</code>\n` +
                         `📊 <b>Credits Balance:</b> <code>${uData.credits ?? 0}</code>\n` +
                         `👑 <b>VIP Account:</b> <code>${uData.isPremium ? "YES" : "NO"}</code>\n` +
                         `⚙️ <b>Active Context:</b> <code>${uData.context || "None"}</code>\n` +
                         `⏳ <b>Account Age:</b> <code>${accountAge}</code>`;
          return bot.sendMessage(chatId, report, { parse_mode: 'HTML' });
        }

        // Command 2: /give_credit <userChatId> <amount>
        if (command === '/give_credit') {
          const targetId = args[1];
          const amount = parseInt(args[2], 10);
          if (!targetId || isNaN(amount)) return bot.sendMessage(chatId, "❌ Usage: /give_credit <userChatId> <amount>");

          const numId = Number(targetId);
          if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate(
              { telegramId: numId },
              { $inc: { creditBalance: amount, totalCreditsEarned: Math.max(0, amount) } },
              { upsert: true, new: true }
            ).catch(() => {});
          }

          if (userDatabase[targetId]) {
            userDatabase[targetId].credits = (userDatabase[targetId].credits || 0) + amount;
          }

          let userDoc = await usersRef.doc(String(targetId)).get().catch(() => null);
          if (userDoc && userDoc.exists) {
            await usersRef.doc(String(targetId)).update({
              credits: AdminFieldValue.increment(amount),
              lastActiveAt: Date.now()
            }).catch(() => {});
          }

          try {
            await bot.sendMessage(targetId, `🎁 <b>System Update:</b> Admin has added <code>${amount} Credits</code> to your account!`, { parse_mode: 'HTML' });
          } catch (e: any) {}
          return bot.sendMessage(chatId, `✅ Successfully added <b>${amount} credits</b> to User <code>${targetId}</code>`, { parse_mode: 'HTML' });
        }

        // Command: /deduct_credit <userChatId> <amount>
        if (command === '/deduct_credit') {
          const targetId = args[1];
          const amount = parseInt(args[2], 10);
          if (!targetId || isNaN(amount)) return bot.sendMessage(chatId, "❌ Usage: /deduct_credit <userChatId> <amount>");

          const numId = Number(targetId);
          if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate(
              { telegramId: numId },
              { $inc: { creditBalance: -amount } },
              { new: true }
            ).catch(() => {});
          }

          if (userDatabase[targetId]) {
            userDatabase[targetId].credits = Math.max(0, (userDatabase[targetId].credits || 0) - amount);
          }

          let userDoc = await usersRef.doc(String(targetId)).get().catch(() => null);
          if (userDoc && userDoc.exists) {
            await usersRef.doc(String(targetId)).update({
              credits: AdminFieldValue.increment(-amount),
              lastActiveAt: Date.now()
            }).catch(() => {});
          }

          return bot.sendMessage(chatId, `✅ Deducted <b>${amount} credits</b> from User <code>${targetId}</code>`, { parse_mode: 'HTML' });
        }

        // Command: /set_credit <userChatId> <amount>
        if (command === '/set_credit') {
          const targetId = args[1];
          const amount = parseInt(args[2], 10);
          if (!targetId || isNaN(amount)) return bot.sendMessage(chatId, "❌ Usage: /set_credit <userChatId> <amount>");

          const numId = Number(targetId);
          if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate(
              { telegramId: numId },
              { creditBalance: amount },
              { upsert: true, new: true }
            ).catch(() => {});
          }

          if (userDatabase[targetId]) {
            userDatabase[targetId].credits = amount;
          }

          let userDoc = await usersRef.doc(String(targetId)).get().catch(() => null);
          if (userDoc && userDoc.exists) {
            await usersRef.doc(String(targetId)).update({
              credits: amount,
              lastActiveAt: Date.now()
            }).catch(() => {});
          }

          return bot.sendMessage(chatId, `✅ Credit balance for User <code>${targetId}</code> set to <b>${amount}</b>`, { parse_mode: 'HTML' });
        }

        // Command 3: /set_vip <userChatId> <true/false>
        if (command === '/set_vip') {
          const targetId = args[1];
          const isVipValue = args[2] === 'true';
          if (!targetId || (args[2] !== 'true' && args[2] !== 'false')) {
            return bot.sendMessage(chatId, "❌ Usage: /set_vip <userChatId> <true/false>");
          }

          const numId = Number(targetId);
          if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate(
              { telegramId: numId },
              { activeSubscription: isVipValue },
              { upsert: true, new: true }
            ).catch(() => {});
          }

          if (userDatabase[targetId]) {
            userDatabase[targetId].isPremium = isVipValue;
            userDatabase[targetId].activeSubscription = isVipValue;
          }

          let userDoc = await usersRef.doc(String(targetId)).get().catch(() => null);
          if (userDoc && userDoc.exists) {
            await usersRef.doc(String(targetId)).update({
              isPremium: isVipValue,
              lastActiveAt: Date.now()
            }).catch(() => {});
          }

          try {
            await bot.sendMessage(targetId, `👑 <b>VIP Status Update:</b> Your account status has been changed to <b>${isVipValue ? "VIP PASS ACTIVE" : "STANDARD"}</b>.`, { parse_mode: 'HTML' });
          } catch (e: any) {}
          return bot.sendMessage(chatId, `✅ User <code>${targetId}</code> VIP status updated to <b>${isVipValue}</b>`, { parse_mode: 'HTML' });
        }

        // Command: /ban <chatId>
        if (command === '/ban') {
          const targetId = Number(args[1]);
          if (!targetId) return bot.sendMessage(chatId, "❌ Usage: /ban <chatId>");
          if (targetId === ADMIN_ID || targetId === SUPREME_OWNER_ID) return bot.sendMessage(chatId, "❌ Cannot ban Supreme Admin.");

          if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate({ telegramId: targetId }, { isBanned: true, role: 'banned' }).catch(() => {});
          }
          if (userDatabase[targetId]) {
            userDatabase[targetId].isBanned = true;
            userDatabase[targetId].role = 'banned' as any;
          }
          return bot.sendMessage(chatId, `🚫 User <code>${targetId}</code> has been <b>BANNED</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /unban <chatId>
        if (command === '/unban') {
          const targetId = Number(args[1]);
          if (!targetId) return bot.sendMessage(chatId, "❌ Usage: /unban <chatId>");

          if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate({ telegramId: targetId }, { isBanned: false, role: 'user' }).catch(() => {});
          }
          if (userDatabase[targetId]) {
            userDatabase[targetId].isBanned = false;
            userDatabase[targetId].role = 'user' as any;
          }
          return bot.sendMessage(chatId, `✅ User <code>${targetId}</code> has been <b>UNBANNED</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /set_vip_price <amount>
        if (command === '/set_vip_price') {
          const rate = parseInt(args[1], 10);
          if (isNaN(rate) || rate <= 0) return bot.sendMessage(chatId, "❌ Usage: /set_vip_price <amount>");
          globalVipPrice = rate;
          if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { baseSubRate: rate }, { upsert: true, new: true }).catch(() => {});
          }
          return bot.sendMessage(chatId, `✅ VIP Monthly Pass Rate set to <b>₹${rate}</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /set_credit_price <amount>
        if (command === '/set_credit_price') {
          const rate = parseInt(args[1], 10);
          if (isNaN(rate) || rate <= 0) return bot.sendMessage(chatId, "❌ Usage: /set_credit_price <amount>");
          globalCreditRate = rate;
          if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { creditRate: rate }, { upsert: true, new: true }).catch(() => {});
          }
          return bot.sendMessage(chatId, `✅ Credit Unit Rate set to <b>₹${rate}/credit</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /set_tax <percent>
        if (command === '/set_tax') {
          const tax = parseFloat(args[1]);
          if (isNaN(tax) || tax < 0) return bot.sendMessage(chatId, "❌ Usage: /set_tax <percent>");
          if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { taxPercent: tax }, { upsert: true, new: true }).catch(() => {});
          }
          return bot.sendMessage(chatId, `✅ Dynamic Tax Rate set to <b>${tax}%</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /set_commission <percent>
        if (command === '/set_commission') {
          const comm = parseFloat(args[1]);
          if (isNaN(comm) || comm < 0) return bot.sendMessage(chatId, "❌ Usage: /set_commission <percent>");
          if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { commissionPercent: comm }, { upsert: true, new: true }).catch(() => {});
          }
          return bot.sendMessage(chatId, `✅ Referral Commission Rate set to <b>${comm}%</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /set_upi <upiId>
        if (command === '/set_upi') {
          const upi = args[1]?.trim();
          if (!upi) return bot.sendMessage(chatId, "❌ Usage: /set_upi <upiId>");
          adminUpiId = upi;
          if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { adminUpiId: upi }, { upsert: true, new: true }).catch(() => {});
          }
          return bot.sendMessage(chatId, `✅ Admin UPI ID updated to: <code>${upi}</code>`, { parse_mode: 'HTML' });
        }

        // Command: /set_next_mult <multiplier>
        if (command === '/set_next_mult') {
          const mult = parseFloat(args[1]);
          if (isNaN(mult) || mult < 1.0) return bot.sendMessage(chatId, "❌ Usage: /set_next_mult <multiplier>");
          liveTelemetryState.nextRoundMultiplier = mult;
          return bot.sendMessage(chatId, `🎯 Next Round Crash Multiplier overridden to <b>${mult}x</b>!`, { parse_mode: 'HTML' });
        }

        // Command: /broadcast <message>
        if (command === '/broadcast') {
          const bMsg = args.slice(1).join(' ').trim();
          if (!bMsg) return bot.sendMessage(chatId, "❌ Usage: /broadcast <message>");
          let users: any[] = [];
          if (mongoose.connection.readyState === 1) {
            users = await BotUser.find({ isBanned: false }).lean().catch(() => []);
          } else {
            users = Object.keys(userDatabase).map(k => ({ telegramId: Number(k) }));
          }
          let sent = 0;
          for (const u of users) {
            try {
              await bot.sendMessage(u.telegramId, `📢 <b>ADMIN BROADCAST:</b>\n\n${bMsg}`, { parse_mode: 'HTML' });
              sent++;
            } catch (_) {}
          }
          return bot.sendMessage(chatId, `✅ Broadcast sent to <b>${sent}</b> users.`, { parse_mode: 'HTML' });
        }

        // Command: /set_role <userChatId> <role>
        if (command === '/set_role') {
          const targetId = Number(args[1]);
          const newRole = args[2]?.toLowerCase();
          if (!targetId || !newRole) return bot.sendMessage(chatId, "❌ Usage: /set_role <userChatId> <role> (user|vip|admin|banned)");
          if (targetId === ADMIN_ID || targetId === SUPREME_OWNER_ID) return bot.sendMessage(chatId, "❌ Cannot alter Supreme Admin role.");

          if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate({ telegramId: targetId }, { role: newRole }, { upsert: true, new: true }).catch(() => {});
          }
          if (userDatabase[targetId]) {
            userDatabase[targetId].role = newRole as any;
          }
          return bot.sendMessage(chatId, `✅ User <code>${targetId}</code> role updated to <b>${newRole}</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /reset_user <userChatId>
        if (command === '/reset_user') {
          const targetId = Number(args[1]);
          if (!targetId) return bot.sendMessage(chatId, "❌ Usage: /reset_user <userChatId>");

          if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate(
              { telegramId: targetId },
              { creditBalance: 0, activeSubscription: false, role: 'user', isBanned: false },
              { new: true }
            ).catch(() => {});
          }
          if (userDatabase[targetId]) {
            userDatabase[targetId].credits = 0;
            userDatabase[targetId].isPremium = false;
            userDatabase[targetId].activeSubscription = false;
            userDatabase[targetId].role = 'user';
            userDatabase[targetId].isBanned = false;
          }
          return bot.sendMessage(chatId, `✅ User <code>${targetId}</code> reset to 0 credits & standard status.`, { parse_mode: 'HTML' });
        }

        // Command: /del_user <userChatId>
        if (command === '/del_user') {
          const targetId = Number(args[1]);
          if (!targetId) return bot.sendMessage(chatId, "❌ Usage: /del_user <userChatId>");
          if (targetId === ADMIN_ID || targetId === SUPREME_OWNER_ID) return bot.sendMessage(chatId, "❌ Cannot delete Supreme Admin.");

          if (mongoose.connection.readyState === 1) {
            await BotUser.deleteOne({ telegramId: targetId }).catch(() => {});
          }
          delete userDatabase[targetId];
          return bot.sendMessage(chatId, `🗑️ User <code>${targetId}</code> permanently deleted from database.`, { parse_mode: 'HTML' });
        }

        // Command: /set_slab10 <amount>
        if (command === '/set_slab10') {
          const slab = parseInt(args[1], 10);
          if (isNaN(slab) || slab <= 0) return bot.sendMessage(chatId, "❌ Usage: /set_slab10 <amount>");
          if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { slab10: slab }, { upsert: true, new: true }).catch(() => {});
          }
          return bot.sendMessage(chatId, `✅ 10 Credits Slab price set to <b>₹${slab}</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /set_slab100 <amount>
        if (command === '/set_slab100') {
          const slab = parseInt(args[1], 10);
          if (isNaN(slab) || slab <= 0) return bot.sendMessage(chatId, "❌ Usage: /set_slab100 <amount>");
          if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { slab100: slab }, { upsert: true, new: true }).catch(() => {});
          }
          return bot.sendMessage(chatId, `✅ 100 Credits Slab price set to <b>₹${slab}</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /set_daily_credits <amount>
        if (command === '/set_daily_credits') {
          const amt = parseInt(args[1], 10);
          if (isNaN(amt) || amt < 0) return bot.sendMessage(chatId, "❌ Usage: /set_daily_credits <amount>");
          if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { dailyCredits: amt }, { upsert: true, new: true }).catch(() => {});
          }
          return bot.sendMessage(chatId, `✅ Daily Free Credits bonus set to <b>${amt}</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /set_min_ref <num>
        if (command === '/set_min_ref') {
          const num = parseInt(args[1], 10);
          if (isNaN(num) || num < 0) return bot.sendMessage(chatId, "❌ Usage: /set_min_ref <num>");
          if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { minReferralsForClaim: num }, { upsert: true, new: true }).catch(() => {});
          }
          return bot.sendMessage(chatId, `✅ Minimum Referrals for Daily Claim set to <b>${num}</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /set_url <url>
        if (command === '/set_url') {
          const url = args[1]?.trim();
          if (!url) return bot.sendMessage(chatId, "❌ Usage: /set_url <url>");
          if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { dynamicWebsiteUrl: url }, { upsert: true, new: true }).catch(() => {});
          }
          if (options) options.websiteUrl = url;
          return bot.sendMessage(chatId, `✅ Dynamic Website URL set to: <code>${url}</code>`, { parse_mode: 'HTML' });
        }

        // Command: /maintenance <on/off>
        if (command === '/maintenance') {
          const stateVal = args[1]?.toLowerCase();
          if (stateVal !== 'on' && stateVal !== 'off') return bot.sendMessage(chatId, "❌ Usage: /maintenance <on/off>");
          const isMaint = stateVal === 'on';
          if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { maintenanceMode: isMaint }, { upsert: true, new: true }).catch(() => {});
          }
          return bot.sendMessage(chatId, `🛠️ Maintenance Mode is now <b>${isMaint ? 'ENABLED' : 'DISABLED'}</b>.`, { parse_mode: 'HTML' });
        }

        // Command: /clear_logs
        if (command === '/clear_logs') {
          if (mongoose.connection.readyState === 1) {
            await BotLog.deleteMany({}).catch(() => {});
          }
          return bot.sendMessage(chatId, `🧹 All system telemetry and audit logs have been flushed.`, { parse_mode: 'HTML' });
        }

        // Command: /users
        if (command === '/users') {
          let users: any[] = [];
          if (mongoose.connection.readyState === 1) {
            users = await BotUser.find({}).sort({ creditBalance: -1 }).lean().catch(() => []);
          } else {
            users = Object.entries(userDatabase).map(([id, u]: [string, any]) => ({
              telegramId: Number(id),
              username: u.username || '',
              activeSubscription: !!u.isPremium,
              creditBalance: u.credits ?? 0,
              totalCreditsEarned: u.credits ?? 0,
              totalReferrals: u.dailyReferralCount ?? 0
            })).sort((a: any, b: any) => (b.creditBalance || 0) - (a.creditBalance || 0));
          }

          const count = users.length;
          const vips = users.filter((u: any) => u.activeSubscription || u.isPremium).length;
          const totalCredits = users.reduce((acc: number, u: any) => acc + (u.creditBalance ?? 0), 0);

          let rpt = `📊 <b>USER AUDIT DIRECTORY</b>\n\n👥 Registered: <b>${count}</b> | 👑 VIPs: <b>${vips}</b>\n🪙 Total System Credits: <b>${totalCredits}</b>\n───────────────────────\n`;
          users.slice(0, 10).forEach((u: any, i: number) => {
            rpt += `${i + 1}. <b>${u.username ? '@' + u.username : 'ID:' + u.telegramId}</b>: 🪙 <b>${u.creditBalance ?? 0}</b> | ${u.activeSubscription ? '👑 VIP' : 'Free'}\n`;
          });
          return bot.sendMessage(chatId, rpt, { parse_mode: 'HTML' });
        }

        // Command: /subadmins
        if (command === '/subadmins') {
          let list: any[] = [];
          if (mongoose.connection.readyState === 1) {
            list = await SubAdmin.find({}).lean().catch(() => []);
          } else {
            list = Array.from(inMemorySubAdmins.values());
          }
          if (list.length === 0) return bot.sendMessage(chatId, "🛡️ No Sub-Admins registered currently.");
          let msg = `🛡️ <b>REGISTERED SUB-ADMINS (${list.length})</b>\n──────────────────────────\n`;
          list.forEach(s => {
            msg += `• <b>${s.username}</b>: Bot:${s.canManageTelegramBot ? '✅' : '❌'} Rates:${s.canManageRates ? '✅' : '❌'} UPI:${s.canManageUPI ? '✅' : '❌'} Broadcast:${s.canBroadcast ? '✅' : '❌'}\n`;
          });
          return bot.sendMessage(chatId, msg, { parse_mode: 'HTML' });
        }

        // Command: /add_subadmin <username> <password>
        if (command === '/add_subadmin') {
          const uName = args[1]?.trim();
          const pWord = args[2]?.trim();
          if (!uName || !pWord) return bot.sendMessage(chatId, "❌ Usage: /add_subadmin <username> <password>");
          if (mongoose.connection.readyState === 1) {
            await SubAdmin.findOneAndUpdate(
              { username: uName },
              { username: uName, password: pWord, canManageTelegramBot: false, canManageRates: false, canManageUPI: false, canBroadcast: false },
              { upsert: true, new: true }
            );
          } else {
            inMemorySubAdmins.set(uName, { username: uName, password: pWord, canManageTelegramBot: false, canManageRates: false, canManageUPI: false, canBroadcast: false });
          }
          return bot.sendMessage(chatId, `✅ Sub-Admin <b>${uName}</b> created successfully. Configure permissions in Web Dashboard.`, { parse_mode: 'HTML' });
        }

        // Command: /del_subadmin <username>
        if (command === '/del_subadmin') {
          const uName = args[1]?.trim();
          if (!uName) return bot.sendMessage(chatId, "❌ Usage: /del_subadmin <username>");
          if (mongoose.connection.readyState === 1) {
            await SubAdmin.deleteOne({ username: uName }).catch(() => {});
          }
          for (const [k, v] of inMemorySubAdmins.entries()) {
            if (v.username === uName) inMemorySubAdmins.delete(k);
          }
          return bot.sendMessage(chatId, `🗑️ Sub-Admin <b>${uName}</b> removed.`, { parse_mode: 'HTML' });
        }

        // Command: /system or /status
        if (command === '/system' || command === '/status') {
          const totalUsersCount = await getTotalUserCount();
          const logCount = await BotLog.countDocuments().catch(() => 0);
          const sysMsg = `👑 <b>WIN NOVA SYSTEM TELEMETRY SUMMARY</b>\n──────────────────────────\n` +
                         `• <b>VIP Monthly Pass:</b> ₹${globalVipPrice}\n` +
                         `• <b>Credit Price:</b> ₹${globalCreditRate}/credit\n` +
                         `• <b>Merchant UPI:</b> <code>${adminUpiId}</code>\n` +
                         `• <b>Registered Users:</b> ${totalUsersCount}\n` +
                         `• <b>Database Logs:</b> ${logCount} records\n` +
                         `• <b>Live Telemetry Round:</b> #${liveTelemetryState.roundId} (${liveTelemetryState.status})\n` +
                         `• <b>Target Crash:</b> ${liveTelemetryState.targetMultiplier.toFixed(2)}x\n` +
                         `• <b>Website URL:</b> ${options?.websiteUrl || 'http://localhost:3000'}\n` +
                         `• <b>Notifications:</b> ${isAdminNotificationOn ? '✅ ON' : '❌ OFF'}\n` +
                         `──────────────────────────`;
          return bot.sendMessage(chatId, sysMsg, { parse_mode: 'HTML' });
        }

        // Command 4: /admin or /owner help
        if (command === '/admin' || command === '/owner' || command === '/admin_help') {
          const helpMsg = `👑 <b>SUPREME OWNER & ADMIN DASHBOARD</b> 👑\n──────────────────────────\n` +
                          `👑 <b>Supreme Authority:</b> <code>${SUPREME_OWNER_ID}</code>\n\n` +
                          `<b>User Management:</b>\n` +
                          `• <code>/check &lt;chatId&gt;</code> - View user details\n` +
                          `• <code>/give_credit &lt;chatId&gt; &lt;amt&gt;</code> - Add credits\n` +
                          `• <code>/deduct_credit &lt;chatId&gt; &lt;amt&gt;</code> - Deduct credits\n` +
                          `• <code>/set_credit &lt;chatId&gt; &lt;amt&gt;</code> - Set exact credits\n` +
                          `• <code>/set_vip &lt;chatId&gt; &lt;true/false&gt;</code> - Toggle VIP\n` +
                          `• <code>/set_role &lt;chatId&gt; &lt;role&gt;</code> - Set role (user/vip/admin/banned)\n` +
                          `• <code>/ban &lt;chatId&gt;</code> | <code>/unban &lt;chatId&gt;</code> - Ban/Unban\n` +
                          `• <code>/reset_user &lt;chatId&gt;</code> - Reset user to 0 credits\n` +
                          `• <code>/del_user &lt;chatId&gt;</code> - Permanently delete user\n` +
                          `• <code>/users</code> - List user directory\n\n` +
                          `<b>System Rates & Telemetry:</b>\n` +
                          `• <code>/set_vip_price &lt;amount&gt;</code> - Change VIP rate\n` +
                          `• <code>/set_credit_price &lt;amount&gt;</code> - Change credit price\n` +
                          `• <code>/set_slab10 &lt;amount&gt;</code> - Change 10-credits price\n` +
                          `• <code>/set_slab100 &lt;amount&gt;</code> - Change 100-credits price\n` +
                          `• <code>/set_tax &lt;percent&gt;</code> - Change tax rate\n` +
                          `• <code>/set_commission &lt;percent&gt;</code> - Change commission\n` +
                          `• <code>/set_daily_credits &lt;amt&gt;</code> - Daily bonus setting\n` +
                          `• <code>/set_min_ref &lt;num&gt;</code> - Min referrals for claim\n` +
                          `• <code>/set_upi &lt;upiId&gt;</code> - Set merchant UPI\n` +
                          `• <code>/set_url &lt;url&gt;</code> - Set dynamic website URL\n` +
                          `• <code>/set_next_mult &lt;multiplier&gt;</code> - Force next crash\n` +
                          `• <code>/maintenance &lt;on/off&gt;</code> - Toggle maintenance mode\n` +
                          `• <code>/broadcast &lt;text&gt;</code> - Instant global broadcast\n` +
                          `• <code>/clear_logs</code> - Flush system logs\n` +
                          `• <code>/status</code> - View complete live status\n` +
                          `• <code>/off</code> | <code>/on</code> - Toggle real-time alerts\n\n` +
                          `<b>Sub-Admins:</b>\n` +
                          `• <code>/subadmins</code> - View sub-admins list\n` +
                          `• <code>/add_subadmin &lt;user&gt; &lt;pass&gt;</code> - Add sub-admin\n` +
                          `• <code>/del_subadmin &lt;user&gt;</code> - Remove sub-admin\n` +
                          `──────────────────────────`;
          return bot.sendMessage(chatId, helpMsg, { parse_mode: 'HTML' });
        }
      }

      // 2. Unrestricted /start routing gateway check
      if (text === '/start') {
        const isMember = await checkChannelsMembership(bot, msg.from?.id || chatId);
        if (isMember) {
          return sendProtectedMenu(bot, chatId, msg.from?.first_name);
        } else {
          const lockMsg = `⚠️ <b>ACCESS LOCKED: VERIFICATION REQUIRED</b> ⚠️`;
          const inlineKeyboard: any[][] = REQUIRED_CHANNELS.map(ch => [{ text: `🔗 Join ${ch.name}`, url: ch.url }]);
          inlineKeyboard.push([{ text: '🔄 Verified & Check Status', callback_data: 'check_gate' }]);

          return bot.sendMessage(chatId, lockMsg, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: inlineKeyboard }
          });
        }
      }

      // 3. Dynamic calculator state trigger mapping
      if (text === '📱 Dynamic Top-up Calculator' || text === '🔋 Dynamic Top-up Calculator') {
        userDatabase[chatId].context = 'awaiting_rounds_count';
        return bot.sendMessage(
          chatId,
          `🔢 <b>DYNAMIC CALCULATOR ACTIVATE</b>\n\nAapko kitne rounds ka data chahiye? Chat box mein <b>sirf number type karke send karein</b> (e.g. 10, 30, 100).\n\n⚠️ <i>Minimum top-up logic limit requires 10 rounds.</i>`,
          { parse_mode: 'HTML' }
        );
      }

      // 4. Input intercept and calculator payload processing layer
      if (userDatabase[chatId].context === 'awaiting_rounds_count' && !isNaN(Number(text))) {
        userDatabase[chatId].context = null; // Instantly release context block
        const roundDemand = parseInt(text.trim(), 10);
        const result = calculateTopupCost(roundDemand);

        if (result.error) {
          return bot.sendMessage(chatId, result.message || '⚠️ Invalid number', { parse_mode: 'HTML' });
        }

        userDatabase[chatId].lastCalculatedRounds = roundDemand;
        userDatabase[chatId].lastCalculatedTotal = result.total;
        userDatabase[chatId].context = 'awaiting_payment_proof';
        usersRef.doc(String(chatId)).set({ context: 'awaiting_payment_proof' }, { merge: true }).catch(() => {});

        const upiPaymentString = `upi://pay?pa=${adminUpiId}&pn=GhostVIP&am=${result.total}&cu=INR`;
        const qrBuffer = await generateUpiQrCodeBuffer(adminUpiId, result.total, "GhostVIP");

        const paymentInstructionText =
          `📊 <b>CALCULATOR INVOICE MATRIX GENERATED</b> 📊\n\n` +
          `🔄 <b>Rounds Demanded:</b> <code>${roundDemand} rounds</code>\n` +
          `💵 <b>Base Pricing (₹3/Rd):</b> ₹${result.base}\n` +
          `🛠️ <b>Dynamic System Tax Applied:</b> ₹${result.tax}\n` +
          `🔥 <b>NET PAYABLE VALUE:</b> <code>₹${result.total}</code>\n\n` +
          `🏛️ <b>Merchant UPI Gateway:</b> <code>${adminUpiId}</code>\n\n` +
          `👇 <b>Payment complete karne ke baad screenshot bhejein ya UTR / Transaction ID yahan reply karein.</b>`;

        if (qrBuffer) {
          return bot.sendPhoto(chatId, qrBuffer, { caption: paymentInstructionText, parse_mode: 'HTML' });
        }
        return bot.sendMessage(chatId, paymentInstructionText, { parse_mode: 'HTML' });
      }

      // Intercept User Payment Proof Submission (Text UTR / Transaction ID)
      if (userDatabase[chatId]?.context === 'awaiting_payment_proof') {
        const isMenuCommand = [
          '🚀 Fetch Signal',
          '🚀 Get Next Round',
          '📱 Dynamic Top-up Calculator',
          '🔋 Dynamic Top-up Calculator',
          '👑 VIP Subscription Pass',
          '👑 VIP Plan',
          '👑 VIP Pass',
          '💼 Check Session Status',
          '💼 My Status',
          '📢 Official Networks'
        ].some(cmd => text.startsWith(cmd));

        if (!isMenuCommand && !text.startsWith('/')) {
          userDatabase[chatId].context = null;
          usersRef.doc(String(chatId)).set({ context: null }, { merge: true }).catch(() => {});

          const amount = userDatabase[chatId]?.lastCalculatedTotal || globalVipPrice;
          const rounds = userDatabase[chatId]?.lastCalculatedRounds || 32;

          try {
            // 1. ANTI-FRAUD VALIDATION LAYER: Check for duplicate submissions
            const duplicateCheck = await db.collection('deposits')
              .where('proof', '==', text.trim())
              .limit(1)
              .get();

            if (!duplicateCheck.empty) {
              return bot.sendMessage(
                chatId,
                "❌ <b>SECURITY ALERT:</b> Duplicate transaction reference detected. This request has been flagged by the firewall network.",
                { parse_mode: 'HTML' }
              );
            }

            const depositRef = db.collection('deposits').doc();
            const depositPayload = {
              id: depositRef.id,
              chatId: String(chatId),
              username: msg.from?.username || 'None',
              firstName: msg.from?.first_name || 'Pilot',
              amount: amount,
              rounds: rounds,
              proof: text.trim(),
              isPhoto: false,
              status: 'pending',
              createdAt: AdminFieldValue.serverTimestamp()
            };
            await depositRef.set(depositPayload);

            // Also keep legacy queue item for existing UI compatibility
            pendingReceiptQueue.unshift({
              id: depositRef.id,
              chatId,
              userId: msg.from?.id || chatId,
              username: msg.from?.username || 'Pilot',
              firstName: msg.from?.first_name || 'Pilot',
              demandType: rounds === 32 ? `VIP Pass (₹${amount})` : `${rounds} Rounds Top-up (₹${amount})`,
              roundsDemanded: rounds,
              amount: amount,
              date: new Date().toLocaleTimeString(),
              timestamp: Date.now(),
              status: 'PENDING'
            });

            // Inform user
            await bot.sendMessage(
              chatId,
              '⏳ <b>Your payment proof has been submitted successfully!</b>\nOur admin panel is verifying the network ledger. Please wait for an automated status notification.',
              { parse_mode: 'HTML' }
            );

            // Forward Alert notification directly to Supreme Owner ID
            const alertMsg = `🚨 <b>NEW DEPOSIT REQUEST SUBMITTED</b> 🚨\n\n` +
                             `👤 <b>User:</b> ${msg.from?.first_name || 'Pilot'} (@${msg.from?.username || 'None'})\n` +
                             `🆔 <b>User Chat ID:</b> <code>${chatId}</code>\n` +
                             `💰 <b>Amount:</b> <code>₹${amount}</code> (${rounds} Rounds)\n` +
                             `📝 <b>Proof/UTR:</b> <code>${text.trim()}</code>\n` +
                             `📌 <b>Txn Token ID:</b> <code>${depositRef.id}</code>`;

            const adminMarkup = {
              inline_keyboard: [[
                { text: 'Approve ✅', callback_data: `app_dep:${depositRef.id}` },
                { text: 'Reject ❌', callback_data: `rej_dep:${depositRef.id}` }
              ]]
            };

            await bot.sendMessage(SUPREME_OWNER_ID, alertMsg, { parse_mode: 'HTML', reply_markup: adminMarkup });
          } catch (err: any) {
            console.error('Deposit submission error:', err.message);
            bot.sendMessage(chatId, '❌ System processing failure. Please contact administrator support.');
          }
          return;
        }
      }

      // 5. Signals trigger: "🚀 Fetch Signal (7 Seconds Advance)"
      if (
        text === '🚀 Fetch Signal (7 Seconds Advance)' ||
        text === '🚀 Get Next Round Prediction (7 Sec Before)'
      ) {
        const integrityCheck = await checkChannelsMembership(bot, msg.from?.id || chatId);
        if (!integrityCheck) {
          return bot.sendMessage(
            chatId,
            '⛔ <b>Security Lock!</b> Aapne channels leave kar diye hain. Dubara verify karne ke liye /start type karein.',
            { parse_mode: 'HTML' }
          );
        }

        if (userDatabase[chatId].credits > 0) {
          userDatabase[chatId].credits--;
          userDatabase[chatId].predictionsRequested = (userDatabase[chatId].predictionsRequested || 0) + 1;

          await bot.sendMessage(chatId, '⏳ <i>Connecting to Google AI Studio Live Stream Matrix...</i>', { parse_mode: 'HTML' });

          const realAiX = await generateAiPrediction();
          const maskedSignal = applySmartIllusion(realAiX);

          setTimeout(() => {
            bot.sendMessage(
              chatId,
              `🔮 <b>GHOST GOOGLE AI LIVE SIGNAL</b> 🔮\n⏱️ <i>[ Dispatched exactly 7 seconds before takeoff ]</i>\n────────────────────────\n📈 <b>TARGET VALUE:</b> <code>${maskedSignal}</code>\n🎯 <b>AI CONFIDENCE LEVEL:</b> <code>99.6% Stable</code>\n────────────────────────\n📉 <b>Remaining Balance:</b> <code>${userDatabase[chatId].credits} Loops left</code>`,
              {
                parse_mode: 'HTML',
                protect_content: true // 🔒 Lock signal copy/forward
              }
            );
          }, 2000);
        } else {
          return bot.sendMessage(
            chatId,
            `❌ <b>Zero Credits Available!</b> Wallet empty. Tap Recharge options below to proceed.\n\nTap <b>📱 Dynamic Top-up Calculator</b> or <b>👑 VIP Subscription Pass (₹${globalVipPrice})</b>.`,
            { parse_mode: 'HTML' }
          );
        }
      }

      // 6. VIP Subscription Pass
      if (
        text === `👑 VIP Subscription Pass (₹${globalVipPrice})` ||
        text?.startsWith('👑 VIP Subscription Pass') ||
        text === '👑 VIP Plan (₹149)' ||
        text === '👑 VIP Pass (₹149)'
      ) {
        userDatabase[chatId].lastCalculatedRounds = 32;
        userDatabase[chatId].lastCalculatedTotal = globalVipPrice;
        userDatabase[chatId].context = 'awaiting_payment_proof';
        usersRef.doc(String(chatId)).set({ context: 'awaiting_payment_proof' }, { merge: true }).catch(() => {});

        const vipCleanNotice =
          `👑 <b>WIN NOVA VIP SUBSCRIPTION GATEWAY</b> 👑\n──────────────────────────\n` +
          `💵 <b>VIP Pass Cost:</b> <code>₹${globalVipPrice}</code>\n` +
          `💎 <b>VIP Duration:</b> 30 Days Full Access\n` +
          `🏛️ <b>Merchant UPI ID:</b> <code>${adminUpiId}</code>\n──────────────────────────\n` +
          `Send ₹${globalVipPrice} to <code>${adminUpiId}</code> via any UPI app and reply with your UTR or payment proof here for instant approval.`;

        const qrBuffer = await generateUpiQrCodeBuffer(adminUpiId, globalVipPrice, "WinNova");
        if (qrBuffer) {
          return bot.sendPhoto(chatId, qrBuffer, { caption: vipCleanNotice, parse_mode: 'HTML' });
        }
        return bot.sendMessage(chatId, vipCleanNotice, { parse_mode: 'HTML' });
      }

      // 7. Check Session Status
      if (text === '💼 Check Session Status' || text === '💼 My Status') {
        const user = userDatabase[chatId] || { credits: 0, isPremium: false };
        const status = user.isPremium ? '🥇 Active Premium VIP Pass' : '🥈 Standard Account Data Logs';
        return bot.sendMessage(
          chatId,
          `👤 <b>USER ACCOUNT METRIC LOGS</b>\n───────────────────\n🆔 <b>Session Chat ID:</b> <code>${chatId}</code>\n🏆 <b>Verification Level:</b> <b>${status}</b>\n🔋 <b>Wallet Quota:</b> <code>${user.credits ?? 0} Credits</code>\n───────────────────`,
          { parse_mode: 'HTML', protect_content: true }
        );
      }

      // 8. Official Networks
      if (text === '📢 Official Networks') {
        let netMsg = `<b>📢 WIN NOVA OFFICIAL TELEGRAM NETWORKS:</b>\n\n`;
        OFFICIAL_NETWORKS.forEach(net => {
          netMsg += `• <a href="${net.url}"><b>${net.name}</b></a>: ${net.handle}\n`;
        });
        netMsg += `\n<i>Join all networks for loot codes, transparent live deposit logs, and instant VIP support!</i>`;
        return bot.sendMessage(chatId, netMsg, { parse_mode: 'HTML' });
      }
    });

    // 4. Photo Handler for Screenshots & Payment Proofs
    bot.on('photo', async (msg: any) => {
      const chatId = msg.chat.id;
      const photoArray = msg.photo || [];
      const highestResPhoto = photoArray[photoArray.length - 1];
      const fileId = highestResPhoto?.file_id;

      if (!fileId) return;

      if (userDatabase[chatId]) {
        userDatabase[chatId].context = null;
      }
      usersRef.doc(String(chatId)).set({ context: null }, { merge: true }).catch(() => {});

      const amount = userDatabase[chatId]?.lastCalculatedTotal || globalVipPrice;
      const rounds = userDatabase[chatId]?.lastCalculatedRounds || 32;

      try {
        // 1. ANTI-FRAUD VALIDATION LAYER: Check for duplicate submissions
        const duplicateCheck = await db.collection('deposits')
          .where('proof', '==', fileId)
          .limit(1)
          .get();

        if (!duplicateCheck.empty) {
          return bot.sendMessage(
            chatId,
            "❌ <b>SECURITY ALERT:</b> Duplicate transaction reference or screenshot detected. This request has been flagged by the firewall network.",
            { parse_mode: 'HTML' }
          );
        }

        // Create pending transaction ledger entry in Firestore
        const depositRef = db.collection('deposits').doc();
        const depositPayload = {
          id: depositRef.id,
          chatId: String(chatId),
          username: msg.from?.username || 'None',
          firstName: msg.from?.first_name || 'Pilot',
          amount: amount,
          rounds: rounds,
          proof: fileId,
          isPhoto: true,
          status: 'pending',
          createdAt: AdminFieldValue.serverTimestamp()
        };
        await depositRef.set(depositPayload);

        // Also queue into pendingReceiptQueue for dashboard display
        const queueItem: TelegramReceiptVerification = {
          id: depositRef.id,
          chatId,
          userId: msg.from?.id || chatId,
          username: msg.from?.username || 'Pilot',
          firstName: msg.from?.first_name || 'Pilot',
          demandType: rounds === 32 ? `VIP Pass (₹${amount})` : `${rounds} Rounds Top-up (₹${amount})`,
          roundsDemanded: rounds,
          amount: amount,
          fileId,
          date: new Date().toLocaleTimeString(),
          timestamp: Date.now(),
          status: 'PENDING'
        };
        pendingReceiptQueue.unshift(queueItem);

        // Inform user that processing has initiated
        await bot.sendMessage(
          chatId,
          '⏳ <b>Your payment proof has been submitted successfully!</b>\nOur admin panel is verifying the network ledger. Please wait for an automated status notification.',
          { parse_mode: 'HTML' }
        );

        // Forward Alert notification directly to Supreme Owner ID
        const alertMsg = `🚨 <b>NEW DEPOSIT REQUEST SUBMITTED</b> 🚨\n\n` +
                         `👤 <b>User:</b> ${msg.from?.first_name || 'Pilot'} (@${msg.from?.username || 'None'})\n` +
                         `🆔 <b>User Chat ID:</b> <code>${chatId}</code>\n` +
                         `💰 <b>Amount:</b> <code>₹${amount}</code> (${rounds} Rounds)\n` +
                         `📝 <b>Proof/UTR:</b> [Attached Screenshot Image]\n` +
                         `📌 <b>Txn Token ID:</b> <code>${depositRef.id}</code>`;

        const adminMarkup = {
          inline_keyboard: [[
            { text: 'Approve ✅', callback_data: `app_dep:${depositRef.id}` },
            { text: 'Reject ❌', callback_data: `rej_dep:${depositRef.id}` }
          ]]
        };

        await bot.sendPhoto(SUPREME_OWNER_ID, fileId, {
          caption: alertMsg,
          parse_mode: 'HTML',
          reply_markup: adminMarkup
        }).catch(async (err: any) => {
          console.warn('[SEND PHOTO ALERT NOTE]:', err.message);
          await bot.sendMessage(SUPREME_OWNER_ID, alertMsg, { parse_mode: 'HTML', reply_markup: adminMarkup });
        });

        if (options?.onScreenshotReceived) {
          options.onScreenshotReceived({
            chatId,
            userId: msg.from?.id,
            username: msg.from?.username,
            fileId,
            timestamp: Date.now()
          });
        }
      } catch (err: any) {
        console.error('Deposit submission error:', err.message);
        bot.sendMessage(chatId, '❌ System processing failure. Please contact administrator support.');
      }
    });

    // ==========================================
    // 🔔 MASTER HUB BOT (@thakkujackbot) - EXACT 7-BUTTON CUSTOM GRID LAYOUT
    // ==========================================
    masterHubBot.onText(/\/start/, async (msg: any) => {
      const chatId = msg.chat.id;
      const userId = Number(msg.from?.id || chatId);

      if (userId !== ADMIN_ID && userId !== SUPREME_OWNER_ID) {
        return masterHubBot.sendMessage(chatId, "❌ Access Denied: Unauthorized terminal access attempt.");
      }

      return masterHubBot.sendMessage(
        chatId,
        `🔔 <b>Thakku Payment Notification Hub Active (@thakkujackbot)</b>\n\nManaging payment approvals, rate calibrations, and merchant QR deployment natively.\n\nSelect a control operation:`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            keyboard: [
              [{ text: '✅ Approve Last Deposit' }, { text: '❌ Reject Last Deposit' }],
              [{ text: '⚙️ Edit Sub Rate' }, { text: '🪙 Edit Credit Slabs' }],
              [{ text: '📊 Bot Stats & Logs' }, { text: '📢 Fast Broadcast' }],
              [{ text: '🖼️ Upload New UPI QR' }]
            ],
            resize_keyboard: true
          }
        }
      );
    });

    masterHubBot.on('message', async (msg: any) => {
      const chatId = msg.chat.id;
      const userId = Number(msg.from?.id || chatId);
      const text = msg.text;

      if (userId !== ADMIN_ID && userId !== SUPREME_OWNER_ID) return;
      if (!text) return;

      if (text === '✅ Approve Last Deposit') {
        const pending = pendingReceiptQueue.find(q => q.status === 'PENDING');
        if (pending) {
          await processDepositVerification(pending.id, 'approve', 'telegram', bot);
          return masterHubBot.sendMessage(chatId, `✅ Transaction <code>${pending.id}</code> successfully approved for User <code>${pending.userId}</code>!`, { parse_mode: 'HTML' });
        }
        return masterHubBot.sendMessage(chatId, "⚠️ No pending deposit found in the active verification buffer.", { parse_mode: 'HTML' });
      }

      if (text === '❌ Reject Last Deposit') {
        const pending = pendingReceiptQueue.find(q => q.status === 'PENDING');
        if (pending) {
          await processDepositVerification(pending.id, 'reject', 'telegram', bot);
          return masterHubBot.sendMessage(chatId, `❌ Transaction <code>${pending.id}</code> marked as rejected.`, { parse_mode: 'HTML' });
        }
        return masterHubBot.sendMessage(chatId, "⚠️ No pending deposit found in the active verification buffer.", { parse_mode: 'HTML' });
      }

      if (text === '⚙️ Edit Sub Rate') {
        return masterHubBot.sendMessage(
          chatId,
          `⚙️ <b>Current VIP Rate:</b> ₹${globalVipPrice}\n\nType <code>/set_vip_price [Amount]</code> on main bot or use the Admin Web Dashboard to update instantly.`,
          { parse_mode: 'HTML' }
        );
      }

      if (text === '🪙 Edit Credit Slabs') {
        return masterHubBot.sendMessage(
          chatId,
          `🪙 <b>Tiered Slabs:</b>\n• 10 Credits: ₹32\n• 100 Credits: ₹315\n\nRate: ₹${globalCreditRate}/credit. Manage dynamically via Admin Web Dashboard.`,
          { parse_mode: 'HTML' }
        );
      }

      if (text === '📊 Bot Stats & Logs') {
        const liveCount = await getTotalUserCount();
        const logCount = await BotLog.countDocuments().catch(() => 0);
        return masterHubBot.sendMessage(
          chatId,
          `📊 <b>FINANCIAL & TELEMETRY DASHBOARD</b>\n\n👥 <b>Total Registered:</b> <code>${liveCount} Players</code>\n📝 <b>Logged Operations:</b> <code>${logCount} Records</code>\n💳 <b>Active VIP Price:</b> ₹${globalVipPrice}\n⚡ <b>Engine Health:</b> 100% Operational`,
          { parse_mode: 'HTML' }
        );
      }

      if (text === '📢 Fast Broadcast') {
        return masterHubBot.sendMessage(
          chatId,
          `📢 <b>Fast Broadcast:</b>\nUse command <code>/promo_blast</code> or dispatch announcements from the Web Dashboard.`,
          { parse_mode: 'HTML' }
        );
      }

      if (text === '🖼️ Upload New UPI QR') {
        return masterHubBot.sendMessage(
          chatId,
          `📸 <b>Upload New UPI QR Code:</b>\nPlease send your new QR code screenshot right now. The server backend will capture and overwrite <code>/public/uploads/admin-qr.png</code> natively.`,
          { parse_mode: 'HTML' }
        );
      }
    });

    masterHubBot.on('photo', async (msg: any) => {
      const chatId = msg.chat.id;
      const userId = Number(msg.from?.id || chatId);
      if (userId !== ADMIN_ID && userId !== SUPREME_OWNER_ID) return;

      const photoArray = msg.photo || [];
      const highestResPhoto = photoArray[photoArray.length - 1];
      const fileId = highestResPhoto?.file_id;
      if (!fileId) return;

      try {
        const fileLink = await masterHubBot.getFileLink(fileId);
        const uploadsDir = path.resolve(process.cwd(), 'public', 'uploads');
        if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
        const dest = path.join(uploadsDir, 'admin-qr.png');

        const response = await axios({ url: fileLink, responseType: 'stream' });
        const writer = fs.createWriteStream(dest);
        response.data.pipe(writer);

        writer.on('finish', () => {
          masterHubBot.sendMessage(chatId, "✅ <b>Success:</b> Admin UPI QR image received and auto-overwritten natively inside /public/uploads/admin-qr.png!", { parse_mode: 'HTML' });
        });
        writer.on('error', (err: any) => {
          masterHubBot.sendMessage(chatId, `❌ Write fault: ${err.message}`);
        });
      } catch (err: any) {
        masterHubBot.sendMessage(chatId, `❌ QR overwrite fault: ${err.message}`);
      }
    });

    // ==========================================
    // WEBHOOK EXPRESS ROUTES
    // ==========================================
    const handleWebhookUpdate = async (req: Request, res: Response) => {
      try {
        if (req.body && typeof req.body === 'object') {
          await bot.processUpdate(req.body);
        }
        res.sendStatus(200);
      } catch (err: any) {
        console.warn('[TELEGRAM BOT] Webhook processing error:', err.message);
        res.sendStatus(200);
      }
    };

    app.post('/telegram-webhook', handleWebhookUpdate);
    app.post('/api/telegram-webhook', handleWebhookUpdate);

    app.get('/api/telegram/status', (_req, res) => {
      res.json({
        success: true,
        botActive: true,
        webhookUrl: currentWebhookUrl,
        totalUsers: Object.keys(userDatabase).length,
        requiredChannels: REQUIRED_CHANNELS,
        officialNetworks: OFFICIAL_NETWORKS,
        activeApiKeyIndex: currentKeyIndex
      });
    });

    app.post('/api/telegram/set-webhook', async (req, res) => {
      const { url } = req.body || {};
      const targetUrl = url || `${req.protocol}://${req.get('host')}/telegram-webhook`;
      try {
        await bot.setWebHook(targetUrl);
        currentWebhookUrl = targetUrl;
        res.json({ success: true, message: `Webhook set to ${targetUrl}`, webhookUrl: targetUrl });
      } catch (err: any) {
        res.status(500).json({ success: false, error: err.message });
      }
    });

    // Endpoint to simulate /start for testing
    app.post('/api/telegram/test-start', async (req, res) => {
      const { chatId = 999999999, firstName = 'Pilot' } = req.body || {};
      if (!userDatabase[chatId]) {
        userDatabase[chatId] = {
          credits: 10,
          isPremium: false,
          registeredAt: Date.now(),
          lastActiveAt: Date.now(),
          predictionsRequested: 0,
          firstName
        };
      }
      res.json({
        success: true,
        message: 'Simulation of /start executed',
        user: userDatabase[chatId],
        requiredChannels: REQUIRED_CHANNELS,
        menuKeyboard: [
          ['🚀 Fetch Signal (7 Seconds Advance)'],
          ['🔋 Top-up (₹3/Rd)', '👑 VIP Plan (₹149)'],
          ['💼 Check Session Status', '📢 Official Networks']
        ]
      });
    });

    // Endpoint to simulate signal prediction fetch for web preview
    app.post('/api/telegram/test-signal', async (req, res) => {
      const { chatId = 999999999 } = req.body || {};
      if (!userDatabase[chatId]) {
        userDatabase[chatId] = {
          credits: 10,
          isPremium: false,
          registeredAt: Date.now(),
          lastActiveAt: Date.now(),
          predictionsRequested: 0,
          firstName: 'Pilot'
        };
      }

      if (userDatabase[chatId].credits <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Zero Credits Available! Wallet empty. Please recharge.',
          credits: 0
        });
      }

      userDatabase[chatId].credits--;
      userDatabase[chatId].predictionsRequested++;

      const signalMultiplier = await generateAiPrediction();
      const maskedSignal = applySmartIllusion(signalMultiplier);

      res.json({
        success: true,
        multiplier: maskedSignal,
        confidence: '99.6% Stable',
        remainingCredits: userDatabase[chatId].credits,
        signalsClaimed: userDatabase[chatId].predictionsRequested,
        protectContent: true,
        timingNotice: 'Dispatched exactly 7 seconds before takeoff'
      });
    });

    // Endpoint for Admin Dashboard to trigger Promo Blast to all 0-credit inactive users
    app.post('/api/telegram/promo-blast', async (_req, res) => {
      let count = 0;
      const userKeys = Object.keys(userDatabase);

      for (const userChatId of userKeys) {
        if (userDatabase[userChatId].credits === 0) {
          try {
            await bot.sendMessage(
              userChatId,
              `🎁 <b>MASTERMIND WEEKEND BONUS FLASH!</b> 🎁\n──────────────────────────\nHi Player! We noticed your prediction panel is inactive.\n\nAdmin has credited <b>2 FREE BONUS CREDITS</b> into your account for the next 2 hours only! Go test the 7-second advance accuracy right now!\n──────────────────────────\n🚀 Type /start to activate your dashboard.`,
              { parse_mode: 'HTML', protect_content: true }
            );
            userDatabase[userChatId].credits = 2;
            count++;
          } catch (e: any) {
            console.warn(`[PROMO BLAST API] Failed to notify ${userChatId}:`, e.message);
          }
        }
      }

      res.json({
        success: true,
        message: `Promo Blast executed successfully to all inactive users! Credited 2 bonus credits to ${count} users.`,
        creditedUsers: count,
        totalUsers: userKeys.length
      });
    });

    // ==========================================
    // 🛡️ SUB-ADMIN RBAC AUTH MIDDLEWARE
    // ==========================================
    async function verifyBotAdminAuth(req: Request, res: Response, requiredPermission?: string) {
      const authHeader = req.headers.authorization || '';
      const adminKey = (req.headers['x-admin-key'] as string) || (req.query.adminKey as string) || (authHeader.startsWith('Bearer ') ? authHeader.slice(7) : authHeader);

      // Supreme Admin Master Key bypass
      if (adminKey === 'supreme_jack_7939005883' || adminKey === String(ADMIN_ID) || adminKey === String(SUPREME_OWNER_ID)) {
        return { isSupreme: true, username: 'Supreme Architect Jack' };
      }

      if (!adminKey) {
        res.status(401).json({ status: 'error', message: 'Authentication token required' });
        return null;
      }

      let subAdmin: any = null;
      if (mongoose.connection.readyState === 1) {
        subAdmin = await SubAdmin.findOne({ token: adminKey }).lean().catch(() => null);
      } else {
        subAdmin = inMemorySubAdmins.get(adminKey);
      }

      if (!subAdmin) {
        res.status(403).json({ status: 'error', message: 'Invalid or expired Sub-Admin credentials' });
        return null;
      }

      if (requiredPermission && !subAdmin[requiredPermission]) {
        res.status(403).json({
          status: 'error',
          message: `Permission Denied: '${requiredPermission}' required. Contact Supreme Admin.`
        });
        return null;
      }

      return { isSupreme: false, username: subAdmin.username, permissions: subAdmin };
    }

    // Sub-Admin Login Endpoint
    app.post('/api/admin/login', async (req: Request, res: Response) => {
      try {
        const { username, password } = req.body || {};
        if (!username || !password) return res.status(400).json({ error: 'Username and password required' });

        if (username === 'admin' && password === 'jack7939005883') {
          return res.json({
            success: true,
            token: 'supreme_jack_7939005883',
            role: 'supreme_admin',
            permissions: {
              canManageTelegramBot: true,
              canManageRates: true,
              canManageUPI: true,
              canBroadcast: true
            }
          });
        }

        let sub: any = null;
        if (mongoose.connection.readyState === 1) {
          sub = await SubAdmin.findOne({ username, password });
        } else {
          sub = Array.from(inMemorySubAdmins.values()).find((s: any) => s.username === username && s.password === password);
        }

        if (!sub) return res.status(401).json({ error: 'Invalid username or password' });

        const sessionToken = `sub_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
        if (mongoose.connection.readyState === 1) {
          await SubAdmin.findOneAndUpdate({ username }, { token: sessionToken });
        } else {
          sub.token = sessionToken;
          inMemorySubAdmins.set(sessionToken, sub);
        }

        return res.json({
          success: true,
          token: sessionToken,
          role: 'sub_admin',
          permissions: {
            canManageTelegramBot: !!sub.canManageTelegramBot,
            canManageRates: !!sub.canManageRates,
            canManageUPI: !!sub.canManageUPI,
            canBroadcast: !!sub.canBroadcast
          }
        });
      } catch (err: any) {
        return res.status(500).json({ error: err.message });
      }
    });

    // Sub-Admin Management (Supreme Admin only)
    app.get('/api/admin/sub-admins', async (req: Request, res: Response) => {
      const auth = await verifyBotAdminAuth(req, res);
      if (!auth) return;
      if (!auth.isSupreme) return res.status(403).json({ error: 'Only Supreme Admin can manage Sub-Admins' });

      let list: any[] = [];
      if (mongoose.connection.readyState === 1) {
        list = await SubAdmin.find({}).select('-password').lean().catch(() => []);
      } else {
        list = Array.from(inMemorySubAdmins.values()).map((s: any) => {
          const { password, ...rest } = s;
          return rest;
        });
      }
      return res.json({ success: true, subAdmins: list });
    });

    app.post('/api/admin/sub-admins', async (req: Request, res: Response) => {
      const auth = await verifyBotAdminAuth(req, res);
      if (!auth) return;
      if (!auth.isSupreme) return res.status(403).json({ error: 'Only Supreme Admin can create/edit Sub-Admins' });

      const { username, password, canManageTelegramBot, canManageRates, canManageUPI, canBroadcast } = req.body || {};
      if (!username) return res.status(400).json({ error: 'Username required' });

      const updateData: any = {
        canManageTelegramBot: Boolean(canManageTelegramBot),
        canManageRates: Boolean(canManageRates),
        canManageUPI: Boolean(canManageUPI),
        canBroadcast: Boolean(canBroadcast)
      };
      if (password) updateData.password = password;

      if (mongoose.connection.readyState === 1) {
        await SubAdmin.findOneAndUpdate({ username }, { $set: updateData }, { upsert: true, new: true });
      } else {
        const existing = Array.from(inMemorySubAdmins.values()).find((s: any) => s.username === username) || { username, password: password || 'sub123' };
        Object.assign(existing, updateData);
        inMemorySubAdmins.set(existing.token || username, existing);
      }

      return res.json({ success: true, message: `Sub-Admin '${username}' updated successfully` });
    });

    // Dynamic Rates Management (Single Source of Truth)
    app.post(['/api/admin/rates', '/api/update-settings', '/api/telegram/update-settings'], async (req: Request, res: Response) => {
      const auth = await verifyBotAdminAuth(req, res, 'canManageRates');
      if (!auth) return;

      try {
        const { subRate, vipPrice, creditRate, upiId, webUrl, taxPercent, commissionPercent } = req.body || {};
        const updates: any = {};
        const newSubRate = subRate !== undefined ? Number(subRate) : (vipPrice !== undefined ? Number(vipPrice) : undefined);
        if (newSubRate !== undefined && !isNaN(newSubRate)) updates.baseSubRate = newSubRate;
        if (creditRate !== undefined && !isNaN(Number(creditRate))) updates.creditRate = Number(creditRate);
        if (taxPercent !== undefined && !isNaN(Number(taxPercent))) updates.taxPercent = Number(taxPercent);
        if (commissionPercent !== undefined && !isNaN(Number(commissionPercent))) updates.commissionPercent = Number(commissionPercent);
        if (upiId && typeof upiId === 'string' && upiId.trim()) updates.adminUpiId = upiId.trim();
        if (webUrl && typeof webUrl === 'string' && webUrl.trim()) updates.dynamicWebsiteUrl = webUrl.trim();

        let updatedDbSettings: any = null;
        if (mongoose.connection.readyState === 1) {
          const updated = await AdminSettings.findOneAndUpdate(
            { id: 1 },
            updates,
            { upsert: true, new: true }
          );
          if (updated) {
            updatedDbSettings = updated;
            if (updated.baseSubRate != null) globalVipPrice = updated.baseSubRate;
            if (updated.creditRate != null) globalCreditRate = updated.creditRate;
            if (updated.adminUpiId) adminUpiId = updated.adminUpiId;
          }
        } else {
          if (updates.baseSubRate != null) globalVipPrice = updates.baseSubRate;
          if (updates.creditRate != null) globalCreditRate = updates.creditRate;
          if (updates.adminUpiId) adminUpiId = updates.adminUpiId;
        }

        console.log(`📡 [ADMIN CONTROL] Settings Synchronized: VIP Cost = ₹${globalVipPrice}, UPI = ${adminUpiId}`);
        return res.json({
          status: 'success',
          success: true,
          message: 'Settings updated permanently in RAM & DB',
          config: {
            baseSubRate: globalVipPrice,
            creditRate: globalCreditRate,
            taxPercent: updatedDbSettings?.taxPercent ?? updates.taxPercent ?? 5,
            commissionPercent: updatedDbSettings?.commissionPercent ?? updates.commissionPercent ?? 10,
            adminUpiId,
            dynamicWebsiteUrl: options?.websiteUrl || 'http://localhost:3000'
          }
        });
      } catch (err: any) {
        return res.status(500).json({ status: 'error', success: false, message: err.message });
      }
    });

    // ==========================================
    // THAKKU BOT - ADMIN CONTROL CENTRE API ROUTES
    // ==========================================
    app.get(['/api/admin/stats', '/api/admin/bot-stats'], async (_req: Request, res: Response) => {
      try {
        let dbUsers: any[] = [];
        let totalLogs = 0;
        let recentLogs: any[] = [];
        try {
          dbUsers = await BotUser.find({}).sort({ joinedAt: -1 }).limit(200).lean();
          totalLogs = await BotLog.countDocuments({});
          recentLogs = await BotLog.find({}).sort({ timestamp: -1 }).limit(50).lean();
        } catch (e) {}

        const inMemoryUsers = Object.entries(userDatabase).map(([id, u]: [string, any]) => ({
          telegramId: Number(id),
          username: u.username || '',
          firstName: u.firstName || 'Pilot',
          role: u.role === 'super_admin' ? 'Admin' : (u.role || 'user'),
          activeSubscription: Boolean(u.isPremium),
          creditBalance: u.credits ?? 0,
          totalCreditsEarned: u.credits ?? 0,
          totalReferrals: u.dailyReferralCount ?? 0,
          isBanned: u.role === 'banned',
          joinedAt: new Date(u.registeredAt || Date.now())
        }));

        const map = new Map<number, any>();
        inMemoryUsers.forEach(u => map.set(u.telegramId, u));
        dbUsers.forEach(u => {
          const inMem = map.get(u.telegramId);
          map.set(u.telegramId, {
            telegramId: u.telegramId,
            username: u.username || inMem?.username || '',
            firstName: u.firstName || inMem?.firstName || 'Pilot',
            role: u.role === 'super_admin' || u.telegramId === ADMIN_ID ? 'Admin' : (u.role || inMem?.role || 'user'),
            activeSubscription: Boolean(u.activeSubscription || inMem?.activeSubscription),
            creditBalance: u.creditBalance ?? inMem?.creditBalance ?? 0,
            totalCreditsEarned: u.totalCreditsEarned ?? u.creditBalance ?? inMem?.totalCreditsEarned ?? 0,
            totalReferrals: u.totalReferrals ?? u.dailyReferralCount ?? inMem?.totalReferrals ?? 0,
            isBanned: Boolean(u.isBanned || u.role === 'banned' || inMem?.isBanned),
            joinedAt: u.joinedAt || inMem?.joinedAt || new Date()
          });
        });

        if (!map.has(ADMIN_ID)) {
          map.set(ADMIN_ID, {
            telegramId: ADMIN_ID,
            username: 'jackhype7',
            firstName: 'Developer Jack',
            role: 'Admin',
            activeSubscription: true,
            creditBalance: 999999,
            totalCreditsEarned: 999999,
            totalReferrals: 0,
            isBanned: false,
            joinedAt: new Date()
          });
        }

        const rawList = Array.from(map.values());
        const totalSystemCredits = rawList.reduce((acc, u) => acc + (u.creditBalance || 0), 0);

        const enrichedUsers = rawList.map(u => ({
          ...u,
          poolPercentageShare: totalSystemCredits > 0 ? Number((((u.creditBalance || 0) / totalSystemCredits) * 100).toFixed(2)) : 0
        })).sort((a, b) => (b.creditBalance || 0) - (a.creditBalance || 0));

        let currentSettings = {
          baseSubRate: globalVipPrice,
          creditRate: globalCreditRate,
          adminUpiId,
          dynamicWebsiteUrl: options?.websiteUrl || 'http://localhost:3000'
        };
        try {
          if (mongoose.connection.readyState === 1) {
            const dbSet = await AdminSettings.findOne({ id: 1 }).lean();
            if (dbSet) {
              currentSettings = {
                baseSubRate: dbSet.baseSubRate ?? globalVipPrice,
                creditRate: dbSet.creditRate ?? globalCreditRate,
                adminUpiId: dbSet.adminUpiId || adminUpiId,
                dynamicWebsiteUrl: dbSet.dynamicWebsiteUrl || (options?.websiteUrl || 'http://localhost:3000')
              };
            }
          }
        } catch (_) {}

        return res.json({
          success: true,
          stats: {
            totalUsers: enrichedUsers.length,
            totalLogs: Math.max(totalLogs, 42)
          },
          totalUsers: enrichedUsers.length,
          totalSystemCredits,
          totalLogs: Math.max(totalLogs, 42),
          systemMode: 'Long Polling Mode (Conflict-Proof Sync)',
          adminId: ADMIN_ID,
          config: currentSettings,
          users: enrichedUsers,
          recentUsers: enrichedUsers.slice(0, 50),
          recentLogs
        });
      } catch (err: any) {
        return res.status(500).json({ success: false, error: err.message });
      }
    });

    app.post('/api/admin/broadcast', async (req: Request, res: Response) => {
      const auth = await verifyBotAdminAuth(req, res, 'canBroadcast');
      if (!auth) return;

      const { message } = req.body || {};
      if (!message || typeof message !== 'string' || !message.trim()) {
        return res.status(400).json({ success: false, message: 'Message content is required.' });
      }

      let sentCount = 0;
      let targetIds = new Set<number>();
      targetIds.add(ADMIN_ID);

      try {
        const users = await BotUser.find({ isBanned: false }).select('telegramId').lean();
        users.forEach((u: any) => targetIds.add(Number(u.telegramId)));
      } catch (e) {}

      Object.keys(userDatabase).forEach(id => targetIds.add(Number(id)));

      for (const tId of targetIds) {
        try {
          await bot.sendMessage(
            tId,
            `📢 <b>OFFICIAL PREDICTION BROADCAST</b>\n──────────────────────────\n${message.trim()}\n──────────────────────────\n🚀 <i>Verified by Thakku Bot Admin</i>`,
            { parse_mode: 'HTML' }
          );
          sentCount++;
        } catch (e) {}
      }

      return res.json({
        success: true,
        message: `Broadcast successfully dispatched to ${sentCount} recipient(s)!`,
        deliveredCount: sentCount
      });
    });

    app.post('/api/admin/ban-user', async (req: Request, res: Response) => {
      const auth = await verifyBotAdminAuth(req, res, 'canManageTelegramBot');
      if (!auth) return;

      const { telegramId, ban } = req.body || {};
      const numId = Number(telegramId);
      if (!numId) return res.status(400).json({ success: false, message: 'Valid telegramId required' });
      if (numId === ADMIN_ID || numId === SUPREME_OWNER_ID) return res.status(403).json({ success: false, message: 'Cannot ban Supreme Admin.' });

      try {
        const newRole = ban ? 'banned' : 'user';
        if (mongoose.connection.readyState === 1) {
          await BotUser.findOneAndUpdate({ telegramId: numId }, { role: newRole, isBanned: Boolean(ban) }, { new: true }).catch(() => {});
        }
        if (userDatabase[numId]) {
          userDatabase[numId].role = newRole as any;
          userDatabase[numId].isBanned = Boolean(ban);
        }
        return res.json({ success: true, message: `User ${numId} status set to ${newRole}.` });
      } catch (err: any) {
        return res.status(500).json({ success: false, error: err.message });
      }
    });

    // Master User Data Update Endpoint (Credits, VIP, Role, Bans)
    app.post('/api/admin/update-user', async (req: Request, res: Response) => {
      const auth = await verifyBotAdminAuth(req, res, 'canManageTelegramBot');
      if (!auth) return;

      const { telegramId, creditBalance, deltaCredits, activeSubscription, isBanned, role } = req.body || {};
      const numId = Number(telegramId);
      if (!numId) return res.status(400).json({ success: false, message: 'Valid telegramId required' });

      try {
        const updateFields: any = {};
        if (creditBalance !== undefined && !isNaN(Number(creditBalance))) {
          updateFields.creditBalance = Number(creditBalance);
        }
        if (activeSubscription !== undefined) {
          updateFields.activeSubscription = Boolean(activeSubscription);
        }
        if (isBanned !== undefined) {
          updateFields.isBanned = Boolean(isBanned);
          if (isBanned) updateFields.role = 'banned';
        }
        if (role && typeof role === 'string') {
          updateFields.role = role;
        }

        let updatedDoc = null;
        if (mongoose.connection.readyState === 1) {
          if (deltaCredits !== undefined && !isNaN(Number(deltaCredits))) {
            updatedDoc = await BotUser.findOneAndUpdate(
              { telegramId: numId },
              { $inc: { creditBalance: Number(deltaCredits), totalCreditsEarned: Math.max(0, Number(deltaCredits)) }, $set: updateFields },
              { upsert: true, new: true }
            );
          } else {
            updatedDoc = await BotUser.findOneAndUpdate(
              { telegramId: numId },
              { $set: updateFields },
              { upsert: true, new: true }
            );
          }
        }

        if (userDatabase[numId]) {
          if (updateFields.creditBalance !== undefined) userDatabase[numId].credits = updateFields.creditBalance;
          if (deltaCredits !== undefined) userDatabase[numId].credits = (userDatabase[numId].credits || 0) + Number(deltaCredits);
          if (updateFields.activeSubscription !== undefined) {
            userDatabase[numId].isPremium = updateFields.activeSubscription;
            userDatabase[numId].activeSubscription = updateFields.activeSubscription;
          }
          if (updateFields.isBanned !== undefined) userDatabase[numId].isBanned = updateFields.isBanned;
          if (updateFields.role) userDatabase[numId].role = updateFields.role;
        }

        return res.json({
          success: true,
          message: `User ${numId} updated successfully`,
          user: updatedDoc || userDatabase[numId]
        });
      } catch (err: any) {
        return res.status(500).json({ success: false, error: err.message });
      }
    });

    // Telemetry Crash Multiplier Override Endpoint
    app.post('/api/admin/set-next-mult', async (req: Request, res: Response) => {
      const auth = await verifyBotAdminAuth(req, res, 'canManageRates');
      if (!auth) return;

      const { multiplier } = req.body || {};
      const mult = parseFloat(multiplier);
      if (isNaN(mult) || mult < 1.0) {
        return res.status(400).json({ success: false, message: 'Valid multiplier >= 1.0 is required' });
      }

      liveTelemetryState.nextRoundMultiplier = mult;
      return res.json({
        success: true,
        message: `Next crash target multiplier overridden to ${mult}x`,
        nextRoundMultiplier: mult
      });
    });

    // Pending Manual Verification Queue (Receipt Proof Checks)
    app.get('/api/telegram/receipt-queue', (_req: Request, res: Response) => {
      return res.json({
        success: true,
        queue: pendingReceiptQueue,
        currentVipPrice: globalVipPrice,
        currentUpi: adminUpiId
      });
    });

    // Admin 1-Click Approve / Reject Receipt
    app.post('/api/telegram/approve-receipt', (req: Request, res: Response) => {
      const { receiptId, action } = req.body || {};
      const item = pendingReceiptQueue.find(r => r.id === receiptId);
      if (!item) {
        return res.status(404).json({ success: false, message: 'Receipt request not found in queue.' });
      }

      if (action === 'REJECT') {
        item.status = 'REJECTED';
        bot.sendMessage(
          item.chatId,
          `❌ <b>PAYMENT RECEIPT NOT VERIFIED</b> ❌\n\nAdmin could not verify your transfer proof. Please re-check UPI ID & payment screenshot, and try again.`,
          { parse_mode: 'HTML' }
        );
        return res.json({ success: true, message: 'Receipt rejected successfully.' });
      }

      item.status = 'APPROVED';
      if (item.demandType.toLowerCase().includes('vip') || item.roundsDemanded === 32) {
        processAdminVipApproval(item.chatId);
      } else {
        processAdminCustomTopupApproval(item.chatId, item.roundsDemanded || 10);
      }

      return res.json({
        success: true,
        message: 'Receipt verified & approved! Credits/VIP released live.'
      });
    });

    // ==========================================
    // EXTERNAL WEB DASHBOARD CONTROL ROUTE API: /api/verify-deposit
    // ==========================================
    app.post(['/api/telegram-webhook', '/api/telegram/prediction-bot-webhook'], async (req: Request, res: Response) => {
      try {
        const update = req.body;
        if (update && typeof update === 'object') {
          await bot.processUpdate(update);
        }
        return res.status(200).json({ ok: true });
      } catch (err: any) {
        return res.status(200).json({ ok: true });
      }
    });

    app.get('/api/telegram/status', async (req: Request, res: Response) => {
      try {
        const me = await bot.getMe();
        return res.json({
          status: 'online',
          bot: me?.result?.username || 'Thakku67bot',
          tokenConfigured: true,
          supremeOwnerId: SUPREME_OWNER_ID
        });
      } catch (err: any) {
        return res.json({ status: 'active', error: err.message });
      }
    });

    app.post('/api/verify-deposit', async (req: Request, res: Response) => {
      const { depositId, action, secretKey } = req.body || {};

      const allowedSecrets = [
        "YOUR_SUPER_SECRET_WEB_PASSPHRASE",
        "Faisal786",
        process.env.ADMIN_SECRET_KEY,
        process.env.SUPER_ADMIN_PASSWORD
      ].filter(Boolean);

      if (!secretKey || !allowedSecrets.includes(secretKey)) {
        return res.status(401).json({ success: false, message: "Unauthorized API gateway query parameters" });
      }

      if (action !== "approve" && action !== "reject") {
        return res.status(400).json({ success: false, message: "Invalid action routing query parameters parameter" });
      }

      try {
        const apiResponse = await processDepositVerification(depositId, action, "web", bot);
        if (!apiResponse.success) {
          return res.status(400).json(apiResponse);
        }
        return res.json(apiResponse);
      } catch (err: any) {
        return res.status(500).json({ success: false, error: err.message });
      }
    });

    // ==========================================
    // WEB INTEGRATION: ADMINISTRATIVE MANAGEMENT ROUTE: /api/manage-admin
    // ==========================================
    app.post('/api/manage-admin', async (req: Request, res: Response) => {
      const { action, targetAdminId, secretKey } = req.body || {};

      const allowedSecrets = [
        "YOUR_SUPER_SECRET_WEB_PASSPHRASE",
        "Faisal786",
        process.env.ADMIN_SECRET_KEY,
        process.env.SUPER_ADMIN_PASSWORD
      ].filter(Boolean);

      if (!secretKey || !allowedSecrets.includes(secretKey)) {
        return res.status(401).json({ success: false, message: "Unauthorized API attempt" });
      }

      try {
        const adminDocRef = db.collection('settings').doc('admins');
        const doc = await adminDocRef.get();
        let currentAdmins: string[] = doc.exists ? (doc.data()?.adminList || []) : [];

        if (action === "add") {
          if (targetAdminId && !currentAdmins.includes(String(targetAdminId))) {
            currentAdmins.push(String(targetAdminId));
          }
        } else if (action === "remove") {
          currentAdmins = currentAdmins.filter(id => id !== String(targetAdminId));
        }

        await adminDocRef.set({ adminList: currentAdmins, updatedAt: new Date().toISOString() }, { merge: true });
        return res.json({ success: true, currentAdminList: currentAdmins, supremeOwnerId: SUPREME_OWNER_ID });
      } catch (err: any) {
        return res.status(500).json({ success: false, error: err.message });
      }
    });

    app.get('/api/manage-admin', async (_req: Request, res: Response) => {
      try {
        const adminDocRef = db.collection('settings').doc('admins');
        const doc = await adminDocRef.get();
        const currentAdmins: string[] = doc.exists ? (doc.data()?.adminList || []) : [];
        return res.json({
          success: true,
          supremeOwnerId: SUPREME_OWNER_ID,
          adminList: currentAdmins
        });
      } catch (err: any) {
        return res.status(500).json({ success: false, error: err.message });
      }
    });

    // Endpoint for fetching manual deposits from Firestore
    app.get('/api/deposits', async (_req: Request, res: Response) => {
      try {
        const snapshot = await db.collection('deposits').limit(100).get();
        const depositList = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        return res.json({ success: true, deposits: depositList });
      } catch (err: any) {
        return res.status(500).json({ success: false, error: err.message });
      }
    });

    // Test Endpoints for owner commands testing from simulator/REST
    app.post('/api/telegram/test-check', async (req: Request, res: Response) => {
      const { targetId } = req.body || {};
      if (!targetId) return res.status(400).json({ success: false, message: 'targetId required' });

      let userDoc = await usersRef.doc(String(targetId)).get();
      if (!userDoc.exists) {
        if (userDatabase[targetId]) {
          await usersRef.doc(String(targetId)).set({
            chatId: String(targetId),
            credits: userDatabase[targetId].credits ?? 0,
            isPremium: !!userDatabase[targetId].isPremium,
            context: userDatabase[targetId].context || null,
            role: userDatabase[targetId].role || 'user',
            registeredAt: userDatabase[targetId].registeredAt || Date.now(),
            lastActiveAt: Date.now()
          }, { merge: true });
          userDoc = await usersRef.doc(String(targetId)).get();
        } else {
          return res.status(404).json({ success: false, message: 'User not found in Firestore database.' });
        }
      }
      return res.json({ success: true, data: userDoc.data() });
    });

    app.post('/api/telegram/test-give-credit', async (req: Request, res: Response) => {
      const { targetId, amount } = req.body || {};
      const numAmount = parseInt(String(amount), 10);
      if (!targetId || isNaN(numAmount)) return res.status(400).json({ success: false, message: 'targetId and valid amount required' });

      await usersRef.doc(String(targetId)).set({
        credits: AdminFieldValue.increment(numAmount),
        lastActiveAt: Date.now()
      }, { merge: true });

      if (userDatabase[targetId]) {
        userDatabase[targetId].credits = (userDatabase[targetId].credits || 0) + numAmount;
      }
      return res.json({ success: true, message: `Successfully added ${numAmount} credits to ${targetId}` });
    });

    app.post('/api/telegram/test-set-vip', async (req: Request, res: Response) => {
      const { targetId, isVip } = req.body || {};
      const isVipBool = isVip === true || isVip === 'true';
      if (!targetId) return res.status(400).json({ success: false, message: 'targetId required' });

      await usersRef.doc(String(targetId)).set({
        isPremium: isVipBool,
        lastActiveAt: Date.now()
      }, { merge: true });

      if (userDatabase[targetId]) {
        userDatabase[targetId].isPremium = isVipBool;
      }
      return res.json({ success: true, message: `User ${targetId} VIP set to ${isVipBool}` });
    });

    // 👑 Super Admin - Protected Telegram Controller Page (Full Screen Dashboard)
    app.get('/superadmin/telegram-controller', (_req: Request, res: Response) => {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>👑 Super Admin - Protected Telegram Controller</title>
    <style>
        body { background-color: #0b0c10; color: #c5c6c7; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 20px; margin: 0; }
        .dashboard { max-width: 1400px; margin: 0 auto; }
        .header { border-bottom: 2px solid #66fcf1; padding-bottom: 12px; margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
        .header h1 { color: #66fcf1; margin: 0; font-size: 22px; letter-spacing: 1px; display: flex; align-items: center; gap: 8px; }
        .header-badges { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
        .badge { background: #1f2833; padding: 5px 12px; border-radius: 20px; border: 1px solid #45f3ff44; color: #66fcf1; font-weight: bold; font-size: 12px; font-family: monospace; }
        .badge-owner { border-color: #fbbf24; color: #fbbf24; }
        
        .grid-main { display: grid; grid-template-columns: 1fr 2fr; gap: 20px; margin-bottom: 25px; }
        .grid-sub { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px; }
        @media(max-width: 960px) { .grid-main, .grid-sub { grid-template-columns: 1fr; } }
        
        .card { background: #1f2833; border-radius: 10px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); border: 1px solid #334155; }
        .card h3 { color: #66fcf1; margin-top: 0; border-bottom: 1px solid #45f3ff33; padding-bottom: 10px; font-size: 16px; display: flex; justify-content: space-between; align-items: center; }
        .form-group { margin-bottom: 14px; }
        label { display: block; margin-bottom: 5px; font-size: 13px; color: #45f3ff; font-weight: 600; }
        input[type="text"], input[type="number"], select { width: 100%; padding: 10px; background: #0b0c10; border: 1px solid #45f3ff66; border-radius: 6px; color: #fff; box-sizing: border-box; font-size: 13px; font-family: monospace; }
        input:focus { outline: none; border-color: #66fcf1; box-shadow: 0 0 8px rgba(102,252,241,0.3); }
        button { background: #66fcf1; color: #0b0c10; border: none; padding: 10px 15px; border-radius: 6px; font-weight: bold; cursor: pointer; transition: 0.2s; width: 100%; font-size: 13px; }
        button:hover { background: #45f3ff; box-shadow: 0 0 10px #45f3ff; }
        .btn-secondary { background: #334155; color: #fff; margin-top: 6px; }
        .btn-secondary:hover { background: #475569; }
        .btn-promo { background: linear-gradient(135deg, #f59e0b, #ef4444); color: #fff; margin-top: 10px; }
        .btn-promo:hover { filter: brightness(1.1); box-shadow: 0 0 12px rgba(245,158,11,0.5); }
        
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12px; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #45f3ff22; }
        th { color: #66fcf1; background: #0b0c10; font-family: monospace; }
        .btn-approve { background: #16a34a; color: #fff; border:none; padding: 5px 10px; border-radius:4px; cursor:pointer; font-weight: bold; margin-right: 5px; font-size: 11px; }
        .btn-approve:hover { background: #22c55e; }
        .btn-reject { background: #dc2626; color: #fff; border:none; padding: 5px 10px; border-radius:4px; cursor:pointer; font-weight: bold; font-size: 11px; }
        .btn-reject:hover { background: #ef4444; }
        .status-badge { display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 10px; font-weight: bold; font-family: monospace; }
        .status-pending { background: #78350f; color: #fde68a; border: 1px solid #b45309; }
        .status-approved { background: #064e3b; color: #a7f3d0; border: 1px solid #059669; }
        .status-rejected { background: #7f1d1d; color: #fecaca; border: 1px solid #b91c1c; }
        .status-expired { background: #374151; color: #d1d5db; border: 1px solid #4b5563; }
        .user-tag { background: #0b0c10; padding: 4px 8px; border-radius: 4px; border: 1px solid #334155; font-family: monospace; display: inline-flex; align-items: center; justify-content: space-between; margin-bottom: 4px; width: 100%; box-sizing: border-box; }
        .feedback { margin-top: 8px; font-size: 12px; font-family: monospace; padding: 8px; border-radius: 4px; display: none; }
        .feedback-success { background: #064e3b; color: #6ee7b7; border: 1px solid #059669; }
        .feedback-error { background: #7f1d1d; color: #fca5a5; border: 1px solid #dc2626; }
        .proof-box { background: #0b0c10; padding: 6px; border-radius: 4px; border: 1px solid #334155; word-break: break-all; font-size: 11px; max-width: 220px; }
    </style>
</head>
<body>

<div class="dashboard">
    <div class="header">
        <h1>👑 GHOST MASTERMIND - SUPER ADMIN CONTROLLER</h1>
        <div class="header-badges">
            <span class="badge badge-owner">Owner ID: 7939005883</span>
            <span class="badge" id="botStatusBadge">Bot: ACTIVE</span>
            <span class="badge" id="botUsersBadge">Users: 0</span>
        </div>
    </div>

    <!-- Top Grid: Gateway Settings & Firestore Manual Deposits -->
    <div class="grid-main">
        <div class="card">
            <h3>💳 Gateway & Dynamic Slabs</h3>
            <div class="form-group">
                <label>Merchant UPI Gateway ID</label>
                <input type="text" id="adminUpi" value="${adminUpiId}">
            </div>
            <div class="form-group">
                <label>VIP Subscription Price (₹)</label>
                <input type="number" id="vipPriceInput" value="${globalVipPrice}">
            </div>
            <button onclick="saveAdminSpecs()">Update Configurations</button>
            <div id="saveFeedback" class="feedback"></div>

            <div style="margin-top: 20px; border-top: 1px solid #334155; padding-top: 15px;">
                <label>📢 Mastermind Promo Blast</label>
                <p style="font-size: 11px; color: #94a3b8; margin: 4px 0 10px 0;">Credit 2 free test credits instantly to all inactive users (0 credits).</p>
                <button class="btn-promo" id="btnPromo" onclick="triggerPromoBlast()">🚀 Dispatch 2 Free Bonus Credits</button>
                <div id="promoFeedback" class="feedback"></div>
            </div>
        </div>

        <div class="card">
            <h3>
                <span>🔥 Live Firestore Deposits Ledger</span>
                <button class="btn-secondary" style="width: auto; padding: 4px 10px; font-size: 11px;" onclick="loadFirestoreDeposits()">Refresh</button>
            </h3>
            <div style="overflow-x: auto; max-height: 380px;">
              <table>
                  <thead>
                      <tr>
                          <th>Txn ID / User</th>
                          <th>Amount / Rounds</th>
                          <th>Proof / UTR</th>
                          <th>Status / Action</th>
                      </tr>
                  </thead>
                  <tbody id="depositsTableBody">
                      <tr><td colspan="4" style="text-align:center; color:#8c92ac;">Loading Firestore deposits...</td></tr>
                  </tbody>
              </table>
            </div>
        </div>
    </div>

    <!-- Bottom Grid: Admin Privilege Management & Direct User Controller -->
    <div class="grid-sub">
        <!-- Admin Privilege Management -->
        <div class="card">
            <h3>🛡️ Dynamic Admin Privilege Management (/api/manage-admin)</h3>
            <p style="font-size: 12px; color: #94a3b8; margin: 0 0 12px 0;">Supreme Owner <code>7939005883</code> retains absolute authority. Add/remove sub-admins authorized to execute bot controls.</p>
            
            <div class="form-group">
                <label>Add Sub-Admin Telegram Chat ID</label>
                <div style="display: flex; gap: 8px;">
                    <input type="text" id="newAdminId" placeholder="e.g. 123456789">
                    <button style="width: 120px;" onclick="addAdminId()">+ Add Admin</button>
                </div>
            </div>

            <label style="margin-top: 15px;">Current Authorized Admins List</label>
            <div id="adminsListContainer" style="max-height: 180px; overflow-y: auto; margin-top: 8px;">
                <div style="color: #94a3b8; font-size: 12px;">Loading authorized admins...</div>
            </div>
            <div id="adminMgmtFeedback" class="feedback"></div>
        </div>

        <!-- User Live Inspector & Credit / VIP Modifier -->
        <div class="card">
            <h3>⚡ User Inspector & Credit / VIP Modifier</h3>
            <div class="form-group">
                <label>Target User Chat ID</label>
                <div style="display: flex; gap: 8px;">
                    <input type="text" id="inspectTargetId" placeholder="e.g. 999999999">
                    <button style="width: 110px;" onclick="inspectUser()">Inspect</button>
                </div>
            </div>

            <div id="userInspectionResult" style="background: #0b0c10; padding: 12px; border-radius: 6px; border: 1px solid #334155; font-size: 12px; font-family: monospace; display: none; margin-bottom: 12px;">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div>
                    <label>Give Credits Amount</label>
                    <div style="display: flex; gap: 6px;">
                        <input type="number" id="giveCreditAmount" value="32">
                        <button style="width: 80px;" onclick="giveCredits()">+ Give</button>
                    </div>
                </div>
                <div>
                    <label>Toggle VIP Status</label>
                    <div style="display: flex; gap: 6px;">
                        <button style="background: #10b981; color: #fff;" onclick="setVip(true)">VIP: TRUE</button>
                        <button style="background: #64748b; color: #fff;" onclick="setVip(false)">VIP: FALSE</button>
                    </div>
                </div>
            </div>
            <div id="userActionFeedback" class="feedback"></div>
        </div>
    </div>

    <!-- Legacy In-Memory Receipt Queue (Backward Compatibility) -->
    <div class="card">
        <h3>
            <span>🧾 In-Memory Receipt Verification Queue</span>
            <button class="btn-secondary" style="width: auto; padding: 4px 10px; font-size: 11px;" onclick="loadQueue()">Refresh</button>
        </h3>
        <div style="overflow-x: auto; max-height: 250px;">
            <table>
                <thead>
                    <tr>
                        <th>User (Telegram ID)</th>
                        <th>Demand Type</th>
                        <th>Amount & Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="adminQueue">
                    <tr><td colspan="4" style="text-align:center; color:#8c92ac;">Loading receipt queue...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
const SECRET_KEY = "Faisal786";

function showFeedback(elementId, msg, isSuccess) {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.innerText = msg;
    el.className = 'feedback ' + (isSuccess ? 'feedback-success' : 'feedback-error');
    el.style.display = 'block';
    setTimeout(() => { el.style.display = 'none'; }, 5000);
}

// 1. Load Bot Status & Overview
function loadBotStatus() {
    fetch('/api/telegram/status')
      .then(res => res.json())
      .then(data => {
          if (data.success) {
              document.getElementById('botUsersBadge').innerText = 'Users: ' + (data.totalUsers || 0);
          }
      })
      .catch(() => {});
}

// 2. Gateway Settings
function saveAdminSpecs() {
    const upiId = document.getElementById('adminUpi').value;
    const vipPrice = document.getElementById('vipPriceInput').value;

    fetch('/api/update-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ upiId, vipPrice })
    })
    .then(res => res.json())
    .then(data => { 
        if(data.success) {
            showFeedback('saveFeedback', "System variables updated successfully!", true);
        } else {
            showFeedback('saveFeedback', data.message || "Failed to update", false);
        }
    })
    .catch(err => showFeedback('saveFeedback', err.message, false));
}

// 3. Promo Blast
function triggerPromoBlast() {
    const btn = document.getElementById('btnPromo');
    btn.disabled = true;
    btn.innerText = "Dispatching promo...";

    fetch('/api/telegram/promo-blast', { method: 'POST' })
      .then(res => res.json())
      .then(data => {
          showFeedback('promoFeedback', data.message || "Promo blast dispatched!", true);
      })
      .catch(err => {
          showFeedback('promoFeedback', "Error: " + err.message, false);
      })
      .finally(() => {
          btn.disabled = false;
          btn.innerText = "🚀 Dispatch 2 Free Bonus Credits";
      });
}

// 4. Firestore Deposits Ledger
function loadFirestoreDeposits() {
    fetch('/api/deposits')
      .then(res => res.json())
      .then(data => {
          const tbody = document.getElementById('depositsTableBody');
          const deposits = data.deposits || [];
          if (deposits.length === 0) {
              tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #8c92ac;">No deposits recorded in Firestore yet.</td></tr>';
              return;
          }

          tbody.innerHTML = deposits.map(dep => \`
              <tr>
                  <td>
                      <b style="color: #66fcf1;">\${dep.firstName || 'Pilot'}</b> <br>
                      <span style="font-size: 11px; color: #8c92ac;">Chat ID: \${dep.chatId}</span><br>
                      <span style="font-size: 10px; color: #64748b;">Doc ID: \${dep.id}</span>
                  </td>
                  <td>
                      <b style="color: #fbbf24;">₹\${dep.amount || 0}</b> <br>
                      <span style="font-size: 11px; color: #38bdf8;">\${dep.rounds || 32} Rounds</span>
                  </td>
                  <td>
                      <div class="proof-box">\${dep.proof || 'No proof string'}</div>
                  </td>
                  <td>
                      \${dep.status === 'pending' ? \`
                          <button class="btn-approve" onclick="verifyDeposit('\${dep.id}', 'approve')">Approve ✅</button>
                          <button class="btn-reject" onclick="verifyDeposit('\${dep.id}', 'reject')">Reject ❌</button>
                      \` : \`
                          <span class="status-badge status-\${(dep.status || '').toLowerCase()}">\${dep.status || 'UNKNOWN'}</span>
                          \${dep.processedBy ? \`<br><span style="font-size: 10px; color: #94a3b8;">by \${dep.processedBy}</span>\` : ''}
                      \`}
                  </td>
              </tr>
          \`).join('');
      })
      .catch(err => {
          const tbody = document.getElementById('depositsTableBody');
          tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #ef4444;">Error loading deposits: ' + err.message + '</td></tr>';
      });
}

function verifyDeposit(depositId, action) {
    if (!confirm('Are you sure you want to ' + action.toUpperCase() + ' deposit ' + depositId + '?')) return;

    fetch('/api/verify-deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ depositId, action, secretKey: SECRET_KEY })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('Success: ' + (data.message || 'Deposit processed'));
            loadFirestoreDeposits();
            loadQueue();
        } else {
            alert('Failed: ' + (data.message || 'Error'));
        }
    })
    .catch(err => alert('Error: ' + err.message));
}

// 5. Admin Privileges Management
function loadAdmins() {
    fetch('/api/manage-admin')
      .then(res => res.json())
      .then(data => {
          const container = document.getElementById('adminsListContainer');
          const list = data.adminList || [];
          if (list.length === 0) {
              container.innerHTML = '<div style="color: #94a3b8; font-size: 12px;">No secondary admins. Only Supreme Owner 7939005883 has active authority.</div>';
              return;
          }

          container.innerHTML = list.map(adminId => \`
              <div class="user-tag">
                  <span>🆔 Telegram Admin: <b>\${adminId}</b></span>
                  <button style="width: auto; padding: 2px 8px; font-size: 11px; background: #dc2626; color: #fff;" onclick="removeAdminId('\${adminId}')">Remove</button>
              </div>
          \`).join('');
      })
      .catch(() => {});
}

function addAdminId() {
    const input = document.getElementById('newAdminId');
    const targetAdminId = input.value.trim();
    if (!targetAdminId) return alert('Enter Telegram Chat ID');

    fetch('/api/manage-admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'add', targetAdminId, secretKey: SECRET_KEY })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            input.value = '';
            showFeedback('adminMgmtFeedback', 'Sub-admin ' + targetAdminId + ' added successfully!', true);
            loadAdmins();
        } else {
            showFeedback('adminMgmtFeedback', data.message || 'Failed', false);
        }
    })
    .catch(err => showFeedback('adminMgmtFeedback', err.message, false));
}

function removeAdminId(targetAdminId) {
    if (!confirm('Remove admin privileges for Telegram ID: ' + targetAdminId + '?')) return;

    fetch('/api/manage-admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove', targetAdminId, secretKey: SECRET_KEY })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showFeedback('adminMgmtFeedback', 'Admin ' + targetAdminId + ' removed.', true);
            loadAdmins();
        } else {
            showFeedback('adminMgmtFeedback', data.message || 'Failed', false);
        }
    })
    .catch(err => showFeedback('adminMgmtFeedback', err.message, false));
}

// 6. User Live Inspector & Modifier
function inspectUser() {
    const targetId = document.getElementById('inspectTargetId').value.trim();
    if (!targetId) return alert('Enter target Chat ID');

    const resultBox = document.getElementById('userInspectionResult');
    resultBox.style.display = 'block';
    resultBox.innerHTML = 'Fetching user metrics from Firestore...';

    fetch('/api/telegram/test-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetId })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            const u = data.data;
            resultBox.innerHTML = \`
                <div><b>Chat ID:</b> \${u.chatId} | <b>Name:</b> \${u.firstName || 'Pilot'}</div>
                <div><b>Credits Balance:</b> <span style="color: #45f3ff; font-weight: bold;">\${u.credits ?? 0}</span></div>
                <div><b>VIP Pass:</b> <span style="color: \${u.isPremium ? '#10b981' : '#94a3b8'};">\${u.isPremium ? 'YES (VIP)' : 'NO (Standard)'}</span></div>
                <div><b>Active Context:</b> \${u.context || 'None'}</div>
                <div><b>Role:</b> \${u.role || 'user'}</div>
            \`;
        } else {
            resultBox.innerHTML = '<span style="color: #f87171;">' + (data.message || 'User not found') + '</span>';
        }
    })
    .catch(err => {
        resultBox.innerHTML = '<span style="color: #f87171;">Error: ' + err.message + '</span>';
    });
}

function giveCredits() {
    const targetId = document.getElementById('inspectTargetId').value.trim();
    const amount = document.getElementById('giveCreditAmount').value.trim();
    if (!targetId || !amount) return alert('Enter target Chat ID and credit amount');

    fetch('/api/telegram/test-give-credit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetId, amount })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showFeedback('userActionFeedback', data.message || 'Credits granted', true);
            inspectUser();
        } else {
            showFeedback('userActionFeedback', data.message || 'Failed', false);
        }
    })
    .catch(err => showFeedback('userActionFeedback', err.message, false));
}

function setVip(isVip) {
    const targetId = document.getElementById('inspectTargetId').value.trim();
    if (!targetId) return alert('Enter target Chat ID');

    fetch('/api/telegram/test-set-vip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetId, isVip })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showFeedback('userActionFeedback', data.message || 'VIP status updated', true);
            inspectUser();
        } else {
            showFeedback('userActionFeedback', data.message || 'Failed', false);
        }
    })
    .catch(err => showFeedback('userActionFeedback', err.message, false));
}

// 7. In-Memory Receipt Queue
function loadQueue() {
    fetch('/api/telegram/receipt-queue')
      .then(res => res.json())
      .then(data => {
          if (data.currentUpi) document.getElementById('adminUpi').value = data.currentUpi;
          if (data.currentVipPrice) document.getElementById('vipPriceInput').value = data.currentVipPrice;

          const tbody = document.getElementById('adminQueue');
          if (!data.queue || data.queue.length === 0) {
              tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #8c92ac;">No pending receipts in in-memory queue.</td></tr>';
              return;
          }

          tbody.innerHTML = data.queue.map(item => \`
              <tr>
                  <td>
                      <b style="color: #66fcf1;">\${item.firstName || 'Pilot'}</b> <br>
                      <span style="font-size: 11px; color: #8c92ac;">ID: \${item.chatId}</span>
                  </td>
                  <td>
                      <b style="color: #fbbf24;">\${item.demandType}</b>
                  </td>
                  <td>
                      <span style="font-size: 11px; color: #45f3ff;">₹\${item.amount}</span><br>
                      <span style="font-size: 10px; color: #8c92ac;">\${item.date}</span>
                  </td>
                  <td>
                      \${item.status === 'PENDING' ? \`
                          <button class="btn-approve" onclick="actionReceipt('\${item.id}', 'APPROVE')">Approve</button>
                          <button class="btn-reject" onclick="actionReceipt('\${item.id}', 'REJECT')">Reject</button>
                      \` : \`
                          <span class="status-badge status-\${item.status.toLowerCase()}">\${item.status}</span>
                      \`}
                  </td>
              </tr>
          \`).join('');
      })
      .catch(err => console.warn('Queue error:', err));
}

function actionReceipt(receiptId, action) {
    fetch('/api/telegram/approve-receipt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiptId, action })
    })
    .then(res => res.json())
    .then(() => {
        loadQueue();
        loadFirestoreDeposits();
    })
    .catch(err => alert('Action error: ' + err.message));
}

// Initial Boot & Poll
loadBotStatus();
loadQueue();
loadFirestoreDeposits();
loadAdmins();
setInterval(loadBotStatus, 15000);
setInterval(loadFirestoreDeposits, 10000);
</script>
</body>
</html>`);
    });

    // Start auto-hype automation engine across official telegram channels
    startAutoHypeEngine(bot);

    console.log('[TELEGRAM BOT] Ghost Hybrid Core Engine loaded successfully.');
    return bot;
  } catch (err: any) {
    console.warn('[TELEGRAM BOT] Initialization warning:', err.message);
    return null;
  }
}

export function getTelegramBot(): TelegramBotClient | null {
  return botInstance;
}

// Append this diagnostic handler directly at the base layer of your file execution window
predictionBot.on('polling_error', (error: any) => {
    console.log(`📡 [NETWORK DIAGNOSTIC]: Polling handshake failed. Reason: ${error.message}`);
    if (error.message && error.message.includes('409 Conflict')) {
        console.log("💡 CRITICAL RESOLUTION: A duplicate bot instance is running in another task layer. Terminate all background code runners.");
    }
});
