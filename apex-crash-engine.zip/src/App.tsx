import React, { useState, useEffect, useRef } from 'react';
import {
  User,
  GameState,
  GameStatus,
  Bet,
  MultiplierHistoryItem,
  HighRollerWinner,
  TimedCampaign,
  buildLiveVipLevelsData,
  AppNotification
} from './types';
import { socketService } from './services/socket';
import { audioService } from './services/audio';
import { Navbar } from './components/Navbar';
import { HistoryTicker, appendNewCrashToMiniHistoryBar } from './components/HistoryTicker';
import { GameCanvas } from './components/GameCanvas';
import { BettingConsole } from './components/BettingConsole';
import { LiveBetsPanel } from './components/LiveBetsPanel';
import { AuthModal } from './components/AuthModal';
import { CashierModal } from './components/CashierModal';
import { ReferralModal } from './components/ReferralModal';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminGameSideController } from './components/AdminGameSideController';
import { WelcomeBonusModal } from './components/WelcomeBonusModal';
import { RulesModal } from './components/RulesModal';
import { MaintenanceOverlay } from './components/MaintenanceOverlay';
import { BottomNav, BottomNavTab } from './components/BottomNav';
import { ProfileModal } from './components/ProfileModal';
import { VipSpinWheel } from './components/VipSpinWheel';
import { NotificationCenterModal } from './components/NotificationCenterModal';
import { TelegramNetworksModal } from './components/TelegramNetworksModal';
import { Bell, Gift, ChevronRight } from 'lucide-react';
import {
  calculateExponentialMultiplier
} from './services/aviatorPrecisionEngine';
import { referralService } from './services/referral';
import {
  auth,
  onAuthStateChanged,
  loginWithGoogle,
  logoutFirebase,
  subscribeToGameControl,
  subscribeToGameHistory,
  subscribeToUserBets,
  syncUserToFirestore,
  getTabSessionId,
  generateNewTabSessionId,
  updateUserSessionInFirestore,
  subscribeToUserSession,
  verifySessionInFirestore,
  subscribeToActiveUserRealtime,
  DeepAuditSystem
} from './firebase';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<any>(null);
  const userRef = useRef<User | null>(user);

  // Single Session Tracking (Multi-tab protection)
  const [tabSessionId, setTabSessionId] = useState<string>(() => getTabSessionId());
  const [isSessionSuperseded, setIsSessionSuperseded] = useState<boolean>(false);
  const [supersededReason, setSupersededReason] = useState<string>('');

  const [token, setToken] = useState<string | null>(localStorage.getItem('winnova_token'));
  const [isSuperAdmin, setIsSuperAdmin] = useState<boolean>(
    localStorage.getItem('winnova_is_sa') === 'true'
  );

  useEffect(() => {
    userRef.current = user;
    if (typeof window !== 'undefined') {
      if (isSuperAdmin || user?.role === 'superadmin') {
        localStorage.setItem('user_role', 'super_admin');
        sessionStorage.setItem('admin_session', 'super_admin');
      } else if (user?.role === 'admin') {
        localStorage.setItem('user_role', 'admin');
        sessionStorage.setItem('admin_session', 'admin');
      } else {
        localStorage.removeItem('user_role');
        sessionStorage.removeItem('admin_session');
      }
      if (typeof (window as any).syncGhostAdminAI === 'function') {
        (window as any).syncGhostAdminAI();
      }
    }
  }, [user, isSuperAdmin]);
  const [isMuted, setIsMuted] = useState<boolean>(audioService.isMuted());
  const [latestNotification, setLatestNotification] = useState<AppNotification | null>(null);
  const [claimingBannerId, setClaimingBannerId] = useState<string | null>(null);

  // Game Engine State
  const [gameState, setGameState] = useState<GameState>({
    roundId: 'R-1000',
    status: 'WAITING',
    multiplier: 1.00,
    elapsedSeconds: 0,
    crashMultiplier: undefined,
    countdownSeconds: 5,
    startedAt: 0,
    history: [],
    controlMode: 'AUTO_AI',
    activeBetsCount: 0,
    totalBetAmount: 0
  });

  const [activeBets, setActiveBets] = useState<Bet[]>([]);
  const [highRollers, setHighRollers] = useState<HighRollerWinner[]>([]);
  const [myBetsByConsole, setMyBetsByConsole] = useState<[Bet | null, Bet | null]>([null, null]);
  const currentRoundIdRef = useRef<string>('');

  // Dedicated RAF Flight Interpolation Loop Refs (requestAnimationFrame synced with backend)
  const flightRafIdRef = useRef<number | null>(null);
  const flightStartTimePerfRef = useRef<number>(0);
  const latestServerTickRef = useRef<{ multiplier: number; elapsedSeconds: number; clientReceivedAt: number }>({
    multiplier: 1.00,
    elapsedSeconds: 0,
    clientReceivedAt: 0
  });
  const liveMultiplierRef = useRef<number>(1.00);
  const isCrashedRef = useRef<boolean>(false);
  const plannedCrashPointRef = useRef<number>(0);
  const lastUiDispatchRef = useRef<number>(0);
  const statusRef = useRef<GameStatus>('WAITING');

  // CALIBRATED TIMING & EXPONENTIAL MULTIPLIER CURVE
  const calculateCurve = (t: number) => {
    return calculateExponentialMultiplier(t);
  };

  const addToHistory = (backendCrashPoint: number, roundId?: string, serverHistory?: MultiplierHistoryItem[]) => {
    const fixedPoint = +Number(backendCrashPoint || 1.00).toFixed(2);
    setGameState((prev) => {
      let updatedHistory: MultiplierHistoryItem[];
      if (serverHistory && serverHistory.length > 0) {
        updatedHistory = serverHistory;
      } else {
        const targetRoundId = roundId || currentRoundIdRef.current || prev.roundId || `R-${Date.now()}`;
        const newItem: MultiplierHistoryItem = {
          roundId: targetRoundId,
          multiplier: fixedPoint,
          crashedAt: Date.now()
        };
        updatedHistory = [newItem, ...prev.history.filter((h) => h.roundId !== targetRoundId)].slice(0, 60);
      }
      return {
        ...prev,
        status: 'CRASHED',
        multiplier: fixedPoint,
        crashMultiplier: fixedPoint,
        history: updatedHistory
      };
    });
  };

  // ✈️ 1. Multiplier ko screen par badhane wala function
  const startFlightInterpolationLoop = (startTimeMs?: number) => {
    if (flightRafIdRef.current) {
      cancelAnimationFrame(flightRafIdRef.current);
      flightRafIdRef.current = null;
    }
    flightStartTimePerfRef.current = startTimeMs ?? performance.now();

    const updateMultiplier = () => {
      if (isCrashedRef.current || statusRef.current !== 'FLYING') {
        flightRafIdRef.current = null;
        return; // Agar crash ho chuka hai toh screen par ek point bhi aage nahi badhna chahiye
      }

      const now = performance.now();
      const elapsed = Math.max(0, (now - flightStartTimePerfRef.current) / 1000);
      const theoretical = calculateCurve(elapsed);

      // Reconcile with latest authoritative socket tick
      const tick = latestServerTickRef.current;
      let target = theoretical;
      if (tick.multiplier > 1.00) {
        const tickExpected = calculateCurve(tick.elapsedSeconds);
        const delta = Math.max(0, theoretical - tickExpected);
        target = Math.max(theoretical, tick.multiplier + delta);
      }

      let nextVal = Math.max(liveMultiplierRef.current, target);

      // Clamp to backend planned crash point so client never overshoots (e.g., 2.08x -> never shows 2.10x/2.12x)
      if (plannedCrashPointRef.current > 0 && nextVal >= plannedCrashPointRef.current) {
        nextVal = plannedCrashPointRef.current;
      }

      liveMultiplierRef.current = nextVal;

      // Real-time audio engine pitch acceleration linked to live multiplier
      audioService.updateEnginePitch(nextVal);

      // Screen par text show karna
      const formattedText = `${nextVal.toFixed(2)}x`;
      const displayEl1 = document.getElementById('multiplierDisplay');
      if (displayEl1) {
        displayEl1.innerText = formattedText;
      }
      const displayEl2 = document.getElementById('multiplier-display');
      if (displayEl2) {
        displayEl2.innerText = formattedText;
        displayEl2.classList.remove('crashed', 'text-red-500');
        displayEl2.classList.add('text-white');
      }

      // Throttle React state dispatch to ~15 FPS to eliminate React reconciliation lag
      if (now - lastUiDispatchRef.current >= 66) {
        lastUiDispatchRef.current = now;
        setGameState((prev) => {
          if (isCrashedRef.current || prev.status !== 'FLYING') return prev;
          return {
            ...prev,
            multiplier: +nextVal.toFixed(2),
            elapsedSeconds: +elapsed.toFixed(2)
          };
        });
      }

      // Agle frame ke liye loop chalana
      flightRafIdRef.current = requestAnimationFrame(updateMultiplier);
    };

    flightRafIdRef.current = requestAnimationFrame(updateMultiplier);
  };

  // 💥 2. CRASH FIX FUNCTION (Jab backend se signal aaye)
  const triggerCrash = (backendCrashPoint: number, roundId?: string, serverHistory?: MultiplierHistoryItem[]) => {
    isCrashedRef.current = true;
    statusRef.current = 'CRASHED';

    // ⚡ CRITICAL FIX: Timer loop ko usi microsecond par kill kar dena
    if (flightRafIdRef.current) {
      cancelAnimationFrame(flightRafIdRef.current);
      flightRafIdRef.current = null;
    }
    audioService.stopEngine();

    // Screen par wahi fixed multiplier dikhana jo backend se aaya hai, na ki jo lag ki wajah se aage badha thha
    const fixedCrashPoint = +(Number(backendCrashPoint) > 0 ? Number(backendCrashPoint) : (liveMultiplierRef.current || 1.00)).toFixed(2);
    liveMultiplierRef.current = fixedCrashPoint;
    latestServerTickRef.current = {
      multiplier: fixedCrashPoint,
      elapsedSeconds: latestServerTickRef.current.elapsedSeconds,
      clientReceivedAt: performance.now()
    };

    const formattedCrash = `${fixedCrashPoint.toFixed(2)}x`;
    const displayEl1 = document.getElementById('multiplierDisplay');
    if (displayEl1) {
      displayEl1.innerText = formattedCrash;
    }
    const displayEl2 = document.getElementById('multiplier-display');
    if (displayEl2) {
      displayEl2.innerText = formattedCrash;
      displayEl2.classList.add('crashed', 'text-red-500');
      displayEl2.classList.remove('text-white', 'text-emerald-400');
    }

    if (typeof (window as any).canvasTriggerCrash === 'function') {
      (window as any).canvasTriggerCrash(fixedCrashPoint);
    } else if (typeof (window as any).renderMultiplierText === 'function') {
      (window as any).renderMultiplierText(fixedCrashPoint);
    }

    // Iske baad purana history update karne ka code chala dein
    appendNewCrashToMiniHistoryBar(fixedCrashPoint);
    addToHistory(fixedCrashPoint, roundId, serverHistory);
    audioService.stopEngineAndCrash();
  };

  const stopFlightInterpolationLoop = () => {
    if (flightRafIdRef.current) {
      cancelAnimationFrame(flightRafIdRef.current);
      flightRafIdRef.current = null;
    }
    audioService.stopEngine();
  };

  // Modals & Navigation
  const [bottomNavTab, setBottomNavTab] = useState<BottomNavTab>('lobby');
  const [showAuthModal, setShowAuthModal] = useState<boolean>(!token);
  const [cashierModalTab, setCashierModalTab] = useState<'deposit' | 'withdraw' | 'vip' | null>(null);
  const [showReferralModal, setShowReferralModal] = useState<boolean>(false);
  const [showAdminModal, setShowAdminModal] = useState<boolean>(false);
  const [showRulesModal, setShowRulesModal] = useState<boolean>(false);
  const [showProfileModal, setShowProfileModal] = useState<boolean>(false);
  const [showVipSpinWheel, setShowVipSpinWheel] = useState<boolean>(false);
  const [showNotificationCenter, setShowNotificationCenter] = useState<boolean>(false);
  const [showTelegramNetworksModal, setShowTelegramNetworksModal] = useState<boolean>(false);
  const [unreadNotificationCount, setUnreadNotificationCount] = useState<number>(1);
  const [welcomeBonus, setWelcomeBonus] = useState<number | null>(null);

  // Active Campaign State (Module 19)
  const [activeCampaign, setActiveCampaign] = useState<TimedCampaign | null>(null);

  // In-app floating toast alerts
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'info') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4500);
  };

  // Restore or auto-init session & initialize Firebase infrastructure
  useEffect(() => {
    // Listen to Firebase Auth state
    const unsubscribeAuth = onAuthStateChanged(auth, (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        console.log('[FIREBASE AUTH] Session active:', fbUser.email || fbUser.uid);
      }
    });

    // Initialize real-time Firestore listeners for game control sync
    const unsubscribeControl = subscribeToGameControl((control) => {
      if (!control) return;
      const isCrashed = control.status === 'crashed' || (control.status as string) === 'ended';
      if (isCrashed) {
        // Intercept definitive backend final multiplier from incoming snapshot
        const rawFinal = (typeof control.crashMultiplier === 'number' && control.crashMultiplier > 0)
          ? control.crashMultiplier
          : ((typeof control.finalMultiplier === 'number' && control.finalMultiplier > 0)
            ? control.finalMultiplier
            : control.currentMultiplier);

        if (typeof rawFinal === 'number' && rawFinal > 0) {
          triggerCrash(rawFinal, control.roundId || `Round No - ${control.roundNumber || Date.now()}`);
        }
      }
    });

    const savedUserId = localStorage.getItem('winnova_user_id');
    if (savedUserId) {
      fetchUserProfile(savedUserId);
    } else {
      initDemoUser();
    }

    return () => {
      unsubscribeAuth();
      unsubscribeControl();
    };
  }, []);

  // Sync user profile and balance to Firestore only when user is authenticated in Firebase
  useEffect(() => {
    if (user?.id && firebaseUser) {
      syncUserToFirestore(user.id, {
        balance: user.mainBalance ?? 0,
        email: user.email || firebaseUser.email || `${user.id}@winnova.play`,
        role: user.role === 'admin' ? 'admin' : (user.role === 'superadmin' ? 'super_admin' : 'player'),
        name: user.name || firebaseUser.displayName || 'Player',
        phone: user.phone || '',
        promoWallet: user.promoWallet || 0,
        isFrozen: user.isFrozen || false
      }).catch((e) => console.warn('Firestore user sync notice:', e));
    }
  }, [user?.id, user?.mainBalance, user?.promoWallet, user?.role, user?.isFrozen, firebaseUser]);

  // Real-time onSnapshot listener: Instant UI balance update when Super Admin modifies wallet
  useEffect(() => {
    if (!user?.id) return;
    const unsub = subscribeToActiveUserRealtime(user.id, (realtimeData) => {
      setUser((prev) => {
        if (!prev || prev.id !== user.id) return prev;
        if (
          prev.mainBalance === realtimeData.mainBalance &&
          prev.withdrawableBalance === realtimeData.withdrawableBalance &&
          prev.bonusBalance === realtimeData.bonusBalance &&
          prev.isFrozen === realtimeData.isFrozen
        ) {
          return prev;
        }
        return {
          ...prev,
          mainBalance: realtimeData.mainBalance,
          withdrawableBalance: realtimeData.withdrawableBalance,
          bonusBalance: realtimeData.bonusBalance,
          isFrozen: realtimeData.isFrozen
        };
      });
    });
    return () => unsub();
  }, [user?.id]);

  const initDemoUser = async () => {
    try {
      const res = await fetch('/api/auth/demo-login', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        localStorage.setItem('winnova_user_id', data.user.id);
        socketService.joinUserRoom(data.user.id);
      }
    } catch (e) {
      console.warn('Auto demo login skipped:', e);
    }
  };

  // Fetch active promotional campaign on mount
  useEffect(() => {
    fetch('/api/promotions/active')
      .then((r) => r.json())
      .then((data) => {
        if (data?.campaign) {
          setActiveCampaign(data.campaign);
        }
      })
      .catch(() => {});
  }, []);

  // Synchronize global CoreGameEngine.vipState & WebSystemVipEngine with live user & campaign data
  useEffect(() => {
    const liveVipState = buildLiveVipLevelsData(user, activeCampaign);
    if (typeof window !== 'undefined') {
      window.CoreGameEngine = {
        ...(window.CoreGameEngine || {}),
        vipState: liveVipState
      };
      window.WebSystemVipEngine = liveVipState;
    }
  }, [user, activeCampaign]);

  // Capture incoming referral parameters (?ref=... or ?r=...) from URL
  useEffect(() => {
    const trackedRefCode = referralService.captureReferralFromUrl();
    if (trackedRefCode) {
      console.log(`🔗 [REFERRAL LINK TRACKER]: Incoming referral code active: ${trackedRefCode}`);
    }
  }, []);

  // Guarantee that logged-in users have an active, shareable referral code generated
  useEffect(() => {
    if (user && user.id) {
      if (!user.referralCode || user.referralCode.trim() === '') {
        referralService.ensureUserReferralCode(user).then((generatedCode) => {
          if (generatedCode) {
            setUser(prev => prev ? { ...prev, referralCode: generatedCode } : null);
          }
        }).catch(() => {});
      }
    }
  }, [user?.id, user?.referralCode]);

  const fetchUserProfile = async (userId: string) => {
    try {
      const res = await fetch('/api/user/profile', {
        headers: { 'x-user-id': userId }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        socketService.joinUserRoom(data.user.id);
        if (data.user.role === 'superadmin') {
          setIsSuperAdmin(true);
        }
      } else {
        // Fallback to demo login if user session was not found
        const demoRes = await fetch('/api/auth/demo-login', { method: 'POST' });
        if (demoRes.ok) {
          const demoData = await demoRes.json();
          setUser(demoData.user);
          localStorage.setItem('winnova_user_id', demoData.user.id);
          socketService.joinUserRoom(demoData.user.id);
        }
      }
    } catch (e) {
      console.error('Error fetching profile:', e);
    }
  };

  // Setup Socket Listeners
  useEffect(() => {
    socketService.connect();

    const handleInitState = (data: any) => {
      if (data.gameState) {
        statusRef.current = data.gameState.status;
        isCrashedRef.current = data.gameState.status === 'CRASHED';
        if (typeof data.gameState.crashMultiplier === 'number' && data.gameState.crashMultiplier > 0) {
          plannedCrashPointRef.current = data.gameState.crashMultiplier;
        }
        if (data.gameState.status === 'FLYING') {
          liveMultiplierRef.current = data.gameState.multiplier || 1.00;
          const elapsedSec = data.gameState.elapsedSeconds || 0;
          startFlightInterpolationLoop(performance.now() - elapsedSec * 1000);
        }
        setGameState((prev) => ({
          ...prev,
          ...data.gameState,
          history: (data.history && data.history.length > 0) ? data.history : (data.gameState.history || prev.history)
        }));
        if (data.gameState.roundId) {
          currentRoundIdRef.current = data.gameState.roundId;
        }
      }
      if (data.activeBets) {
        setActiveBets(data.activeBets);
      }
      if (data.highRollers) {
        setHighRollers(data.highRollers);
      }
    };
    const unsubInit1 = socketService.on('initial_state', handleInitState);
    const unsubInit2 = socketService.on('init_state', handleInitState);

    const unsubGameState = socketService.on('game_state', (state: GameState) => {
      if (state.roundId && currentRoundIdRef.current && state.roundId !== currentRoundIdRef.current) {
        currentRoundIdRef.current = state.roundId;
        setMyBetsByConsole([null, null]);
      } else if (state.roundId) {
        currentRoundIdRef.current = state.roundId;
      }
      if (state.status === 'CRASHED') {
        const finalPt = state.crashMultiplier || state.multiplier || liveMultiplierRef.current || 1.00;
        triggerCrash(finalPt, state.roundId, state.history);
        return;
      }
      statusRef.current = state.status;
      isCrashedRef.current = false;
      setGameState((prev) => ({
        ...prev,
        ...state,
        history: (state.history && state.history.length > 0) ? state.history : prev.history
      }));
    });

    const unsubCountdown = socketService.on('countdown_tick', (data: { countdownSeconds: number; roundId?: string }) => {
      stopFlightInterpolationLoop();
      isCrashedRef.current = false;
      statusRef.current = 'WAITING';
      plannedCrashPointRef.current = 0;
      liveMultiplierRef.current = 1.00;
      if (data.roundId && currentRoundIdRef.current && data.roundId !== currentRoundIdRef.current) {
        currentRoundIdRef.current = data.roundId;
        setMyBetsByConsole([null, null]);
      } else if (data.roundId) {
        currentRoundIdRef.current = data.roundId;
      }
      setGameState((prev) => ({
        ...prev,
        countdownSeconds: data.countdownSeconds,
        status: 'WAITING',
        multiplier: 1.00,
        roundId: data.roundId || prev.roundId
      }));
      audioService.playTick(data.countdownSeconds);
    });

    const unsubFlight = socketService.on('flight_started', (data) => {
      if (data.roundId && currentRoundIdRef.current && data.roundId !== currentRoundIdRef.current) {
        currentRoundIdRef.current = data.roundId;
        setMyBetsByConsole([null, null]);
      } else if (data.roundId) {
        currentRoundIdRef.current = data.roundId;
      }
      stopFlightInterpolationLoop();
      isCrashedRef.current = false;
      statusRef.current = 'FLYING';
      plannedCrashPointRef.current = (typeof data?.plannedCrashMultiplier === 'number' && data.plannedCrashMultiplier > 0)
        ? data.plannedCrashMultiplier
        : 0;
      liveMultiplierRef.current = 1.00;
      latestServerTickRef.current = { multiplier: 1.00, elapsedSeconds: 0, clientReceivedAt: performance.now() };
      startFlightInterpolationLoop(performance.now());
      setGameState((prev) => ({
        ...prev,
        status: 'FLYING',
        roundId: data.roundId,
        startedAt: data.startedAt,
        multiplier: 1.00
      }));
      audioService.playFlightStart();
    });

    const handleTick = (data: { multiplier: number; elapsedSeconds: number; plannedCrashMultiplier?: number }) => {
      // Agar crash ho chuka hai toh screen par ek point bhi aage nahi badhna chahiye
      if (isCrashedRef.current || statusRef.current === 'CRASHED') return;
      if (typeof data.plannedCrashMultiplier === 'number' && data.plannedCrashMultiplier > 0) {
        plannedCrashPointRef.current = data.plannedCrashMultiplier;
      }
      const now = performance.now();
      latestServerTickRef.current = {
        multiplier: data.multiplier,
        elapsedSeconds: data.elapsedSeconds,
        clientReceivedAt: now
      };
      // Smooth clock synchronization with server
      const expectedStart = now - (data.elapsedSeconds * 1000);
      if (flightStartTimePerfRef.current === 0) {
        flightStartTimePerfRef.current = expectedStart;
      } else {
        flightStartTimePerfRef.current = (flightStartTimePerfRef.current * 0.85) + (expectedStart * 0.15);
      }
      // Ensure interpolation loop is running
      if (!flightRafIdRef.current && !isCrashedRef.current && statusRef.current === 'FLYING') {
        startFlightInterpolationLoop(flightStartTimePerfRef.current);
      }
    };
    const unsubTick = socketService.on('flight_tick', handleTick);

    let lastCrashedRoundId = '';
    const handleCrashed = (data: { roundId: string; crashMultiplier: number; finalMultiplier?: number; history?: MultiplierHistoryItem[] }) => {
      const definitiveFinalMultiplier = (typeof data?.crashMultiplier === 'number' && data.crashMultiplier > 0)
        ? data.crashMultiplier
        : (typeof data?.finalMultiplier === 'number' && data.finalMultiplier > 0)
        ? data.finalMultiplier
        : (plannedCrashPointRef.current > 0 ? plannedCrashPointRef.current : (liveMultiplierRef.current || 1.00));

      if (data.roundId && data.roundId === lastCrashedRoundId && isCrashedRef.current) {
        return;
      }
      if (data.roundId) lastCrashedRoundId = data.roundId;

      triggerCrash(definitiveFinalMultiplier, data.roundId, data.history);
    };
    const unsubCrashed1 = socketService.on('flight_crashed', handleCrashed);
    const unsubCrashed2 = socketService.on('round_crashed', handleCrashed);

    if (typeof window !== 'undefined') {
      (window as any).triggerCrash = triggerCrash;
      (window as any).addToHistory = addToHistory;
    }

    const unsubBetQueued = socketService.on('bet_queued', (data: any) => {
      showToast(data.message || 'Bet queued for next flight!', 'info');
      if (data.bet) {
        const bet: Bet = data.bet;
        const currentUser = userRef.current;
        if (currentUser && bet.userId === currentUser.id) {
          setMyBetsByConsole((prev) => {
            const next = [...prev] as [Bet | null, Bet | null];
            next[bet.consoleIndex] = bet;
            return next;
          });
        }
      }
      setUser((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          mainBalance: data.newBalance !== undefined ? data.newBalance : prev.mainBalance,
          bonusBalance: data.newBonus !== undefined ? data.newBonus : prev.bonusBalance
        };
      });
    });

    // SYSTEM 3: GAME INTEGRATION FUNCTION (Database Permanent Save)
    const updateBalanceAfterGame = async (username: string, finalBalance: number) => {
      try {
        await fetch('/api/wallets/upsert', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username,
            userId: userRef.current?.id || username,
            balance: finalBalance
          })
        });
      } catch (err) {
        console.error('Error updating balance:', err);
      }
    };
    if (typeof window !== 'undefined') {
      (window as any).updateBalanceAfterGame = updateBalanceAfterGame;
    }

    const unsubBetPlaced = socketService.on('bet_placed', (data: any) => {
      const bet: Bet = data.bet || data;
      setActiveBets((prev) => [...prev.filter((b) => b.id !== bet.id), bet]);
      const currentUser = userRef.current;
      if (currentUser && bet.userId === currentUser.id) {
        setMyBetsByConsole((prev) => {
          const next = [...prev] as [Bet | null, Bet | null];
          next[bet.consoleIndex] = bet;
          return next;
        });
        audioService.playBetPlaced();
        // Dynamic balance and requiredWager reduction
        setUser((prev) => {
          if (!prev) return null;
          const newMain = data.newBalance !== undefined ? data.newBalance : Math.max(0, +(prev.mainBalance - bet.amount).toFixed(2));
          const newBonus = data.newBonus !== undefined ? data.newBonus : prev.bonusBalance;
          const reqWager = data.requiredWager !== undefined ? data.requiredWager : (prev.requiredWager ? Math.max(0, +(prev.requiredWager - bet.amount).toFixed(2)) : 0);
          updateBalanceAfterGame(prev.name || prev.id, newMain);
          return {
            ...prev,
            mainBalance: newMain,
            bonusBalance: newBonus,
            requiredWager: reqWager
          };
        });
      }
    });

    const handleCashedOut = (data: { betId: string; winAmount: number; multiplier: number; userId: string; mainBalance?: number }) => {
      setActiveBets((prev) =>
        prev.map((b) =>
          b.id === data.betId
            ? { ...b, cashedOut: true, winAmount: data.winAmount, cashedOutMultiplier: data.multiplier }
            : b
        )
      );
      const currentUser = userRef.current;
      if (currentUser && data.userId === currentUser.id) {
        setMyBetsByConsole((prev) => {
          const next = [...prev] as [Bet | null, Bet | null];
          const idx = next.findIndex((b) => b?.id === data.betId);
          if (idx !== -1 && next[idx]) {
            next[idx] = {
              ...next[idx]!,
              cashedOut: true,
              winAmount: data.winAmount,
              cashedOutMultiplier: data.multiplier
            };
          }
          return next;
        });
        if (data.mainBalance !== undefined) {
          setUser((prev) => {
            if (!prev) return null;
            updateBalanceAfterGame(prev.name || prev.id, data.mainBalance!);
            return {
              ...prev,
              mainBalance: data.mainBalance!
            };
          });
        }
        audioService.playCashOut();
        showToast(`Cashed out ₹${data.winAmount.toFixed(2)} @ ${data.multiplier.toFixed(2)}x!`, 'success');
      }
    };
    const unsubCashedOut1 = socketService.on('cashed_out', handleCashedOut);
    const unsubCashedOut2 = socketService.on('bet_cashed_out', handleCashedOut);

    const handleActiveBets = (bets: Bet[]) => {
      setActiveBets(bets);
    };
    const unsubActiveBets1 = socketService.on('active_bets_list', handleActiveBets);
    const unsubActiveBets2 = socketService.on('active_bets_update', handleActiveBets);

    const unsubBalance = socketService.on('balance_updated', (data) => {
      setUser((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          mainBalance: data.mainBalance,
          withdrawableBalance: data.withdrawableBalance ?? prev.withdrawableBalance,
          promoWallet: data.promoWallet ?? prev.promoWallet,
          vipLevel: data.vipLevel ?? prev.vipLevel,
          lifetimeDeposit: data.lifetimeDeposit ?? prev.lifetimeDeposit,
          requiredWager: data.requiredWager ?? prev.requiredWager
        };
      });
      if (data.message) {
        showToast(data.message, 'success');
      }
    });

    const unsubLiveWalletSync = socketService.on('wallet_live_sync', (payload: any) => {
      if (!payload) return;
      const curr = userRef.current;
      if (
        curr &&
        (payload.userId === curr.id ||
          (payload.username && String(payload.username).toLowerCase() === curr.name.toLowerCase()) ||
          (payload.uid && String(payload.uid) === curr.uid))
      ) {
        if (payload.balance !== undefined) {
          setUser((prev) => {
            if (!prev) return null;
            return {
              ...prev,
              mainBalance: payload.balance,
              withdrawableBalance: payload.withdrawableBalance ?? prev.withdrawableBalance
            };
          });
          const walletEl = document.getElementById('realWallet');
          if (walletEl) {
            walletEl.innerText = payload.balance >= 900000000 ? '∞' : String(payload.balance);
          }
        }
      }
    });

    // MODULE 18: VIP Level Upgraded event
    const unsubVipUpgrade = socketService.on('vip_level_upgraded', (data: { vipLevel: number; label: string; maxSingleWithdrawal: number; lifetimeDeposit: number }) => {
      setUser((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          vipLevel: data.vipLevel,
          lifetimeDeposit: data.lifetimeDeposit
        };
      });
      showToast(
        `🌟 VIP UPGRADE! You reached ${data.label} (Tier ${data.vipLevel})! Single withdrawal limit increased to ₹${data.maxSingleWithdrawal.toLocaleString('en-IN')}!`,
        'success'
      );
    });

    // MODULE 18 & 19: Deposit Bonus Awarded
    const unsubBonusAwarded = socketService.on('bonus_awarded', (data: { amount: number; type: string; newPromoWallet: number }) => {
      setUser((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          promoWallet: data.newPromoWallet
        };
      });
      showToast(
        `🎁 ₹${data.amount} ${data.type === 'FIRST_TIME_DEPOSIT_BONUS' ? 'First-Time' : 'Deposit'} Bonus added to Promo Wallet!`,
        'success'
      );
    });

    // MODULE 19: Timed Campaign Updated Realtime Event
    const unsubCampaign = socketService.on('campaign_updated', (camp: TimedCampaign) => {
      setActiveCampaign(camp);
      if (camp.isActive) {
        showToast(`⚡ Promo Alert: "${camp.campaignTitle}" is now active!`, 'info');
      }
    });

    const unsubRebate = socketService.on('rebate_credited', (data) => {
      setUser((prev) => {
        if (!prev) return null;
        return { ...prev, promoWallet: data.newPromoWallet };
      });
      showToast(`0.02% Lifetime Betting Rebate (+₹${data.rebateAmount}) credited from ${data.fromUser}'s bet!`, 'success');
    });

    const unsubReferralUnlock = socketService.on('referral_bonus_unlocked', (data) => {
      setUser((prev) => {
        if (!prev) return null;
        return { ...prev, promoWallet: data.newPromoWallet };
      });
      showToast(`₹${data.amount} Referral Bounty unlocked! ${data.fromUser} completed first deposit!`, 'success');
    });

    const unsubBetError = socketService.on('bet_error', (data: any) => {
      console.error('[BET SERVER ERROR RECEIVED]', {
        code: data?.code,
        reason: data?.reason,
        userId: data?.userId,
        message: data?.message,
        payload: data
      });

      // Pinpoint multi-tab session conflicts
      if (data?.code === 'SESSION_SUPERSEDED' || data?.code === 'MULTI_TAB_SESSION_MISMATCH') {
        setIsSessionSuperseded(true);
        setSupersededReason(data?.message || 'Session active in another tab. Multi-tab betting is prohibited.');
        showToast(data?.message || 'Bet rejected: Multi-tab session conflict.', 'error');
        return;
      }

      // Pinpoint token mismatch or session expiration
      if (data?.code === 'TOKEN_MISMATCH') {
        showToast('Authentication token mismatch. Refreshing session...', 'error');
        localStorage.removeItem('winnova_token');
        fetch('/api/auth/demo-login', { method: 'POST' }).then(async (res) => {
          if (res.ok) {
            const d = await res.json();
            setUser(d.user);
            setToken(d.token);
            localStorage.setItem('winnova_token', d.token);
            localStorage.setItem('winnova_user_id', d.user.id);
            const currentSession = getTabSessionId();
            updateUserSessionInFirestore(d.user.id, currentSession).catch(() => {});
            socketService.joinUserRoom(d.user.id, currentSession);
            showToast('Session refreshed! You can now place your bet.', 'info');
          }
        }).catch(console.error);
        return;
      }

      if (data?.code === 'USER_NOT_FOUND' || data?.reason === 'SESSION_EXPIRED_OR_INVALID_USER') {
        showToast(`Session notice: ${data.message || 'User session expired. Restoring...'}`, 'error');
        fetch('/api/auth/demo-login', { method: 'POST' }).then(async (res) => {
          if (res.ok) {
            const d = await res.json();
            setUser(d.user);
            setToken(d.token);
            localStorage.setItem('winnova_token', d.token);
            localStorage.setItem('winnova_user_id', d.user.id);
            const currentSession = getTabSessionId();
            updateUserSessionInFirestore(d.user.id, currentSession).catch(() => {});
            socketService.joinUserRoom(d.user.id, currentSession);
            showToast('Account restored! Ready to bet.', 'info');
          }
        }).catch(console.error);
        return;
      }

      showToast(data?.message || 'Bet rejected by server', 'error');
    });

    const unsubCashoutError = socketService.on('cashout_error', (data) => {
      if (data?.message && (data.message.includes('Multi-tab') || data.message.includes('another tab'))) {
        setIsSessionSuperseded(true);
        setSupersededReason(data.message);
      }
      showToast(data.message || 'Cashout failed', 'error');
    });

    const unsubMaintenance = socketService.on('maintenance_status', (data: { active: boolean }) => {
      setGameState((prev) => ({ ...prev, maintenanceModeActive: data.active }));
      showToast(
        data.active
          ? 'System Maintenance Activated: New bets suspended.'
          : 'System Maintenance Concluded: Full gameplay restored!',
        data.active ? 'error' : 'success'
      );
    });

    const unsubSessionTerminated = socketService.on('session_terminated', (data: { reason: string }) => {
      setIsSessionSuperseded(true);
      setSupersededReason(data.reason || 'Account opened in another browser tab or device.');
      showToast(data.reason || 'Session closed from another device.', 'error');
    });

    const unsubLiabilityAlert = socketService.on('liability_spike_alert', (data: { totalLiability: number; threshold: number }) => {
      if (isSuperAdmin) {
        showToast(`⚠️ Liability Alert: Total exposure ₹${data.totalLiability} exceeded ₹${data.threshold}!`, 'error');
      }
    });

    const unsubHighRollers = socketService.on('high_rollers_update', (list: HighRollerWinner[]) => {
      if (Array.isArray(list)) {
        setHighRollers(list);
      }
    });

    const unsubPush = socketService.on('push_notification', (data: { title: string; body: string; tag?: string }) => {
      import('./services/notification').then(({ notificationService }) => {
        notificationService.sendLocalAlert(data.title, {
          body: data.body,
          tag: data.tag,
          requireInteraction: true
        });
      });
      showToast(`${data.title}: ${data.body}`, 'info');
    });

    const unsubNotifReceived = socketService.on('notification_received', (notif: any) => {
      const curr = userRef.current;
      if (!notif || notif.is_deleted) return;
      if (notif.targetUserId === 'ALL' || (curr && (notif.targetUserId === curr.id || notif.targetUserId === curr.uid))) {
        setLatestNotification(notif);
        setUnreadNotificationCount((prev) => prev + 1);
        showToast(
          notif.rewardAmount > 0
            ? `🎁 New Reward Notification: "${notif.title}" (+₹${notif.rewardAmount}) — Claim now!`
            : `🔔 New Notification: ${notif.title}`,
          'success'
        );
      }
    });

    return () => {
      unsubInit1();
      unsubInit2();
      unsubGameState();
      unsubCountdown();
      unsubFlight();
      unsubTick();
      unsubCrashed1();
      unsubCrashed2();
      unsubBetQueued();
      unsubBetPlaced();
      unsubCashedOut1();
      unsubCashedOut2();
      unsubActiveBets1();
      unsubActiveBets2();
      unsubBalance();
      unsubLiveWalletSync();
      unsubVipUpgrade();
      unsubBonusAwarded();
      unsubCampaign();
      unsubRebate();
      unsubReferralUnlock();
      unsubBetError();
      unsubCashoutError();
      unsubMaintenance();
      unsubSessionTerminated();
      unsubLiabilityAlert();
      unsubHighRollers();
      unsubPush();
      unsubNotifReceived();
    };
  }, []);

  // Fetch user notifications for persistent Notification Bar
  const fetchLatestNotification = async (targetUser: User | null) => {
    if (!targetUser) return;
    try {
      const res = await fetch(`/api/notifications/${encodeURIComponent(targetUser.id)}`);
      if (!res.ok) return;
      const data = await res.json();
      if (data.success && Array.isArray(data.notifications)) {
        const activeList = data.notifications.filter((n: AppNotification) => !n.is_deleted);
        if (activeList.length > 0) {
          setLatestNotification(activeList[0]);
          const unclaimedCount = activeList.filter(
            (n: AppNotification) => (n.rewardAmount || 0) > 0 && !(n.claimedBy || []).includes(targetUser.id)
          ).length;
          setUnreadNotificationCount(unclaimedCount > 0 ? unclaimedCount : 0);
        }
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    if (user?.id) {
      fetchLatestNotification(user);
    }
  }, [user?.id]);

  const handleClaimBannerReward = async (notif: AppNotification) => {
    if (!user || claimingBannerId) return;
    setClaimingBannerId(notif.id);
    try {
      const res = await fetch(`/api/notifications/${encodeURIComponent(notif.id)}/claim`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notificationId: notif.id, userId: user.id })
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message || `Claimed ₹${notif.rewardAmount}!`, 'success');
        fetchUserProfile(user.id);
        fetchLatestNotification(user);
      } else {
        showToast(data.error || 'Failed to claim reward.', 'error');
      }
    } catch {
      showToast('Network error while claiming notification reward.', 'error');
    } finally {
      setClaimingBannerId(null);
    }
  };

  // Join personal user room when logged in & enforce Single Session Tracking
  useEffect(() => {
    if (!user?.id) return;
    const currentSession = getTabSessionId();
    setTabSessionId(currentSession);

    // Overwrite currentSessionId in Firestore on tab open / user login
    updateUserSessionInFirestore(user.id, currentSession).catch((err) => {
      console.warn('[SESSION FIRESTORE SYNC NOTICE]', err);
    });

    // Synchronize currentSessionId with server
    fetch('/api/user/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user.id, sessionId: currentSession })
    }).catch(() => {});

    // Join personal user room with current session
    socketService.joinUserRoom(user.id, currentSession);

    // Real-time Firestore session listener to detect multi-tab hacking
    const unsubscribeSession = subscribeToUserSession(user.id, (activeSessionId) => {
      if (activeSessionId && activeSessionId !== currentSession) {
        console.warn(`[SINGLE SESSION ALERT] Session taken over by another tab: ${activeSessionId}`);
        setIsSessionSuperseded(true);
        setSupersededReason('Your account was opened in another browser tab or device. Multi-tab betting is locked on this screen.');
      } else if (activeSessionId === currentSession) {
        setIsSessionSuperseded(false);
      }
    });

    return () => {
      unsubscribeSession();
    };
  }, [user?.id]);

  const handleReactivateSession = async () => {
    const newSession = generateNewTabSessionId();
    setTabSessionId(newSession);
    setIsSessionSuperseded(false);
    setSupersededReason('');
    const targetUserId = user?.id || localStorage.getItem('winnova_user_id');
    if (targetUserId) {
      await updateUserSessionInFirestore(targetUserId, newSession).catch(() => {});
      await fetch('/api/user/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: targetUserId, sessionId: newSession })
      }).catch(() => {});
      socketService.joinUserRoom(targetUserId, newSession);
      showToast('Session activated in this tab. Previous tabs deactivated.', 'success');
    }
  };

  const handleLoginSuccess = (loggedInUser: User, authJwt: string, isSuper?: boolean) => {
    const newSession = generateNewTabSessionId();
    setTabSessionId(newSession);
    setIsSessionSuperseded(false);
    setSupersededReason('');

    setUser(loggedInUser);
    setToken(authJwt);
    localStorage.setItem('winnova_token', authJwt);
    localStorage.setItem('winnova_user_id', loggedInUser.id);
    if (isSuper) {
      setIsSuperAdmin(true);
      localStorage.setItem('winnova_is_sa', 'true');
    }

    updateUserSessionInFirestore(loggedInUser.id, newSession).catch(() => {});
    fetch('/api/user/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: loggedInUser.id, sessionId: newSession })
    }).catch(() => {});
    socketService.joinUserRoom(loggedInUser.id, newSession);

    setShowAuthModal(false);
    showToast(`Welcome back, ${loggedInUser.name}!`, 'success');
  };

  const handleRegisteredSuccess = (newUser: User, bonusAwarded: number) => {
    const newSession = generateNewTabSessionId();
    setTabSessionId(newSession);
    setIsSessionSuperseded(false);
    setSupersededReason('');

    setUser(newUser);
    setToken(`token_${newUser.id}`);
    localStorage.setItem('winnova_token', `token_${newUser.id}`);
    localStorage.setItem('winnova_user_id', newUser.id);

    updateUserSessionInFirestore(newUser.id, newSession).catch(() => {});
    fetch('/api/user/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: newUser.id, sessionId: newSession })
    }).catch(() => {});
    socketService.joinUserRoom(newUser.id, newSession);

    setShowAuthModal(false);
    setWelcomeBonus(bonusAwarded);
  };

  const handleLogout = () => {
    setUser(null);
    setToken(null);
    setIsSuperAdmin(false);
    localStorage.removeItem('winnova_token');
    localStorage.removeItem('winnova_user_id');
    localStorage.removeItem('winnova_is_sa');
    setShowAuthModal(true);
  };

  const handleToggleAudio = () => {
    const muted = audioService.toggleMute();
    setIsMuted(muted);
  };

  const handlePlaceBet = async (consoleIndex: 0 | 1, amount: number, autoCashout?: number) => {
    const currentToken = localStorage.getItem('winnova_token') || token;
    let activeUserId = user?.id || localStorage.getItem('winnova_user_id');

    console.log('[BET WORKFLOW INITIATED]', {
      consoleIndex,
      amount,
      autoCashout,
      activeUserId,
      sessionId: tabSessionId,
      tokenPresent: !!currentToken,
      userStatePresent: !!user,
      socketConnected: socketService.isConnected(),
      roundId: currentRoundIdRef.current,
      gameStatus: gameState.status
    });

    if (!activeUserId) {
      console.warn('[BET WORKFLOW] No active user ID found in state or localStorage. Triggering auto demo login recovery...');
      try {
        const res = await fetch('/api/auth/demo-login', { method: 'POST' });
        if (res.ok) {
          const data = await res.json();
          console.log('[BET WORKFLOW] Auto demo session recovered successfully:', data.user?.id);
          setUser(data.user);
          setToken(data.token);
          localStorage.setItem('winnova_token', data.token);
          localStorage.setItem('winnova_user_id', data.user.id);
          const currentSession = getTabSessionId();
          updateUserSessionInFirestore(data.user.id, currentSession).catch(() => {});
          socketService.joinUserRoom(data.user.id, currentSession);
          activeUserId = data.user.id;
        } else {
          console.error('[BET WORKFLOW] Demo login recovery returned status:', res.status);
          setShowAuthModal(true);
          return;
        }
      } catch (e) {
        console.error('[BET WORKFLOW] Demo login recovery error:', e);
        setShowAuthModal(true);
        return;
      }
    }

    if (!activeUserId) {
      setShowAuthModal(true);
      return;
    }

    // SINGLE SESSION ENFORCEMENT: Reject immediately if this tab was superseded
    if (isSessionSuperseded) {
      showToast('Multi-tab hacking blocked: Betting disabled because your account was opened in another tab.', 'error');
      return;
    }

    // Verify session in Firestore before submitting bet
    const verification = await verifySessionInFirestore(activeUserId, tabSessionId);
    if (!verification.valid) {
      setIsSessionSuperseded(true);
      setSupersededReason('Multi-tab hacking blocked: Another active tab has session control.');
      showToast('Multi-tab error: Your session was superseded by another tab. Multi-tab betting is disabled.', 'error');
      return;
    }

    socketService.joinUserRoom(activeUserId, tabSessionId);
    socketService.placeBet({
      userId: activeUserId,
      amount,
      consoleIndex,
      autoCashout,
      token: currentToken || undefined,
      sessionId: tabSessionId
    });
  };

  const handleCashOut = (betId: string) => {
    if (!user) return;

    // SINGLE SESSION ENFORCEMENT: Reject cashout if this tab was superseded
    if (isSessionSuperseded) {
      showToast('Cashout blocked: Multi-tab protection active. Only the latest active tab can cash out.', 'error');
      return;
    }

    // INSTANT WEB CASHOUT (ZERO DELAY): Non-blocking HTTP POST + WebSocket cashout executed immediately
    fetch('/api/game/cashout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        betId,
        userId: user.id,
        multiplier: liveMultiplierRef.current || gameState.multiplier || 1.00
      })
    }).then(async (res) => {
      const data = await res.json().catch(() => null);
      if (data && data.success) {
        showToast(`Cashed out at ${Number(data.multiplier).toFixed(2)}x! +₹${data.winAmount}`, 'success');
      }
    }).catch(() => {});

    socketService.cashOut({
      betId,
      userId: user.id,
      sessionId: tabSessionId
    });

    // Background session verification without blocking click execution
    verifySessionInFirestore(user.id, tabSessionId).then((verification) => {
      if (!verification.valid) {
        setIsSessionSuperseded(true);
        setSupersededReason('Multi-tab hacking blocked: Another active tab has session control.');
      }
    }).catch(() => {});
  };

  // Bottom Navigation Handler (Module 18)
  const handleBottomNavSelect = (tab: BottomNavTab) => {
    setBottomNavTab(tab);
    if (tab === 'lobby') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (tab === 'vip') {
      if (!user) {
        setShowAuthModal(true);
      } else {
        setShowVipSpinWheel(true);
      }
    } else if (tab === 'wallet') {
      if (!user) {
        setShowAuthModal(true);
      } else {
        setCashierModalTab('deposit');
      }
    } else if (tab === 'invite') {
      if (!user) {
        setShowAuthModal(true);
      } else {
        setShowReferralModal(true);
      }
    } else if (tab === 'profile') {
      if (!user) {
        setShowAuthModal(true);
      } else {
        setShowProfileModal(true);
      }
    } else if (tab === 'support') {
      setShowRulesModal(true);
    }
  };

  const isUserSuperAdmin = Boolean(isSuperAdmin || user?.role === 'superadmin');
  const userAvailableBalance = isUserSuperAdmin
    ? 999999999
    : (user?.mainBalance || 0) + (user?.bonusBalance || 0);

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden overflow-y-auto bg-[#101114] text-slate-100 flex flex-col justify-between selection:bg-rose-600 selection:text-white pb-20 relative">
      {/* 1. Header Navigation (Compact Brand + Balance + Controls) */}
      <Navbar
        user={user}
        isMuted={isMuted}
        isSuperAdmin={isSuperAdmin}
        unreadNotificationCount={unreadNotificationCount}
        onOpenNotifications={() => setShowNotificationCenter(true)}
        onOpenTelegramNetworks={() => setShowTelegramNetworksModal(true)}
        onOpenCashier={(tab) => setCashierModalTab(tab)}
        onOpenReferrals={() => setShowReferralModal(true)}
        onOpenRules={() => setShowRulesModal(true)}
        onOpenAdmin={() => setShowAdminModal(true)}
        onOpenProfile={() => setShowProfileModal(true)}
        onOpenVipSpin={() => setShowVipSpinWheel(true)}
        onToggleAudio={handleToggleAudio}
        onLogout={handleLogout}
        onOpenLogin={() => setShowAuthModal(true)}
      />

      {/* 2. Persistent Live Notification Bar (Replaces Fake Chat) */}
      <div
        id="live-notification-bar"
        className="bg-gradient-to-r from-[#14151b] via-[#191b24] to-[#14151b] border-b border-[#262936] px-3 sm:px-5 py-2 flex items-center justify-between gap-3 text-xs shadow-sm"
      >
        <div
          onClick={() => setShowNotificationCenter(true)}
          className="flex items-center gap-2.5 min-w-0 flex-1 cursor-pointer group"
        >
          <div className="p-1.5 rounded-lg bg-amber-500/15 text-amber-400 border border-amber-500/30 shrink-0 relative">
            <Bell className="w-3.5 h-3.5" />
            {unreadNotificationCount > 0 && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            )}
          </div>
          <div className="min-w-0 flex-1 truncate">
            {latestNotification ? (
              <div className="flex items-center gap-2 truncate">
                <span className="font-bold text-amber-300 shrink-0">{latestNotification.title}:</span>
                <span className="text-neutral-300 truncate group-hover:text-white transition">
                  {latestNotification.message}
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2 truncate">
                <span className="font-bold text-amber-300 shrink-0">Official Notice:</span>
                <span className="text-neutral-300 truncate group-hover:text-white transition">
                  Welcome to WIN NOVA! Check Notification Centre for official announcements and direct wallet rewards.
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {latestNotification &&
            (latestNotification.rewardAmount || 0) > 0 &&
            user &&
            !(latestNotification.claimedBy || []).includes(user.id) && (
              <button
                type="button"
                onClick={() => handleClaimBannerReward(latestNotification)}
                disabled={claimingBannerId === latestNotification.id}
                className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black text-[11px] flex items-center gap-1 shadow cursor-pointer transition"
              >
                <Gift className="w-3 h-3" />
                <span>
                  {claimingBannerId === latestNotification.id
                    ? 'Claiming...'
                    : `Claim ₹${latestNotification.rewardAmount}`}
                </span>
              </button>
            )}

          <button
            type="button"
            onClick={() => setShowNotificationCenter(true)}
            className="px-2.5 py-1 rounded-lg bg-[#22242e] hover:bg-[#2c2f3b] border border-[#343846] text-neutral-200 font-bold text-[11px] flex items-center gap-1 cursor-pointer transition"
          >
            <span>Inbox</span>
            {unreadNotificationCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[10px] font-black">
                {unreadNotificationCount}
              </span>
            )}
            <ChevronRight className="w-3 h-3 text-neutral-400" />
          </button>
        </div>
      </div>

      {/* Single Session Lock Banner (Multi-tab protection) */}
      {isSessionSuperseded && (
        <div
          id="single-session-lock-banner"
          className="bg-gradient-to-r from-red-950/95 via-red-900/90 to-red-950/95 border-b border-red-700/80 px-4 py-2.5 text-red-200 text-xs sm:text-sm flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg z-30"
        >
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping shrink-0" />
            <div className="text-left">
              <span className="font-bold text-white mr-1.5">Single Session Enforcement:</span>
              <span className="text-red-200">
                {supersededReason || 'Account opened in another browser tab. Multi-tab betting and cashouts are locked in this tab.'}
              </span>
            </div>
          </div>
          <button
            type="button"
            id="reactivate-session-btn"
            onClick={handleReactivateSession}
            className="px-3.5 py-1.5 bg-red-600 hover:bg-red-500 active:scale-95 text-white font-bold rounded-lg transition text-xs shrink-0 cursor-pointer shadow flex items-center gap-1.5"
          >
            <span>Resume in this Tab</span>
          </button>
        </div>
      )}

      {/* 3. Main Arena Layout */}
      <main className="flex-1 max-w-7xl w-full max-w-full mx-auto p-2 sm:p-4 md:p-5 flex flex-col gap-4 relative overflow-x-hidden">
        {/* Module 8: Scheduled Server Maintenance Overlay */}
        <MaintenanceOverlay active={Boolean(gameState.maintenanceModeActive)} />

        {/* Super Admin & Admin In-Game Side Controller (Crash Now & Real Player Bets Monitor) */}
        <AdminGameSideController
          user={user}
          isSuperAdmin={isSuperAdmin}
          gameStatus={gameState.status}
          multiplier={gameState.multiplier}
          activeBets={activeBets}
          onOpenFullDashboard={() => setShowAdminModal(true)}
          showToast={(msg, type) => showToast(msg, type === 'warning' ? 'info' : type)}
        />

        {/* Game Stage & Live Bets Split */}
        <div className="flex flex-col lg:flex-row gap-3 md:gap-4 items-stretch">
          {/* Left / Side Social Bets Feed with private identity masking */}
          <div className="order-2 lg:order-1 shrink-0">
            <LiveBetsPanel
              activeBets={activeBets}
              currentUserId={user?.id || ''}
              highRollers={highRollers}
            />
          </div>

          {/* Central Parabolic Track Canvas & Dual Betting Consoles */}
          <div className="order-1 lg:order-2 flex-1 flex flex-col gap-3 md:gap-4 min-w-0">
            {/* Plane Area Wrapper with Horizontal Mini History Bar attached directly to top border pane */}
            <div className="flex flex-col rounded-2xl border border-[#282a32] bg-[#141518] shadow-2xl relative">
              {/* HORIZONTAL MINI HISTORY BAR (PLANE KE THEEK UPAR BORDER PANE) */}
              <HistoryTicker history={gameState.history} />

              {/* Parabolic HTML5 Flight Canvas */}
              <GameCanvas
                status={gameState.status}
                multiplier={gameState.multiplier}
                countdownSeconds={gameState.countdownSeconds}
                elapsedSeconds={gameState.elapsedSeconds}
                crashMultiplier={gameState.crashMultiplier}
              />
            </div>

            {/* Dual Betting Consoles: Console 1 and Console 2 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
              <BettingConsole
                consoleIndex={0}
                status={gameState.status}
                multiplier={gameState.multiplier}
                countdownSeconds={gameState.countdownSeconds}
                userBalance={userAvailableBalance}
                activeBet={myBetsByConsole[0]}
                onPlaceBet={(amount, autoCashout) => handlePlaceBet(0, amount, autoCashout)}
                onCashOut={handleCashOut}
                onOpenDeposit={() => setCashierModalTab('deposit')}
              />

              <BettingConsole
                consoleIndex={1}
                status={gameState.status}
                multiplier={gameState.multiplier}
                countdownSeconds={gameState.countdownSeconds}
                userBalance={userAvailableBalance}
                activeBet={myBetsByConsole[1]}
                onPlaceBet={(amount, autoCashout) => handlePlaceBet(1, amount, autoCashout)}
                onCashOut={handleCashOut}
                onOpenDeposit={() => setCashierModalTab('deposit')}
              />
            </div>
          </div>
        </div>
      </main>

      {/* 4. Sleek White-Label Footer */}
      <footer className="w-full bg-[#0d0e10] border-t border-[#1e2026] py-3 px-4 text-center select-none">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between text-[11px] text-neutral-400 gap-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-neutral-300 font-['Chakra_Petch']">WIN NOVA</span>
            <span>&bull;</span>
            <span>Provably Fair & Real-Time Hybrid Multiplier Engine</span>
          </div>

          <div className="flex items-center gap-4 text-neutral-400">
            <button
              onClick={() => setShowRulesModal(true)}
              className="hover:text-neutral-200 transition cursor-pointer"
            >
              2.7s Progression Formula
            </button>
            <span>&bull;</span>
            <button
              onClick={() => setShowReferralModal(true)}
              className="hover:text-neutral-200 transition cursor-pointer"
            >
              0.02% Lifetime Rebate
            </button>
            <span>&bull;</span>
            <span>18+ Responsible Gaming</span>
          </div>
        </div>
      </footer>

      {/* 5. Floating Toast Notification */}
      {notification && (
        <div
          className={`fixed bottom-20 right-3 sm:right-5 left-3 sm:left-auto max-w-[calc(100vw-24px)] z-50 px-4 py-2.5 rounded-xl shadow-2xl border text-xs font-bold flex items-center gap-2 animate-in slide-in-from-bottom-5 duration-200 ${
            notification.type === 'success'
              ? 'bg-emerald-950/95 border-emerald-500/60 text-emerald-200'
              : notification.type === 'error'
              ? 'bg-red-950/95 border-red-500/60 text-red-200'
              : 'bg-[#1b1c22]/95 border-[#343744] text-white'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-current animate-ping" />
          <span>{notification.message}</span>
        </div>
      )}

      {/* 6. Module 18: Persistent Casino Bottom Navigation Bar */}
      <BottomNav
        activeTab={bottomNavTab}
        onTabChange={handleBottomNavSelect}
        user={user}
        onOpenCashier={(tab) => setCashierModalTab(tab)}
        onOpenReferrals={() => setShowReferralModal(true)}
        onOpenSupport={() => setShowRulesModal(true)}
        onOpenProfile={() => {
          if (!user) setShowAuthModal(true);
          else setShowProfileModal(true);
        }}
        onOpenVip={() => {
          if (!user) setShowAuthModal(true);
          else setShowVipSpinWheel(true);
        }}
        onOpenAdmin={() => setShowAdminModal(true)}
        isSuperAdmin={isSuperAdmin}
      />

      {/* 7. Modals */}
      {/* Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onLoginSuccess={handleLoginSuccess}
        onRegisteredSuccess={handleRegisteredSuccess}
      />

      {/* Welcome Bonus Reward Modal */}
      {welcomeBonus !== null && (
        <WelcomeBonusModal
          isOpen={true}
          bonusAmount={welcomeBonus}
          onClose={() => setWelcomeBonus(null)}
        />
      )}

      {/* Cashier Modal (Deposit with QR & UTR proof / VIP-Enforced Withdrawal) */}
      {user && cashierModalTab && (
        <CashierModal
          isOpen={true}
          initialTab={cashierModalTab}
          user={user}
          onClose={() => {
            setCashierModalTab(null);
            setBottomNavTab('lobby');
          }}
          onRefreshUser={() => fetchUserProfile(user.id)}
        />
      )}

      {/* Referral & Rebate Modal */}
      {user && (
        <ReferralModal
          isOpen={showReferralModal}
          user={user}
          onClose={() => {
            setShowReferralModal(false);
            setBottomNavTab('lobby');
          }}
        />
      )}

      {/* Super Admin Control Panel */}
      {isSuperAdmin && (
        <AdminDashboard
          isOpen={showAdminModal}
          onClose={() => setShowAdminModal(false)}
          adminKey="Faisal786"
          gameStatus={gameState.status}
          currentMultiplier={gameState.multiplier}
        />
      )}

      {/* Rules & Provably Fair Modal */}
      <RulesModal
        isOpen={showRulesModal}
        onClose={() => {
          setShowRulesModal(false);
          setBottomNavTab('lobby');
        }}
      />

      {/* Module 20 & 22: User Profile Panel & VIP Milestone Lucky Spin Wheel */}
      {user && (
        <ProfileModal
          isOpen={showProfileModal}
          user={user}
          onClose={() => setShowProfileModal(false)}
          onOpenCashier={(tab) => {
            setShowProfileModal(false);
            setCashierModalTab(tab);
          }}
          onRefreshUser={() => fetchUserProfile(user.id)}
          onLogout={handleLogout}
        />
      )}

      {/* Module 20: VIP Spin Wheel direct modal */}
      {user && (
        <VipSpinWheel
          isOpen={showVipSpinWheel}
          user={user}
          onClose={() => setShowVipSpinWheel(false)}
          onRewardClaimed={() => {
            fetchUserProfile(user.id);
          }}
        />
      )}

      {/* Notification & Reward Centre Modal */}
      <NotificationCenterModal
        isOpen={showNotificationCenter}
        user={user}
        onClose={() => {
          setShowNotificationCenter(false);
          fetchLatestNotification(user);
        }}
        onRefreshUser={() => {
          if (user?.id) {
            fetchUserProfile(user.id);
            fetchLatestNotification(user);
          }
        }}
        onUnreadCountChange={(cnt) => setUnreadNotificationCount(cnt)}
      />

      {/* Official Telegram Networks & VIP Prediction Bot Modal */}
      <TelegramNetworksModal
        isOpen={showTelegramNetworksModal}
        onClose={() => setShowTelegramNetworksModal(false)}
      />
    </div>
  );
}
