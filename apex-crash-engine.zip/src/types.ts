export interface User {
  id: string;
  uid: string;                 // Unique Player UID (e.g. UID-8492)
  name: string;
  email: string;
  phone: string;
  role: 'user' | 'admin' | 'superadmin' | 'subadmin';
  vipLevel?: number;           // VIP 0 to VIP 4
  vipTier?: string;            // Tier name (Bronze, Silver, Gold, Platinum, Diamond, VIP Elite)
  cumulativeVolume?: number;   // Volumetric Engine: Absolute sum of all placed bets
  percentageProgress?: number; // Clamped 0.00 to 100.00 tier progression
  nextTierDelta?: number;      // Remaining volume to reach next tier ceiling
  lifetimeDeposit?: number;    // Cumulative verified lifetime deposits (₹)
  depositCount?: number;       // Total number of completed deposits for multi-tier bonus
  mainBalance: number;          // Real cash balance
  promoWallet: number;          // Promo & 0.02% rebate wallet
  bonusBalance: number;         // Registration & pending bonus
  withdrawableBalance: number;  // Funds eligible for payout
  turnoverRequired: number;     // Wagering requirement to unlock bonus
  turnoverCompleted: number;    // Wagering volume achieved so far
  referralCode: string;
  referredBy?: string;
  referralRewardStatus: 'none' | 'pending' | 'released';
  isFrozen: boolean;
  currentSessionId?: string;    // Single session tracking ID (Firestore & Auth sync)
  deviceFingerprint: string;
  registeredIp: string;
  lastLoginIp: string;
  createdAt: number;
  lastActivityAt?: number;      // Module 20/21: Handshake and bet activity timestamp
  lastVipSpinAt?: number;       // Module 20: 24-hour VIP spin cooldown
  requiredWager?: number;       // Module 22: Dynamic countdown wagering target (₹)
  sessionInitialDeposit?: number;
  sessionInitialBalance?: number;
  netSessionProfit?: number;
  smartLockActive?: boolean;
  smartLockRoundsLeft?: number;
  smartLockTriggeredAt?: number;
  lastRevivalCreditAt?: number;       // Module 23: Last ₹18 loss-recovery revival credit
  revivalCreditsTotal?: number;
  promoConversionHistory?: Array<{
    amount: number;
    convertedToMain: number;
    rolloverRequired: number;
    timestamp: number;
  }>;
}

export interface Bet {
  id: string;
  userId: string;
  uid?: string;                // Player unique UID (e.g. UID-9412)
  userName: string;
  roundId: string;
  consoleIndex: 0 | 1;
  amount: number;
  autoCashoutMultiplier?: number;
  cashedOut: boolean;
  cashedOutMultiplier?: number;
  winAmount?: number;
  createdAt: number;
  isBot?: boolean;
}

export type GameStatus = 'WAITING' | 'FLYING' | 'CRASHED';

export interface GameState {
  roundId: string;
  status: GameStatus;
  multiplier: number;
  elapsedSeconds: number;
  crashMultiplier: number;
  countdownSeconds: number;
  startedAt: number;
  history: MultiplierHistoryItem[];
  controlMode: 'AUTO_AI' | 'MANUAL_OVERRIDE';
  activeBetsCount: number;
  totalBetAmount: number;
  onlinePlayersCount?: number;
  roundCashOutTotal?: number;
  totalCashOutThisRound?: number;
  maintenanceMode?: boolean;
  maintenanceModeActive?: boolean;
}

export interface MultiplierHistoryItem {
  roundId: string;
  roundName?: string;
  roundNumber?: number;
  multiplier: number;
  crashedAt: number;
}

export interface DepositRequest {
  id: string;
  orderId?: string;
  userId: string;
  userName: string;
  userPhone: string;
  amount: number;
  paymentMethod: 'UPI_QR' | 'BANK_TRANSFER' | 'IMPS';
  utrNumber: string;
  proofImageUrl: string;
  selfDeclaredConsent?: boolean;
  auditMetadata?: {
    clientIp: string;
    userAgent: string;
    epochTimestamp: number;
  };
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'EXPIRED';
  rejectionReason?: string;
  upiNodeId?: string;
  createdAt: number;
  expiresAt?: number;
  reviewedAt?: number;
  is_deleted?: boolean;
  deleted_at?: number;
}

export interface WithdrawalRequest {
  id: string;
  orderId?: string;
  userId: string;
  userName: string;
  userPhone: string;
  amount: number;
  taxPercent?: number;
  taxAmount?: number;
  netPayoutAmount?: number;
  walletDeducted?: number;
  payoutMethod: 'UPI' | 'BANK';
  upiId?: string;
  bankAccount?: string;
  ifscCode?: string;
  accountHolderName?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  rejectionReason?: string;
  adminUtr?: string;
  createdAt: number;
  reviewedAt?: number;
  is_deleted?: boolean;
  deleted_at?: boolean | number;
}

export const MIN_WITHDRAWAL_AMOUNT = 100;
export const WITHDRAWAL_TAX_RATE = 0.10; // Default 10% tax slab (< ₹2000: 10%, ₹2000-₹4999: 9%, >= ₹5000: 8%)

/**
 * Final Dynamic Withdrawal Tax Function (Exclusive Slab)
 * @param {number} requestedAmount - Jitna amount user nikalna chahta hai (e.g., 5000)
 * @param {number} walletBalance - User ke wallet mein abhi jitna balance hai
 */
export function processExclusiveWithdrawal(
  requestedAmount: number,
  walletBalance: number
): {
  success: boolean;
  message?: string;
  userGets: number;
  taxCollected: number;
  walletDeducted: number;
  remainingBalance: number;
  taxRate: number;
  taxPercent: number;
} {
  const cleanRequested = Math.max(0, +Number(requestedAmount || 0).toFixed(2));
  const cleanWallet = Math.max(0, +Number(walletBalance || 0).toFixed(2));
  let taxRate = 0.10; // Chote amounts par standard 10% tax

  // 1. DYNAMIC TAX SLABS (Bade amount par tax discount)
  if (cleanRequested >= 5000) {
    taxRate = 0.08; // ₹5000 ya usse upar par 8% tax (5000 ka 8% = ₹400)
  } else if (cleanRequested >= 2000) {
    taxRate = 0.09; // ₹2000 se ₹4999 tak 9% tax
  } else {
    taxRate = 0.10; // ₹2000 se kam par 10% tax
  }

  // 2. Calculations (Amount ke UPAR tax lagega)
  const taxAmount = +(cleanRequested * taxRate).toFixed(2);
  const totalWalletDeduction = +(cleanRequested + taxAmount).toFixed(2); // Jaise 5000 + 400 = 5400

  // 3. Balance Check
  if (cleanWallet < totalWalletDeduction) {
    return {
      success: false,
      message: `Insufficient Funds! Balance needed: ₹${totalWalletDeduction} (including ₹${taxAmount} tax).`,
      userGets: cleanRequested,
      taxCollected: taxAmount,
      walletDeducted: totalWalletDeduction,
      remainingBalance: cleanWallet,
      taxRate,
      taxPercent: Math.round(taxRate * 100)
    };
  }

  // 4. Final Safe Output Data (No data tampering)
  return {
    success: true,
    userGets: cleanRequested,                                        // User ko poora cash milega (₹5000)
    taxCollected: taxAmount,                                         // Admin ka tax profit (₹400)
    walletDeducted: totalWalletDeduction,                            // Wallet se total itna minus hoga (₹5400)
    remainingBalance: +(cleanWallet - totalWalletDeduction).toFixed(2),
    taxRate,
    taxPercent: Math.round(taxRate * 100)
  };
}

export function calculateWithdrawalTaxBreakdown(requestedAmount: number): {
  grossAmount: number;
  taxAmount: number;
  netPayoutAmount: number;
  walletDeducted: number;
  taxPercent: number;
} {
  const res = processExclusiveWithdrawal(requestedAmount, Number.MAX_SAFE_INTEGER);
  return {
    grossAmount: res.userGets,
    taxAmount: res.taxCollected,
    netPayoutAmount: res.userGets,
    walletDeducted: res.walletDeducted,
    taxPercent: res.taxPercent
  };
}

// ==========================================
// DATE FILTER: Pichle 30 Din Ka Check
// ==========================================
export function isWithinLast30Days(transactionDateInput: string | number | Date): boolean {
  if (!transactionDateInput) return false;
  const transactionDate = new Date(transactionDateInput);
  if (isNaN(transactionDate.getTime())) return true;
  const currentDate = new Date();
  // Dono dates ke beech ka difference milliseconds mein nikalna
  const timeDifference = currentDate.getTime() - transactionDate.getTime();
  // Milliseconds ko dino (days) mein convert karna
  const daysDifference = timeDifference / (1000 * 3600 * 24);
  // Agar difference 30 din ya usse kam hai toh true return karega
  return daysDifference <= 30;
}

export interface FraudAlert {
  id: string;
  userId: string;
  userEmail: string;
  userPhone: string;
  reason: 'DUPLICATE_DEVICE_FINGERPRINT' | 'DUPLICATE_IP_BONUS_HUNTING' | 'SELF_REFERRAL_ATTEMPT' | 'RAPID_ABUSE';
  deviceFingerprint: string;
  ipAddress: string;
  targetAccount?: string;
  actionTaken: 'BLOCKED' | 'FLAGGED';
  timestamp: number;
}

export interface ReferralStat {
  userId: string;
  userName: string;
  userPhone: string;
  registeredAt: number;
  hasDeposited: boolean;
  instantBonusStatus: 'PENDING' | 'RELEASED';
  rebateGenerated: number;
}

export interface TrendSeedConfig {
  mode: 'NATURAL' | 'FORCED_CRASH_STREAK' | 'HIGH_FLY_BAIT' | 'CUSTOM_SEQUENCE';
  customSequence: number[];
  consecutiveCrashesRemaining: number;
  autoOverrideOnLiability: boolean;
  liabilityCrashThreshold: number; // e.g. 10000 INR
}

export interface LiabilityAlert {
  currentLiability: number;
  threshold: number;
  activeRealStakes: number;
  liveMultiplier: number;
  recommendation: string;
  timestamp: number;
}

export interface CollectiveCashOutTicker {
  totalVolume: number;
  realVolume: number;
  syntheticVolume: number;
  isCrashed: boolean;
}

export type LeaderboardTimeframe = 'DAILY' | 'WEEKLY' | 'YEARLY';
export type LeaderboardMetric = 'MOST_MULTIPLIER' | 'MOST_WIN';

export interface LeaderboardEntry {
  id: string;
  username: string;
  anonymizedName: string;
  metricValue: number;
  multiplier: number;
  betAmount: number;
  payoutAmount: number;
  timeframe: LeaderboardTimeframe;
  type: LeaderboardMetric;
  timestamp: number;
  isSynthetic: boolean;
  roundId?: string;
}

export interface SystemConfig {
  minDeposit: number;
  minWithdrawal: number;
  targetHouseWinRate: number; // e.g. 0.60 for 60% loss
  turnoverMultiplier: number; // e.g. 1.5x
  instantReferralBonus: number; // 20 INR
  rebatePercent: number; // 0.0002 (0.02%)
  adminUpiId: string;
  adminUpiName: string;
  adminQrUrl: string;
  manualOverrideActive: boolean;
  nextRoundPresetCrash?: number;
  cheatPercentage?: number; // default 60%
  crashPercentage?: number; // default 47%
  smartProfitCapLimit: number; // e.g. 3000 INR
  rotateAfterTransactions: number; // e.g. 15
  activeDepositNodeId?: string;
  fakeChatEnabled: boolean;
  fakeChatMinSec: number;
  fakeChatMaxSec: number;
  maintenanceModeActive?: boolean;
  maxPlatformLiabilityThreshold?: number;
  trendSeedConfig?: TrendSeedConfig;
  posterGirlImageUrl?: string;
  telegramBotToken?: string;
  telegramChatId?: string;
  allowAdminRewardDispatch?: boolean;
}

export interface CheatPercentagesConfig {
  cheatPercentage: number; // default 60%
  crashPercentage: number; // default 47%
  updatedAt?: number;
  updatedBy?: string;
}

export type CheatTimeControlMode = 'MANUAL' | 'TIMED_DURATION' | 'SCHEDULED_WINDOW' | 'AUTO_DYNAMIC';

export interface CheatCrashTimeControl {
  // Master Cheat ON/OFF Switch (Super Admin & Approved Admin)
  // When true: all cheat modules & configured percentages work.
  // When false: 100% Fair Mode (no cheats work at all).
  cheatSystemEnabled: boolean;
  cheatToggleTimerActive?: boolean;
  cheatToggleDurationMinutes?: number;
  cheatToggleTimerStartedAt?: number;
  cheatToggleTimerExpiresAt?: number;
  cheatToggleTargetState?: boolean; // State held while timer runs; reverts to !cheatToggleTargetState on expiry
  lastToggledBy?: string;
  mode: CheatTimeControlMode;
  // Timed Duration Mode (active for N minutes)
  durationMinutes: number;
  timerActive: boolean;
  timerStartedAt: number;
  timerExpiresAt: number;
  timedCheatPercentage: number;
  timedCrashPercentage: number;
  // Scheduled Time Window Mode (HH:MM to HH:MM daily or specific time)
  scheduleEnabled: boolean;
  scheduleStartTime: string; // e.g. "14:00"
  scheduleEndTime: string;   // e.g. "18:00"
  scheduledCheatPercentage: number;
  scheduledCrashPercentage: number;
  // Set Time / Flight Seconds When To Crash
  crashAtFlightSecondsEnabled: boolean;
  crashAtFlightSeconds: number; // e.g. crash after 4.5s of flight
  scheduledExactCrashTime?: string; // e.g. "15:30"
  // Developer Loss Situation Protection ("if in loss situation of developers")
  devLossProtectionEnabled: boolean;
  devLossTriggerThreshold: number; // e.g. 0 (triggers whenever net profit < 0 or loss exceeds threshold)
  devLossCheatPercentage: number;  // e.g. 95%
  devLossCrashPercentage: number;  // e.g. 90%
  devLossMaxCrashMultiplier: number; // e.g. 1.35x max ceiling when developers are in loss
  isCurrentlyInDevLoss: boolean;
  currentDeveloperNetProfit: number;
  totalRealStakesCollected: number;
  totalRealPayoutsGiven: number;
  activeReason?: string;
}

/**
 * Formats or normalizes a 7-digit UID so every player has a clean, unique 7-digit UID.
 */
export function format7DigitUid(uid?: string, fallbackId?: string): string {
  if (uid) {
    const digits = uid.replace(/\D/g, '');
    if (digits.length === 7) return digits;
    if (digits.length > 7) return digits.slice(0, 7);
    if (digits.length > 0) return digits.padStart(7, '1');
  }
  if (fallbackId) {
    let hash = 0;
    for (let i = 0; i < fallbackId.length; i++) {
      hash = (hash * 31 + fallbackId.charCodeAt(i)) % 9000000;
    }
    return String(1000000 + Math.abs(hash));
  }
  return '1000001';
}

export interface DepositNode {
  id: string;
  upiId: string;
  displayName: string;
  qrImageUrl?: string;
  maxTransactions?: number;
  maxLimit?: number;
  currentTransactions: number;
  isActive: boolean;
  totalVolume: number;
  createdAt?: number;
  is_deleted?: boolean;
  deleted_at?: number;
}

export interface ChatMessage {
  id: string;
  userId?: string;
  username: string;
  message: string;
  timestamp: number;
  isFake?: boolean;
  avatarColor?: string;
  badge?: string;
  is_deleted?: boolean;
  deleted_at?: number;
}

export interface FakeChatSettings {
  enabled: boolean;
  minDelaySeconds: number;
  maxDelaySeconds: number;
  presetMessages: string[];
}

export interface FakeChatConfig {
  enabled: boolean;
  minIntervalSec: number;
  maxIntervalSec: number;
  userHandles: string[];
  messageTemplates: string[];
}

export interface HighRollerWinner {
  id: string;
  username: string;
  anonymizedName: string;
  multiplier: number;
  winAmount: number;
  timestamp: number;
  roundId?: string;
}

export interface SubAdminAccount {
  id: string;
  uid?: string;
  name: string;
  email: string;
  token: string;
  role: 'SUB_ADMIN';
  permissions: {
    canManageWithdrawals: boolean;
    canViewGameEngine: boolean;
    canViewMetrics: boolean;
    canManageDeposits: boolean;
    canConfirmOrderIds?: boolean; // Selected/Approved Admin permission for Deposit & Withdrawal Order ID confirmation
    canSendNotifications?: boolean;
    canSendNotificationsWithMoney?: boolean; // Strictly governed by Super Admin toggle
  };
  isActive: boolean;
  createdAt: number;
  is_deleted?: boolean;
  deleted_at?: number;
}

export interface PlatformNotification {
  id: string;
  targetUserId: string; // 'ALL' or specific userId / 7-digit UID
  title: string;
  message: string;
  type: 'REWARD' | 'SYSTEM' | 'PROMO' | 'SECURITY';
  rewardAmount: number;
  rewardType?: 'MAIN' | 'BONUS' | 'PROMO';
  claimedBy: string[];
  readBy: string[];
  dismissedBy?: string[];
  sentBy?: string;
  senderName?: string;
  senderRole: 'SUPER_ADMIN' | 'SUB_ADMIN' | 'ADMIN';
  isClaimed?: boolean;
  isRead?: boolean;
  claimedAt?: number;
  createdAt: number;
  is_deleted: boolean;
  deleted_at?: number | null;
  deletedBy?: string;
}

export type AppNotification = PlatformNotification;

export interface PeakVolumeSchedule {
  id: string;
  name: string;
  startHour: number; // 0 - 23
  endHour: number;   // 0 - 23
  forcedCrashProbability: number; // e.g. 0.65 (65% under 1.90x)
  isActive: boolean;
}

export function maskUsername(username: string): string {
  if (!username) return 'Pl***r';
  const clean = username.trim();
  if (clean.length <= 2) return clean[0].toUpperCase() + '***';
  if (clean.length <= 4) return clean[0].toUpperCase() + '***' + clean[clean.length - 1].toLowerCase();
  // Example: Ramesh -> Ra***h
  return clean.slice(0, 2) + '***' + clean.slice(-1);
}

export function maskPlayerName(name: string): string {
  return maskUsername(name);
}

export type VipTierLevel = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;

export interface VipTierConfig {
  level: VipTierLevel;
  minLifetimeDeposit: number;
  maxSingleWithdrawal: number;
  requiredBetAmount?: number;
  upgradeReward?: number;
  monthlyReward?: number;
  label: string;
}

export const VIP_TIERS: VipTierConfig[] = [
  { level: 0, minLifetimeDeposit: 0, maxSingleWithdrawal: 120, requiredBetAmount: 0, upgradeReward: 0, monthlyReward: 0, label: 'VIP 0' },
  { level: 1, minLifetimeDeposit: 100, maxSingleWithdrawal: 522, requiredBetAmount: 550, upgradeReward: 22, monthlyReward: 7, label: 'VIP 1' },
  { level: 2, minLifetimeDeposit: 500, maxSingleWithdrawal: 1500, requiredBetAmount: 2000, upgradeReward: 45, monthlyReward: 18, label: 'VIP 2' },
  { level: 3, minLifetimeDeposit: 2000, maxSingleWithdrawal: 6000, requiredBetAmount: 5000, upgradeReward: 85, monthlyReward: 40, label: 'VIP 3' },
  { level: 4, minLifetimeDeposit: 5000, maxSingleWithdrawal: 15000, requiredBetAmount: 10000, upgradeReward: 102, monthlyReward: 60, label: 'VIP 4' },
  { level: 5, minLifetimeDeposit: 10000, maxSingleWithdrawal: 25000, requiredBetAmount: 20000, upgradeReward: 180, monthlyReward: 110, label: 'VIP 5' },
  { level: 6, minLifetimeDeposit: 25000, maxSingleWithdrawal: 50000, requiredBetAmount: 50000, upgradeReward: 350, monthlyReward: 220, label: 'VIP 6' },
  { level: 7, minLifetimeDeposit: 50000, maxSingleWithdrawal: 100000, requiredBetAmount: 100000, upgradeReward: 650, monthlyReward: 450, label: 'VIP 7' },
  { level: 8, minLifetimeDeposit: 100000, maxSingleWithdrawal: 250000, requiredBetAmount: 200000, upgradeReward: 1250, monthlyReward: 850, label: 'VIP 8' },
  { level: 9, minLifetimeDeposit: 250000, maxSingleWithdrawal: 500000, requiredBetAmount: 500000, upgradeReward: 2500, monthlyReward: 1800, label: 'VIP 9' },
  { level: 10, minLifetimeDeposit: 500000, maxSingleWithdrawal: 1000000, requiredBetAmount: 1000000, upgradeReward: 5000, monthlyReward: 3600, label: 'VIP 10' }
];

export function getVipConfig(lifetimeDeposit: number = 0): VipTierConfig {
  for (let i = VIP_TIERS.length - 1; i >= 0; i--) {
    if (lifetimeDeposit >= VIP_TIERS[i].minLifetimeDeposit) {
      return VIP_TIERS[i];
    }
  }
  return VIP_TIERS[0];
}

export interface VipLevelDataItem {
  level: number;
  levelName: string;
  requiredDeposit: number;
  requiredBetAmount: number;
  currentAccumulated: number;
  currentBetAccumulated: number;
  upgradeReward: number;
  monthlyReward: number;
  dailyWithdrawLimit: number;
  progressPercentage: number;
  isLocked: boolean;
}

export interface CoreVipState {
  currentViewingIndex: number;
  userActualVipLevel: number;
  lifetimeDeposit: number;
  cumulativeBetVolume: number;
  vipLevelsData: VipLevelDataItem[];
}

export function buildLiveVipLevelsData(
  user?: Partial<User> | null,
  activeCampaign?: TimedCampaignState | null
): CoreVipState {
  const isSuper =
    user?.role === 'superadmin' ||
    user?.id === 'admin_master_01' ||
    (user?.mainBalance || 0) >= 900000000;
  const lifetimeDeposit = isSuper ? Math.max(500000, Number(user?.lifetimeDeposit || 0)) : Number(user?.lifetimeDeposit || 0);
  const cumulativeBetVolume = isSuper
    ? Math.max(1000000, Number(user?.cumulativeVolume ?? user?.turnoverCompleted ?? 0))
    : Number(user?.cumulativeVolume ?? user?.turnoverCompleted ?? 0);

  const resolvedConfig = getVipConfig(lifetimeDeposit);
  const userActualVipLevel = isSuper
    ? 10
    : typeof user?.vipLevel === 'number'
    ? Math.max(user.vipLevel, resolvedConfig.level)
    : resolvedConfig.level;

  const vipLevelsData: VipLevelDataItem[] = VIP_TIERS.map((tier, idx) => {
    const reqDeposit = tier.minLifetimeDeposit;
    const reqBet = tier.requiredBetAmount ?? calculateSlidingWager(reqDeposit);

    // Map live bonus from BASELINE_DEPOSIT_BONUSES & active TimedCampaign overrides
    const baselineMatch = BASELINE_DEPOSIT_BONUSES.find((b) => b.depositAmount === reqDeposit);
    const campaignOverride =
      activeCampaign?.isActive && activeCampaign?.overrides
        ? activeCampaign.overrides[String(reqDeposit)]
        : undefined;

    const upgradeReward =
      campaignOverride?.firstTime ??
      baselineMatch?.firstTimeBonus ??
      tier.upgradeReward ??
      0;

    const monthlyReward =
      campaignOverride?.recurring ??
      baselineMatch?.recurringBonus ??
      tier.monthlyReward ??
      0;

    const isUnlocked = isSuper || idx <= userActualVipLevel || lifetimeDeposit >= reqDeposit;

    // Progress percentage calculation toward next tier or current tier target
    const nextTier = VIP_TIERS[Math.min(VIP_TIERS.length - 1, idx + 1)];
    const targetForBar = idx === 0 ? nextTier.minLifetimeDeposit : reqDeposit;
    let progressPercentage = 0;
    if (isSuper || idx <= userActualVipLevel) {
      progressPercentage = 100;
    } else if (targetForBar <= 0) {
      progressPercentage = 100;
    } else {
      progressPercentage = Math.min(100, Math.max(0, Math.floor((lifetimeDeposit / targetForBar) * 100)));
    }

    return {
      level: idx,
      levelName: `VIP${idx}`,
      requiredDeposit: reqDeposit,
      requiredBetAmount: reqBet,
      currentAccumulated: lifetimeDeposit,
      currentBetAccumulated: cumulativeBetVolume,
      upgradeReward,
      monthlyReward,
      dailyWithdrawLimit: tier.maxSingleWithdrawal,
      progressPercentage,
      isLocked: !isUnlocked
    };
  });

  return {
    currentViewingIndex: userActualVipLevel,
    userActualVipLevel,
    lifetimeDeposit,
    cumulativeBetVolume,
    vipLevelsData
  };
}

// Module 18: Multi-Tiered First/Recurring Deposit Bonus Engine
export interface DepositBonusTier {
  depositAmount: number;
  firstTimeBonus: number;
  recurringBonus: number;
}

export const BASELINE_DEPOSIT_BONUSES: DepositBonusTier[] = [
  { depositAmount: 100, firstTimeBonus: 22, recurringBonus: 7 },
  { depositAmount: 200, firstTimeBonus: 29, recurringBonus: 11 },
  { depositAmount: 500, firstTimeBonus: 45, recurringBonus: 18 },
  { depositAmount: 1000, firstTimeBonus: 65, recurringBonus: 25 },
  { depositAmount: 2000, firstTimeBonus: 85, recurringBonus: 40 },
  { depositAmount: 5000, firstTimeBonus: 102, recurringBonus: 60 } // Absolute Ceiling
];

// Module 19: Timed Promotional Campaigns & Overrides
export interface TimedCampaignState {
  isActive: boolean;
  campaignTitle: string;
  durationMinutes: number;
  startsAt: number;
  expiresAt: number;
  overrides: Record<string, { firstTime: number; recurring: number }>;
}

export type TimedCampaign = TimedCampaignState;

// =========================================================================
// MODULE 20: VIP LOYALTY ENGAGEMENT WHEEL PRIZES
// =========================================================================
export interface VipPrize {
  id: string;
  label: string;
  amount: number;
  type: 'PROMO_WALLET' | 'BONUS_CHIP' | 'BET_BOOST' | 'NO_PRIZE';
  color: string;
  description: string;
  probabilityWeight: number; // Server-side structural RNG
}

export const VIP_SPIN_PRIZES: VipPrize[] = [
  { id: 'prize_5', label: '₹5 Promo', amount: 5, type: 'PROMO_WALLET', color: '#10b981', description: 'Credited to Promo Wallet', probabilityWeight: 35 },
  { id: 'prize_10', label: '₹10 Promo', amount: 10, type: 'PROMO_WALLET', color: '#06b6d4', description: 'Credited to Promo Wallet', probabilityWeight: 25 },
  { id: 'prize_boost', label: '1.1x Boost', amount: 1.1, type: 'BET_BOOST', color: '#8b5cf6', description: 'Next Bet Multiplier Boost', probabilityWeight: 8 },
  { id: 'prize_2', label: '₹2 Bonus', amount: 2, type: 'BONUS_CHIP', color: '#f59e0b', description: 'Instant Bonus Chip', probabilityWeight: 15 },
  { id: 'prize_15', label: '₹15 Promo', amount: 15, type: 'PROMO_WALLET', color: '#14b8a6', description: 'Credited to Promo Wallet', probabilityWeight: 10 },
  { id: 'prize_none', label: 'Better Luck', amount: 0, type: 'NO_PRIZE', color: '#4b5563', description: 'Free spin again in 24h', probabilityWeight: 2 },
  { id: 'prize_20', label: '₹20 Promo', amount: 20, type: 'PROMO_WALLET', color: '#f43f5e', description: 'VIP High Bonus', probabilityWeight: 4 },
  { id: 'prize_25', label: '₹25 Mystery', amount: 25, type: 'PROMO_WALLET', color: '#fbbf24', description: 'Rare Jackpot Drop', probabilityWeight: 1 }
];

// =========================================================================
// MODULE 21: WHALE VELOCITY ISOLATION ENGINE
// =========================================================================
export const WHALE_STAKE_THRESHOLD = 2000; // Trigger limit updated from 5000 to 2000

export function evaluateWhaleRisk(userId: string, currentBetAmount: number): boolean {
  if (currentBetAmount >= WHALE_STAKE_THRESHOLD) {
    console.log(`WHALE ALERT: User ${userId} placed a high stake of ₹${currentBetAmount}. Shifting to Targeted Rigging Sequence.`);
    return true; // Routes user to the 2-round bait-and-clamp loop
  }
  return false;
}

// =========================================================================
// MODULE 22: DYNAMIC SLIDING SCALE WAGER TURNOVER FORMULA
// =========================================================================
export function calculateSlidingWager(depositAmount: number): number {
  let wagerMultiplier = 5.5; // Default low-tier multiplier

  if (depositAmount === 100) {
    wagerMultiplier = 5.5;
  } else if (depositAmount === 200) {
    wagerMultiplier = 5.0;
  } else if (depositAmount === 500) {
    wagerMultiplier = 4.0;
  } else if (depositAmount === 1000) {
    wagerMultiplier = 3.0;
  } else if (depositAmount === 2000) {
    wagerMultiplier = 2.5;
  } else if (depositAmount >= 5000) {
    wagerMultiplier = 2.0; // Reduced high-tier multiplier for big whales
  }

  let calculatedWager = depositAmount * wagerMultiplier;
  return calculatedWager;
}

// =========================================================================
// UPI ACCOUNTS & ROLE CONTROL
// =========================================================================
export interface UpiAccount {
  id: number;
  upi_id: string;
  today_received: number;
  max_limit: number;
  status: 'active' | 'pending' | 'completed';
  is_deleted?: boolean;
  deleted_at?: number;
}

// =========================================================================
// VOLUMETRIC MATHEMATICAL PROGRESSION ENGINE
// =========================================================================
export interface VolumetricTierConfig {
  tierIndex: number;
  tierName: string;
  tierBase: number;
  tierCeiling: number;
}

export const VOLUMETRIC_TIER_MATRIX: VolumetricTierConfig[] = [
  { tierIndex: 0, tierName: 'Bronze Tier', tierBase: 0, tierCeiling: 1000 },
  { tierIndex: 1, tierName: 'Silver Tier', tierBase: 1000, tierCeiling: 5000 },
  { tierIndex: 2, tierName: 'Gold Tier', tierBase: 5000, tierCeiling: 20000 },
  { tierIndex: 3, tierName: 'Platinum Tier', tierBase: 20000, tierCeiling: 50000 },
  { tierIndex: 4, tierName: 'Diamond Tier', tierBase: 50000, tierCeiling: 100000 },
  { tierIndex: 5, tierName: 'VIP Elite Club', tierBase: 100000, tierCeiling: 250000 }
];

export interface VolumetricProgressionResult {
  cumulativeVolume: number;
  activeTier: VolumetricTierConfig;
  tierIndex: number;
  tierName: string;
  tierBase: number;
  tierCeiling: number;
  percentageProgress: number;
  nextTierDelta: number;
  isMaxTier: boolean;
}

/**
 * Extracts user performance data using strict cumulative math module:
 * 1. Cumulative_Volume = Absolute Sum of All Placed Bets.
 *    (Progression logic ignores win/loss outcome flags and continuously increments base history)
 * 2. Percentage_Progress = ((Current_Volume - Tier_Base) / (Tier_Ceiling - Tier_Base)) * 100.
 *    (Securely clamped strictly between 0.00 and 100.00)
 * 3. Next_Tier_Delta = Tier_Ceiling - Current_Volume.
 */
export function calculateVolumetricProgression(
  currentVolumeOrBets: number | Array<{ amount: number } | number>,
  tierMatrix: VolumetricTierConfig[] = VOLUMETRIC_TIER_MATRIX
): VolumetricProgressionResult {
  let cumulativeVolume = 0;
  if (Array.isArray(currentVolumeOrBets)) {
    cumulativeVolume = currentVolumeOrBets.reduce<number>((sum, b) => {
      const amt = typeof b === 'number' ? b : (b?.amount || 0);
      return sum + Math.abs(Number(amt) || 0);
    }, 0);
  } else {
    cumulativeVolume = Math.abs(Number(currentVolumeOrBets) || 0);
  }

  let activeTier = tierMatrix[0];
  for (let i = 0; i < tierMatrix.length; i++) {
    const tier = tierMatrix[i];
    if (cumulativeVolume >= tier.tierBase) {
      activeTier = tier;
    }
  }

  const { tierBase, tierCeiling, tierName, tierIndex } = activeTier;
  const isMaxTier = tierIndex === tierMatrix.length - 1 && cumulativeVolume >= tierCeiling;

  // Compute visual percentage progression using standard fractional equation
  let rawProgress = 0;
  if (tierCeiling > tierBase) {
    rawProgress = ((cumulativeVolume - tierBase) / (tierCeiling - tierBase)) * 100;
  }
  // Securely clamp floating-point outcome metric strictly between 0.00 and 100.00
  const percentageProgress = Number(Math.max(0, Math.min(100, rawProgress)).toFixed(2));

  // Determine next tier deltas using mathematical delta matrix
  const nextTierDelta = Number(Math.max(0, tierCeiling - cumulativeVolume).toFixed(2));

  return {
    cumulativeVolume,
    activeTier,
    tierIndex,
    tierName,
    tierBase,
    tierCeiling,
    percentageProgress,
    nextTierDelta,
    isMaxTier
  };
}

// =========================================================================
// MODULE 22: BROWSER DATA SCRAPING LAYER & RETENTION TYPES
// =========================================================================
export interface BrowserScrapedMetrics {
  uid: string;
  balance: number;
  role: string;
  transactionRef: string;
  cumulativeVolume: number;
  percentageProgress: number;
  nextTierDelta: number;
  activeLedgerRoute: string;
  timestamp: number;
}

export function cleanDomNumeric(raw: unknown): number {
  if (typeof raw === 'number') return isNaN(raw) ? 0 : raw;
  if (!raw) return 0;
  const cleaned = String(raw).replace(/[^\d.-]/g, '').trim();
  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? 0 : Number(parsed.toFixed(2));
}

export function cleanDomString(raw: unknown): string {
  if (!raw) return '';
  return String(raw)
    .replace(/<[^>]*>?/gm, '')
    .replace(/[\n\r\t]+/g, ' ')
    .trim();
}

// =========================================================================
// AVIATOR 8-SEC 2X EXPONENTIAL CURVE & SECURE FIRESTORE WALLET SYSTEM
// =========================================================================
// Mathematically: e^(speed_factor * 8) = 2 => speed_factor = ln(2) / 8 ≈ 0.08664339756999316
export const AVIATOR_SPEED_FACTOR = 0.06931471805599453; // 20% decreased flight speed (0.08664339756999316 * 0.8)

export interface UserWalletDoc {
  userId: string;
  deposited_balance: number;
  bonus_balance: number;
  gift_balance: number;
  total_balance: number;
  updatedAt?: any;
}

export interface WalletTransactionDoc {
  id?: string;
  type: 'deposit' | 'bonus' | 'gift_code' | 'admin_credit';
  amount: number;
  balance_type: 'deposited_balance' | 'bonus_balance' | 'gift_balance';
  previous_balance: number;
  new_balance: number;
  credited_by: string;
  note?: string;
  timestamp: any;
}





