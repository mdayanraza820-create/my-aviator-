import React, { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

interface ScreenGuardProps {
  children: React.ReactNode;
}

interface ScreenGuardState {
  hasError: boolean;
  retryKey: number;
}

class ScreenGuardBoundary extends React.Component<ScreenGuardProps, ScreenGuardState> {
  declare props: Readonly<ScreenGuardProps>;
  declare setState: React.Component<ScreenGuardProps, ScreenGuardState>['setState'];
  state: ScreenGuardState = { hasError: false, retryKey: 0 };

  static getDerivedStateFromError(): Partial<ScreenGuardState> {
    return { hasError: true };
  }

  componentDidCatch() {
    setTimeout(() => {
      this.setState((prev) => ({ hasError: false, retryKey: prev.retryKey + 1 }));
    }, 10);
  }

  render() {
    return <React.Fragment key={this.state.retryKey}>{this.props.children}</React.Fragment>;
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ScreenGuardBoundary>
      <App />
    </ScreenGuardBoundary>
  </StrictMode>,
);
