/**
 * ============================================================================
 * SUPER ADMIN OVERRIDES & REAL-TIME FIRESTORE SYNCHRONIZATION
 * ============================================================================
 * Capabilities:
 * 1. Absolute Master Remote Authority: Overwrite, Credit, Debit, or Zero Out (0.00)
 *    any player's wallet data with atomic Before/After audit tracking.
 * 2. Real-Time Snapshot Sync (onSnapshot): Any change in Admin panel updates
 *    all active players' screens instantly without a page refresh.
 * 3. Global UPI Configuration: Master control to update the platform UPI ID
 *    stored in /system_config/global with live propagation to all players.
 * 4. Comprehensive Ledger Commit: Writes to /admin_audit_trail on every mutation.
 * ============================================================================
 */

import {
  doc,
  getDoc,
  setDoc,
  serverTimestamp,
  onSnapshot,
  Firestore,
  Unsubscribe
} from 'firebase/firestore';
import { persistentDb as db, persistentAuth as auth } from './firebaseCloudSync';
import { DeepAuditSystem } from './deepAuditSystem';
import { UserWalletDoc } from '../types';

export type BalanceOverrideAction = 'CREDIT' | 'DEBIT' | 'OVERWRITE' | 'ZERO_OUT';

export interface ModifyBalanceParams {
  adminId: string;
  targetUserId: string;
  action: BalanceOverrideAction;
  amount?: number;
  reason?: string;
  note?: string;
}

export interface ModifyBalanceResult {
  success: boolean;
  targetUserId: string;
  action: BalanceOverrideAction;
  beforeBalance: number;
  afterBalance: number;
  auditTrailId: string;
  message: string;
}

/**
 * Super Admin Master Remote Balance Authority
 * Performs atomic modification of user wallet, logs Before/After snapshots,
 * and notifies active game sessions.
 */
export async function superAdminModifyUserBalance(
  params: ModifyBalanceParams
): Promise<ModifyBalanceResult> {
  const { adminId, targetUserId, action, amount = 0, reason, note } = params;

  if (!targetUserId) {
    throw new Error('Target User ID is required for Super Admin balance modification.');
  }

  const userDocRef = doc(db as Firestore, 'users', targetUserId);
  const walletDocRef = doc(db as Firestore, 'wallets', targetUserId);

  // 1. Fetch current Before Snapshot
  const [userSnap, walletSnap] = await Promise.all([
    getDoc(userDocRef),
    getDoc(walletDocRef)
  ]);

  const userData = userSnap.exists() ? userSnap.data() : {};
  const walletData = walletSnap.exists() ? walletSnap.data() : {};

  const beforeBalance = Number(walletData.deposited_balance ?? userData.balance ?? userData.mainBalance ?? 0);
  const beforeBonus = Number(walletData.bonus_balance ?? userData.bonusBalance ?? 0);
  const beforePromo = Number(userData.promoWallet ?? 0);

  let newDeposited = beforeBalance;
  let newBonus = beforeBonus;
  let newPromo = beforePromo;

  // 2. Compute Target Balances according to Master Action
  switch (action) {
    case 'CREDIT':
      newDeposited = +(beforeBalance + Math.max(0, amount)).toFixed(2);
      break;

    case 'DEBIT':
      newDeposited = Math.max(0, +(beforeBalance - Math.max(0, amount)).toFixed(2));
      break;

    case 'OVERWRITE':
      newDeposited = Math.max(0, +amount.toFixed(2));
      break;

    case 'ZERO_OUT':
      // Strictly 0.00 zero-out across all balances
      newDeposited = 0.00;
      newBonus = 0.00;
      newPromo = 0.00;
      break;

    default:
      throw new Error(`Unsupported master override action: ${action}`);
  }

  const newTotal = +(newDeposited + newBonus).toFixed(2);

  const beforeSnapshot = {
    balance: beforeBalance,
    bonus_balance: beforeBonus,
    promo_wallet: beforePromo,
    total_balance: +(beforeBalance + beforeBonus).toFixed(2)
  };

  const afterSnapshot = {
    balance: newDeposited,
    bonus_balance: newBonus,
    promo_wallet: newPromo,
    total_balance: newTotal
  };

  // 3. Atomically update Firestore /wallets/{targetUserId}
  const walletPayload: UserWalletDoc = {
    userId: targetUserId,
    deposited_balance: newDeposited,
    bonus_balance: newBonus,
    gift_balance: Number(walletData.gift_balance || 0),
    total_balance: newTotal,
    updatedAt: serverTimestamp()
  };

  await setDoc(walletDocRef, walletPayload, { merge: true });

  // 4. Update Firestore /users/{targetUserId} for cross-platform profile parity
  await setDoc(
    userDocRef,
    {
      balance: newDeposited,
      mainBalance: newDeposited,
      withdrawableBalance: newDeposited,
      bonusBalance: newBonus,
      promoWallet: newPromo,
      updatedAt: serverTimestamp()
    },
    { merge: true }
  );

  // 5. Commit Immutable Before/After Audit Trail to /admin_audit_trail
  const auditTrailId = await DeepAuditSystem.commitAdminAuditTrail({
    adminId: adminId || auth.currentUser?.uid || 'super_admin',
    targetUserId,
    action,
    beforeSnapshot,
    afterSnapshot,
    amount,
    reason: reason || note || `Super Admin master override: ${action} ₹${amount}`,
    timestamp: serverTimestamp()
  });

  // 6. Optional: Sync with local Node backend for active WebSockets emission
  try {
    const adminKey = localStorage.getItem('winnova_admin_key') || 'WINNOVA_MASTER_ADMIN_SECRET_KEY_PROD_2025';
    let backendAction = 'ADD_BALANCE';
    if (action === 'DEBIT') backendAction = 'DEDUCT_BALANCE';
    if (action === 'OVERWRITE') backendAction = 'SET_BALANCE';
    if (action === 'ZERO_OUT') backendAction = 'ZERO_BALANCE';

    await fetch('/api/admin/user/action', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-key': adminKey
      },
      body: JSON.stringify({
        userId: targetUserId,
        action: backendAction,
        amount: action === 'ZERO_OUT' ? 0 : amount,
        note: reason || note || `Master remote ${action}`
      })
    });
  } catch (err) {
    // Non-blocking: Direct Firestore sync is the source of truth
    console.warn('[superAdminModifyUserBalance] Backend memory sync notice:', err);
  }

  return {
    success: true,
    targetUserId,
    action,
    beforeBalance,
    afterBalance: newDeposited,
    auditTrailId,
    message: `Master override ${action} completed: ₹${beforeBalance.toFixed(2)} -> ₹${newDeposited.toFixed(2)}`
  };
}

/**
 * Super Admin Global UPI Gateway Configuration
 * Updates the global system document and broadcasts active UPI ID across all players.
 */
export async function updateGlobalSystemUpi(params: {
  adminId: string;
  upiId: string;
  qrCodeUrl?: string;
  merchantName?: string;
  note?: string;
}): Promise<boolean> {
  const { adminId, upiId, qrCodeUrl, merchantName = 'WIN NOVA Cashier', note } = params;

  if (!upiId || !upiId.includes('@')) {
    throw new Error('Please specify a valid UPI ID (e.g. merchant@upi).');
  }

  const systemConfigRef = doc(db as Firestore, 'system_config', 'global');
  const depositNodeRef = doc(db as Firestore, 'deposit_nodes', 'active_upi');

  const configPayload = {
    activeUpiId: upiId.trim(),
    upiId: upiId.trim(),
    qrCodeUrl: qrCodeUrl || '',
    merchantName: merchantName.trim(),
    updatedAt: serverTimestamp(),
    updatedBy: adminId || auth.currentUser?.uid || 'super_admin'
  };

  await Promise.all([
    setDoc(systemConfigRef, configPayload, { merge: true }),
    setDoc(
      depositNodeRef,
      {
        id: 'active_upi',
        upiId: upiId.trim(),
        qrImageUrl: qrCodeUrl || '',
        displayName: merchantName.trim(),
        isActive: true,
        updatedAt: serverTimestamp()
      },
      { merge: true }
    )
  ]);

  // Record to Admin Audit Trail
  await DeepAuditSystem.commitAdminAuditTrail({
    adminId: adminId || auth.currentUser?.uid || 'super_admin',
    targetUserId: 'SYSTEM_GLOBAL',
    action: 'UPDATE_UPI',
    beforeSnapshot: {},
    afterSnapshot: configPayload,
    reason: note || `Updated platform active UPI ID to ${upiId}`
  });

  // Notify local backend if available
  try {
    const adminKey = localStorage.getItem('winnova_admin_key') || 'WINNOVA_MASTER_ADMIN_SECRET_KEY_PROD_2025';
    await fetch('/api/admin/config', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-key': adminKey
      },
      body: JSON.stringify({ activeUpiId: upiId.trim(), upiMerchantName: merchantName.trim() })
    });
  } catch {}

  return true;
}

/**
 * Real-Time onSnapshot Listener: Global System Configuration
 * Propagates UPI ID changes to Cashier modals and UI without page reload.
 */
export function subscribeToGlobalSystemConfig(
  onUpdate: (config: { activeUpiId: string; merchantName: string }) => void
): Unsubscribe {
  const docRef = doc(db as Firestore, 'system_config', 'global');
  return onSnapshot(
    docRef,
    (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        onUpdate({
          activeUpiId: data.activeUpiId || 'winnova.merchant@upi',
          merchantName: data.merchantName || 'WIN NOVA Cashier'
        });
      }
    },
    (err) => {
      console.warn('[subscribeToGlobalSystemConfig] Realtime listener notice:', err);
    }
  );
}

export interface ModifyBalanceByUidParams {
  adminId: string;
  targetUid: string;
  action: BalanceOverrideAction;
  amount?: number;
  walletType?: 'main' | 'bonus' | 'promo';
  reason?: string;
  note?: string;
}

/**
 * Super Admin Master Balance Transfer by 7-Digit UID
 * Allows Super Admin (with Unlimited Balance) to credit, debit, overwrite, or zero-out
 * any player anytime using their unique 7-digit UID.
 */
export async function superAdminModifyBalanceByUid(
  params: ModifyBalanceByUidParams
): Promise<ModifyBalanceResult & { targetUser?: any }> {
  const { adminId, targetUid, action, amount = 0, walletType = 'main', reason, note } = params;
  const cleanUid = String(targetUid || '').replace(/\D/g, '').trim();

  if (!cleanUid || cleanUid.length < 4) {
    throw new Error('Please enter a valid 7-digit Player UID (e.g. 1048291).');
  }

  const adminKey = localStorage.getItem('winnova_admin_key') || 'WINNOVA_MASTER_ADMIN_SECRET_KEY_PROD_2025';
  let backendAction = 'ADD_BALANCE';
  if (action === 'DEBIT') backendAction = 'DEDUCT_BALANCE';
  if (action === 'OVERWRITE') backendAction = 'SET_BALANCE';
  if (action === 'ZERO_OUT') backendAction = 'ZERO_BALANCE';

  const res = await fetch('/api/admin/user/balance-by-uid', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-admin-key': adminKey
    },
    body: JSON.stringify({
      uid: cleanUid,
      action: backendAction,
      amount: action === 'ZERO_OUT' ? 0 : amount,
      walletType,
      note: reason || note || `Super Admin UID (${cleanUid}) ${action}`
    })
  });

  const data = await res.json();
  if (!res.ok || data.error) {
    throw new Error(data.error || `Failed to find or update player with UID ${cleanUid}`);
  }

  const targetUser = data.user;
  const targetUserId = targetUser?.id || cleanUid;

  // Also sync to Firestore & DeepAuditSystem directly for 100% immutable persistence
  try {
    if (walletType === 'main') {
      await superAdminModifyUserBalance({
        adminId,
        targetUserId,
        action,
        amount,
        reason: reason || note || `Super Admin UID [${cleanUid}] ${action} ₹${amount}`
      });
    } else {
      const userDocRef = doc(db as Firestore, 'users', targetUserId);
      const walletDocRef = doc(db as Firestore, 'wallets', targetUserId);
      await Promise.all([
        setDoc(userDocRef, {
          uid: targetUser.uid || cleanUid,
          mainBalance: targetUser.mainBalance,
          balance: targetUser.mainBalance,
          withdrawableBalance: targetUser.withdrawableBalance,
          bonusBalance: targetUser.bonusBalance,
          promoWallet: targetUser.promoWallet,
          updatedAt: serverTimestamp()
        }, { merge: true }),
        setDoc(walletDocRef, {
          userId: targetUserId,
          uid: targetUser.uid || cleanUid,
          deposited_balance: targetUser.mainBalance,
          bonus_balance: targetUser.bonusBalance,
          total_balance: +(Number(targetUser.mainBalance || 0) + Number(targetUser.bonusBalance || 0)).toFixed(2),
          updatedAt: serverTimestamp()
        }, { merge: true })
      ]);
    }
  } catch (err) {
    console.warn('[superAdminModifyBalanceByUid] Firestore sync notice:', err);
  }

  return {
    success: true,
    targetUserId,
    targetUser,
    action,
    beforeBalance: Number(data.beforeSnapshot?.mainBalance ?? 0),
    afterBalance: Number(data.afterSnapshot?.mainBalance ?? targetUser?.mainBalance ?? 0),
    auditTrailId: `uid_audit_${Date.now()}`,
    message: data.message || `Updated UID ${cleanUid} (${targetUser?.name}) successfully.`
  };
}

/**
 * Real-Time onSnapshot Listener: Active Player Balances
 * Listens to remote Firestore /users/{userId} and /wallets/{userId}
 * and updates local React state immediately with 0 page refresh.
 */
export function subscribeToActiveUserRealtime(
  userId: string,
  onUpdate: (data: {
    mainBalance: number;
    withdrawableBalance: number;
    bonusBalance: number;
    isFrozen: boolean;
  }) => void
): Unsubscribe {
  if (!userId || !auth.currentUser) {
    return () => {};
  }

  const currentUid = auth.currentUser.uid;
  const isAuthorizedAdmin =
    auth.currentUser.email === 'mdfaisalraza7777@gmail.com' ||
    auth.currentUser.email === 'mdfaisalraza9771@gmail.com';
  const targetId = (isAuthorizedAdmin || userId === currentUid) ? userId : currentUid;

  const userDocRef = doc(db as Firestore, 'users', targetId);
  const walletDocRef = doc(db as Firestore, 'wallets', targetId);

  let currentWalletDep: number | null = null;
  let currentWalletBon: number | null = null;
  let latestUserData: Record<string, any> | null = null;

  const emitCombined = () => {
    if (!latestUserData && currentWalletDep === null) return;
    const u = latestUserData || {};
    const role = String(u.role || '').toLowerCase();
    if (role === 'superadmin' || role === 'super_admin') {
      onUpdate({
        mainBalance: 999999999,
        withdrawableBalance: 999999999,
        bonusBalance: Number(u.bonusBalance ?? 999999),
        isFrozen: false
      });
      return;
    }
    const main = currentWalletDep !== null ? currentWalletDep : Number(u.balance ?? u.mainBalance ?? 0);
    const withdrawable = Number(u.withdrawableBalance ?? main);
    const bonus = currentWalletBon !== null ? currentWalletBon : Number(u.bonusBalance ?? 0);
    const isFrozen = Boolean(u.isFrozen);

    onUpdate({
      mainBalance: main,
      withdrawableBalance: withdrawable,
      bonusBalance: bonus,
      isFrozen
    });
  };

  const unsubWallet = onSnapshot(
    walletDocRef,
    (snap) => {
      if (snap.exists()) {
        const d = snap.data();
        currentWalletDep = typeof d.deposited_balance === 'number' ? d.deposited_balance : null;
        currentWalletBon = typeof d.bonus_balance === 'number' ? d.bonus_balance : null;
        emitCombined();
      }
    },
    () => {}
  );

  const unsubUser = onSnapshot(
    userDocRef,
    (snap) => {
      if (snap.exists()) {
        latestUserData = snap.data();
        emitCombined();
      }
    },
    (err) => {
      console.warn('[subscribeToActiveUserRealtime] User listener notice:', err);
    }
  );

  return () => {
    unsubWallet();
    unsubUser();
  };
}
