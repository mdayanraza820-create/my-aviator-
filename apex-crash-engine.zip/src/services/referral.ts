/**
 * =========================================================================
 * REFERRAL SYSTEM SERVICE & LINK TRACKING ENGINE
 * =========================================================================
 * Handles referral code generation, URL tracking, link sharing, and
 * synchronization with Firestore and the backend API.
 */

import { doc, updateDoc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { User, ReferralStat } from '../types';

export interface AdminReferrerMetric {
  referrerId: string;
  referrerName: string;
  referrerUid: string;
  referralCode: string;
  totalReferrals: number;
  activeReferrals: number;
  totalBonusEarned: number;
  promoWallet: number;
}

export interface AdminReferralMetricsResponse {
  success: boolean;
  globalTotalReferrals: number;
  globalActiveReferrals: number;
  globalTotalBonusesGenerated: number;
  referrers: AdminReferrerMetric[];
}

export interface UserReferralStatsResponse {
  referralCode: string;
  referralLink: string;
  totalReferrals: number;
  promoWallet: number;
  referralList: ReferralStat[];
}

const STORAGE_KEY = 'winnova_pending_referral';

class ReferralService {
  /**
   * Generates a unique, high-entropy referral code (e.g., WN-A8K92)
   */
  public generateReferralCode(prefix: string = 'WN'): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let suffix = '';
    for (let i = 0; i < 5; i++) {
      suffix += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return `${prefix}-${suffix}`;
  }

  /**
   * Parses URL search parameters on app mount to capture and track incoming referral links (?ref= or ?r=)
   */
  public captureReferralFromUrl(): string | null {
    if (typeof window === 'undefined') return null;

    try {
      const urlParams = new URLSearchParams(window.location.search);
      const refCode = urlParams.get('ref') || urlParams.get('r') || urlParams.get('referral') || urlParams.get('invite');

      if (refCode && refCode.trim().length > 0) {
        const cleaned = refCode.trim().toUpperCase();
        localStorage.setItem(STORAGE_KEY, cleaned);
        sessionStorage.setItem(STORAGE_KEY, cleaned);
        console.log(`🎯 [REFERRAL TRACKING]: Captured referral link code: ${cleaned}`);
        return cleaned;
      }
    } catch (e) {
      console.warn('[REFERRAL TRACKING]: Failed to parse URL search parameters', e);
    }

    return this.getStoredReferralCode();
  }

  /**
   * Retrieves any cached pending referral code from local or session storage
   */
  public getStoredReferralCode(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem(STORAGE_KEY) || sessionStorage.getItem(STORAGE_KEY) || null;
  }

  /**
   * Clears the stored referral code once applied upon registration
   */
  public clearStoredReferralCode(): void {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(STORAGE_KEY);
    sessionStorage.removeItem(STORAGE_KEY);
  }

  /**
   * Builds the full canonical invite URL for a given referral code
   */
  public getReferralLink(referralCode: string, origin?: string): string {
    const base = origin || (typeof window !== 'undefined' ? window.location.origin : 'https://winnova.app');
    return `${base}/?ref=${encodeURIComponent(referralCode)}`;
  }

  /**
   * Copies the player's personalized referral link to system clipboard
   */
  public async copyReferralLink(referralCode: string): Promise<boolean> {
    const link = this.getReferralLink(referralCode);
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(link);
        return true;
      }
    } catch {
      // Fallback
    }
    return false;
  }

  /**
   * Ensures that a user profile has an active referral code, generating one if missing
   */
  public async ensureUserReferralCode(user: User): Promise<string> {
    if (user.referralCode && user.referralCode.trim().length > 0) {
      return user.referralCode;
    }

    const newCode = this.generateReferralCode();
    user.referralCode = newCode;

    // Update in Firestore asynchronously
    try {
      const userRef = doc(db, 'users', user.id);
      await updateDoc(userRef, {
        referralCode: newCode
      }).catch(async () => {
        await setDoc(userRef, { referralCode: newCode }, { merge: true });
      });
    } catch (err) {
      console.warn('[REFERRAL SERVICE]: Failed to sync referralCode to Firestore:', err);
    }

    return newCode;
  }

  /**
   * Updates referral fields (referralCode, referredBy) directly in Firestore
   */
  public async syncReferralToFirestore(
    userId: string,
    data: { referralCode?: string; referredBy?: string }
  ): Promise<void> {
    try {
      const userRef = doc(db, 'users', userId);
      await setDoc(
        userRef,
        {
          ...(data.referralCode ? { referralCode: data.referralCode } : {}),
          ...(data.referredBy ? { referredBy: data.referredBy } : {})
        },
        { merge: true }
      );
    } catch (err) {
      console.warn('[REFERRAL SERVICE]: Firestore referral sync warning:', err);
    }
  }

  /**
   * Fetches the user's personal referral list and stats from backend API
   */
  public async fetchUserReferralStats(userId: string): Promise<UserReferralStatsResponse | null> {
    try {
      const res = await fetch(`/api/user/referrals?userId=${encodeURIComponent(userId)}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (err) {
      console.warn('[REFERRAL SERVICE]: fetchUserReferralStats error:', err);
      return null;
    }
  }

  /**
   * Fetches global referral performance metrics for the Admin Dashboard
   */
  public async fetchAdminReferralMetrics(): Promise<AdminReferralMetricsResponse | null> {
    try {
      const res = await fetch('/api/admin/referrals/metrics');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (err) {
      console.warn('[REFERRAL SERVICE]: fetchAdminReferralMetrics error:', err);
      return null;
    }
  }
}

export const referralService = new ReferralService();
export default referralService;
