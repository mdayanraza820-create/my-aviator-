// =========================================================================
// MODULE 8: CASINO ENGINE SENSORY REINFORCEMENT & AUDIO SFX CONTROLLER
// High-fidelity Web Audio API synthesizer with zero external dependencies:
// 1. "Tan-Tan" Ticking Timer SFX during round preparation countdown
// 2. Continuous flying engine hum with dynamic pitch acceleration based on live multiplier
// 3. High-impact "Flew Away" crash blast with sub-bass drop & explosion decay
// 4. Token drop cashout chime & hardware haptic feedback
// 5. Global mute/volume state management with browser autoplay unlock
// =========================================================================

class AudioService {
  private ctx: AudioContext | null = null;
  private engineOsc: OscillatorNode | null = null;
  private engineSubOsc: OscillatorNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private engineGain: GainNode | null = null;
  private masterGain: GainNode | null = null;
  private muted: boolean = false;
  private volume: number = 0.7;
  private isEngineRunning: boolean = false;

  constructor() {
    try {
      this.muted = localStorage.getItem('winnova_muted') === 'true';
      const storedVol = localStorage.getItem('winnova_volume');
      if (storedVol !== null) {
        this.volume = Math.max(0, Math.min(1, parseFloat(storedVol)));
      }
    } catch {
      this.muted = false;
    }

    // Auto-unlock AudioContext on first user gesture anywhere in the window
    if (typeof window !== 'undefined') {
      const unlock = () => {
        this.initCtx();
        window.removeEventListener('click', unlock);
        window.removeEventListener('keydown', unlock);
        window.removeEventListener('touchstart', unlock);
      };
      window.addEventListener('click', unlock, { once: true, passive: true });
      window.addEventListener('keydown', unlock, { once: true, passive: true });
      window.addEventListener('touchstart', unlock, { once: true, passive: true });

      // STRICT VISIBILITY FILTER: Instantly pause/suspend audio on tab switch or minimize
      document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
          if (this.ctx && this.ctx.state === 'running') {
            this.ctx.suspend().catch(() => {});
          }
          this.stopEngine();
        } else {
          if (!this.muted && this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume().catch(() => {});
          }
        }
      });
    }
  }

  public init() {
    this.initCtx();
  }

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        this.ctx = new AudioCtxClass();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(this.muted ? 0 : this.volume, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public resumeAudio() {
    this.initCtx();
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public getVolume(): number {
    return this.volume;
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    try {
      localStorage.setItem('winnova_volume', String(this.volume));
    } catch {}
    if (this.masterGain && this.ctx && !this.muted) {
      this.masterGain.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.05);
    }
  }

  public setMuted(muted: boolean): boolean {
    this.muted = muted;
    try {
      localStorage.setItem('winnova_muted', String(this.muted));
    } catch {}
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.muted ? 0 : this.volume, this.ctx.currentTime, 0.02);
    }
    if (this.muted) {
      this.stopEngine();
    }
    return this.muted;
  }

  public toggleMute(): boolean {
    return this.setMuted(!this.muted);
  }

  // PERMANENT NO VIBRATION: Explicitly disabled to prevent phone or browser vibration
  public triggerHaptic(_pattern: number[] = [50]) {
    // Haptics permanently disabled per strict admin compliance rules
    return false;
  }

  // =========================================================================
  // 1. THE TICKING TIMER SFX ("Tan-Tan" Loading Phase)
  // Sharp clock tick & crystal metallic strike on every whole second decrement
  // =========================================================================
  public playTick(countdownSeconds?: number) {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx || !this.masterGain) return;

      const now = this.ctx.currentTime;
      const isUrgent = countdownSeconds !== undefined && countdownSeconds <= 1;

      // Primary metallic ping (Tan-Tan harmonic)
      const osc1 = this.ctx.createOscillator();
      const gain1 = this.ctx.createGain();
      osc1.type = 'sine';
      const baseFreq = isUrgent ? 1650 : 1320; // Crisp high tone
      osc1.frequency.setValueAtTime(baseFreq, now);
      osc1.frequency.exponentialRampToValueAtTime(baseFreq * 0.5, now + 0.055);

      gain1.gain.setValueAtTime(0.14, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.055);

      osc1.connect(gain1);
      gain1.connect(this.masterGain);

      // Resonant harmonic overtone (crystal chime body)
      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      osc2.type = 'triangle';
      const harmonicFreq = isUrgent ? 3300 : 2640;
      osc2.frequency.setValueAtTime(harmonicFreq, now);
      osc2.frequency.exponentialRampToValueAtTime(harmonicFreq * 0.4, now + 0.04);

      gain2.gain.setValueAtTime(0.08, now);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

      osc2.connect(gain2);
      gain2.connect(this.masterGain);

      osc1.start(now);
      osc1.stop(now + 0.06);
      osc2.start(now);
      osc2.stop(now + 0.045);
    } catch {}
  }

  // =========================================================================
  // 2. THE FLYING ENGINE SFX (Continuous Plane Hum & Pitch Acceleration)
  // Continuous plane hum looping with pitch tied dynamically to multiplier
  // =========================================================================
  public startEngine(multiplier: number = 1.00) {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx || !this.masterGain) return;

      // If engine already running, simply update its pitch
      if (this.isEngineRunning && this.engineOsc && this.engineGain) {
        this.updateEnginePitch(multiplier);
        return;
      }

      this.stopEngine();

      const now = this.ctx.currentTime;

      // Dual oscillator setup: Sawtooth (jet turbine drive) + Triangle (deep fuselage rumble)
      this.engineOsc = this.ctx.createOscillator();
      this.engineSubOsc = this.ctx.createOscillator();
      this.engineFilter = this.ctx.createBiquadFilter();
      this.engineGain = this.ctx.createGain();

      this.engineOsc.type = 'sawtooth';
      this.engineSubOsc.type = 'triangle';

      this.engineFilter.type = 'lowpass';
      this.engineFilter.frequency.setValueAtTime(420, now);
      this.engineFilter.Q.setValueAtTime(2.8, now);

      // Smooth fade-in
      this.engineGain.gain.setValueAtTime(0.001, now);
      this.engineGain.gain.exponentialRampToValueAtTime(0.045, now + 0.15);

      this.engineOsc.connect(this.engineFilter);
      this.engineSubOsc.connect(this.engineFilter);
      this.engineFilter.connect(this.engineGain);
      this.engineGain.connect(this.masterGain);

      this.engineOsc.start(now);
      this.engineSubOsc.start(now);
      this.isEngineRunning = true;

      this.updateEnginePitch(multiplier);
    } catch {}
  }

  public updateEnginePitch(multiplier: number) {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      if (!this.isEngineRunning || !this.engineOsc || !this.engineSubOsc || !this.engineFilter || !this.engineGain) {
        this.startEngine(multiplier);
        return;
      }

      const now = this.ctx.currentTime;
      const safeMult = Math.max(1.0, multiplier);
      const logMult = Math.log10(safeMult);

      // Dynamic frequency scaling: Base 105Hz climbing up smoothly to ~850Hz at high multipliers
      const baseFreq = Math.min(850, 105 * (1.0 + logMult * 1.35));
      this.engineOsc.frequency.setTargetAtTime(baseFreq, now, 0.03);
      this.engineSubOsc.frequency.setTargetAtTime(baseFreq * 0.5, now, 0.03);

      // Dynamically open up low-pass cutoff filter as flight accelerates into high gear
      const targetCutoff = Math.min(3400, 420 + logMult * 1450);
      this.engineFilter.frequency.setTargetAtTime(targetCutoff, now, 0.04);

      // Controlled volume swelling to heighten tension without ear-splitting clipping
      const targetGain = Math.min(0.085, 0.042 + logMult * 0.035);
      this.engineGain.gain.setTargetAtTime(targetGain, now, 0.04);
    } catch {}
  }

  public stopEngine() {
    this.isEngineRunning = false;
    try {
      if (this.engineGain && this.ctx) {
        this.engineGain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.02);
      }
      setTimeout(() => {
        try {
          if (this.engineOsc) {
            this.engineOsc.stop();
            this.engineOsc.disconnect();
            this.engineOsc = null;
          }
          if (this.engineSubOsc) {
            this.engineSubOsc.stop();
            this.engineSubOsc.disconnect();
            this.engineSubOsc = null;
          }
          if (this.engineFilter) {
            this.engineFilter.disconnect();
            this.engineFilter = null;
          }
          if (this.engineGain) {
            this.engineGain.disconnect();
            this.engineGain = null;
          }
        } catch {}
      }, 30);
    } catch {}
  }

  // =========================================================================
  // 3. THE CRASH IMPACT SFX ("Flew Away" Blast)
  // Abruptly kills flying engine audio stream and fires explosion / bass drop
  // =========================================================================
  public stopEngineAndCrash() {
    this.playCrash();
  }

  public playCrash() {
    // Immediately terminate continuous engine loop
    this.stopEngine();

    // Heavy crash haptic blast
    this.triggerHaptic([140, 60, 180]);

    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx || !this.masterGain) return;

      const now = this.ctx.currentTime;

      // 1. Resonant sub-bass drop (sine sweep from 180Hz down to 24Hz)
      const subOsc = this.ctx.createOscillator();
      const subGain = this.ctx.createGain();
      subOsc.type = 'sine';
      subOsc.frequency.setValueAtTime(180, now);
      subOsc.frequency.exponentialRampToValueAtTime(24, now + 0.45);

      subGain.gain.setValueAtTime(0.38, now);
      subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.48);

      subOsc.connect(subGain);
      subGain.connect(this.masterGain);
      subOsc.start(now);
      subOsc.stop(now + 0.5);

      // 2. Explosive low-pass white noise blast (detonation decay)
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.4);
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450, now);
      filter.frequency.exponentialRampToValueAtTime(50, now + 0.4);

      const noiseGain = this.ctx.createGain();
      noiseGain.gain.setValueAtTime(0.32, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      whiteNoise.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(this.masterGain);

      whiteNoise.start(now);
      whiteNoise.stop(now + 0.42);
    } catch {}
  }

  // =========================================================================
  // ADDITIONAL CASINO SOUND VECTORS: Flight start, Bet placed, Cashout
  // =========================================================================
  public playFlightStart() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx || !this.masterGain) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(220, now);
      osc.frequency.exponentialRampToValueAtTime(440, now + 0.2);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.25);

      // Start engine loop at baseline
      this.startEngine(1.00);
    } catch {}
  }

  public playBetPlaced() {
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx || !this.masterGain) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(350, now);
      osc.frequency.exponentialRampToValueAtTime(700, now + 0.08);

      gain.gain.setValueAtTime(0.09, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.1);
    } catch {}
  }

  public playCashout() {
    this.triggerHaptic([40, 50, 70]);
    if (this.muted) return;
    try {
      this.initCtx();
      if (!this.ctx || !this.masterGain) return;

      const now = this.ctx.currentTime;
      const tokenPitches = [523.25, 783.99, 1046.50, 1318.51, 1567.98, 2093.00];

      tokenPitches.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        const delayOffset = idx * 0.038;

        osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now + delayOffset);
        osc.frequency.exponentialRampToValueAtTime(freq * 0.96, now + delayOffset + 0.18);

        gain.gain.setValueAtTime(0.12, now + delayOffset);
        gain.gain.exponentialRampToValueAtTime(0.001, now + delayOffset + 0.22);

        osc.connect(gain);
        gain.connect(this.masterGain!);

        osc.start(now + delayOffset);
        osc.stop(now + delayOffset + 0.22);
      });
    } catch {}
  }

  public playCashOut() {
    this.playCashout();
  }
}

export const audioService = new AudioService();

// Exact user-specified GameSFX controller interface compatibility export
export const GameSFX = {
  get isMuted() {
    return audioService.isMuted();
  },
  set isMuted(val: boolean) {
    audioService.setMuted(val);
  },

  init() {
    audioService.init();
  },

  playTick(countdownSeconds?: number) {
    audioService.playTick(countdownSeconds);
  },

  startEngine(multiplier: number = 1.0) {
    audioService.startEngine(multiplier);
  },

  updateEnginePitch(multiplier: number) {
    audioService.updateEnginePitch(multiplier);
  },

  stopEngineAndCrash() {
    audioService.stopEngineAndCrash();
  },

  toggleMute(): boolean {
    return audioService.toggleMute();
  }
};
