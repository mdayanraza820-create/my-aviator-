// ==========================================
// 1. SHADOW LAYER: DELETION KO BYPASS KARNE KE LIYE
// Cookie Backup Layer: 5 saal tak safe
// ==========================================

export function saveToShadowStorage(key: string, data: any): void {
  try {
    const stringData = JSON.stringify(data);
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, stringData);
    }
    
    if (typeof document !== 'undefined') {
      const expiry = new Date();
      expiry.setFullYear(expiry.getFullYear() + 5); // 5 saal tak safe
      document.cookie = `${key}=${encodeURIComponent(stringData)}; expires=${expiry.toUTCString()}; path=/; SameSite=Strict`;
    }
  } catch (err) {
    console.warn('[ShadowStorage] saveToShadowStorage error:', err);
  }
}

export function getFromShadowStorage(key: string): any[] {
  try {
    // 1. Pehle localStorage check karein
    if (typeof localStorage !== 'undefined') {
      const localData = localStorage.getItem(key);
      if (localData) {
        try {
          return JSON.parse(localData);
        } catch {}
      }
    }

    // 2. Agar localStorage delete ho chuka hai, toh backup cookie se rescue karein
    if (typeof document !== 'undefined') {
      const matches = document.cookie.match(
        new RegExp('(?:^|; )' + key.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + '=([^;]*)')
      );
      if (matches) {
        const cookieData = decodeURIComponent(matches[1]);
        try {
          const parsed = JSON.parse(cookieData);
          if (typeof localStorage !== 'undefined') {
            localStorage.setItem(key, cookieData);
          }
          return parsed;
        } catch {}
      }
    }
  } catch (err) {
    console.warn('[ShadowStorage] getFromShadowStorage error:', err);
  }
  return [];
}

// ==========================================
// 2. MASTER TRANSACTIONS SAVE LOGIC
// ==========================================

export function masterSaveDeposit(
  userId: string,
  username: string,
  amount: number | string,
  status: string = 'Success',
  orderId?: string
) {
  const history = getFromShadowStorage('shadow_global_deposits');
  const txId = orderId || ('DEP' + Date.now() + Math.floor(Math.random() * 1000));
  
  const newDeposit = {
    transactionId: txId,
    orderId: txId,
    userId: userId,
    username: username || 'Player',
    amount: parseFloat(String(amount)) || 0,
    status: status,
    date: new Date().toLocaleString()
  };

  // Check if already in history
  const idx = history.findIndex((h: any) => h.transactionId === txId || h.orderId === txId);
  if (idx >= 0) {
    history[idx] = { ...history[idx], ...newDeposit };
  } else {
    history.unshift(newDeposit);
  }

  saveToShadowStorage('shadow_global_deposits', history);
  console.log('🔒 Deposit locked in Shadow Layer:', newDeposit);
  return newDeposit;
}

export function masterSaveWithdrawal(
  userId: string,
  username: string,
  requestedAmount: number | string,
  walletBalance: number,
  status: string = 'Success',
  orderId?: string
) {
  const reqAmt = parseFloat(String(requestedAmount)) || 0;
  const taxRate = reqAmt >= 5000 ? 0.08 : (reqAmt >= 2000 ? 0.09 : 0.10);
  const taxAmount = reqAmt * taxRate;
  const totalDeduction = reqAmt + taxAmount;

  if (walletBalance < totalDeduction && status !== 'REJECTED') {
    return { success: false, message: 'Insufficient Funds' };
  }

  const history = getFromShadowStorage('shadow_global_withdrawals');
  const txId = orderId || ('WIT' + Date.now() + Math.floor(Math.random() * 1000));

  const newWithdrawal = {
    transactionId: txId,
    orderId: txId,
    userId: userId,
    username: username || 'Player',
    amountRequested: reqAmt,
    taxCollected: taxAmount,
    totalWalletDeducted: totalDeduction,
    status: status,
    date: new Date().toLocaleString()
  };

  const idx = history.findIndex((h: any) => h.transactionId === txId || h.orderId === txId);
  if (idx >= 0) {
    history[idx] = { ...history[idx], ...newWithdrawal };
  } else {
    history.unshift(newWithdrawal);
  }

  saveToShadowStorage('shadow_global_withdrawals', history);
  console.log('🔒 Withdrawal locked in Shadow Layer:', newWithdrawal);

  return { success: true, data: newWithdrawal, newBalance: walletBalance - totalDeduction };
}

// ==========================================
// 3. UI RENDER ENGINE FOR ADMIN / SUPER ADMIN
// ==========================================

export function renderAdminMasterPanel(depositBoxId: string, withdrawBoxId: string) {
  if (typeof window === 'undefined') return;
  const currentRole = localStorage.getItem('user_role') || sessionStorage.getItem('admin_session') || (localStorage.getItem('winnova_is_sa') === 'true' ? 'super_admin' : '');
  if (currentRole !== 'super_admin' && currentRole !== 'admin') return;

  const globalDeposits = getFromShadowStorage('shadow_global_deposits');
  const globalWithdrawals = getFromShadowStorage('shadow_global_withdrawals');

  const depElement = document.getElementById(depositBoxId);
  if (depElement) {
    depElement.innerHTML = globalDeposits.length === 0 ? "<tr><td colspan='4' style='padding: 12px; color: #8c92ac; text-align: center;'>No deposits recorded in shadow storage yet.</td></tr>" : 
      globalDeposits.map((item: any) => `
        <tr style="border-bottom: 1px solid #2d2d44; color: #fff;">
            <td style="padding: 10px;">${item.date}</td>
            <td style="padding: 10px; color: #00adb5;">${item.username} (ID: ${item.userId})</td>
            <td style="padding: 10px; color: #28a745; font-weight: bold;">+₹${item.amount}</td>
            <td style="padding: 10px;"><span style="background: ${item.status === 'REJECTED' ? '#dc3545' : '#28a745'}; padding: 2px 6px; border-radius: 4px; font-size: 12px;">${item.status}</span></td>
        </tr>
      `).join('');
  }

  const witElement = document.getElementById(withdrawBoxId);
  if (witElement) {
    witElement.innerHTML = globalWithdrawals.length === 0 ? "<tr><td colspan='5' style='padding: 12px; color: #8c92ac; text-align: center;'>No withdrawals recorded in shadow storage yet.</td></tr>" : 
      globalWithdrawals.map((item: any) => `
        <tr style="border-bottom: 1px solid #2d2d44; color: #fff;">
            <td style="padding: 10px;">${item.date}</td>
            <td style="padding: 10px; color: #00adb5;">${item.username} (ID: ${item.userId})</td>
            <td style="padding: 10px; color: #dc3545; font-weight: bold;">₹${item.amountRequested}</td>
            <td style="padding: 10px; color: #ffc107;">₹${item.taxCollected}</td>
            <td style="padding: 10px;"><span style="background: ${item.status === 'REJECTED' ? '#ffc107' : '#dc3545'}; padding: 2px 6px; border-radius: 4px; font-size: 12px;">${item.status}</span></td>
        </tr>
      `).join('');
  }
}

// Global exposure on window
if (typeof window !== 'undefined') {
  (window as any).saveToShadowStorage = saveToShadowStorage;
  (window as any).getFromShadowStorage = getFromShadowStorage;
  (window as any).masterSaveDeposit = masterSaveDeposit;
  (window as any).masterSaveWithdrawal = masterSaveWithdrawal;
  (window as any).renderAdminMasterPanel = renderAdminMasterPanel;
}
