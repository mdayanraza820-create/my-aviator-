export function getDeviceFingerprint(): string {
  // Check if cached in storage
  const cached = localStorage.getItem('winnova_dfp');
  if (cached && cached.length > 8) {
    return cached;
  }

  try {
    const components: string[] = [
      navigator.userAgent,
      navigator.language,
      screen.colorDepth ? `${screen.colorDepth}` : '24',
      `${screen.width}x${screen.height}`,
      `${screen.availWidth}x${screen.availHeight}`,
      new Date().getTimezoneOffset().toString(),
      navigator.hardwareConcurrency ? `${navigator.hardwareConcurrency}` : '4'
    ];

    // Canvas fingerprint
    const canvas = document.createElement('canvas');
    canvas.width = 160;
    canvas.height = 40;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.textBaseline = 'top';
      ctx.font = '14px Arial';
      ctx.fillStyle = '#f60';
      ctx.fillRect(10, 5, 60, 20);
      ctx.fillStyle = '#069';
      ctx.fillText('WIN_NOVA_AVTR_786', 15, 8);
      components.push(canvas.toDataURL().slice(-50));
    }

    // Simple hash
    const str = components.join('###');
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }

    const fingerprint = 'dfp_' + Math.abs(hash).toString(16) + '_' + Math.abs(str.length).toString(16);
    localStorage.setItem('winnova_dfp', fingerprint);
    return fingerprint;
  } catch {
    const fallback = 'dfp_fallback_' + Math.random().toString(36).substring(2, 10);
    localStorage.setItem('winnova_dfp', fallback);
    return fallback;
  }
}
