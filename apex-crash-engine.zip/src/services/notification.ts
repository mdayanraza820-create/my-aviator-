// Notification Service for PWA Push & Session Re-Engagement (Module 20 & 21)

class NotificationService {
  private registration: ServiceWorkerRegistration | null = null;
  private hasPermission: boolean = false;

  constructor() {
    if (typeof window !== 'undefined') {
      this.init();
    }
  }

  async init() {
    if ('serviceWorker' in navigator) {
      try {
        const reg = await navigator.serviceWorker.register('/sw.js');
        this.registration = reg;
        console.log('[PWA SW] Service worker registered successfully');
      } catch (err) {
        console.warn('[PWA SW] Service worker registration failed:', err);
      }
    }

    if ('Notification' in window) {
      this.hasPermission = Notification.permission === 'granted';
    }
  }

  async requestPermission(): Promise<boolean> {
    if (!('Notification' in window)) return false;
    try {
      const result = await Notification.requestPermission();
      this.hasPermission = result === 'granted';
      return this.hasPermission;
    } catch {
      return false;
    }
  }

  async sendLocalAlert(title: string, options: NotificationOptions = {}) {
    if (!this.hasPermission) {
      // Attempt silent request if not denied
      if ('Notification' in window && Notification.permission !== 'denied') {
        const granted = await this.requestPermission();
        if (!granted) return;
      } else {
        return;
      }
    }

    try {
      if (this.registration && 'showNotification' in this.registration) {
        await this.registration.showNotification(title, {
          icon: '/pwa-192x192.png',
          badge: '/icon.svg',
          ...options
        });
      } else if ('Notification' in window) {
        new Notification(title, options);
      }
    } catch (e) {
      console.warn('[NotificationService] Failed to show notification:', e);
    }
  }
}

export const notificationService = new NotificationService();
