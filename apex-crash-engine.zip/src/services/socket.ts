import { io, Socket } from 'socket.io-client';
import { GameState, Bet, MultiplierHistoryItem } from '../types';

class SocketService {
  private socket: Socket | null = null;
  private listeners: Map<string, Set<(data: any) => void>> = new Map();
  private currentUserId: string | null = null;

  connect() {
    if (this.socket) {
      if (!this.socket.connected) {
        this.socket.connect();
      }
      return;
    }

    this.socket = io({
      transports: ['polling', 'websocket'],
      reconnectionAttempts: Infinity,
      reconnectionDelay: 500,
      timeout: 10000
    });

    this.socket.on('connect', () => {
      console.log('[WIN NOVA Socket] Connected to game server');
      this.emitInternal('connect_status', true);
      if (this.currentUserId) {
        this.socket?.emit('join_user_room', this.currentUserId);
      }
    });

    this.socket.on('disconnect', () => {
      console.log('[WIN NOVA Socket] Disconnected from game server');
      this.emitInternal('connect_status', false);
    });

    // Forward ALL incoming socket events seamlessly to listeners using onAny
    this.socket.onAny((event: string, data: any) => {
      this.emitInternal(event, data);
    });
  }

  joinUserRoom(userId: string, sessionId?: string) {
    this.currentUserId = userId;
    if (this.socket && this.socket.connected) {
      this.socket.emit('join_user_room', { userId, sessionId });
    }
  }

  isConnected(): boolean {
    return !!(this.socket && this.socket.connected);
  }

  placeBet(data: { userId: string; amount: number; consoleIndex: 0 | 1; autoCashout?: number; token?: string; sessionId?: string }) {
    if (this.socket) {
      this.socket.emit('place_bet', data);
    }
  }

  cashOut(data: { betId: string; userId: string; sessionId?: string }) {
    if (this.socket) {
      this.socket.emit('cash_out', data);
    }
  }

  sendChatMessage(data: { userId?: string; username: string; message: string }) {
    if (this.socket) {
      this.socket.emit('send_chat_message', data);
    }
  }

  // Admin actions
  adminCrashNow(adminKey: string, immediate: boolean = true) {
    if (this.socket) {
      this.socket.emit('admin:crash_now', { adminKey, immediate });
    }
  }

  emit(event: string, data?: any) {
    if (this.socket) {
      this.socket.emit(event, data);
    }
  }

  adminSetMode(mode: 'AUTO_AI' | 'MANUAL_OVERRIDE', adminKey: string) {
    if (this.socket) {
      this.socket.emit('admin:set_mode', { mode, adminKey });
    }
  }

  adminSetNextCrash(multiplier: number, adminKey: string) {
    if (this.socket) {
      this.socket.emit('admin:set_next_crash', { multiplier, adminKey });
    }
  }

  adminSetCheatPercentages(data: { cheatPercentage: number; crashPercentage: number; adminKey: string }) {
    if (this.socket) {
      this.socket.emit('admin_update_cheat_percentages', data);
    }
  }

  on(event: string, callback: (data: any) => void) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
    return () => this.off(event, callback);
  }

  off(event: string, callback: (data: any) => void) {
    if (this.listeners.has(event)) {
      this.listeners.get(event)!.delete(callback);
    }
  }

  private emitInternal(event: string, data: any) {
    if (this.listeners.has(event)) {
      this.listeners.get(event)!.forEach((cb) => cb(data));
    }
  }
}

export const socketService = new SocketService();
