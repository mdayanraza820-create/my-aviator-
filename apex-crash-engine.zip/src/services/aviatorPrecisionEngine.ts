/**
 * ============================================================================
 * WIN NOVA - AVIATOR PRECISION GAMEPLAY & SYNCHRONIZATION ENGINE
 * Pure Mathematical Exponential Speed Curve & Zero-Glitch Precision Loop
 * ============================================================================
 *
 * Mathematical Foundations:
 * Multiplier = Math.pow(Math.E, AVIATOR_SPEED_FACTOR * elapsed_seconds)
 *
 * Exact 8-Second 2X Lock:
 * AVIATOR_SPEED_FACTOR = ln(2) / 8 ≈ 0.08664339756999316
 *
 * Guaranteed Natural Milestones:
 * - t = 0.00s  -> 1.00x (takeoff)
 * - t = 8.00s  -> 2.00x (EXACT LOCK)
 * - t ≈ 26.58s -> 10.00x
 * - t ≈ 31.57s -> 15.40x
 * - t ≈ 53.15s -> 100.00x
 * - t ≈ 79.73s -> 1000.00x
 * ============================================================================
 */

export const AVIATOR_SPEED_FACTOR = 0.06931471805599453; // 20% decreased flight speed (0.08664339756999316 * 0.8)
export const MAX_MULTIPLIER_CEILING = 10000.00;

/**
 * Calculates multiplier from elapsed seconds using pure exponential curve.
 * No artificial easing, no timer stretching, no speed distortion.
 */
export function calculateExponentialMultiplier(elapsedSeconds: number): number {
  if (elapsedSeconds <= 0) return 1.00;
  const raw = Math.pow(Math.E, AVIATOR_SPEED_FACTOR * elapsedSeconds);
  const capped = Math.min(MAX_MULTIPLIER_CEILING, raw);
  // Strictly formatted to 2 decimal places as a standard float
  return Math.floor(capped * 100) / 100;
}

/**
 * Calculates exact natural flight duration in seconds required to reach target multiplier.
 * Derived directly from inverse exponential: t = ln(multiplier) / speed_factor
 */
export function calculateNaturalFlightDuration(targetMultiplier: number): number {
  if (targetMultiplier <= 1.00) return 0;
  return Math.log(targetMultiplier) / AVIATOR_SPEED_FACTOR;
}

export interface PrecisionLoopConfig {
  crashPoint: number;                       // Pre-determined authoritative crash decimal (e.g. 15.40)
  displayElementId?: string;                 // e.g. "multiplier-display"
  onTick?: (state: PrecisionTickState) => void;
  onCrash?: (finalMultiplier: number, elapsedSeconds: number) => void;
  startDelayMs?: number;
}

export interface PrecisionTickState {
  multiplier: number;
  multiplierString: string;
  elapsedSeconds: number;
  progressPercent: number;
  isCrashed: boolean;
}

/**
 * Standalone Precision-Locked Aviator Game Loop
 * Runs via requestAnimationFrame with microsecond precision via performance.now().
 *
 * Features:
 * - Mirrors real-time multiplier precisely up to 2 decimal places.
 * - Tracks exact microsecond elapsed time.
 * - Compares continually to predetermined true 'crashPoint'.
 * - Triggers crash state animation at that EXACT decimal without any freeze, mismatch, or 2.50x lag.
 * - Automatically updates the specified DOM element (e.g. #multiplier-display).
 */
export class AviatorPrecisionLoop {
  private rafId: number | null = null;
  private startTime: number = 0;
  private isRunning: boolean = false;
  private isCrashed: boolean = false;
  private currentMultiplier: number = 1.00;
  private targetDurationSeconds: number = 0;

  constructor(public config: PrecisionLoopConfig) {
    this.targetDurationSeconds = calculateNaturalFlightDuration(config.crashPoint);
  }

  /**
   * Start the flight animation loop.
   * Can pass explicit start timestamp from server or defaults to performance.now().
   */
  public start(explicitStartPerfMs?: number): void {
    this.stop();
    this.isRunning = true;
    this.isCrashed = false;
    this.currentMultiplier = 1.00;
    this.startTime = explicitStartPerfMs ?? performance.now();
    this.targetDurationSeconds = calculateNaturalFlightDuration(this.config.crashPoint);

    // Initial DOM update
    this.updateDom(1.00, false);

    const frame = () => {
      if (!this.isRunning) return;

      const now = performance.now();
      const elapsedSeconds = Math.max(0, (now - this.startTime) / 1000);

      // Pure mathematical curve
      const calculatedMult = calculateExponentialMultiplier(elapsedSeconds);

      // CRASH CONDITION: Check if current calculated multiplier >= predetermined crashPoint
      if (calculatedMult >= this.config.crashPoint || elapsedSeconds >= this.targetDurationSeconds) {
        // Force-lock precisely to the authoritative crash decimal (e.g., 15.40x)
        const finalDecimal = this.config.crashPoint;
        this.currentMultiplier = finalDecimal;
        this.isCrashed = true;
        this.isRunning = false;
        this.rafId = null;

        // Final DOM sync: update display with exact crash multiplier in crashed state
        this.updateDom(finalDecimal, true);

        if (this.config.onTick) {
          this.config.onTick({
            multiplier: finalDecimal,
            multiplierString: `${finalDecimal.toFixed(2)}x`,
            elapsedSeconds,
            progressPercent: 100,
            isCrashed: true
          });
        }

        if (this.config.onCrash) {
          this.config.onCrash(finalDecimal, elapsedSeconds);
        }
        return;
      }

      // In-flight active tick: non-decreasing multiplier
      this.currentMultiplier = Math.max(this.currentMultiplier, calculatedMult);
      const multStr = `${this.currentMultiplier.toFixed(2)}x`;

      // Update DOM element directly without React latency
      this.updateDom(this.currentMultiplier, false);

      if (this.config.onTick) {
        const progress = Math.min(100, (Math.log(this.currentMultiplier) / Math.log(this.config.crashPoint)) * 100);
        this.config.onTick({
          multiplier: this.currentMultiplier,
          multiplierString: multStr,
          elapsedSeconds,
          progressPercent: progress,
          isCrashed: false
        });
      }

      this.rafId = requestAnimationFrame(frame);
    };

    this.rafId = requestAnimationFrame(frame);
  }

  /**
   * Directly synchronize with an authoritative server tick if network drift occurs
   */
  public syncWithServer(serverMultiplier: number, serverElapsedSeconds: number): void {
    if (!this.isRunning || this.isCrashed) return;

    // Check if server already crashed or reached crash point
    if (serverMultiplier >= this.config.crashPoint) {
      this.forceCrash(this.config.crashPoint);
      return;
    }

    // Align start time smoothly to eliminate clock skew
    const now = performance.now();
    const expectedStart = now - (serverElapsedSeconds * 1000);
    this.startTime = this.startTime * 0.80 + expectedStart * 0.20;
    this.currentMultiplier = Math.max(this.currentMultiplier, serverMultiplier);
  }

  /**
   * Instantly trigger crash state and snap to exact crash multiplier
   */
  public forceCrash(crashMultiplier?: number): void {
    this.isRunning = false;
    this.isCrashed = true;
    if (this.rafId) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }

    const finalVal = crashMultiplier ?? this.config.crashPoint;
    this.currentMultiplier = finalVal;
    this.updateDom(finalVal, true);

    const elapsed = Math.max(0, (performance.now() - this.startTime) / 1000);

    if (this.config.onTick) {
      this.config.onTick({
        multiplier: finalVal,
        multiplierString: `${finalVal.toFixed(2)}x`,
        elapsedSeconds: elapsed,
        progressPercent: 100,
        isCrashed: true
      });
    }

    if (this.config.onCrash) {
      this.config.onCrash(finalVal, elapsed);
    }
  }

  /**
   * Stop loop cleanly
   */
  public stop(): void {
    this.isRunning = false;
    if (this.rafId) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  public getMultiplier(): number {
    return this.currentMultiplier;
  }

  public isFlightActive(): boolean {
    return this.isRunning && !this.isCrashed;
  }

  private updateDom(val: number, isCrash: boolean): void {
    const elId = this.config.displayElementId || 'multiplier-display';
    const el = document.getElementById(elId);
    if (!el) return;

    const formatted = `${val.toFixed(2)}x`;
    el.innerText = formatted;

    if (isCrash) {
      el.classList.add('crashed', 'text-red-500');
      el.classList.remove('text-white', 'text-emerald-400');
    } else {
      el.classList.remove('crashed', 'text-red-500');
      el.classList.add('text-white');
    }
  }
}

/**
 * Convenient factory function to launch a standalone precision loop
 */
export function startStandaloneAviatorLoop(
  crashPoint: number,
  displayElementId: string = 'multiplier-display',
  onCrash?: (final: number) => void
): AviatorPrecisionLoop {
  const loop = new AviatorPrecisionLoop({
    crashPoint,
    displayElementId,
    onCrash: (final) => {
      if (onCrash) onCrash(final);
    }
  });
  loop.start();
  return loop;
}
