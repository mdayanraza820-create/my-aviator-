/**
 * ============================================================================
 * DEEP AUDIT SYSTEM - IMMUTABLE CLOUD OBSERVER & STATE RECOVERY
 * Production-Grade Standalone Audit Observer for Aviator Engine
 * Compatible with Netlify, Vercel, Google Cloud Run, and AI Studio CI/CD
 * ============================================================================
 * Directives:
 * 1. 100% Persistent & Immutable: Frontend deployments change; Firestore logs never drop.
 * 2. Non-blocking Observer: Silently catches errors; never interrupts animations or game loops.
 * 3. Deep-Clone & Merge: Eliminates circular references and preserves pre-existing document keys.
 * 4. Automatic Audit Metadata: Injects serverTimestamp(), actor_uid, and session provenance.
 * ============================================================================
 */

import {
  doc,
  collection,
  setDoc,
  serverTimestamp,
  Firestore
} from 'firebase/firestore';
import { persistentDb as db, persistentAuth as auth } from './firebaseCloudSync';
import { AVIATOR_SPEED_FACTOR } from '../types';

// Per-tab unique session provenance identifier
const CLIENT_SESSION_ID = typeof window !== 'undefined'
  ? (window as any).__WINNOVA_SESSION_ID__ ||
    `sess_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
  : 'server_env';

if (typeof window !== 'undefined') {
  (window as any).__WINNOVA_SESSION_ID__ = CLIENT_SESSION_ID;
}

/**
 * Deep-clone an arbitrary object or array, stripping circular references,
 * undefined values, and functions while retaining nested primitives and arrays.
 */
function sanitizePayload(raw: any): any {
  if (raw === undefined || typeof raw === 'function') {
    return null;
  }
  try {
    return JSON.parse(
      JSON.stringify(raw, (_key, value) => {
        if (typeof value === 'undefined') return null;
        if (typeof value === 'function') return undefined;
        return value;
      })
    );
  } catch {
    return { _serialization_fallback: String(raw) };
  }
}

export interface DeepAuditObserver {
  commitLog(
    logType: string,
    documentId?: string | null,
    payloadObject?: any
  ): Promise<boolean>;

  commitDepositRequest(data: {
    userId: string;
    amount: number;
    upiId: string;
    utrNumber: string;
    proofImageUrl?: string;
    status?: 'pending' | 'verified' | 'rejected';
    [key: string]: any;
  }): Promise<string>;

  commitDepositSuccess(data: {
    depositRequestId: string;
    userId: string;
    amount: number;
    creditedBy: string;
    [key: string]: any;
  }): Promise<string>;

  commitWithdrawalRequest(data: {
    userId: string;
    amount: number;
    payoutMethod: 'UPI' | 'BANK';
    upiId?: string;
    bankAccount?: string;
    ifscCode?: string;
    status?: 'pending' | 'processed' | 'rejected';
    [key: string]: any;
  }): Promise<string>;

  commitWithdrawalPayout(data: {
    withdrawalRequestId: string;
    userId: string;
    amount: number;
    adminUtr: string;
    paidBy: string;
    [key: string]: any;
  }): Promise<string>;

  commitAdminAuditTrail(data: {
    adminId: string;
    targetUserId: string;
    action: 'CREDIT' | 'DEBIT' | 'OVERWRITE' | 'ZERO_OUT' | 'UPDATE_UPI' | 'SET_RTP' | string;
    beforeSnapshot: Record<string, any>;
    afterSnapshot: Record<string, any>;
    reason?: string;
    [key: string]: any;
  }): Promise<string>;

  commitPlayerLog(
    userId: string,
    eventType: string,
    payload: Record<string, any>
  ): Promise<string>;
}

export const DeepAuditSystem: DeepAuditObserver = {
  /**
   * Universal, standalone observer method.
   * Commits any raw JavaScript state or object to Firestore using { merge: true }
   * with automatic server timestamp and actor metadata.
   */
  async commitLog(
    logType: string,
    documentId?: string | null,
    payloadObject: any = {}
  ): Promise<boolean> {
    if (!logType) {
      console.warn('[DeepAuditSystem] logType must be specified');
      return false;
    }

    try {
      const sanitized = sanitizePayload(payloadObject);
      const actorUid = auth.currentUser?.uid || 'system_event';
      const actorEmail = auth.currentUser?.email || 'unauthenticated';

      // Build envelope with comprehensive audit and provenance metadata
      const envelope = {
        ...sanitized,
        timestamp: serverTimestamp(),
        actor_uid: actorUid,
        actor_email: actorEmail,
        _audit_meta: {
          session_id: CLIENT_SESSION_ID,
          client_timestamp: Date.now(),
          host: typeof window !== 'undefined' ? window.location.hostname : 'cloud-run',
          origin: typeof window !== 'undefined' ? window.location.origin : 'container',
          user_agent: typeof navigator !== 'undefined' ? navigator.userAgent : 'node-runtime',
          engine_speed_factor: AVIATOR_SPEED_FACTOR
        }
      };

      // Handle subcollection paths or top-level collection names
      let targetDocRef;
      if (documentId && documentId.trim().length > 0) {
        targetDocRef = doc(db as Firestore, logType, documentId.trim());
      } else {
        targetDocRef = doc(collection(db as Firestore, logType));
      }

      // Guarantee immutable merge: existing database fields will NEVER be dropped or wiped
      await setDoc(targetDocRef, envelope, { merge: true });
      return true;
    } catch (err: any) {
      // Passive background observer: Never throw or disrupt game rendering or UI operations
      console.warn(`[DeepAuditSystem] Passive log dispatch deferred: ${err?.message || err}`);
      return false;
    }
  },

  /**
   * Log player deposit request to /deposit_requests
   */
  async commitDepositRequest(data): Promise<string> {
    const docRef = doc(collection(db as Firestore, 'deposit_requests'));
    const docId = docRef.id;
    await this.commitLog('deposit_requests', docId, {
      id: docId,
      status: 'pending',
      ...data
    });
    return docId;
  },

  /**
   * Log verified and credited deposit to /deposit_success
   */
  async commitDepositSuccess(data): Promise<string> {
    const docRef = doc(collection(db as Firestore, 'deposit_success'));
    const docId = docRef.id;
    await this.commitLog('deposit_success', docId, {
      id: docId,
      ...data
    });
    return docId;
  },

  /**
   * Log player withdrawal request to /withdrawal_requests
   */
  async commitWithdrawalRequest(data): Promise<string> {
    const docRef = doc(collection(db as Firestore, 'withdrawal_requests'));
    const docId = docRef.id;
    await this.commitLog('withdrawal_requests', docId, {
      id: docId,
      status: 'pending',
      ...data
    });
    return docId;
  },

  /**
   * Log cashier withdrawal payout to /withdrawal_payouts
   */
  async commitWithdrawalPayout(data): Promise<string> {
    const docRef = doc(collection(db as Firestore, 'withdrawal_payouts'));
    const docId = docRef.id;
    await this.commitLog('withdrawal_payouts', docId, {
      id: docId,
      ...data
    });
    return docId;
  },

  /**
   * Record master Super Admin Before/After snapshot to /admin_audit_trail
   */
  async commitAdminAuditTrail(data): Promise<string> {
    const docRef = doc(collection(db as Firestore, 'admin_audit_trail'));
    const docId = docRef.id;
    await this.commitLog('admin_audit_trail', docId, {
      id: docId,
      ...data
    });
    return docId;
  },

  /**
   * Log stream event to /player_logs/{userId}/logs/{logId}
   */
  async commitPlayerLog(userId, eventType, payload): Promise<string> {
    const docRef = doc(collection(db as Firestore, `player_logs/${userId}/logs`));
    const docId = docRef.id;
    await this.commitLog(`player_logs/${userId}/logs`, docId, {
      id: docId,
      userId,
      eventType,
      payload
    });
    return docId;
  }
};

// Global Browser Window Exposure for easy inspection and zero-import script hooks
if (typeof window !== 'undefined') {
  (window as any).DeepAuditSystem = DeepAuditSystem;
}
