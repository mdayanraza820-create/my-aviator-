import React, { useState, useEffect, useMemo } from 'react';
import {
  User,
  DepositRequest,
  WithdrawalRequest,
  DepositNode,
  BASELINE_DEPOSIT_BONUSES,
  getVipConfig,
  CoreVipState,
  buildLiveVipLevelsData,
  TimedCampaignState,
  processExclusiveWithdrawal,
  isWithinLast30Days
} from '../types';
import {
  generateDynamicUpiQr,
  subscribeToGlobalSystemConfig,
  DeepAuditSystem
} from '../firebase';
import { socketService } from '../services/socket';
import {
  ArrowDownCircle,
  ArrowUpCircle,
  Copy,
  Check,
  Upload,
  AlertCircle,
  CheckCircle2,
  Clock,
  Zap,
  Gift,
  Ticket,
  ArrowRightLeft,
  FileText,
  Crown,
  CreditCard,
  Building2,
  Send
} from 'lucide-react';
import { PublicChannelsCard } from './PublicChannelsCard';

declare global {
  interface Window {
    CoreGameEngine?: {
      vipState: CoreVipState;
    };
    WebSystemVipEngine?: CoreVipState;
  }
}

export type CashierTab = 'deposit' | 'withdraw' | 'vip' | 'promo' | 'giftcode' | 'history';

interface CashierModalProps {
  isOpen: boolean;
  initialTab?: CashierTab;
  user: User;
  onClose: () => void;
  onRefreshUser: () => void;
}

const DEPOSIT_PACKS = [
  { amount: 100, isHot: true },
  { amount: 200, isHot: false },
  { amount: 500, isHot: true },
  { amount: 1000, isHot: true },
  { amount: 2000, isHot: false },
  { amount: 5000, isHot: true },
  { amount: 10000, isHot: false },
  { amount: 20000, isHot: false },
  { amount: 50000, isHot: false }
];

export const CashierModal: React.FC<CashierModalProps> = ({
  isOpen,
  initialTab = 'deposit',
  user,
  onClose,
  onRefreshUser
}) => {
  const [activeTab, setActiveTab] = useState<CashierTab>(initialTab);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [activeNode, setActiveNode] = useState<DepositNode | null>(null);
  const [liveSystemUpi, setLiveSystemUpi] = useState<{ activeUpiId: string; merchantName: string } | null>(null);
  const [activeCampaign, setActiveCampaign] = useState<TimedCampaignState | null>(null);

  // Live CoreGameEngine.vipState & WebSystemVipEngine state (VIP0 to VIP10)
  const initialVipState = useMemo(
    () => buildLiveVipLevelsData(user, activeCampaign),
    [user, activeCampaign]
  );
  const [vipState, setVipState] = useState<CoreVipState>(initialVipState);
  const [currentViewingIndex, setCurrentViewingIndex] = useState<number>(initialVipState.userActualVipLevel);
  const [vipSubTab, setVipSubTab] = useState<'activity' | 'vip'>('vip');

  // Deposit Channel & Amount state
  const [depositChannel, setDepositChannel] = useState<'normal' | 'bonus'>('bonus');
  const [depositAmount, setDepositAmount] = useState<number>(500);
  const [depositInputRaw, setDepositInputRaw] = useState<string>('500');
  const [utrNumber, setUtrNumber] = useState<string>('');
  const [proofImage, setProofImage] = useState<string>('');
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [depositSubmitting, setDepositSubmitting] = useState<boolean>(false);
  const [depositSuccess, setDepositSuccess] = useState<string | null>(null);
  const [depositError, setDepositError] = useState<string | null>(null);
  const [selfDeclaredConsent, setSelfDeclaredConsent] = useState<boolean>(true);
  const [depositUsername, setDepositUsername] = useState<string>(user.name || user.uid || user.id);
  const [liveWalletBalance, setLiveWalletBalance] = useState<number>(user.mainBalance || 0);
  const [liveSyncStatusText, setLiveSyncStatusText] = useState<string>('🟢 Live Sync: Connected (Instant)');

  // Promo Vault Conversion state (Module 24 B)
  const [promoAmount, setPromoAmount] = useState<number>(0);
  const [promoStatus, setPromoStatus] = useState<{
    promoWallet: number;
    convertedInLast24h: number;
    remaining24hInstantCap: number;
    dailyLimit: number;
  } | null>(null);
  const [promoConverting, setPromoConverting] = useState<boolean>(false);
  const [promoConvertSuccess, setPromoConvertSuccess] = useState<string | null>(null);
  const [promoConvertError, setPromoConvertError] = useState<string | null>(null);

  // Withdrawal state
  const [withdrawAmount, setWithdrawAmount] = useState<number>(110);
  const [withdrawInputRaw, setWithdrawInputRaw] = useState<string>('110');
  const [payoutMethod, setPayoutMethod] = useState<'UPI' | 'BANK'>(() => {
    const saved = localStorage.getItem(`winnova_payout_method_${user.id}`);
    return saved === 'UPI' ? 'UPI' : 'BANK';
  });
  const [upiId, setUpiId] = useState<string>(() => localStorage.getItem(`winnova_upi_${user.id}`) || '');
  const [bankAccount, setBankAccount] = useState<string>(() => localStorage.getItem(`winnova_bank_acc_${user.id}`) || '');
  const [ifscCode, setIfscCode] = useState<string>(() => localStorage.getItem(`winnova_ifsc_${user.id}`) || '');
  const [accountHolderName, setAccountHolderName] = useState<string>(
    () => localStorage.getItem(`winnova_holder_${user.id}`) || user.name || ''
  );
  const [isEditingBank, setIsEditingBank] = useState<boolean>(false);
  const [withdrawSubmitting, setWithdrawSubmitting] = useState<boolean>(false);
  const [withdrawSuccess, setWithdrawSuccess] = useState<string | null>(null);
  const [withdrawError, setWithdrawError] = useState<string | null>(null);

  // Gift Code state
  const [giftCodeInput, setGiftCodeInput] = useState<string>('');
  const [giftCodeLoading, setGiftCodeLoading] = useState<boolean>(false);
  const [giftCodeSuccess, setGiftCodeSuccess] = useState<string | null>(null);
  const [giftCodeError, setGiftCodeError] = useState<string | null>(null);

  // History state
  const [historyDeposits, setHistoryDeposits] = useState<DepositRequest[]>([]);
  const [historyWithdrawals, setHistoryWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);
  const [submittedDepositOrderId, setSubmittedDepositOrderId] = useState<string | null>(null);
  const [submittedWithdrawalOrderId, setSubmittedWithdrawalOrderId] = useState<string | null>(null);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  // Synchronize CoreGameEngine.vipState and WebSystemVipEngine whenever user or activeCampaign changes
  useEffect(() => {
    const computed = buildLiveVipLevelsData(user, activeCampaign);
    setVipState((prev) => {
      const updated: CoreVipState = {
        ...computed,
        currentViewingIndex: prev.currentViewingIndex
      };
      if (typeof window !== 'undefined') {
        window.CoreGameEngine = {
          ...(window.CoreGameEngine || {}),
          vipState: updated
        };
        window.WebSystemVipEngine = updated;
      }
      return updated;
    });
  }, [user, activeCampaign]);

  // Sync currentViewingIndex into global CoreGameEngine.vipState & WebSystemVipEngine
  useEffect(() => {
    setVipState((prev) => {
      const updated = { ...prev, currentViewingIndex };
      if (typeof window !== 'undefined') {
        window.CoreGameEngine = {
          ...(window.CoreGameEngine || {}),
          vipState: updated
        };
        window.WebSystemVipEngine = updated;
      }
      return updated;
    });
  }, [currentViewingIndex]);

  useEffect(() => {
    setLiveWalletBalance(user.mainBalance || 0);
    const walletEl = document.getElementById('realWallet');
    if (walletEl) {
      walletEl.innerText = user.role === 'superadmin' || user.mainBalance >= 900000000 ? '∞' : String(user.mainBalance ?? 0);
    }
  }, [user.mainBalance, user.role]);

  // ⚡ SYSTEM 1: INSTANT LIVE REALTIME SYNC FUNCTION
  const startLiveSync = async (overrideUsername?: string) => {
    const rawUsername = (overrideUsername !== undefined ? overrideUsername : depositUsername).trim();
    const statusDiv = document.getElementById('syncStatus');
    const walletSpan = document.getElementById('realWallet');

    if (!rawUsername) {
      setLiveSyncStatusText('🔴 Live Sync: Enter Username');
      if (statusDiv) statusDiv.innerText = '🔴 Live Sync: Enter Username';
      if (walletSpan) walletSpan.innerText = '0';
      setLiveWalletBalance(0);
      return;
    }

    try {
      setLiveSyncStatusText('🔴 Live Sync: Connecting...');
      if (statusDiv) statusDiv.innerText = '🔴 Live Sync: Connecting...';

      const res = await fetch(`/api/wallets/${encodeURIComponent(rawUsername)}`);
      if (res.ok) {
        const json = await res.json();
        const bal = json?.data?.balance ?? 0;
        setLiveWalletBalance(bal);
        if (walletSpan) {
          walletSpan.innerText = bal >= 900000000 ? '∞' : String(bal);
        }
      }
      setLiveSyncStatusText('🟢 Live Sync: Connected (Instant)');
      if (statusDiv) statusDiv.innerText = '🟢 Live Sync: Connected (Instant)';
    } catch {
      setLiveSyncStatusText('🟢 Live Sync: Connected (Instant)');
    }
  };

  // SYSTEM 3: GAME INTEGRATION FUNCTION (Database Permanent Save)
  const updateBalanceAfterGame = async (usernameKey: string, finalBalance: number) => {
    try {
      await fetch('/api/wallets/upsert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: usernameKey || user.name || user.id,
          userId: user.id,
          balance: finalBalance
        })
      });
    } catch (err) {
      console.error('Error updating balance:', err);
    }
  };

  useEffect(() => {
    if (typeof window !== 'undefined') {
      (window as any).startLiveSync = () => startLiveSync();
      (window as any).updateBalanceAfterGame = updateBalanceAfterGame;
      (window as any).processExclusiveWithdrawal = processExclusiveWithdrawal;
    }
  }, [depositUsername, user.id]);

  // Subscribe to instant live wallet changes via Socket.IO
  useEffect(() => {
    const unsubLiveWallet = socketService.on('wallet_live_sync', (payload: any) => {
      if (!payload) return;
      const targetKey = (depositUsername || user.name || user.id).trim().toLowerCase();
      const matchesUser =
        payload.userId === user.id ||
        (payload.username && String(payload.username).toLowerCase() === targetKey) ||
        (payload.uid && String(payload.uid).toLowerCase() === targetKey);

      if (matchesUser && payload.balance !== undefined) {
        setLiveWalletBalance(payload.balance);
        const walletSpan = document.getElementById('realWallet');
        if (walletSpan) {
          walletSpan.innerText = payload.balance >= 900000000 ? '∞' : String(payload.balance);
        }
        setLiveSyncStatusText('🟢 Live Sync: Connected (Instant)');
        onRefreshUser();
      }
    });

    return () => {
      unsubLiveWallet();
    };
  }, [depositUsername, user.id, user.name]);

  useEffect(() => {
    if (isOpen) {
      fetchTransactionHistory();
      fetchActiveDepositNode();
      fetchPromoStatus();
      fetchLiveVipEngineState();
      fetchSavedPayoutDetails();
      startLiveSync(depositUsername || user.name || user.uid || user.id);
    }
  }, [isOpen, user.id]);

  const fetchSavedPayoutDetails = async () => {
    try {
      const res = await fetch(`/api/user/payout-details?userId=${encodeURIComponent(user.id)}`, {
        headers: { 'x-user-id': user.id }
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.details) {
          if (data.details.upiId && !upiId) setUpiId(data.details.upiId);
          if (data.details.accNo && !bankAccount) setBankAccount(data.details.accNo);
          if (data.details.ifsc && !ifscCode) setIfscCode(data.details.ifsc);
          if (data.details.accName && !accountHolderName) setAccountHolderName(data.details.accName);
        }
      }
    } catch {}
  };

  // Persist user's saved bank/UPI info locally and on server database
  useEffect(() => {
    localStorage.setItem(`winnova_payout_method_${user.id}`, payoutMethod);
    if (upiId) localStorage.setItem(`winnova_upi_${user.id}`, upiId);
    if (bankAccount) localStorage.setItem(`winnova_bank_acc_${user.id}`, bankAccount);
    if (ifscCode) localStorage.setItem(`winnova_ifsc_${user.id}`, ifscCode);
    if (accountHolderName) localStorage.setItem(`winnova_holder_${user.id}`, accountHolderName);

    if (upiId || bankAccount || ifscCode) {
      fetch('/api/user/payout-details', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user.id },
        body: JSON.stringify({
          userId: user.id,
          upiId,
          accName: accountHolderName,
          accNo: bankAccount,
          ifsc: ifscCode
        })
      }).catch(() => {});
    }
  }, [payoutMethod, upiId, bankAccount, ifscCode, accountHolderName, user.id]);

  // Real-time onSnapshot listener for Super Admin global UPI updates
  useEffect(() => {
    const unsub = subscribeToGlobalSystemConfig((cfg) => {
      if (cfg?.activeUpiId) {
        setLiveSystemUpi(cfg);
      }
    });
    return () => unsub();
  }, []);

  const fetchLiveVipEngineState = async () => {
    try {
      const [vipRes, promoRes] = await Promise.all([
        fetch(`/api/vip/state?userId=${encodeURIComponent(user.id)}`, {
          headers: { 'x-user-id': user.id }
        }),
        fetch('/api/promotions/active')
      ]);

      if (promoRes.ok) {
        const promoData = await promoRes.json();
        if (promoData?.campaign) {
          setActiveCampaign(promoData.campaign);
        }
      }

      if (vipRes.ok) {
        const data = await vipRes.json();
        if (data?.vipState && Array.isArray(data.vipState.vipLevelsData)) {
          setVipState(data.vipState);
          setCurrentViewingIndex(data.vipState.userActualVipLevel || 0);
          if (typeof window !== 'undefined') {
            window.CoreGameEngine = {
              ...(window.CoreGameEngine || {}),
              vipState: data.vipState
            };
            window.WebSystemVipEngine = data.vipState;
          }
        }
      }
    } catch {}
  };

  const navigateVipLevel = (direction: number) => {
    setCurrentViewingIndex((prev) => {
      const maxIdx = Math.max(0, (vipState.vipLevelsData?.length || 11) - 1);
      const nextIdx = prev + direction;
      if (nextIdx >= 0 && nextIdx <= maxIdx) {
        return nextIdx;
      }
      return prev;
    });
  };

  const fetchActiveDepositNode = async () => {
    try {
      const res = await fetch('/api/public/deposit-info');
      if (res.ok) {
        const data = await res.json();
        if (data.activeNode) {
          setActiveNode(data.activeNode);
        }
      }
    } catch {}
  };

  const fetchTransactionHistory = async () => {
    try {
      const res = await fetch(`/api/user/transactions?userId=${user.id}`);
      if (res.ok) {
        const data = await res.json();
        const deps = data.deposits || [];
        const withs = data.withdrawals || [];
        setHistoryDeposits(deps);
        setHistoryWithdrawals(withs);

        // Sync with localStorage for ghost player widgets & offline backup
        try {
          const ghostDeps = deps.map((d: any) => ({
            amount: d.amount,
            date: d.createdAt ? new Date(d.createdAt).toLocaleString() : new Date().toLocaleString(),
            status: d.status,
            orderId: d.orderId || d.id
          }));
          const ghostWiths = withs.map((w: any) => ({
            amount: w.amount,
            tax: w.taxAmount || 0,
            date: w.createdAt ? new Date(w.createdAt).toLocaleString() : new Date().toLocaleString(),
            status: w.status,
            orderId: w.orderId || w.id
          }));
          localStorage.setItem('ghost_deposit_history', JSON.stringify(ghostDeps));
          localStorage.setItem('ghost_withdrawal_history', JSON.stringify(ghostWiths));
        } catch {}
      }
    } catch {}
  };

  const fetchPromoStatus = async () => {
    try {
      const res = await fetch(`/api/wallet/promo-status?userId=${user.id}`);
      if (res.ok) {
        const data = await res.json();
        setPromoStatus(data);
      }
    } catch {}
  };

  const handleConvertPromo = async () => {
    if (!promoAmount || promoAmount <= 0) {
      setPromoConvertError('Please enter a valid transfer amount greater than ₹0.');
      return;
    }
    if (promoAmount > (user.promoWallet || 0)) {
      setPromoConvertError(`Amount exceeds available Promo Vault balance (₹${(user.promoWallet || 0).toFixed(2)}).`);
      return;
    }

    setPromoConverting(true);
    setPromoConvertError(null);
    setPromoConvertSuccess(null);

    try {
      const res = await fetch('/api/wallet/convert-promo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          amount: promoAmount
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to transfer promotional balance');
      }

      setPromoConvertSuccess(data.message || 'Successfully transferred to main balance!');
      setPromoAmount(0);
      fetchPromoStatus();
      onRefreshUser();
    } catch (err: any) {
      setPromoConvertError(err.message || 'Error processing promotional conversion.');
    } finally {
      setPromoConverting(false);
    }
  };

  const currentUpiId = activeNode?.upiId || liveSystemUpi?.activeUpiId || 'winnova.merchant@upi';
  const currentDisplayName = activeNode?.displayName || liveSystemUpi?.merchantName || 'WIN NOVA Cashier';

  // Dynamic Amount-Specific UPI Deep Link and QR Generator
  const dynamicUpi = useMemo(() => {
    return generateDynamicUpiQr({
      upiId: currentUpiId,
      merchantName: currentDisplayName,
      amount: Math.max(100, depositAmount || 100),
      note: `Deposit Aviator ID ${user.id.slice(0, 6)}`
    });
  }, [currentUpiId, currentDisplayName, depositAmount, user.id]);

  const upiDeepLink = dynamicUpi.deepLinkUri;
  const qrCodeUrl = activeNode?.qrImageUrl || dynamicUpi.qrImageUrl;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(currentUpiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setDepositError('Screenshot image must be under 5MB.');
      return;
    }

    setProofFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setProofImage(reader.result as string);
      setDepositError(null);
    };
    reader.readAsDataURL(file);
  };

  // Helper to send deposit proof photo directly to Admin Telegram Bot (no extra verification option in Telegram)
  const sendProofToTelegramBot = async (params: {
    username: string;
    amount: string | number;
    txId: string;
    file?: File | null;
  }): Promise<{ ok: boolean; description?: string }> => {
    const botToken = '8828254838:AAEDJDElJPa8ETmhHINPD7PezMrZ9IWgDDU';
    const chatId = '7939005883';

    if (!params.file) {
      return { ok: false, description: 'No receipt file attached' };
    }

    const formData = new FormData();
    formData.append('chat_id', chatId);
    formData.append('photo', params.file);
    formData.append(
      'caption',
      `📥 **NEW DEPOSIT REQUEST**\n\n👤 **User:** ${params.username}\n💵 **Amount:** ₹${params.amount}\n🆔 **Txn ID:** \`${params.txId}\`\n\n📢 *Admin check bank & add manually in Supabase!*`
    );

    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendPhoto`, {
      method: 'POST',
      body: formData
    });

    if (response.ok) {
      return { ok: true };
    } else {
      const errData = await response.json().catch(() => ({}));
      return { ok: false, description: errData.description || 'Failed to send to Telegram' };
    }
  };

  const handleSelectDepositPack = (amt: number) => {
    setDepositAmount(amt);
    setDepositInputRaw(String(amt));
    setDepositError(null);
  };

  const handleDepositInputChange = (val: string) => {
    setDepositInputRaw(val);
    const num = Number(val.replace(/[^\d]/g, ''));
    setDepositAmount(isNaN(num) ? 0 : num);
  };

  const handleClearDepositInput = () => {
    setDepositInputRaw('');
    setDepositAmount(0);
  };

  const handleWithdrawInputChange = (val: string) => {
    setWithdrawInputRaw(val);
    const num = Number(val.replace(/[^\d]/g, ''));
    setWithdrawAmount(isNaN(num) ? 0 : num);
  };

  const handleClearWithdrawInput = () => {
    setWithdrawInputRaw('');
    setWithdrawAmount(0);
  };

  // Calculate live bonus badge for a given pack amount
  const getPackBonusLabel = (amt: number): string | null => {
    if (depositChannel !== 'bonus') return null;
    const isFirstDeposit = (user.lifetimeDeposit || 0) === 0;
    const campaignOverride =
      activeCampaign?.isActive && activeCampaign?.overrides
        ? activeCampaign.overrides[String(amt)]
        : undefined;
    if (campaignOverride) {
      const val = isFirstDeposit ? campaignOverride.firstTime : campaignOverride.recurring;
      return `+₹${val}`;
    }
    const tier = BASELINE_DEPOSIT_BONUSES.find((b) => b.depositAmount === amt);
    if (tier) {
      const bonusVal = isFirstDeposit ? tier.firstTimeBonus : tier.recurringBonus;
      return `+₹${bonusVal}`;
    }
    const vipMatch = vipState.vipLevelsData.find((v) => v.requiredDeposit === amt);
    if (vipMatch && vipMatch.upgradeReward > 0) {
      return `+₹${isFirstDeposit ? vipMatch.upgradeReward : vipMatch.monthlyReward}`;
    }
    return null;
  };

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setDepositError(null);
    setDepositSuccess(null);

    if (!depositAmount || depositAmount < 100) {
      setDepositError('Minimum deposit amount is ₹100.');
      return;
    }

    const cleanUtr = utrNumber.trim();
    if (!cleanUtr || cleanUtr.length < 8) {
      setDepositError('Please provide a valid 12-digit UTR / Transaction Reference Number.');
      return;
    }

    // Client-side pre-check against already submitted UTRs in user's history
    const alreadySubmittedLocally = historyDeposits.some(
      (d) => d.utrNumber && d.utrNumber.trim().toLowerCase() === cleanUtr.toLowerCase()
    );
    if (alreadySubmittedLocally) {
      setDepositError('This UTR number has already been submitted for verification.');
      return;
    }

    if (!proofImage) {
      setDepositError('Please upload payment screenshot proof for security verification.');
      return;
    }

    if (!selfDeclaredConsent) {
      setDepositError('You must verify the mandatory self-declaration to proceed.');
      return;
    }

    setDepositSubmitting(true);
    try {
      const effectiveUsername = (depositUsername || user.name || user.uid || user.id).trim();

      // Submit to backend FIRST so duplicate/already-submitted UTRs are rejected BEFORE any Telegram message is sent
      const res = await fetch('/api/cashier/deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          username: effectiveUsername,
          amount: depositAmount,
          paymentMethod: 'UPI_QR',
          utrNumber: cleanUtr,
          proofImageUrl: proofImage,
          selfDeclaredConsent: true,
          channel: depositChannel,
          telegramSentClientSide: false
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit deposit');
      }

      // Only if the UTR is unsubmitted and accepted by the server:
      // If server did not already dispatch the photo to Telegram, send via client fallback
      if (!data.telegramDispatched && proofFile) {
        await sendProofToTelegramBot({
          username: effectiveUsername,
          amount: depositAmount,
          txId: cleanUtr,
          file: proofFile
        }).catch(() => ({ ok: false }));
      }

      DeepAuditSystem.commitDepositRequest({
        userId: user.id,
        amount: depositAmount,
        upiId: currentUpiId,
        utrNumber: cleanUtr,
        status: 'pending'
      }).catch((e) => console.warn('[CashierModal] DeepAudit deposit request notice:', e));

      setDepositSuccess('Proof sent! Admin / database mein approve hote hi balance instant yahan badal jayega.');
      setUtrNumber('');
      setProofImage('');
      setProofFile(null);
      startLiveSync(effectiveUsername);
      fetchTransactionHistory();
      fetchLiveVipEngineState();
      onRefreshUser();
    } catch (err: any) {
      setDepositError(err.message || 'Error submitting deposit proof.');
    } finally {
      setDepositSubmitting(false);
    }
  };

  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawError(null);
    setWithdrawSuccess(null);

    if (!withdrawAmount || withdrawAmount < 100) {
      setWithdrawError('Minimum withdrawal amount is ₹100.');
      return;
    }

    const isSuperUser = user.role === 'superadmin' || user.mainBalance >= 900000000;
    const effectiveBalance = isSuperUser ? 999999999 : user.withdrawableBalance;
    const exclusiveCheck = processExclusiveWithdrawal(withdrawAmount, effectiveBalance);
    if (!exclusiveCheck.success) {
      setWithdrawError(
        exclusiveCheck.message ||
          `Insufficient Funds! Balance needed: ₹${exclusiveCheck.walletDeducted} (including ₹${exclusiveCheck.taxCollected} tax).`
      );
      return;
    }

    if (payoutMethod === 'UPI' && (!upiId || !upiId.includes('@'))) {
      setIsEditingBank(true);
      setWithdrawError('Please enter a valid UPI ID (e.g. yourname@okaxis) in the payout card.');
      return;
    }

    if (payoutMethod === 'BANK' && (!bankAccount || !ifscCode)) {
      setIsEditingBank(true);
      setWithdrawError('Please provide complete Bank Account Number and IFSC Code in the bank details card.');
      return;
    }

    setWithdrawSubmitting(true);
    try {
      DeepAuditSystem.commitWithdrawalRequest({
        userId: user.id,
        amount: withdrawAmount,
        payoutMethod,
        upiId: payoutMethod === 'UPI' ? upiId : undefined,
        bankAccount: payoutMethod === 'BANK' ? bankAccount : undefined,
        ifscCode: payoutMethod === 'BANK' ? ifscCode : undefined,
        status: 'pending'
      }).catch((e) => console.warn('[CashierModal] DeepAudit withdrawal request notice:', e));

      const res = await fetch('/api/cashier/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          amount: withdrawAmount,
          payoutMethod,
          upiId: payoutMethod === 'UPI' ? upiId : undefined,
          bankAccount: payoutMethod === 'BANK' ? bankAccount : undefined,
          ifscCode: payoutMethod === 'BANK' ? ifscCode : undefined,
          accountHolderName
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Withdrawal request failed');
      }

      setWithdrawSuccess(
        data.message ||
          `Withdrawal request submitted! You get ₹${exclusiveCheck.userGets} (Wallet deducted: ₹${exclusiveCheck.walletDeducted} incl. ₹${exclusiveCheck.taxCollected} tax).`
      );
      fetchTransactionHistory();
      onRefreshUser();
    } catch (err: any) {
      setWithdrawError(err.message || 'Error submitting payout request.');
    } finally {
      setWithdrawSubmitting(false);
    }
  };

  // Dynamic Exclusive Slab Tax Calculator (<2000: 10%, 2000-4999: 9%, >=5000: 8%, added on top of requestedAmount)
  const getDynamicFeePreview = (amt: number) => {
    if (!amt || amt <= 0) {
      return { fee: 0, payout: 0, walletDeducted: 0, taxPercent: 10 };
    }
    const calc = processExclusiveWithdrawal(amt, Number.MAX_SAFE_INTEGER);
    return {
      fee: calc.taxCollected,
      payout: calc.userGets,
      walletDeducted: calc.walletDeducted,
      taxPercent: calc.taxPercent
    };
  };

  // Atomic Gift Code Claim Handler
  const handleClaimGiftCode = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!giftCodeInput.trim()) {
      setGiftCodeError('Please enter a valid gift code.');
      return;
    }
    setGiftCodeLoading(true);
    setGiftCodeError(null);
    setGiftCodeSuccess(null);
    try {
      const res = await fetch('/api/gift-code/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: giftCodeInput.trim().toUpperCase(),
          userId: user.id
        })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to claim gift code.');
      }
      setGiftCodeSuccess(data.message || `Code redeemed! ₹${data.claimedAmount} credited to your wallet.`);
      setGiftCodeInput('');
      onRefreshUser();
      fetchTransactionHistory();
    } catch (err: any) {
      setGiftCodeError(err.message || 'Error claiming gift code.');
    } finally {
      setGiftCodeLoading(false);
    }
  };

  if (!isOpen) return null;

  const isSuper = user.role === 'superadmin' || user.mainBalance >= 900000000;
  const userVip = isSuper
    ? { level: 10, label: 'VIP 10', minLifetimeDeposit: 500000, maxSingleWithdrawal: 1000000 }
    : getVipConfig(user.lifetimeDeposit || 0);

  // Wager progress calculation for Withdraw tab
  const hasRequiredWagerLock = (user.requiredWager || 0) > 0;
  const turnoverPct = user.turnoverRequired > 0
    ? Math.min(100, Math.floor((user.turnoverCompleted / user.turnoverRequired) * 100))
    : hasRequiredWagerLock
    ? Math.min(95, Math.max(15, Math.floor((user.turnoverCompleted / ((user.turnoverCompleted || 0) + (user.requiredWager || 1))) * 100)))
    : 100;

  const headerTitle =
    activeTab === 'deposit'
      ? 'Deposit'
      : activeTab === 'withdraw'
      ? 'Withdraw'
      : activeTab === 'vip'
      ? 'VIP'
      : activeTab === 'promo'
      ? 'Promo Vault'
      : activeTab === 'giftcode'
      ? 'Gift Code'
      : 'Order History';

  const hasBankOrUpiConfigured =
    (payoutMethod === 'BANK' && bankAccount.trim().length > 0 && ifscCode.trim().length > 0) ||
    (payoutMethod === 'UPI' && upiId.trim().includes('@'));

  const showBankInputs = isEditingBank || !hasBankOrUpiConfigured;

  // Active VIP Tier Data from CoreGameEngine.vipState / WebSystemVipEngine
  const activeVipData =
    vipState.vipLevelsData[currentViewingIndex] ||
    vipState.vipLevelsData[0] || {
      level: 0,
      levelName: 'VIP0',
      requiredDeposit: 0,
      requiredBetAmount: 0,
      currentAccumulated: user.lifetimeDeposit || 0,
      currentBetAccumulated: user.cumulativeVolume || user.turnoverCompleted || 0,
      upgradeReward: 0,
      monthlyReward: 0,
      dailyWithdrawLimit: 120,
      progressPercentage: 100,
      isLocked: false
    };

  const nextVipIndex = Math.min(10, currentViewingIndex + 1);
  const nextVipTierData = vipState.vipLevelsData[nextVipIndex] || activeVipData;
  const targetDepositForDisplay =
    currentViewingIndex === 0 ? nextVipTierData.requiredDeposit : activeVipData.requiredDeposit;

  const isTierUnlocked = currentViewingIndex <= vipState.userActualVipLevel || !activeVipData.isLocked;
  const vipSliderPercentage = isTierUnlocked
    ? 100
    : targetDepositForDisplay > 0
    ? Math.min(100, Math.max(0, Math.floor((activeVipData.currentAccumulated / targetDepositForDisplay) * 100)))
    : 100;

  const lockIcon = isTierUnlocked ? '🔓' : '🔒';

  return (
    <div
      id="cashier-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-md"
    >
      {/* Dynamic Wallet & VIP Dashboard Phone Container (.phone-container) */}
      <div
        id="cashier-modal-container"
        className="phone-container w-full max-w-[450px] max-w-[calc(100vw-12px)] bg-[#190924] text-white sm:rounded-2xl shadow-[0_0_25px_rgba(0,0,0,0.75)] border border-[#32164a] overflow-hidden flex flex-col h-full sm:h-auto sm:max-h-[92vh]"
      >
        {/* Top Navigation Header (.app-header) */}
        <div className="app-header flex items-center justify-between p-[15px] bg-[#190924] border-b border-[#32164a] shrink-0">
          <span
            onClick={onClose}
            className="back-btn text-[#f4c430] text-[18px] cursor-pointer flex items-center gap-[5px] hover:opacity-85 transition"
          >
            ‹ <span id="header-type-title">{headerTitle}</span>
          </span>

          <span
            id="close-cashier-btn"
            onClick={onClose}
            className="home-icon text-[#f4c430] text-[22px] cursor-pointer hover:opacity-85 transition"
            title="Return to Lobby"
          >
            🏠
          </span>
        </div>

        {/* Main 3-Tab Navigation (#main-tabs-row .tab-navigation) */}
        <div
          id="main-tabs-row"
          className="tab-navigation flex bg-[#28143a] p-[6px] m-[15px] mb-[8px] rounded-[6px] gap-[5px] shrink-0"
        >
          <button
            type="button"
            id="tab-btn-deposit"
            onClick={() => setActiveTab('deposit')}
            style={
              activeTab === 'deposit'
                ? { background: 'linear-gradient(180deg, #8a1d7c 0%, #4e1256 100%)' }
                : undefined
            }
            className={`tab-btn flex-1 py-[12px] px-2 text-[14px] font-bold rounded-[4px] border-none cursor-pointer transition ${
              activeTab === 'deposit'
                ? 'active text-white shadow-[0_2px_5px_rgba(0,0,0,0.3)]'
                : 'bg-transparent text-[#8d739e] hover:text-white'
            }`}
          >
            🪙 Deposit
          </button>

          <button
            type="button"
            id="tab-btn-withdraw"
            onClick={() => setActiveTab('withdraw')}
            style={
              activeTab === 'withdraw'
                ? { background: 'linear-gradient(180deg, #8a1d7c 0%, #4e1256 100%)' }
                : undefined
            }
            className={`tab-btn flex-1 py-[12px] px-2 text-[14px] font-bold rounded-[4px] border-none cursor-pointer transition ${
              activeTab === 'withdraw'
                ? 'active text-white shadow-[0_2px_5px_rgba(0,0,0,0.3)]'
                : 'bg-transparent text-[#8d739e] hover:text-white'
            }`}
          >
            💰 Withdraw
          </button>

          <button
            type="button"
            id="tab-btn-vip"
            onClick={() => setActiveTab('vip')}
            style={
              activeTab === 'vip'
                ? { background: 'linear-gradient(180deg, #8a1d7c 0%, #4e1256 100%)' }
                : undefined
            }
            className={`tab-btn flex-1 py-[12px] px-2 text-[14px] font-bold rounded-[4px] border-none cursor-pointer transition ${
              activeTab === 'vip'
                ? 'active text-white shadow-[0_2px_5px_rgba(0,0,0,0.3)]'
                : 'bg-transparent text-[#8d739e] hover:text-white'
            }`}
          >
            👑 VIP
          </button>
        </div>

        {/* Secondary Quick Access Strip for Promo Vault, Gift Code & Order Ledger */}
        <div className="flex items-center justify-between gap-1.5 px-[15px] mb-[10px] shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('promo')}
            className={`flex-1 py-1.5 px-2 rounded text-[11px] font-semibold flex items-center justify-center gap-1 transition cursor-pointer border ${
              activeTab === 'promo'
                ? 'bg-[#4e1256] text-[#f4c430] border-[#f4c430]/60'
                : 'bg-[#28143a]/70 text-[#8d739e] border-[#3c1e54] hover:text-white'
            }`}
          >
            <Gift className="w-3.5 h-3.5" />
            <span>Promo Vault</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('giftcode')}
            className={`flex-1 py-1.5 px-2 rounded text-[11px] font-semibold flex items-center justify-center gap-1 transition cursor-pointer border ${
              activeTab === 'giftcode'
                ? 'bg-[#4e1256] text-[#f4c430] border-[#f4c430]/60'
                : 'bg-[#28143a]/70 text-[#8d739e] border-[#3c1e54] hover:text-white'
            }`}
          >
            <Ticket className="w-3.5 h-3.5" />
            <span>Gift Code</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-1.5 px-2 rounded text-[11px] font-semibold flex items-center justify-center gap-1 transition cursor-pointer border ${
              activeTab === 'history'
                ? 'bg-[#4e1256] text-[#f4c430] border-[#f4c430]/60'
                : 'bg-[#28143a]/70 text-[#8d739e] border-[#3c1e54] hover:text-white'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Orders ({historyDeposits.length + historyWithdrawals.length})</span>
          </button>
        </div>

        {/* Main Scrollable View Container */}
        <div className="px-[15px] pb-[20px] overflow-y-auto overflow-x-hidden flex-1">
          {/* =================================================================== */}
          {/* VIP PANEL VIEW (0 to 10 fully dynamic loop bound to live system) */}
          {/* =================================================================== */}
          {activeTab === 'vip' && (
            <div id="panel-vip" className="view-panel active">
              {/* Sub-Tab Navigation (Activity / VIP) */}
              <div
                className="tab-navigation flex bg-[#28143a] rounded-[6px] gap-[5px]"
                style={{ margin: '0 0 15px 0', padding: '4px' }}
              >
                <button
                  type="button"
                  onClick={() => setVipSubTab('activity')}
                  style={
                    vipSubTab === 'activity'
                      ? { background: 'linear-gradient(180deg, #8a1d7c 0%, #4e1256 100%)', fontSize: '13px' }
                      : { fontSize: '13px' }
                  }
                  className={`tab-btn flex-1 py-[10px] font-bold rounded-[4px] border-none cursor-pointer transition ${
                    vipSubTab === 'activity' ? 'active text-white' : 'bg-transparent text-[#8d739e]'
                  }`}
                >
                  Activity
                </button>
                <button
                  type="button"
                  onClick={() => setVipSubTab('vip')}
                  style={
                    vipSubTab === 'vip'
                      ? { background: 'linear-gradient(180deg, #8a1d7c 0%, #4e1256 100%)', fontSize: '13px' }
                      : { fontSize: '13px' }
                  }
                  className={`tab-btn flex-1 py-[10px] font-bold rounded-[4px] border-none cursor-pointer transition ${
                    vipSubTab === 'vip' ? 'active text-white' : 'bg-transparent text-[#8d739e]'
                  }`}
                >
                  VIP
                </button>
              </div>

              {/* Dynamic Slider Card Compartment (.vip-card-scroller) */}
              <div
                className="vip-card-scroller flex items-center justify-between rounded-[12px] p-[20px] mb-[20px] relative border border-[#5a2870]"
                style={{
                  background: 'linear-gradient(135deg, #441b54 0%, #200a2b 100%)'
                }}
              >
                <span
                  onClick={() => navigateVipLevel(-1)}
                  className="nav-arrow text-[#f4c430] text-[28px] cursor-pointer select-none px-[10px] hover:scale-110 transition"
                >
                  ‹
                </span>

                <div className="vip-main-display text-center flex-1">
                  <div
                    id="vip-render-title"
                    className="vip-crown-title text-[32px] font-black text-[#f4c430] italic tracking-[1px] mb-[5px]"
                  >
                    {activeVipData.levelName}
                  </div>
                  <div
                    id="vip-render-progress-text"
                    className="vip-progress-text text-[13px] text-[#d1b4e0] mb-[8px]"
                  >
                    Deposit amount: ₹{activeVipData.currentAccumulated.toLocaleString('en-IN')}/₹
                    {targetDepositForDisplay.toLocaleString('en-IN')} (V{currentViewingIndex} ➔ V{nextVipIndex})
                  </div>
                  <div className="vip-slider-bg w-full h-[10px] bg-[#2b1238] rounded-[10px] overflow-hidden flex items-center p-[1px]">
                    <div
                      id="vip-render-slider-bar"
                      className="vip-slider-fill h-full rounded-[10px] transition-all duration-400"
                      style={{
                        width: `${vipSliderPercentage}%`,
                        background: 'linear-gradient(90deg, #e0a31b 0%, #ffffff 100%)'
                      }}
                    />
                  </div>
                </div>

                <span
                  onClick={() => navigateVipLevel(1)}
                  className="nav-arrow text-[#f4c430] text-[28px] cursor-pointer select-none px-[10px] hover:scale-110 transition"
                >
                  ›
                </span>
              </div>

              {/* Dynamic Reward Status Cards (.rewards-grid) */}
              <div className="rewards-grid grid grid-cols-3 gap-[10px] mb-[20px]">
                <div
                  className="reward-box-card rounded-[8px] py-[15px] px-[5px] text-center flex flex-col justify-between items-center min-h-[125px] border border-[#662787]"
                  style={{
                    background: 'linear-gradient(180deg, #531c6e 0%, #2b0e3b 100%)'
                  }}
                >
                  <span className="reward-box-title text-[11px] text-[#decbe6] leading-[1.3]">
                    Level upgrade reward
                  </span>
                  <div
                    id="vip-card-upgrade-val"
                    className="reward-box-value text-[14px] font-bold text-white bg-black/20 w-[90%] py-[4px] px-[2px] rounded-[4px] my-[8px]"
                  >
                    ₹{activeVipData.upgradeReward.toLocaleString('en-IN')}
                  </div>
                  <span id="vip-card-upgrade-lock" className="lock-icon-indicator text-[14px]">
                    {lockIcon}
                  </span>
                </div>

                <div
                  className="reward-box-card rounded-[8px] py-[15px] px-[5px] text-center flex flex-col justify-between items-center min-h-[125px] border border-[#662787]"
                  style={{
                    background: 'linear-gradient(180deg, #531c6e 0%, #2b0e3b 100%)'
                  }}
                >
                  <span className="reward-box-title text-[11px] text-[#decbe6] leading-[1.3]">
                    Monthly reward
                  </span>
                  <div
                    id="vip-card-monthly-val"
                    className="reward-box-value text-[14px] font-bold text-white bg-black/20 w-[90%] py-[4px] px-[2px] rounded-[4px] my-[8px]"
                  >
                    ₹{activeVipData.monthlyReward.toLocaleString('en-IN')}
                  </div>
                  <span id="vip-card-monthly-lock" className="lock-icon-indicator text-[14px]">
                    {lockIcon}
                  </span>
                </div>

                <div
                  className="reward-box-card rounded-[8px] py-[15px] px-[5px] text-center flex flex-col justify-between items-center min-h-[125px] border border-[#662787]"
                  style={{
                    background: 'linear-gradient(180deg, #531c6e 0%, #2b0e3b 100%)'
                  }}
                >
                  <span className="reward-box-title text-[11px] text-[#decbe6] leading-[1.3]">
                    Daily withdrawal limit
                  </span>
                  <div
                    id="vip-card-withdraw-val"
                    className="reward-box-value text-[14px] font-bold text-white bg-black/20 w-[90%] py-[4px] px-[2px] rounded-[4px] my-[8px]"
                  >
                    ₹{activeVipData.dailyWithdrawLimit.toLocaleString('en-IN')}
                  </div>
                  <span id="vip-card-withdraw-lock" className="lock-icon-indicator text-[14px]">
                    {lockIcon}
                  </span>
                </div>
              </div>

              <div className="vip-footer-notice text-[13px] text-[#8d739e] leading-[1.5] mt-[15px]">
                *Monthly rewards depend on stake amount and VIP
              </div>
              <div className="vip-upgrade-instruction text-[18px] text-[#f4c430] mt-[15px] mb-[10px] font-medium">
                VIP status can be upgraded by accumulating monthly deposits
              </div>

              <div
                style={{
                  backgroundColor: '#2a0f3d',
                  padding: '12px',
                  borderRadius: '6px',
                  fontSize: '12px',
                  lineHeight: 1.4
                }}
              >
                Upgrade Reward: You can get a promotion reward each time you are leveled up
              </div>

              {/* VIP Tier Progression Table Header & Live System Rows */}
              <div className="vip-table-header-mock bg-[#28143a] rounded-[6px] p-[12px] flex justify-between text-[12px] text-[#8d739e] mt-[15px]">
                <span>VIP Level</span>
                <span>Deposit</span>
                <span>Bet amount</span>
                <span>Level upgrade bonus</span>
              </div>

              <div className="mt-1.5 space-y-1">
                {vipState.vipLevelsData.map((item) => {
                  const isCurrentView = item.level === currentViewingIndex;
                  const isUserCurrentTier = item.level === vipState.userActualVipLevel;
                  return (
                    <div
                      key={item.levelName}
                      onClick={() => setCurrentViewingIndex(item.level)}
                      className={`rounded-[6px] px-[12px] py-[10px] flex justify-between items-center text-[12px] cursor-pointer transition border ${
                        isCurrentView
                          ? 'bg-[#3b1954] border-[#f4c430]/70 text-white font-bold'
                          : isUserCurrentTier
                          ? 'bg-[#2e1442] border-[#8a1d7c] text-[#f4c430]'
                          : 'bg-[#210d30] border-transparent text-[#d1b4e0] hover:bg-[#28143a]'
                      }`}
                    >
                      <span className="font-bold text-[#f4c430] flex items-center gap-1">
                        <span>{item.levelName}</span>
                        <span>{item.level <= vipState.userActualVipLevel ? '🔓' : '🔒'}</span>
                      </span>
                      <span>₹{item.requiredDeposit.toLocaleString('en-IN')}</span>
                      <span>₹{item.requiredBetAmount.toLocaleString('en-IN')}</span>
                      <span className="text-[#f4c430] font-semibold">
                        ₹{item.upgradeReward.toLocaleString('en-IN')}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* =================================================================== */}
          {/* DEPOSIT TAB PANEL (#panel-deposit .view-panel) */}
          {/* =================================================================== */}
          {activeTab === 'deposit' && (
            <form id="panel-deposit" onSubmit={handleDepositSubmit} className="view-panel active space-y-4">
              {/* REAL WALLET DISPLAY BOX WITH INSTANT REALTIME SYNC */}
              <div
                style={{ background: 'linear-gradient(135deg, #2ecc71, #27ae60)' }}
                className="text-white p-[15px] rounded-[6px] text-center mb-[16px] shadow-md"
              >
                <h4 className="m-0 uppercase text-[12px] opacity-90 tracking-[1px] font-bold">
                  Real Wallet Balance
                </h4>
                <h1 className="mt-[5px] mb-0 text-[32px] font-black font-mono">
                  ₹<span id="realWallet">{isSuper ? '∞' : liveWalletBalance.toFixed(2)}</span>
                </h1>
                <div id="syncStatus" className="text-[10px] mt-[5px] opacity-90 font-semibold">
                  {liveSyncStatusText}
                </div>
              </div>

              {/* Section Label + Check Order */}
              <div className="flex items-center justify-between mb-[12px]">
                <label className="text-[15px] text-white font-medium">
                  Payment Channel <span className="text-[#ff3333] ml-[3px]">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => setActiveTab('history')}
                  className="text-[#f4c430] text-[14px] flex items-center gap-1 hover:underline cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Check Order</span>
                </button>
              </div>

              {/* Card Channel Selector (.channels-row) */}
              <div className="flex gap-[15px] mb-[20px]">
                {/* Normal Channel Card (.card-channel.normal) */}
                <div
                  onClick={() => setDepositChannel('normal')}
                  style={{
                    background: 'linear-gradient(135deg, #a73c5a 0%, #57162d 100%)'
                  }}
                  className={`flex-1 h-[100px] rounded-[8px] p-[12px] relative cursor-pointer flex flex-col justify-between transition-all ${
                    depositChannel === 'normal'
                      ? 'border-2 border-white shadow-[0_0_12px_rgba(255,255,255,0.4)] opacity-100'
                      : 'border-2 border-transparent opacity-60 hover:opacity-80'
                  }`}
                >
                  <div className="text-[10px] font-bold opacity-75 tracking-[0.5px] uppercase">
                    NORMAL CHANNEL
                  </div>
                  <div className="text-[18px] font-black italic tracking-[0.5px] text-white">
                    Normal
                  </div>
                  <div className="text-[10px] opacity-70 uppercase tracking-wider">
                    {user.name || 'CARD HOLDER'}
                  </div>
                </div>

                {/* Bonus Channel Card (.card-channel.bonus) */}
                <div
                  onClick={() => setDepositChannel('bonus')}
                  style={{
                    background: 'linear-gradient(135deg, #4f2cb5 0%, #200f5c 100%)'
                  }}
                  className={`flex-1 h-[100px] rounded-[8px] p-[12px] relative cursor-pointer flex flex-col justify-between transition-all ${
                    depositChannel === 'bonus'
                      ? 'border-2 border-white shadow-[0_0_12px_rgba(255,255,255,0.4)] opacity-100'
                      : 'border-2 border-transparent opacity-60 hover:opacity-80'
                  }`}
                >
                  <div className="text-[10px] font-bold opacity-75 tracking-[0.5px] uppercase">
                    BONUS CHANNEL
                  </div>
                  <div className="text-[18px] font-black italic tracking-[0.5px] text-[#f4c430]">
                    +Extra Bonus
                  </div>
                  <div className="text-[10px] opacity-70 uppercase tracking-wider">
                    {user.name || 'CARD HOLDER'}
                  </div>
                </div>
              </div>

              {/* Deposit Amount Input (.input-wrapper & .main-input) */}
              <div>
                <label className="text-[15px] text-white mb-[12px] block font-medium">
                  Deposit Amount <span className="text-[#ff3333] ml-[3px]">*</span>
                </label>
                <div className="relative mb-[20px]">
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="100 ~ 50,000"
                    value={depositInputRaw}
                    onChange={(e) => handleDepositInputChange(e.target.value)}
                    className="w-full bg-[#28143a] border border-[#3c1e54] focus:border-[#f4c430] rounded-[6px] p-[15px] pr-10 text-white text-[16px] font-semibold outline-none transition placeholder:text-[#8d739e]"
                  />
                  {depositInputRaw && (
                    <button
                      type="button"
                      onClick={handleClearDepositInput}
                      className="absolute right-[15px] top-1/2 -translate-y-1/2 text-[#8d739e] hover:text-white cursor-pointer text-[20px] leading-none"
                      title="Clear amount"
                    >
                      &times;
                    </button>
                  )}
                </div>
              </div>

              {/* Grid Packs (.packs-grid & .pack-item) */}
              <div className="grid grid-cols-3 gap-[12px] mb-[22px]">
                {DEPOSIT_PACKS.map((pack) => {
                  const isSelected = depositAmount === pack.amount;
                  const bonusText = getPackBonusLabel(pack.amount);
                  return (
                    <button
                      key={pack.amount}
                      type="button"
                      onClick={() => handleSelectDepositPack(pack.amount)}
                      className={`bg-[#28143a] rounded-[6px] py-[16px] px-[8px] text-center relative cursor-pointer transition border ${
                        isSelected
                          ? 'border-[#f4c430] bg-[#361a4f] shadow-[0_0_10px_rgba(244,196,48,0.25)]'
                          : 'border-transparent hover:border-[#4e2670]'
                      }`}
                    >
                      {pack.isHot && (
                        <span className="absolute top-0 left-0 bg-[#d31d1d] text-white text-[8px] px-[4px] py-[1px] rounded-tl-[5px] rounded-br-[5px] font-bold uppercase">
                          HOT
                        </span>
                      )}
                      {bonusText && (
                        <span className="absolute -top-[6px] right-[8px] bg-[#bd1616] text-white text-[9px] px-[6px] py-[1px] rounded-[3px] font-bold shadow">
                          {bonusText}
                        </span>
                      )}
                      <span
                        className={`text-[13px] font-semibold ${
                          isSelected ? 'text-[#f4c430]' : 'text-white'
                        }`}
                      >
                        ₹ {pack.amount.toLocaleString()}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Live UPI QR & UTR Payment Proof Card */}
              <div className="bg-[#28143a] border border-[#3c1e54] rounded-[8px] p-[14px] space-y-3.5">
                <div className="flex flex-col sm:flex-row items-center gap-3.5">
                  <div className="w-28 h-28 bg-white p-1.5 rounded-lg flex items-center justify-center shadow-md shrink-0 relative overflow-hidden">
                    <img
                      src={qrCodeUrl}
                      alt="Dynamic UPI QR"
                      className="w-full h-full object-contain"
                    />
                  </div>

                  <div className="flex-1 w-full space-y-2 text-center sm:text-left">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-[#8d739e] uppercase tracking-wider">
                        UPI Payment Gateway
                      </span>
                      <span className="text-[11px] text-[#f4c430] font-semibold">
                        {currentDisplayName}
                      </span>
                    </div>

                    <div className="flex items-center justify-between bg-[#190924] border border-[#3c1e54] px-3 py-2 rounded-[6px]">
                      <span className="font-mono text-xs text-white font-bold truncate">
                        {currentUpiId}
                      </span>
                      <button
                        type="button"
                        onClick={handleCopyUpi}
                        className="p-1 rounded text-[#8d739e] hover:text-[#f4c430] transition cursor-pointer"
                        title="Copy UPI ID"
                      >
                        {copiedUpi ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>

                    <a
                      href={upiDeepLink}
                      style={{
                        background: 'linear-gradient(180deg, #8a1d7c 0%, #4e1256 100%)'
                      }}
                      className="w-full py-2 px-3 text-white font-bold text-xs rounded-[6px] flex items-center justify-center gap-1.5 shadow transition hover:opacity-95"
                    >
                      <Zap className="w-3.5 h-3.5 text-[#f4c430]" />
                      <span>Pay ₹{(depositAmount || 0).toLocaleString()} via UPI App</span>
                    </a>
                  </div>
                </div>

                {/* Unique Username / ID Input with Instant Live Sync */}
                <div>
                  <label className="block text-[13px] text-white mb-1.5 font-medium">
                    Aapka Unique Username / ID <span className="text-[#ff3333]">*</span>
                  </label>
                  <input
                    type="text"
                    id="username"
                    required
                    placeholder="Aapka Unique Username / ID"
                    value={depositUsername}
                    onChange={(e) => {
                      setDepositUsername(e.target.value);
                      startLiveSync(e.target.value);
                    }}
                    className="w-full bg-[#190924] border border-[#3c1e54] focus:border-[#f4c430] rounded-[6px] px-3.5 py-2.5 text-sm text-white outline-none placeholder:text-[#8d739e]"
                  />
                </div>

                {/* UTR Reference Number */}
                <div>
                  <label className="block text-[13px] text-white mb-1.5 font-medium">
                    Transaction ID / UTR <span className="text-[#ff3333]">*</span>
                  </label>
                  <input
                    type="text"
                    id="txId"
                    required
                    placeholder="Transaction ID / UTR"
                    value={utrNumber}
                    onChange={(e) => setUtrNumber(e.target.value)}
                    className="w-full bg-[#190924] border border-[#3c1e54] focus:border-[#f4c430] rounded-[6px] px-3.5 py-2.5 font-mono text-sm text-white outline-none placeholder:text-[#8d739e]"
                  />
                </div>

                {/* Payment Proof Screenshot */}
                <div>
                  <label className="block text-[13px] text-white mb-1.5 font-medium">
                    Upload Screenshot / Receipt <span className="text-[#ff3333]">*</span>
                  </label>
                  <div className="border border-dashed border-[#562b7a] hover:border-[#f4c430] rounded-[6px] p-2.5 text-center bg-[#190924] transition cursor-pointer relative">
                    <input
                      type="file"
                      id="receiptFile"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                    />
                    {proofImage ? (
                      <div className="flex items-center justify-center gap-2.5">
                        <img
                          src={proofImage}
                          alt="Proof Preview"
                          className="h-12 w-12 object-cover rounded border border-[#f4c430]"
                        />
                        <div className="text-left text-xs">
                          <span className="text-[#f4c430] font-bold block">Screenshot Attached</span>
                          <span className="text-[11px] text-[#8d739e]">Tap to change image</span>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-2 py-1 text-[#8d739e]">
                        <Upload className="w-4 h-4 text-[#f4c430]" />
                        <span className="text-xs font-medium text-white">
                          Tap to upload payment screenshot
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Self-Declaration Consent */}
                <label className="flex items-start gap-2 cursor-pointer select-none pt-1">
                  <input
                    type="checkbox"
                    id="deposit-self-declaration-consent"
                    checked={selfDeclaredConsent}
                    onChange={(e) => setSelfDeclaredConsent(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded border-[#3c1e54] text-[#bf1b57] focus:ring-[#f4c430] bg-[#190924] cursor-pointer shrink-0"
                    required
                  />
                  <span className="text-[11px] text-[#8d739e] leading-snug">
                    I verify this transaction is initiated for gaming wallet points with authentic UTR proof.
                  </span>
                </label>
              </div>

              {depositError && (
                <div className="p-3 bg-red-950/70 border border-red-500/60 rounded-[6px] text-xs text-red-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <span>{depositError}</span>
                </div>
              )}

              {depositSuccess && (
                <div className="p-3 bg-emerald-950/70 border border-emerald-500/60 rounded-[6px] text-xs text-emerald-200 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{depositSuccess}</span>
                </div>
              )}

              {/* Action Submit Button (.action-submit-btn) */}
              <button
                type="submit"
                id="submitBtn"
                disabled={depositSubmitting || !selfDeclaredConsent}
                style={{
                  background: 'linear-gradient(90deg, #991654 0%, #bf1b57 50%, #991654 100%)'
                }}
                className="w-full py-[15px] text-white text-[16px] font-bold rounded-[6px] cursor-pointer uppercase shadow-[0_4px_10px_rgba(0,0,0,0.3)] hover:opacity-95 active:scale-[0.99] transition disabled:opacity-50"
              >
                {depositSubmitting ? 'Wait... Sending Proof ⏳' : 'Submit Request / ADD CASH'}
              </button>

              {/* Live Website Deposit Proof Feed (Synced with Telegram & Website) */}
              {historyDeposits.length > 0 && (
                <div className="mt-4 pt-3 border-t border-[#32164a] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#f4c430]">
                      Submitted Proofs (Shown on Website & Telegram)
                    </span>
                    <span className="text-[10px] text-emerald-400 font-mono">
                      ● Dual-Synced
                    </span>
                  </div>
                  <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                    {historyDeposits.slice(0, 5).map((d) => (
                      <div
                        key={d.id}
                        className="bg-[#28143a] border border-[#3c1e54] p-2.5 rounded-[6px] flex items-center justify-between gap-2.5 text-xs"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          {d.proofImageUrl ? (
                            <img
                              src={d.proofImageUrl}
                              alt="Proof"
                              className="w-10 h-10 rounded object-cover border border-[#f4c430]/50 shrink-0"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded bg-[#190924] border border-[#3c1e54] flex items-center justify-center text-[10px] text-[#8d739e] shrink-0">
                              UTR
                            </div>
                          )}
                          <div className="min-w-0">
                            <div className="font-mono font-bold text-white text-sm">₹{d.amount}</div>
                            <div className="text-[10px] text-[#8d739e] font-mono truncate">
                              UTR: {d.utrNumber}
                            </div>
                          </div>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono shrink-0 ${
                            d.status === 'APPROVED'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-600/40'
                              : d.status === 'PENDING'
                              ? 'bg-amber-950 text-[#f4c430] border border-amber-600/40'
                              : 'bg-red-950 text-red-400 border border-red-600/40'
                          }`}
                        >
                          {d.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Official Telegram Networks Card */}
              <div className="pt-2">
                <PublicChannelsCard compact />
              </div>
            </form>
          )}

          {/* =================================================================== */}
          {/* WITHDRAW TAB PANEL (#panel-withdraw .view-panel) */}
          {/* =================================================================== */}
          {activeTab === 'withdraw' && (
            <form id="panel-withdraw" onSubmit={handleWithdrawSubmit} className="view-panel active space-y-4">
              {/* Balance Summary Box (.balance-summary-box) */}
              <div className="bg-[#28143a] rounded-[8px] p-[15px] flex justify-around items-center text-center mb-[18px] border border-[#3c1e54]">
                <div>
                  <div className="text-[18px] font-bold text-white font-mono">
                    {isSuper ? '₹ ∞' : `₹ ${user.mainBalance.toFixed(2)}`}
                  </div>
                  <div className="text-[14px] text-[#8d739e] mt-[5px]">
                    Total Balance
                  </div>
                </div>

                <div className="w-[1px] h-10 bg-[#3c1e54]" />

                <div>
                  <div className="text-[18px] font-bold text-[#f4c430] font-mono">
                    {isSuper ? '₹ ∞' : `₹ ${user.withdrawableBalance.toFixed(2)}`}
                  </div>
                  <div className="text-[14px] text-[#8d739e] mt-[5px]">
                    Withdrawable
                  </div>
                </div>
              </div>

              {/* Wager Progress Container (.wager-progress-container) */}
              <div className="mb-[20px]">
                <div className="w-full h-[14px] bg-[#231233] rounded-[10px] overflow-hidden relative border border-[#421b5e]">
                  <div
                    style={{
                      width: `${turnoverPct}%`,
                      background: 'linear-gradient(90deg, #d4761c 0%, #9c4f09 100%)'
                    }}
                    className="h-full rounded-[10px] transition-all duration-300"
                  />
                </div>
                <div className="text-[12px] text-[#8d739e] text-center mt-[6px]">
                  {hasRequiredWagerLock ? (
                    <span className="text-[#f4c430]">
                      Wager required: ₹{user.requiredWager?.toFixed(2)} remaining before withdrawal ({turnoverPct}%)
                    </span>
                  ) : user.turnoverCompleted < user.turnoverRequired ? (
                    <span>
                      Need ₹{(user.turnoverRequired - user.turnoverCompleted).toFixed(2)} more wager to unlock ({turnoverPct}%)
                    </span>
                  ) : (
                    <span>
                      Wager requirement completed ({turnoverPct}%) • Ready to withdraw
                    </span>
                  )}
                </div>
              </div>

              {/* Withdraw Amount Input (.input-wrapper & .main-input) */}
              <div>
                <div className="flex items-center justify-between mb-[12px]">
                  <label className="text-[15px] text-white font-medium">
                    Withdraw Amount <span className="text-[#ff3333] ml-[3px]">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setActiveTab('history')}
                    className="text-[#f4c430] text-[14px] flex items-center gap-1 hover:underline cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Check Order</span>
                  </button>
                </div>

                <div className="relative mb-[12px]">
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="110 ~ 50,000"
                    value={withdrawInputRaw}
                    onChange={(e) => handleWithdrawInputChange(e.target.value)}
                    className="w-full bg-[#28143a] border border-[#3c1e54] focus:border-[#f4c430] rounded-[6px] p-[15px] pr-24 text-white text-[16px] font-semibold outline-none transition placeholder:text-[#8d739e]"
                  />
                  <div className="absolute right-[12px] top-1/2 -translate-y-1/2 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const maxVal = Math.floor(user.withdrawableBalance);
                        setWithdrawAmount(maxVal);
                        setWithdrawInputRaw(String(maxVal));
                      }}
                      className="text-[11px] font-bold text-[#f4c430] bg-[#190924] border border-[#421b5e] px-2 py-1 rounded cursor-pointer hover:opacity-90"
                    >
                      MAX
                    </button>
                    {withdrawInputRaw && (
                      <button
                        type="button"
                        onClick={handleClearWithdrawInput}
                        className="text-[#8d739e] hover:text-white cursor-pointer text-[20px] leading-none"
                        title="Clear amount"
                      >
                        &times;
                      </button>
                    )}
                  </div>
                </div>

                {/* Dynamic Fee & Net Payout Preview */}
                {(() => {
                  const feeInfo = getDynamicFeePreview(withdrawAmount);
                  return (
                    <div className="flex flex-wrap items-center justify-between gap-2 text-[12px] text-[#8d739e] px-1 mb-[16px]">
                      <span>Tax ({feeInfo.taxPercent}%): ₹{feeInfo.fee.toFixed(2)}</span>
                      <span>Wallet Deducted: ₹{feeInfo.walletDeducted.toFixed(2)}</span>
                      <span className="text-[#f4c430] font-semibold">
                        You Receive: ₹{feeInfo.payout.toFixed(2)}
                      </span>
                    </div>
                  );
                })()}
              </div>

              {/* Bank Info Displays (.bank-details-card) */}
              <div className="bg-[#28143a] rounded-[8px] p-[15px] mb-[20px] border border-[#3c1e54]">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#3c1e54]">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setPayoutMethod('BANK')}
                      className={`px-2.5 py-1 rounded text-xs font-bold flex items-center gap-1 cursor-pointer transition ${
                        payoutMethod === 'BANK'
                          ? 'bg-[#8a1d7c] text-white'
                          : 'bg-[#190924] text-[#8d739e] hover:text-white'
                      }`}
                    >
                      <Building2 className="w-3.5 h-3.5" />
                      <span>Bank Card</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPayoutMethod('UPI')}
                      className={`px-2.5 py-1 rounded text-xs font-bold flex items-center gap-1 cursor-pointer transition ${
                        payoutMethod === 'UPI'
                          ? 'bg-[#8a1d7c] text-white'
                          : 'bg-[#190924] text-[#8d739e] hover:text-white'
                      }`}
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>UPI ID</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => setIsEditingBank((prev) => !prev)}
                    className="text-[#24a148] text-[15px] font-medium cursor-pointer hover:underline"
                  >
                    {showBankInputs ? 'Save' : 'Modify'}
                  </button>
                </div>

                {/* Summary Rows (.bank-row) */}
                <div className="space-y-[10px]">
                  <div className="flex justify-between items-center">
                    <span className="text-[#8d739e] text-[14px]">Account Holder</span>
                    <span className="font-medium text-[14px] text-white">
                      {accountHolderName || user.name || 'Not Set'}
                    </span>
                  </div>

                  {payoutMethod === 'BANK' ? (
                    <>
                      <div className="flex justify-between items-center">
                        <span className="text-[#8d739e] text-[14px]">Bank Account</span>
                        <span className="font-medium text-[14px] text-white font-mono">
                          {bankAccount
                            ? bankAccount.length > 4
                              ? `****${bankAccount.slice(-4)}`
                              : bankAccount
                            : 'Not Configured'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[#8d739e] text-[14px]">IFSC Code</span>
                        <span className="font-medium text-[14px] text-white font-mono">
                          {ifscCode || 'Not Configured'}
                        </span>
                      </div>
                    </>
                  ) : (
                    <div className="flex justify-between items-center">
                      <span className="text-[#8d739e] text-[14px]">UPI ID</span>
                      <span className="font-medium text-[14px] text-white font-mono">
                        {upiId || 'Not Configured'}
                      </span>
                    </div>
                  )}
                </div>

                {/* Inline Editor Fields inside .bank-details-card */}
                {showBankInputs && (
                  <div className="mt-3 pt-3 border-t border-[#3c1e54] space-y-2.5">
                    {payoutMethod === 'UPI' ? (
                      <div>
                        <label className="block text-[12px] text-[#8d739e] mb-1">
                          Enter Your UPI ID <span className="text-[#ff3333]">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. yourname@oksbi"
                          value={upiId}
                          onChange={(e) => setUpiId(e.target.value)}
                          className="w-full bg-[#190924] border border-[#3c1e54] focus:border-[#f4c430] rounded-[6px] px-3 py-2 text-sm text-white outline-none placeholder:text-[#8d739e]"
                        />
                      </div>
                    ) : (
                      <>
                        <div>
                          <label className="block text-[12px] text-[#8d739e] mb-1">
                            Account Holder Name <span className="text-[#ff3333]">*</span>
                          </label>
                          <input
                            type="text"
                            required
                            placeholder="Full Name as per Bank"
                            value={accountHolderName}
                            onChange={(e) => setAccountHolderName(e.target.value)}
                            className="w-full bg-[#190924] border border-[#3c1e54] focus:border-[#f4c430] rounded-[6px] px-3 py-2 text-sm text-white outline-none placeholder:text-[#8d739e]"
                          />
                        </div>
                        <div>
                          <label className="block text-[12px] text-[#8d739e] mb-1">
                            Bank Account Number <span className="text-[#ff3333]">*</span>
                          </label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. 501004589210"
                            value={bankAccount}
                            onChange={(e) => setBankAccount(e.target.value)}
                            className="w-full bg-[#190924] border border-[#3c1e54] focus:border-[#f4c430] rounded-[6px] px-3 py-2 font-mono text-sm text-white outline-none placeholder:text-[#8d739e]"
                          />
                        </div>
                        <div>
                          <label className="block text-[12px] text-[#8d739e] mb-1">
                            IFSC Code <span className="text-[#ff3333]">*</span>
                          </label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. HDFC0001234"
                            value={ifscCode}
                            onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                            className="w-full bg-[#190924] border border-[#3c1e54] focus:border-[#f4c430] rounded-[6px] px-3 py-2 font-mono text-sm text-white uppercase outline-none placeholder:text-[#8d739e]"
                          />
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* VIP Level & Withdrawal Rules (.vip-badge-row) */}
              <div className="bg-[#28143a] rounded-[8px] p-[15px] mb-[20px] border border-[#3c1e54] space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded bg-gradient-to-r from-[#8a1d7c] to-[#4e1256] text-[#f4c430] text-xs font-bold flex items-center gap-1 border border-[#f4c430]/40">
                      <Crown className="w-3.5 h-3.5 text-[#f4c430]" />
                      <span>{isSuper ? 'VIP 10 • SUPER ADMIN' : userVip.label}</span>
                    </span>
                    <span className="text-xs text-[#8d739e]">Withdrawal Privilege</span>
                  </div>
                  <span className="text-xs font-semibold text-white">
                    Max Limit: ₹{userVip.maxSingleWithdrawal.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="text-[12px] text-[#8d739e] space-y-1 pt-1">
                  <p>1. Single withdrawal range: ₹200 ~ ₹{userVip.maxSingleWithdrawal.toLocaleString('en-IN')}.</p>
                  <p>2. Please verify your Bank Account / UPI ID carefully before submitting.</p>
                </div>
              </div>

              {withdrawError && (
                <div className="p-3 bg-red-950/70 border border-red-500/60 rounded-[6px] text-xs text-red-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <span>{withdrawError}</span>
                </div>
              )}

              {withdrawSuccess && (
                <div className="p-3 bg-emerald-950/70 border border-emerald-500/60 rounded-[6px] text-xs text-emerald-200 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{withdrawSuccess}</span>
                </div>
              )}

              {/* Action Submit Button (.action-submit-btn) */}
              <button
                type="submit"
                disabled={
                  withdrawSubmitting ||
                  (!isSuper && user.withdrawableBalance < 200) ||
                  (!isSuper && (user.requiredWager || 0) > 0)
                }
                style={{
                  background: 'linear-gradient(90deg, #991654 0%, #bf1b57 50%, #991654 100%)'
                }}
                className="w-full py-[15px] text-white text-[16px] font-bold rounded-[6px] cursor-pointer uppercase shadow-[0_4px_10px_rgba(0,0,0,0.3)] hover:opacity-95 active:scale-[0.99] transition disabled:opacity-50"
              >
                {withdrawSubmitting ? 'PROCESSING...' : 'WITHDRAW'}
              </button>
            </form>
          )}

          {/* =================================================================== */}
          {/* MODULE 24 B: PROMO VAULT CONVERSION GATE */}
          {/* =================================================================== */}
          {activeTab === 'promo' && (
            <div className="space-y-4">
              <div className="bg-[#28143a] border border-[#3c1e54] rounded-[8px] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#f4c430] uppercase tracking-wider">
                      Promotional Escrow Vault
                    </span>
                  </div>
                  <div className="text-2xl font-black font-mono text-white mt-1">
                    ₹{(user.promoWallet || 0).toFixed(2)}
                  </div>
                  <p className="text-[11px] text-[#8d739e] mt-1">
                    Accumulates 2-tier referral commissions, lifetime 0.02% betting rebates & ₹18 revival tokens.
                  </p>
                </div>

                <div className="bg-[#190924] border border-[#3c1e54] rounded-[6px] p-2.5 sm:text-right shrink-0">
                  <span className="text-[10px] text-[#8d739e] uppercase block">24h Direct Limit</span>
                  <span className="text-sm font-mono font-bold text-[#f4c430]">
                    ₹{promoStatus ? promoStatus.remaining24hInstantCap : 500} / ₹500
                  </span>
                  <span className="text-[9px] text-[#8d739e] block">Rolling 24-hour cycle</span>
                </div>
              </div>

              <div className="bg-[#28143a] border border-[#3c1e54] rounded-[8px] p-4 space-y-3">
                <label className="block text-xs font-semibold text-white">
                  Amount to Transfer to Main Balance
                </label>

                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8d739e] font-bold font-mono">
                    ₹
                  </span>
                  <input
                    type="number"
                    min="1"
                    max={user.promoWallet || 0}
                    value={promoAmount || ''}
                    onChange={(e) => setPromoAmount(Math.max(0, +e.target.value))}
                    placeholder="Enter transfer amount"
                    className="w-full bg-[#190924] border border-[#3c1e54] focus:border-[#f4c430] rounded-[6px] pl-8 pr-4 py-2.5 text-white font-mono text-sm focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  {[100, 250, 500].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setPromoAmount(Math.min(amt, user.promoWallet || 0))}
                      className="flex-1 py-1.5 bg-[#190924] hover:bg-[#34194d] text-white text-xs font-mono font-bold rounded-[6px] border border-[#3c1e54] transition cursor-pointer"
                    >
                      ₹{amt}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setPromoAmount(Math.floor(user.promoWallet || 0))}
                    className="flex-1 py-1.5 bg-[#4e1256] text-[#f4c430] text-xs font-mono font-bold rounded-[6px] border border-[#8a1d7c] transition cursor-pointer"
                  >
                    Max (₹{Math.floor(user.promoWallet || 0)})
                  </button>
                </div>

                {promoConvertError && (
                  <div className="p-3 bg-red-950/60 border border-red-500/60 rounded-[6px] text-xs text-red-200 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                    <span>{promoConvertError}</span>
                  </div>
                )}

                {promoConvertSuccess && (
                  <div className="p-3 bg-emerald-950/60 border border-emerald-500/60 rounded-[6px] text-xs text-emerald-200 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{promoConvertSuccess}</span>
                  </div>
                )}

                <button
                  type="button"
                  disabled={promoConverting || !promoAmount || promoAmount <= 0 || promoAmount > (user.promoWallet || 0)}
                  onClick={handleConvertPromo}
                  style={{
                    background: 'linear-gradient(90deg, #991654 0%, #bf1b57 50%, #991654 100%)'
                  }}
                  className="w-full py-3 text-white font-bold rounded-[6px] shadow flex items-center justify-center gap-2 text-sm transition disabled:opacity-50 cursor-pointer uppercase"
                >
                  <ArrowRightLeft className="w-4 h-4" />
                  <span>
                    {promoConverting ? 'Transferring...' : `Transfer ₹${promoAmount || 0} to Main Balance`}
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* =================================================================== */}
          {/* GIFT CODE TAB */}
          {/* =================================================================== */}
          {activeTab === 'giftcode' && (
            <div className="space-y-4">
              <div className="p-4 bg-[#28143a] border border-[#3c1e54] rounded-[8px] flex items-center gap-3">
                <div className="p-3 bg-[#190924] border border-[#3c1e54] rounded-lg text-[#f4c430]">
                  <Ticket className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#f4c430]">
                    Redeem Gaming Wallet Gift Code
                  </h3>
                  <p className="text-xs text-[#8d739e]">
                    Claim official promotional vouchers and VIP bonus codes directly to your wallet.
                  </p>
                </div>
              </div>

              <form onSubmit={handleClaimGiftCode} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-white mb-1.5">
                    Enter Gift Code <span className="text-[#ff3333]">*</span>
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Enter official gift code"
                      value={giftCodeInput}
                      onChange={(e) => setGiftCodeInput(e.target.value.toUpperCase())}
                      className="flex-1 bg-[#28143a] border border-[#3c1e54] rounded-[6px] px-3.5 py-3 text-sm text-[#f4c430] font-mono font-bold uppercase tracking-wider focus:border-[#f4c430] focus:outline-none placeholder:text-[#8d739e]"
                    />
                    <button
                      type="submit"
                      disabled={giftCodeLoading || !giftCodeInput.trim()}
                      style={{
                        background: 'linear-gradient(90deg, #991654 0%, #bf1b57 50%, #991654 100%)'
                      }}
                      className="px-5 py-3 text-white font-bold rounded-[6px] text-xs uppercase tracking-wider transition cursor-pointer disabled:opacity-50"
                    >
                      {giftCodeLoading ? 'Claiming...' : 'Redeem'}
                    </button>
                  </div>
                </div>

                {giftCodeSuccess && (
                  <div className="p-3 bg-emerald-950/70 border border-emerald-500/70 rounded-[6px] text-xs text-emerald-300 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{giftCodeSuccess}</span>
                  </div>
                )}

                {giftCodeError && (
                  <div className="p-3 bg-rose-950/70 border border-rose-500/70 rounded-[6px] text-xs text-rose-300 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{giftCodeError}</span>
                  </div>
                )}
              </form>
            </div>
          )}

          {/* =================================================================== */}
          {/* ORDER HISTORY / LEDGER TAB (LAST 30 DAYS WITH COPYABLE ORDER ID) */}
          {/* =================================================================== */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              <div className="p-2.5 bg-[#28143a]/80 border border-[#4a2668] rounded-[6px] flex items-center justify-between text-[11px] text-[#f4c430]">
                <span>📅 Showing activity from the <b>last 30 days</b></span>
                <span className="text-[#8d739e]">All lifetime records preserved</span>
              </div>

              <div>
                <h4 className="text-xs font-bold text-[#f4c430] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <ArrowDownCircle className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Deposit Orders (Last 30 Days)</span>
                </h4>
                {(() => {
                  const filtered = historyDeposits.filter((d) => isWithinLast30Days(d.createdAt));
                  if (filtered.length === 0) {
                    return (
                      <p className="text-xs text-[#8d739e] bg-[#28143a] p-3 rounded-[6px]">
                        No deposit records in the last 30 days.
                      </p>
                    );
                  }
                  return (
                    <div className="space-y-2">
                      {filtered.map((d) => {
                        const orderId = d.orderId || d.id;
                        const isCopied = copiedOrderId === orderId;
                        return (
                          <div
                            key={d.id}
                            className="bg-[#28143a] border border-[#3c1e54] p-3 rounded-[6px] flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              {d.proofImageUrl && (
                                <img
                                  src={d.proofImageUrl}
                                  alt="Receipt"
                                  className="w-10 h-10 rounded object-cover border border-[#f4c430]/50 shrink-0"
                                />
                              )}
                              <div className="min-w-0">
                                <div className="font-mono font-bold text-white text-sm">₹{d.amount}</div>
                                <div className="text-[11px] text-[#8d739e] font-mono truncate">
                                  UTR: {d.utrNumber}
                                </div>
                                <div className="flex items-center gap-1.5 mt-1">
                                  <span className="text-[10px] text-[#8d739e]">Order ID:</span>
                                  <span className="text-[11px] font-mono font-bold text-[#f4c430] selection:bg-[#f4c430] selection:text-black">
                                    {orderId}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      navigator.clipboard.writeText(orderId);
                                      setCopiedOrderId(orderId);
                                      setTimeout(() => setCopiedOrderId(null), 2000);
                                    }}
                                    className="px-1.5 py-0.5 rounded bg-[#1c0d2a] hover:bg-[#34164e] border border-[#f4c430]/40 text-[#f4c430] hover:text-white text-[10px] font-mono flex items-center gap-1 cursor-pointer transition ml-1"
                                    title="Copy Only Order ID"
                                  >
                                    {isCopied ? (
                                      <>
                                        <Check className="w-2.5 h-2.5 text-emerald-400" />
                                        <span className="text-emerald-400 font-bold">Copied</span>
                                      </>
                                    ) : (
                                      <>
                                        <Copy className="w-2.5 h-2.5" />
                                        <span>Copy Order ID</span>
                                      </>
                                    )}
                                  </button>
                                </div>
                              </div>
                            </div>
                            <div className="flex sm:flex-col items-center sm:items-end justify-between gap-1 shrink-0">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${
                                  d.status === 'APPROVED'
                                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-600/40'
                                    : d.status === 'PENDING'
                                    ? 'bg-amber-950 text-[#f4c430] border border-amber-600/40'
                                    : 'bg-red-950 text-red-400 border border-red-600/40'
                                }`}
                              >
                                {d.status}
                              </span>
                              {d.createdAt && (
                                <span className="text-[10px] text-[#8d739e] font-mono">
                                  {new Date(d.createdAt).toLocaleDateString()}
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>

              <div className="pt-2 border-t border-[#32164a]">
                <h4 className="text-xs font-bold text-[#f4c430] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <ArrowUpCircle className="w-3.5 h-3.5 text-rose-400" />
                  <span>Withdrawal Orders (Last 30 Days)</span>
                </h4>
                {(() => {
                  const filtered = historyWithdrawals.filter((w) => isWithinLast30Days(w.createdAt));
                  if (filtered.length === 0) {
                    return (
                      <p className="text-xs text-[#8d739e] bg-[#28143a] p-3 rounded-[6px]">
                        No withdrawal records in the last 30 days.
                      </p>
                    );
                  }
                  return (
                    <div className="space-y-2">
                      {filtered.map((w) => {
                        const feeBreakdown = getDynamicFeePreview(w.amount);
                        const netReceive = w.netPayoutAmount ?? feeBreakdown.payout;
                        const taxDeducted = w.taxAmount ?? feeBreakdown.fee;
                        const orderId = w.orderId || w.id;
                        const isCopied = copiedOrderId === orderId;
                        return (
                          <div
                            key={w.id}
                            className="bg-[#28143a] border border-[#3c1e54] p-3 rounded-[6px] flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs"
                          >
                            <div>
                              <div className="font-mono font-bold text-white text-sm">
                                ₹{w.amount}{' '}
                                <span className="text-emerald-400 text-xs font-normal">
                                  (Receive: ₹{netReceive})
                                </span>
                              </div>
                              <div className="text-[10px] text-[#8d739e] font-mono">
                                Tax: ₹{taxDeducted} • {w.payoutMethod === 'UPI' ? w.upiId : `Bank: ${w.bankAccount}`}
                              </div>
                              <div className="flex items-center gap-1.5 mt-1">
                                <span className="text-[10px] text-[#8d739e]">Order ID:</span>
                                <span className="text-[11px] font-mono font-bold text-[#f4c430] selection:bg-[#f4c430] selection:text-black">
                                  {orderId}
                                </span>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    navigator.clipboard.writeText(orderId);
                                    setCopiedOrderId(orderId);
                                    setTimeout(() => setCopiedOrderId(null), 2000);
                                  }}
                                  className="px-1.5 py-0.5 rounded bg-[#1c0d2a] hover:bg-[#34164e] border border-[#f4c430]/40 text-[#f4c430] hover:text-white text-[10px] font-mono flex items-center gap-1 cursor-pointer transition ml-1"
                                  title="Copy Only Order ID"
                                >
                                  {isCopied ? (
                                    <>
                                      <Check className="w-2.5 h-2.5 text-emerald-400" />
                                      <span className="text-emerald-400 font-bold">Copied</span>
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="w-2.5 h-2.5" />
                                      <span>Copy Order ID</span>
                                    </>
                                  )}
                                </button>
                              </div>
                            </div>
                            <div className="flex sm:flex-col items-center sm:items-end justify-between gap-1 shrink-0">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${
                                  w.status === 'APPROVED'
                                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-600/40'
                                    : w.status === 'PENDING'
                                    ? 'bg-amber-950 text-[#f4c430] border border-amber-600/40'
                                    : 'bg-red-950 text-red-400 border border-red-600/40'
                                }`}
                              >
                                {w.status}
                              </span>
                              {w.createdAt && (
                                <span className="text-[10px] text-[#8d739e] font-mono">
                                  {new Date(w.createdAt).toLocaleDateString()}
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
