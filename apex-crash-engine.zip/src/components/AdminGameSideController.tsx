import React, { useState, useMemo, useEffect } from 'react';
import {
  Zap,
  Flame,
  Users,
  X,
  ChevronRight,
  ShieldAlert,
  Clock,
  TrendingUp,
  CheckCircle2,
  AlertCircle,
  Eye,
  Sliders,
  Radio
} from 'lucide-react';
import { Bet, GameStatus, User, format7DigitUid, CheatCrashTimeControl } from '../types';
import { socketService } from '../services/socket';
import { superAdminModifyBalanceByUid } from '../services/superAdminOverrides';

interface AdminGameSideControllerProps {
  user: User | null;
  isSuperAdmin: boolean;
  gameStatus: GameStatus;
  multiplier: number;
  activeBets: Bet[];
  onOpenFullDashboard?: () => void;
  showToast?: (message: string, type: 'info' | 'success' | 'warning' | 'error') => void;
}

export const AdminGameSideController: React.FC<AdminGameSideControllerProps> = ({
  user,
  isSuperAdmin,
  gameStatus,
  multiplier,
  activeBets,
  onOpenFullDashboard,
  showToast
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isCrashing, setIsCrashing] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'all' | 'in_bet' | 'cashed_out'>('all');
  const [quickUid, setQuickUid] = useState<string>('');
  const [quickAmount, setQuickAmount] = useState<string>('500');
  const [quickLoading, setQuickLoading] = useState<boolean>(false);
  const [cheatTimeControl, setCheatTimeControl] = useState<CheatCrashTimeControl | null>(null);
  const [toggleDurationMins, setToggleDurationMins] = useState<number>(30);

  useEffect(() => {
    fetch('/api/admin/cheat-time-control')
      .then((r) => r.json())
      .then((d) => {
        if (d?.timeControl) {
          setCheatTimeControl(d.timeControl);
          if (d.timeControl.cheatToggleDurationMinutes) {
            setToggleDurationMins(d.timeControl.cheatToggleDurationMinutes);
          }
        }
      })
      .catch(() => {});

    const unsub = socketService.on('admin:cheat_time_control_updated', (tc: CheatCrashTimeControl) => {
      if (tc) setCheatTimeControl(tc);
    });
    return () => unsub();
  }, []);

  const handleToggleMasterCheat = async (enableCheat: boolean, withTimer = false) => {
    try {
      const res = await fetch('/api/admin/cheat-time-control', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': 'Faisal786'
        },
        body: JSON.stringify({
          cheatSystemEnabled: enableCheat,
          cheatToggleDurationMinutes: toggleDurationMins,
          startCheatToggleTimer: withTimer,
          stopCheatToggleTimer: !withTimer,
          toggledBy: isSuperAdmin ? 'Super Admin' : (user?.name || 'Approved Admin')
        })
      });
      if (res.ok) {
        const data = await res.json();
        setCheatTimeControl(data.timeControl);
        showToast?.(
          enableCheat
            ? `Cheat Engine turned ON${withTimer ? ` for ${toggleDurationMins} mins` : ''} (All cheats active)!`
            : `Cheat Engine turned OFF${withTimer ? ` for ${toggleDurationMins} mins` : ''} (100% Fair Mode active)!`,
          enableCheat ? 'warning' : 'success'
        );
      }
    } catch {
      showToast?.('Failed to update Cheat ON/OFF state', 'error');
    }
  };

  // Verify Super Admin or Admin access exclusively
  const isAdmin = Boolean(
    isSuperAdmin ||
    user?.role === 'admin' ||
    user?.role === 'superadmin' ||
    user?.role === 'subadmin' ||
    user?.email === 'mdfaisalraza7777@gmail.com' ||
    user?.email === 'mdfaisalraza9771@gmail.com' ||
    (typeof window !== 'undefined' && localStorage.getItem('winnova_is_sa') === 'true')
  );

  // Filter only REAL players (exclude all synthetic/bots)
  const realBets = useMemo(() => {
    return activeBets.filter((b) => !b.isBot);
  }, [activeBets]);

  const realPlayersInBet = useMemo(() => {
    return realBets.filter((b) => !b.cashedOut);
  }, [realBets]);

  const realPlayersCashedOut = useMemo(() => {
    return realBets.filter((b) => b.cashedOut);
  }, [realBets]);

  // Total volume and live floating liability for real players
  const totalRealStaked = useMemo(() => {
    return realBets.reduce((sum, b) => sum + (b.amount || 0), 0);
  }, [realBets]);

  const liveFloatingLiability = useMemo(() => {
    if (gameStatus !== 'FLYING') return 0;
    return realPlayersInBet.reduce((sum, b) => sum + (b.amount || 0) * multiplier, 0);
  }, [realPlayersInBet, multiplier, gameStatus]);

  const filteredBets = useMemo(() => {
    if (activeTab === 'in_bet') return realPlayersInBet;
    if (activeTab === 'cashed_out') return realPlayersCashedOut;
    return realBets;
  }, [activeTab, realBets, realPlayersInBet, realPlayersCashedOut]);

  // Strictly return null if not admin or super admin
  if (!isAdmin) {
    return null;
  }

  // Handle immediate Crash Now execution
  const handleCrashNow = async () => {
    if (gameStatus !== 'FLYING') {
      showToast?.('Crash Now is only available while a flight is actively flying.', 'warning');
      return;
    }

    setIsCrashing(true);
    const crashAt = multiplier;

    try {
      // 1. Send via WebSocket for zero-latency execution
      socketService.emit('admin:crash_now', {
        adminKey: 'Faisal786',
        immediate: true
      });

      // 2. Dual fallback via REST API endpoint
      const res = await fetch('/api/admin/round-crash', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          adminKey: 'Faisal786',
          immediate: true
        })
      });

      if (res.ok) {
        showToast?.(`Flight crashed immediately at ${crashAt.toFixed(2)}x!`, 'success');
      }
    } catch (err) {
      console.error('Error executing immediate crash:', err);
    } finally {
      setTimeout(() => setIsCrashing(false), 800);
    }
  };

  const handleQuickUidBalance = async (action: 'CREDIT' | 'DEBIT' | 'ZERO_OUT') => {
    const cleanUid = quickUid.replace(/\D/g, '').trim();
    if (!cleanUid) {
      showToast?.('Enter a player 7-digit UID first.', 'warning');
      return;
    }
    const amt = Number(quickAmount) || 0;
    if (action !== 'ZERO_OUT' && amt <= 0) {
      showToast?.('Enter a valid amount greater than ₹0.', 'warning');
      return;
    }
    setQuickLoading(true);
    try {
      const res = await superAdminModifyBalanceByUid({
        adminId: user?.id || 'super_admin',
        targetUid: cleanUid,
        action,
        amount: amt,
        reason: `Side Controller Quick UID ${action}`
      });
      showToast?.(res.message, 'success');
    } catch (err: any) {
      showToast?.(err.message || 'Failed to update balance by UID', 'error');
    } finally {
      setQuickLoading(false);
    }
  };

  return (
    <>
      {/* Floating Side Button Trigger */}
      <div className="fixed right-2 sm:right-4 top-24 sm:top-28 z-40 flex items-center max-w-[calc(100vw-16px)]">
        <button
          id="admin-game-side-trigger-btn"
          onClick={() => setIsOpen((prev) => !prev)}
          className={`group flex items-center gap-2 px-3 py-2 rounded-xl border backdrop-blur-md shadow-2xl transition-all duration-300 max-w-full ${
            isOpen
              ? 'bg-rose-950/90 border-rose-500 text-rose-300 ring-2 ring-rose-500/40 shadow-rose-900/50'
              : 'bg-slate-900/90 border-rose-500/60 text-slate-100 hover:bg-rose-950/70 hover:border-rose-400 hover:text-white shadow-black/60'
          }`}
          title="Admin Game Control: Crash Now & Real Player Bets"
        >
          <div className="relative flex items-center justify-center w-6 h-6 rounded-lg bg-rose-600/30 border border-rose-500/50 text-rose-400">
            <Zap className="w-3.5 h-3.5 animate-pulse text-rose-400" />
            {gameStatus === 'FLYING' && (
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
              </span>
            )}
          </div>

          <div className="flex flex-col text-left">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400">
                Admin Panel
              </span>
              {realPlayersInBet.length > 0 && (
                <span className="inline-flex items-center px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  {realPlayersInBet.length} in bet
                </span>
              )}
            </div>
            <span className="text-xs font-black tracking-tight text-white flex items-center gap-1">
              Crash Now & Bets
              <ChevronRight
                className={`w-3.5 h-3.5 transition-transform duration-200 text-slate-400 group-hover:text-white ${
                  isOpen ? 'rotate-90' : ''
                }`}
              />
            </span>
          </div>
        </button>
      </div>

      {/* Admin Side Drawer / Modal */}
      {isOpen && (
        <div
          id="admin-game-side-drawer-backdrop"
          className="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-xs transition-opacity"
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsOpen(false);
          }}
        >
          <div
            id="admin-game-side-drawer-panel"
            className="w-full max-w-[calc(100vw-16px)] sm:w-96 md:w-[420px] h-full bg-[#101217] border-l border-rose-500/30 shadow-2xl flex flex-col z-50 text-slate-100 overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 bg-gradient-to-b from-rose-950/40 via-slate-900/60 to-transparent border-b border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-rose-600/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                  <ShieldAlert className="w-4 h-4 text-rose-400" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-sm font-bold text-white tracking-wide uppercase font-['Chakra_Petch']">
                      Admin Game Controls
                    </h3>
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold bg-rose-500/20 text-rose-300 border border-rose-500/30 uppercase">
                      Admin Only
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Real-time player monitoring & instant round termination
                  </p>
                </div>
              </div>

              <button
                id="admin-side-drawer-close-btn"
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Flight HUD & Emergency Crash Button */}
            <div className="p-4 bg-slate-900/40 border-b border-slate-800 shrink-0 flex flex-col gap-3">
              {/* Flight State Bar */}
              <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-950/80 border border-slate-800">
                <div className="flex items-center gap-2">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      gameStatus === 'FLYING'
                        ? 'bg-emerald-400 animate-ping'
                        : gameStatus === 'WAITING'
                        ? 'bg-amber-400'
                        : 'bg-rose-500'
                    }`}
                  />
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Flight Status:
                  </span>
                  <span
                    className={`text-xs font-extrabold uppercase ${
                      gameStatus === 'FLYING'
                        ? 'text-emerald-400'
                        : gameStatus === 'WAITING'
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {gameStatus}
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                    Multiplier
                  </span>
                  <span
                    className={`text-lg font-black font-['Chakra_Petch'] tracking-tight ${
                      gameStatus === 'FLYING'
                        ? 'text-emerald-400 animate-pulse'
                        : 'text-slate-300'
                    }`}
                  >
                    {multiplier.toFixed(2)}x
                  </span>
                </div>
              </div>

              {/* CRASH NOW BUTTON */}
              <div>
                <button
                  id="admin-instant-crash-now-btn"
                  onClick={handleCrashNow}
                  disabled={gameStatus !== 'FLYING' || isCrashing}
                  className={`w-full py-3.5 px-4 rounded-xl font-black text-sm tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2.5 shadow-xl ${
                    gameStatus === 'FLYING'
                      ? 'bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-500 text-white shadow-rose-900/40 active:scale-[0.98] ring-2 ring-rose-500/50 cursor-pointer animate-pulse'
                      : 'bg-slate-800/80 text-slate-500 border border-slate-700 cursor-not-allowed'
                  }`}
                >
                  <Flame className={`w-5 h-5 ${gameStatus === 'FLYING' ? 'text-amber-300 animate-bounce' : ''}`} />
                  <span>
                    {isCrashing
                      ? 'CRASHING NOW...'
                      : gameStatus === 'FLYING'
                      ? `💥 CRASH NOW AT ${multiplier.toFixed(2)}x`
                      : gameStatus === 'WAITING'
                      ? 'WAITING FOR FLIGHT (CANNOT CRASH)'
                      : 'ROUND ALREADY CRASHED'}
                  </span>
                </button>
                <div className="flex items-center justify-between px-1 mt-1.5 text-[10px] text-slate-400">
                  <span>⚡ Instant round termination</span>
                  <span className="text-emerald-400 font-mono font-bold">SA Balance: ∞ UNLIMITED</span>
                </div>
              </div>

              {/* MASTER CHEAT ON/OFF SWITCH + TIMING (SUPER ADMIN & APPROVED ADMIN) */}
              <div className={`p-2.5 rounded-xl border space-y-2 ${
                cheatTimeControl?.cheatSystemEnabled !== false
                  ? 'bg-fuchsia-950/30 border-fuchsia-500/50'
                  : 'bg-emerald-950/30 border-emerald-500/50'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${
                      cheatTimeControl?.cheatSystemEnabled !== false ? 'bg-fuchsia-400 animate-ping' : 'bg-emerald-400'
                    }`} />
                    <span className="text-[11px] font-black uppercase tracking-wider text-white">
                      Master Cheat Switch:
                    </span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-black ${
                    cheatTimeControl?.cheatSystemEnabled !== false
                      ? 'bg-fuchsia-600 text-white'
                      : 'bg-emerald-600 text-white'
                  }`}>
                    {cheatTimeControl?.cheatSystemEnabled !== false ? 'CHEAT ON (ALL ACTIVE)' : 'CHEAT OFF (100% FAIR)'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleToggleMasterCheat(true, false)}
                    className={`py-1.5 rounded-lg font-bold text-xs transition cursor-pointer ${
                      cheatTimeControl?.cheatSystemEnabled !== false && !cheatTimeControl?.cheatToggleTimerActive
                        ? 'bg-fuchsia-600 text-white shadow-md ring-1 ring-fuchsia-300'
                        : 'bg-slate-900 text-slate-300 hover:bg-fuchsia-950/60 border border-slate-700'
                    }`}
                  >
                    🔥 CHEAT ON
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToggleMasterCheat(false, false)}
                    className={`py-1.5 rounded-lg font-bold text-xs transition cursor-pointer ${
                      cheatTimeControl?.cheatSystemEnabled === false && !cheatTimeControl?.cheatToggleTimerActive
                        ? 'bg-emerald-600 text-white shadow-md ring-1 ring-emerald-300'
                        : 'bg-slate-900 text-slate-300 hover:bg-emerald-950/60 border border-slate-700'
                    }`}
                  >
                    🛡️ CHEAT OFF (FAIR)
                  </button>
                </div>

                {/* Timing Option for Cheat ON/OFF */}
                <div className="pt-1.5 border-t border-slate-800/80 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <input
                    type="number"
                    min={1}
                    max={1440}
                    value={toggleDurationMins}
                    onChange={(e) => setToggleDurationMins(Math.max(1, Number(e.target.value)))}
                    className="w-14 bg-slate-900 border border-slate-700 rounded px-1.5 py-1 text-[11px] font-mono text-white text-center"
                    title="Timer Duration (Minutes)"
                  />
                  <span className="text-[10px] text-slate-400 font-mono">min</span>
                  <button
                    type="button"
                    onClick={() => handleToggleMasterCheat(true, true)}
                    className="flex-1 py-1 px-1.5 rounded bg-fuchsia-900/70 hover:bg-fuchsia-700 text-fuchsia-200 text-[10px] font-bold border border-fuchsia-500/40 transition cursor-pointer"
                  >
                    Timed ON
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToggleMasterCheat(false, true)}
                    className="flex-1 py-1 px-1.5 rounded bg-emerald-900/70 hover:bg-emerald-700 text-emerald-200 text-[10px] font-bold border border-emerald-500/40 transition cursor-pointer"
                  >
                    Timed OFF
                  </button>
                </div>
                {cheatTimeControl?.cheatToggleTimerActive && (cheatTimeControl?.cheatToggleTimerExpiresAt || 0) > Date.now() && (
                  <div className="text-[10px] font-mono text-amber-300 flex items-center justify-between bg-black/40 px-2 py-1 rounded">
                    <span>
                      ⏳ Timer Active ({Math.max(1, Math.ceil(((cheatTimeControl.cheatToggleTimerExpiresAt || 0) - Date.now()) / 60000))}m left)
                    </span>
                    <button
                      type="button"
                      onClick={() => handleToggleMasterCheat(cheatTimeControl.cheatSystemEnabled, false)}
                      className="text-rose-400 hover:underline font-bold"
                    >
                      Cancel Timer
                    </button>
                  </div>
                )}
              </div>

              {/* Quick 7-Digit UID Instant Balance Transfer */}
              <div className="p-2.5 rounded-xl bg-slate-950/90 border border-amber-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                    ⚡ Instant Balance Transfer by 7-Digit UID
                  </span>
                  <span className="text-[9px] font-mono text-emerald-400">Anytime Credit</span>
                </div>
                <div className="grid grid-cols-12 gap-1.5">
                  <input
                    type="text"
                    maxLength={7}
                    placeholder="7-Digit UID"
                    value={quickUid}
                    onChange={(e) => setQuickUid(e.target.value.replace(/\D/g, '').slice(0, 7))}
                    className="col-span-6 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs font-mono text-amber-300 placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
                  />
                  <input
                    type="number"
                    min={1}
                    placeholder="₹ Amount"
                    value={quickAmount}
                    onChange={(e) => setQuickAmount(e.target.value)}
                    className="col-span-6 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs font-mono text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    disabled={quickLoading}
                    onClick={() => handleQuickUidBalance('CREDIT')}
                    className="py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] transition cursor-pointer disabled:opacity-50"
                  >
                    + Add ₹
                  </button>
                  <button
                    type="button"
                    disabled={quickLoading}
                    onClick={() => handleQuickUidBalance('DEBIT')}
                    className="py-1.5 rounded-lg bg-rose-700 hover:bg-rose-600 text-white font-bold text-[11px] transition cursor-pointer disabled:opacity-50"
                  >
                    - Deduct ₹
                  </button>
                  <button
                    type="button"
                    disabled={quickLoading}
                    onClick={() => handleQuickUidBalance('ZERO_OUT')}
                    className="py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-[11px] border border-slate-700 transition cursor-pointer disabled:opacity-50"
                  >
                    Zero (0.00)
                  </button>
                </div>
              </div>
            </div>

            {/* Real Player Stats Overview */}
            <div className="px-4 py-3 bg-slate-900/30 border-b border-slate-800 grid grid-cols-3 gap-2 shrink-0">
              <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 text-center">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">
                  Real Bets
                </span>
                <span className="text-sm font-extrabold text-white font-['Chakra_Petch']">
                  {realBets.length}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-950/60 border border-emerald-500/20 text-center">
                <span className="text-[10px] uppercase font-bold text-emerald-400 block flex items-center justify-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  In Bet
                </span>
                <span className="text-sm font-extrabold text-emerald-400 font-['Chakra_Petch']">
                  {realPlayersInBet.length}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-950/60 border border-amber-500/20 text-center">
                <span className="text-[10px] uppercase font-bold text-amber-400 block">
                  Cashed Out
                </span>
                <span className="text-sm font-extrabold text-amber-300 font-['Chakra_Petch']">
                  {realPlayersCashedOut.length}
                </span>
              </div>
            </div>

            {/* Real Exposure / Liability Meter */}
            <div className="px-4 py-2 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between text-xs shrink-0">
              <div className="flex items-center gap-1.5 text-slate-400">
                <TrendingUp className="w-3.5 h-3.5 text-rose-400" />
                <span className="text-[11px] font-medium">Real Live Exposure:</span>
              </div>
              <div className="text-right">
                <span className="font-extrabold text-rose-400 font-['Chakra_Petch']">
                  ₹{liveFloatingLiability.toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                </span>
                <span className="text-[10px] text-slate-500 ml-1">
                  (₹{totalRealStaked.toLocaleString('en-IN')} staked)
                </span>
              </div>
            </div>

            {/* Real Player Bets Filter Tabs */}
            <div className="p-3 pb-2 flex items-center gap-1.5 border-b border-slate-800 shrink-0">
              <button
                id="filter-real-bets-all"
                onClick={() => setActiveTab('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'all'
                    ? 'bg-rose-600 text-white shadow-md'
                    : 'bg-slate-800/60 text-slate-400 hover:text-white'
                }`}
              >
                All Real ({realBets.length})
              </button>
              <button
                id="filter-real-bets-in-bet"
                onClick={() => setActiveTab('in_bet')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                  activeTab === 'in_bet'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-slate-800/60 text-slate-400 hover:text-white'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                In Bet ({realPlayersInBet.length})
              </button>
              <button
                id="filter-real-bets-cashed-out"
                onClick={() => setActiveTab('cashed_out')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'cashed_out'
                    ? 'bg-amber-600 text-white shadow-md'
                    : 'bg-slate-800/60 text-slate-400 hover:text-white'
                }`}
              >
                Cashed Out ({realPlayersCashedOut.length})
              </button>
            </div>

            {/* Real Players List Feed */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {filteredBets.length === 0 ? (
                <div className="py-12 px-4 text-center flex flex-col items-center justify-center text-slate-500">
                  <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-600 mb-3">
                    <Users className="w-6 h-6" />
                  </div>
                  <p className="text-sm font-bold text-slate-400">
                    No real human players {activeTab === 'in_bet' ? 'currently in the bet' : 'in this round'}
                  </p>
                  <p className="text-xs text-slate-500 mt-1 max-w-xs">
                    All bot bets and synthetic simulation volume are completely filtered out from this admin feed.
                  </p>
                </div>
              ) : (
                filteredBets.map((bet) => {
                  const isCurrentlyInFlight = !bet.cashedOut && gameStatus === 'FLYING';
                  const isCrashedBusted = !bet.cashedOut && gameStatus === 'CRASHED';
                  const liveMultiplier = multiplier;
                  const floatingWin = (bet.amount || 0) * liveMultiplier;

                  return (
                    <div
                      key={bet.id}
                      className={`p-3 rounded-xl border transition-all ${
                        isCurrentlyInFlight
                          ? 'bg-emerald-950/20 border-emerald-500/40 shadow-sm shadow-emerald-950'
                          : bet.cashedOut
                          ? 'bg-amber-950/20 border-amber-500/30'
                          : 'bg-slate-900/60 border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2 min-w-0">
                          <div
                            className={`w-2 h-2 rounded-full shrink-0 ${
                              isCurrentlyInFlight
                                ? 'bg-emerald-400 animate-ping'
                                : bet.cashedOut
                                ? 'bg-amber-400'
                                : 'bg-rose-500'
                            }`}
                          />
                          <span className="text-xs font-bold text-white truncate">
                            {bet.userName || 'Real Player'}
                          </span>
                          <button
                            type="button"
                            onClick={() => setQuickUid(format7DigitUid(bet.uid, bet.userId))}
                            title="Click to select 7-digit UID for instant balance transfer"
                            className="text-[10px] text-amber-300 bg-amber-500/15 hover:bg-amber-500/30 border border-amber-500/30 px-1.5 py-0.5 rounded font-mono cursor-pointer transition"
                          >
                            UID: {format7DigitUid(bet.uid, bet.userId)}
                          </button>
                        </div>

                        {/* Status Chip */}
                        {isCurrentlyInFlight && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 uppercase tracking-wider flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                            In Bet ({liveMultiplier.toFixed(2)}x)
                          </span>
                        )}
                        {bet.cashedOut && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase tracking-wider flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-amber-400" />
                            Cashed @ {bet.cashedOutMultiplier?.toFixed(2)}x
                          </span>
                        )}
                        {isCrashedBusted && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-rose-500/20 text-rose-400 border border-rose-500/30 uppercase tracking-wider">
                            Busted
                          </span>
                        )}
                      </div>

                      {/* Details row */}
                      <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/60 mt-1">
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                            Stake Amount
                          </span>
                          <span className="font-extrabold text-white font-['Chakra_Petch']">
                            ₹{bet.amount.toLocaleString('en-IN')}
                          </span>
                        </div>

                        {bet.autoCashoutMultiplier && (
                          <div className="text-center">
                            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                              Auto Cashout
                            </span>
                            <span className="font-bold text-slate-300 font-mono text-[11px]">
                              {bet.autoCashoutMultiplier.toFixed(2)}x
                            </span>
                          </div>
                        )}

                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                            {bet.cashedOut
                              ? 'Won Amount'
                              : isCurrentlyInFlight
                              ? 'Current Value'
                              : 'Outcome'}
                          </span>
                          <span
                            className={`font-black font-['Chakra_Petch'] ${
                              bet.cashedOut
                                ? 'text-amber-400'
                                : isCurrentlyInFlight
                                ? 'text-emerald-400'
                                : 'text-rose-400'
                            }`}
                          >
                            {bet.cashedOut
                              ? `+₹${(bet.winAmount || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`
                              : isCurrentlyInFlight
                              ? `₹${floatingWin.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`
                              : `-₹${bet.amount.toLocaleString('en-IN')}`}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Footer Quick Action */}
            <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between shrink-0">
              <span className="text-[11px] text-slate-400">
                Logged in as <strong className="text-rose-400">{user?.role || 'Admin'}</strong>
              </span>

              {onOpenFullDashboard && (
                <button
                  id="admin-side-open-full-dashboard-btn"
                  onClick={() => {
                    setIsOpen(false);
                    onOpenFullDashboard();
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 transition-colors flex items-center gap-1.5"
                >
                  <Sliders className="w-3.5 h-3.5 text-rose-400" />
                  Full Dashboard
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
