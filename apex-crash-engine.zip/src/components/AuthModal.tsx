import React, { useState } from 'react';
import { User } from '../types';
import { getDeviceFingerprint } from '../services/fingerprint';
import { loginWithGoogle } from '../firebase';
import { referralService } from '../services/referral';
import { ShieldAlert, Gift, Key, Phone, User as UserIcon, Mail, ArrowRight, Lock, Zap, X, Sparkles } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onLoginSuccess: (user: User, token: string, isSuperAdmin?: boolean) => void;
  onRegisteredSuccess: (user: User, welcomeBonus: number) => void;
  onClose?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onLoginSuccess,
  onRegisteredSuccess,
  onClose
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [referralCode, setReferralCode] = useState(() => referralService.getStoredReferralCode() || '');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setError(null);
    setLoading(true);
    try {
      const fbUser = await loginWithGoogle();
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: fbUser.uid,
          email: fbUser.email,
          displayName: fbUser.displayName,
          photoURL: fbUser.photoURL
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Google authentication failed');
      onLoginSuccess(data.user, data.token, data.isSuperAdmin);
    } catch (err: any) {
      if (err.code !== 'auth/popup-closed-by-user') {
        setError(err.message || 'Google Sign-in failed');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemoLogin = async () => {
    setError(null);
    const trimmedName = name.trim();
    if (!trimmedName || trimmedName.length < 2) {
      setError('Player Name is compulsory! Please enter your Player Name first (you can edit it later in Profile).');
      const el = document.getElementById('auth-player-name-input');
      if (el) el.focus();
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/demo-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: trimmedName })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Demo login failed');
      }
      onLoginSuccess(data.user, data.token, false);
    } catch (err: any) {
      setError(err.message || 'Demo login failed');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const handleDemoLogin = async () => {
    await handleQuickDemoLogin();
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedIdentifier = identifier.trim();
    const trimmedName = name.trim();
    const isSuperAdminEmail = trimmedIdentifier.toLowerCase() === 'sandeepb96480@gmail.com';

    if (!isSuperAdminEmail && (!trimmedName || trimmedName.length < 2)) {
      setError('Player Name is compulsory during login! Please enter your Player Name (you can edit it anytime later).');
      const el = document.getElementById('auth-player-name-input');
      if (el) el.focus();
      return;
    }

    setLoading(true);

    try {
      const fingerprint = getDeviceFingerprint();
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: trimmedName || undefined,
          identifier: trimmedIdentifier,
          password: password.trim(),
          deviceFingerprint: fingerprint
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Login failed');
      }

      onLoginSuccess(data.user, data.token, data.isSuperAdmin);
    } catch (err: any) {
      setError(err.message || 'An error occurred during login');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const fingerprint = getDeviceFingerprint();
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          phone: phone.trim(),
          email: email.trim() || undefined,
          password: password.trim(),
          referralCode: referralCode.trim() || undefined,
          deviceFingerprint: fingerprint
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Registration failed');
      }

      referralService.clearStoredReferralCode();
      onRegisteredSuccess(data.user, data.welcomeBonus);
    } catch (err: any) {
      setError(err.message || 'An error occurred during registration');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="auth-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#0d0914]/80 backdrop-blur-md overflow-y-auto">
      <div
        id="auth-modal-container"
        className="w-full max-w-md max-w-[calc(100vw-20px)] max-h-[92vh] overflow-y-auto overflow-x-hidden bg-[rgba(23,16,31,0.65)] backdrop-blur-xl border border-white/[0.08] rounded-2xl p-5 sm:p-7 shadow-[0_20px_50px_rgba(0,0,0,0.6)] relative"
      >
        {/* Top Glowing Ambient Accents */}
        <div className="absolute -top-16 -left-16 w-36 h-36 bg-[#d11b6d]/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-[#4c2d75]/30 rounded-full blur-3xl pointer-events-none" />

        {/* Optional Close Button */}
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-[rgba(33,22,43,0.6)] border border-white/[0.08] hover:bg-neutral-700 text-neutral-300 hover:text-white transition z-20 cursor-pointer"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-4">
          <div className="relative mb-2">
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-[#b21e52] to-[#d11b6d] flex items-center justify-center border-2 border-[#d11b6d]/60 shadow-[0_0_20px_rgba(209,27,109,0.5)]">
              <Zap className="w-8 h-8 text-white fill-white" />
            </div>
            <div className="absolute -bottom-1 -right-1 bg-amber-500 text-neutral-950 text-[9px] font-black px-1.5 py-0.2 rounded-full border border-amber-300">
              AVIATOR
            </div>
          </div>
          <div className="flex items-center gap-2 mb-0.5">
            <h1 className="text-2xl font-black tracking-wider text-[#d11b6d] font-['Chakra_Petch'] drop-shadow-[0_0_12px_rgba(209,27,109,0.4)]">
              WIN <span className="text-white">NOVA</span>
            </h1>
          </div>
          <p className="text-xs text-neutral-400">
            Welcome aboard the premier crash flight lounge!
          </p>
        </div>

        {/* 1-Click Instant Demo Pilot Login (Immediate ₹500 test wallet) */}
        <button
          type="button"
          onClick={handleDemoLogin}
          disabled={loading}
          className="w-full py-2.5 mb-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 active:scale-[0.99] rounded-xl font-bold text-xs sm:text-sm text-white shadow-[0_0_15px_rgba(16,185,129,0.35)] flex items-center justify-center gap-2 transition cursor-pointer border border-emerald-400/50"
        >
          <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
          <span>⚡ 1-Click Demo Play (₹500 Balance - No Sign Up)</span>
        </button>

        {/* Welcome Bonus Callout Banner */}
        <div className="bg-[rgba(33,22,43,0.6)] border border-white/[0.08] rounded-xl p-3 mb-5 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[#d11b6d]/20 flex items-center justify-center shrink-0 border border-[#d11b6d]/40">
            <Gift className="w-5 h-5 text-[#d11b6d] animate-bounce" />
          </div>
          <div className="text-left">
            <div className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>Lucky Registration Gift</span>
              <span className="bg-amber-500/20 text-amber-300 text-[10px] px-1.5 py-0.2 rounded border border-amber-500/40">
                ₹12 to ₹50
              </span>
            </div>
            <div className="text-[11px] text-neutral-300">
              New players receive an instant random wallet allocation upon registration!
            </div>
          </div>
        </div>

        {/* Mode Switcher */}
        <div className="flex bg-[rgba(33,22,43,0.6)] p-1 rounded-xl border border-white/[0.08] mb-5">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition ${
              mode === 'login'
                ? 'bg-gradient-to-r from-[#4c2d75] to-[#b21e52] text-white shadow-[0_0_12px_rgba(209,27,109,0.4)]'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Log In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setError(null);
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition ${
              mode === 'register'
                ? 'bg-gradient-to-r from-[#4c2d75] to-[#b21e52] text-white shadow-[0_0_12px_rgba(209,27,109,0.4)]'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Register (Get Bonus)
          </button>
        </div>

        {/* 1-Click Instant Demo Play */}
        <div className="mb-2.5">
          <button
            type="button"
            onClick={handleQuickDemoLogin}
            disabled={loading}
            className="w-full py-2.5 px-3 bg-gradient-to-r from-[#4c2d75] via-[#b21e52] to-[#d11b6d] hover:brightness-110 active:scale-[0.99] rounded-xl font-bold text-xs text-white shadow-[0_0_20px_rgba(209,27,109,0.35)] flex items-center justify-center gap-2 transition cursor-pointer border border-white/[0.12]"
          >
            <Sparkles className="w-4 h-4 text-amber-200 animate-pulse" />
            <span>1-Click Instant Demo Play (₹2,000 Free Wallet)</span>
          </button>
        </div>

        {/* Google Sign In with Firebase */}
        <div className="mb-3">
          <button
            type="button"
            id="google-signin-btn"
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full py-2.5 px-3 bg-[rgba(33,22,43,0.6)] hover:bg-[rgba(33,22,43,0.85)] active:scale-[0.99] rounded-xl font-semibold text-xs text-neutral-200 border border-white/[0.08] flex items-center justify-center gap-2.5 transition cursor-pointer disabled:opacity-50"
          >
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path fill="#EA4335" d="M12 5c1.6 0 3 .6 4.1 1.7l3.1-3.1C17.3 1.8 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.4 9 5 12 5z"/>
              <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.7-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.9z"/>
              <path fill="#FBBC05" d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3 0-.8.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 12.3 0 15.2c0 2.8.7 5.5 1.9 7.8l3.7-2.9z"/>
              <path fill="#34A853" d="M12 23.5c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.4-6.4-5.2L1.9 16.5C3.7 20.2 7.5 23.5 12 23.5z"/>
            </svg>
            <span>Continue with Google</span>
          </button>
        </div>

        <div className="flex items-center gap-2 mb-3">
          <div className="h-px bg-white/[0.08] flex-1" />
          <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider">or sign in with password</span>
          <div className="h-px bg-white/[0.08] flex-1" />
        </div>

        {/* Error notification */}
        {error && (
          <div className="mb-4 p-3 bg-red-950/60 border border-red-600/60 rounded-xl text-xs text-red-200 flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span className="leading-tight">{error}</span>
          </div>
        )}

        {/* LOGIN FORM */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-neutral-200">
                  Player Name <span className="text-[#d11b6d] font-bold">* (Compulsory)</span>
                </label>
                <span className="text-[10px] text-neutral-400">Can edit later anytime</span>
              </div>
              <div className="flex items-center gap-2 bg-[rgba(33,22,43,0.6)] border border-white/[0.08] rounded-xl px-3 py-2.5 focus-within:border-[#d11b6d]">
                <UserIcon className="w-4 h-4 text-[#d11b6d]" />
                <input
                  id="auth-player-name-input"
                  type="text"
                  placeholder="Enter your Player Name (e.g. Maverick, AviatorKing)"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-transparent text-sm text-white placeholder:text-purple-300/40 focus:outline-none"
                />
              </div>
              <p className="text-[10px] text-neutral-400 mt-1">
                Required for game identification. You can change this later from your Profile.
              </p>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">
                Phone Number or Email
              </label>
              <div className="flex items-center gap-2 bg-[rgba(33,22,43,0.6)] border border-white/[0.08] rounded-xl px-3 py-2.5 focus-within:border-[#d11b6d]">
                <UserIcon className="w-4 h-4 text-neutral-400" />
                <input
                  type="text"
                  required
                  placeholder="e.g. 9876543210 or email"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="w-full bg-transparent text-sm text-white placeholder:text-purple-300/40 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">
                Password
              </label>
              <div className="flex items-center gap-2 bg-[rgba(33,22,43,0.6)] border border-white/[0.08] rounded-xl px-3 py-2.5 focus-within:border-[#d11b6d]">
                <Lock className="w-4 h-4 text-neutral-400" />
                <input
                  type="password"
                  required
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-transparent text-sm text-white placeholder:text-purple-300/40 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-[#4c2d75] to-[#b21e52] hover:brightness-110 active:scale-[0.99] rounded-xl font-bold text-sm text-white shadow-[0_4px_20px_rgba(178,30,82,0.4)] border border-white/[0.12] flex items-center justify-center gap-2 transition disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <span>Verifying...</span>
              ) : (
                <>
                  <span>Sign In & Play</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            <div className="text-center pt-2 flex items-center justify-center gap-4">
              <button
                type="button"
                onClick={() => {
                  setIdentifier('player@winnova.com');
                  setPassword('Faisal786');
                }}
                className="text-[11px] text-[#76c043] hover:text-[#8be452] underline transition"
              >
                Quick Demo Player Login
              </button>
            </div>
          </form>
        )}

        {/* REGISTER FORM */}
        {mode === 'register' && (
          <form onSubmit={handleRegister} className="space-y-3.5">
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">
                Full Name
              </label>
              <div className="flex items-center gap-2 bg-[rgba(33,22,43,0.6)] border border-white/[0.08] rounded-xl px-3 py-2 focus-within:border-[#d11b6d]">
                <UserIcon className="w-4 h-4 text-neutral-400" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Verma"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-transparent text-sm text-white placeholder:text-purple-300/40 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">
                Mobile Number (10 Digits)
              </label>
              <div className="flex items-center gap-2 bg-[rgba(33,22,43,0.6)] border border-white/[0.08] rounded-xl px-3 py-2 focus-within:border-[#d11b6d]">
                <Phone className="w-4 h-4 text-neutral-400" />
                <input
                  type="tel"
                  required
                  placeholder="e.g. 9876543210"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-transparent text-sm text-white placeholder:text-purple-300/40 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">
                Password
              </label>
              <div className="flex items-center gap-2 bg-[rgba(33,22,43,0.6)] border border-white/[0.08] rounded-xl px-3 py-2 focus-within:border-[#d11b6d]">
                <Lock className="w-4 h-4 text-neutral-400" />
                <input
                  type="password"
                  required
                  placeholder="Choose a strong password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-transparent text-sm text-white placeholder:text-purple-300/40 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">
                Referral Code (Optional)
              </label>
              <div className="flex items-center gap-2 bg-[rgba(33,22,43,0.6)] border border-white/[0.08] rounded-xl px-3 py-2 focus-within:border-[#d11b6d]">
                <Gift className="w-4 h-4 text-amber-500" />
                <input
                  type="text"
                  placeholder="e.g. WN-WIN777"
                  value={referralCode}
                  onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                  className="w-full bg-transparent text-sm text-white placeholder:text-purple-300/40 focus:outline-none font-mono uppercase"
                />
              </div>
            </div>

            <div className="text-[11px] text-neutral-400 leading-tight">
              By creating an account, you agree to fair gaming regulations. Multi-accounting on same device is strictly prohibited.
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-[#4c2d75] to-[#b21e52] hover:brightness-110 active:scale-[0.99] rounded-xl font-bold text-sm text-white shadow-[0_4px_20px_rgba(178,30,82,0.4)] border border-white/[0.12] flex items-center justify-center gap-2 transition disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <span>Generating Security Token...</span>
              ) : (
                <>
                  <span>Claim Bonus & Register</span>
                  <Gift className="w-4 h-4 text-amber-300" />
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
