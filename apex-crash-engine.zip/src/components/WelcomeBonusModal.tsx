import React from 'react';
import { Gift, CheckCircle, Sparkles, ArrowRight } from 'lucide-react';

interface WelcomeBonusModalProps {
  isOpen: boolean;
  bonusAmount: number;
  onClose: () => void;
}

export const WelcomeBonusModal: React.FC<WelcomeBonusModalProps> = ({
  isOpen,
  bonusAmount,
  onClose
}) => {
  if (!isOpen) return null;

  // Identify Tier
  const tier = bonusAmount <= 20 ? 'Tier 1' : bonusAmount <= 35 ? 'Tier 2 (Rare)' : 'Tier 3 (Super Lucky)';

  return (
    <div id="welcome-bonus-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        id="welcome-bonus-container"
        className="w-full max-w-sm bg-gradient-to-b from-[#1c1d22] to-[#121316] border border-amber-500/50 rounded-2xl p-6 text-center shadow-[0_0_35px_rgba(245,158,11,0.25)] relative overflow-hidden"
      >
        {/* Glow backdrop */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-600 to-yellow-400 mx-auto flex items-center justify-center shadow-[0_0_20px_rgba(245,158,11,0.5)] mb-4 animate-bounce">
          <Gift className="w-8 h-8 text-neutral-950" />
        </div>

        <div className="inline-block px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold uppercase tracking-wider mb-2">
          {tier} Unlocked!
        </div>

        <h3 className="text-xl font-black text-white font-['Chakra_Petch']">
          Welcome Gift Allocated!
        </h3>

        <div className="my-5 p-4 rounded-xl bg-[#17181c] border border-[#2a2c35] flex flex-col items-center justify-center">
          <span className="text-xs text-neutral-400 uppercase tracking-widest font-mono">
            Bonus Balance Credited
          </span>
          <div className="text-4xl font-black font-mono text-amber-400 mt-1 flex items-center gap-1 drop-shadow-[0_0_12px_rgba(245,158,11,0.4)]">
            <span>₹{bonusAmount}</span>
            <Sparkles className="w-6 h-6 text-amber-300 animate-spin" />
          </div>
          <span className="text-[11px] text-neutral-400 mt-1">
            Valid for gameplay right away! Complete 1.5x turnover to unlock full withdrawal.
          </span>
        </div>

        <button
          id="claim-bonus-continue-btn"
          onClick={onClose}
          className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-black rounded-xl shadow-[0_0_20px_rgba(245,158,11,0.3)] flex items-center justify-center gap-2 text-sm transition cursor-pointer"
        >
          <span>Start Playing Now</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
