import React, { useState, useEffect } from 'react';
import { User, PlatformNotification } from '../types';
import {
  Bell,
  Gift,
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  Clock,
  X,
  Coins,
  Trash2,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { socketService } from '../services/socket';

interface NotificationCenterModalProps {
  isOpen: boolean;
  user: User | null;
  onClose: () => void;
  onRefreshUser: () => void;
  onUnreadCountChange?: (count: number) => void;
}

export const NotificationCenterModal: React.FC<NotificationCenterModalProps> = ({
  isOpen,
  user,
  onClose,
  onRefreshUser,
  onUnreadCountChange
}) => {
  const [notifications, setNotifications] = useState<PlatformNotification[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [claimingId, setClaimingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const fetchNotifications = async () => {
    if (!user?.id) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/notifications/${encodeURIComponent(user.id)}`);
      if (res.ok) {
        const data = await res.json();
        const list: PlatformNotification[] = data.notifications || [];
        setNotifications(list);
        if (onUnreadCountChange) {
          const actionable = list.filter(
            (n) =>
              !n.is_deleted &&
              !(n.dismissedBy || []).includes(user.id) &&
              ((n.rewardAmount > 0 && !(n.claimedBy || []).includes(user.id)) ||
                !(n.readBy || []).includes(user.id))
          ).length;
          onUnreadCountChange(actionable);
        }
      }
    } catch {
      // Silent fallback
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      fetchNotifications();
    }
  }, [user?.id, isOpen]);

  useEffect(() => {
    const unsubNew = socketService.on('notification_received', () => {
      if (user?.id) fetchNotifications();
    });
    const unsubUpdated = socketService.on('notifications_updated', () => {
      if (user?.id) fetchNotifications();
    });
    return () => {
      unsubNew();
      unsubUpdated();
    };
  }, [user?.id]);

  const handleClaimReward = async (notif: PlatformNotification) => {
    if (!user) return;
    setClaimingId(notif.id);
    setFeedback(null);
    try {
      const res = await fetch(`/api/notifications/${encodeURIComponent(notif.id)}/claim`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setFeedback({
          type: 'success',
          message: data.message || `🎉 ₹${notif.rewardAmount} credited to your wallet!`
        });
        await fetchNotifications();
        onRefreshUser();
      } else {
        setFeedback({
          type: 'error',
          message: data.error || 'Failed to claim notification reward.'
        });
      }
    } catch {
      setFeedback({ type: 'error', message: 'Network error while claiming reward.' });
    } finally {
      setClaimingId(null);
    }
  };

  const handleSoftDismiss = async (notifId: string) => {
    if (!user) return;
    try {
      const res = await fetch(`/api/notifications/${encodeURIComponent(notifId)}/dismiss`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id })
      });
      if (res.ok) {
        fetchNotifications();
      }
    } catch {
      // Ignore
    }
  };

  if (!isOpen) return null;

  const visibleNotifications = notifications.filter(
    (n) => !n.is_deleted && (!user || !(n.dismissedBy || []).includes(user.id))
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div
        id="notification-center-modal"
        className="bg-[#15161c] border border-[#2b2e3b] rounded-2xl w-full max-w-lg max-w-[calc(100vw-20px)] overflow-hidden shadow-2xl flex flex-col max-h-[88vh]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#252834] flex items-center justify-between bg-gradient-to-r from-[#1c1e28] to-[#15161c]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-rose-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-white text-base font-['Chakra_Petch']">
                  Notification & Reward Centre
                </h3>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {visibleNotifications.length} Active
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                Official broadcasts, system alerts & instant wallet reward drops
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={fetchNotifications}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-[#252834] transition cursor-pointer"
              title="Refresh Notifications"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-amber-400' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-[#252834] transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div
            className={`mx-4 mt-3 p-3 rounded-xl border text-xs font-bold flex items-center gap-2 ${
              feedback.type === 'success'
                ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-200'
                : 'bg-rose-950/70 border-rose-500/50 text-rose-200'
            }`}
          >
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>
        )}

        {/* Notifications List */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {visibleNotifications.length === 0 ? (
            <div className="py-12 text-center space-y-2">
              <Bell className="w-10 h-10 text-neutral-600 mx-auto" />
              <div className="text-sm font-bold text-neutral-300">Your Notification Centre is Clear</div>
              <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                When Super Admin dispatches cash rewards, bonuses, or system updates, they will appear here automatically.
              </p>
            </div>
          ) : (
            visibleNotifications.map((notif) => {
              const hasReward = notif.rewardAmount > 0;
              const isClaimed = user ? (notif.claimedBy || []).includes(user.id) : false;

              return (
                <div
                  key={notif.id}
                  className={`p-3.5 rounded-xl border transition relative ${
                    hasReward && !isClaimed
                      ? 'bg-gradient-to-br from-amber-950/30 via-[#1a1c24] to-[#14161d] border-amber-500/50 shadow-[0_0_20px_rgba(245,158,11,0.12)]'
                      : 'bg-[#121318] border-[#252834]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {hasReward ? (
                        <span className="p-1.5 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-400">
                          <Gift className="w-4 h-4" />
                        </span>
                      ) : (
                        <span className="p-1.5 rounded-lg bg-indigo-500/20 border border-indigo-500/40 text-indigo-400">
                          <ShieldCheck className="w-4 h-4" />
                        </span>
                      )}
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h4 className="text-xs sm:text-sm font-bold text-white">{notif.title}</h4>
                          <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#222530] text-neutral-300 uppercase">
                            {notif.type}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-neutral-500 font-mono mt-0.5">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(notif.createdAt).toLocaleString()}
                          </span>
                          <span>&bull;</span>
                          <span>By {notif.senderRole === 'SUPER_ADMIN' ? 'Super Admin' : 'Admin'}</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleSoftDismiss(notif.id)}
                      className="p-1 rounded text-neutral-500 hover:text-neutral-300 hover:bg-[#232632] transition cursor-pointer"
                      title="Archive Notification (Soft Delete)"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="text-xs text-neutral-300 mt-2.5 leading-relaxed whitespace-pre-line">
                    {notif.message}
                  </p>

                  {hasReward && (
                    <div className="mt-3 pt-2.5 border-t border-[#262936] flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <Coins className="w-4 h-4 text-amber-400" />
                        <div>
                          <span className="text-[10px] text-neutral-400 block uppercase font-mono">
                            Attached {notif.rewardType} Reward
                          </span>
                          <span className="text-sm font-black font-mono text-amber-400">
                            +₹{notif.rewardAmount.toFixed(2)}
                          </span>
                        </div>
                      </div>

                      {isClaimed ? (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-bold font-mono">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          Claimed
                        </span>
                      ) : (
                        <button
                          onClick={() => handleClaimReward(notif)}
                          disabled={claimingId === notif.id}
                          className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-black text-xs uppercase tracking-wider shadow-lg transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>{claimingId === notif.id ? 'Claiming...' : `Claim ₹${notif.rewardAmount}`}</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
