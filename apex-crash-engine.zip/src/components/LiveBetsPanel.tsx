import React, { useState, useMemo } from 'react';
import { Bet, HighRollerWinner, maskUsername, format7DigitUid } from '../types';
import { Users, User as UserIcon, Flame, Sparkles, Crown } from 'lucide-react';

interface LiveBetsPanelProps {
  activeBets?: Bet[];
  currentUserId: string;
  highRollers?: HighRollerWinner[];
}

export const LiveBetsPanel: React.FC<LiveBetsPanelProps> = ({
  activeBets = [],
  currentUserId,
  highRollers = []
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'my' | 'highRollers'>('all');
  const [currencyUnit, setCurrencyUnit] = useState<'INR' | 'USD' | 'PTS'>('INR');

  const safeBets = Array.isArray(activeBets) ? activeBets : [];
  const safeHighRollers = Array.isArray(highRollers) ? highRollers : [];

  // Sort bets so that the highest bettor of the round is strictly placed at the very top of 'All Bets'
  const sortedBets = useMemo(() => {
    return [...safeBets].sort((a, b) => {
      if (b.amount !== a.amount) {
        return b.amount - a.amount;
      }
      return (a.createdAt || 0) - (b.createdAt || 0);
    });
  }, [safeBets]);

  const myBets = useMemo(() => {
    return safeBets.filter((b) => b.userId === currentUserId);
  }, [safeBets, currentUserId]);

  const totalStake = safeBets.reduce((acc, b) => acc + b.amount, 0);

  // Client-side layout transformation layer for dynamic notation
  const formatAmount = (val: number | undefined): string => {
    if (val === undefined || isNaN(val)) return '-';
    if (currencyUnit === 'USD') return `$${(val / 86).toFixed(2)}`;
    if (currencyUnit === 'PTS') return `${Math.round(val * 10)} PTS`;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  const displayedBets = activeTab === 'all' ? sortedBets : myBets;

  return (
    <div
      id="live-bets-panel"
      className="w-full lg:w-72 xl:w-80 bg-[#16171a] border border-[#26282e] rounded-xl flex flex-col h-[320px] lg:h-[580px] overflow-hidden select-none shadow-xl"
    >
      {/* Tab Switcher Header */}
      <div className="flex items-center justify-between border-b border-[#26282e] bg-[#121316] p-1.5 gap-1">
        <button
          onClick={() => setActiveTab('all')}
          className={`flex-1 py-1.5 text-xs font-bold rounded-lg flex items-center justify-center gap-1 transition ${
            activeTab === 'all'
              ? 'bg-[#252830] text-white shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <Users className="w-3.5 h-3.5 text-rose-500" />
          <span>All Bets</span>
        </button>

        <button
          onClick={() => setActiveTab('my')}
          className={`flex-1 py-1.5 text-xs font-bold rounded-lg flex items-center justify-center gap-1 transition ${
            activeTab === 'my'
              ? 'bg-[#252830] text-white shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          <UserIcon className="w-3.5 h-3.5 text-amber-400" />
          <span>My Bets</span>
        </button>

        <button
          onClick={() => setActiveTab('highRollers')}
          className={`flex-1 py-1.5 text-xs font-bold rounded-lg flex items-center justify-center gap-1 transition relative ${
            activeTab === 'highRollers'
              ? 'bg-[#252830] text-amber-300 shadow-sm border border-amber-500/30'
              : 'text-neutral-400 hover:text-amber-400'
          }`}
        >
          <Flame className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
          <span>High Rollers</span>
        </button>
      </div>

      {activeTab !== 'highRollers' ? (
        <>
          {/* Round stats summary bar with Notation Switcher */}
          <div className="bg-[#18191d] px-3 py-2 border-b border-[#26282e] flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              <span className="text-neutral-400 font-medium">Active:</span>
              <span className="font-bold text-white font-mono">{safeBets.length}</span>
            </div>

            {/* Client-side Notation Toggle */}
            <div className="flex items-center gap-1 bg-[#121316] p-0.5 rounded-lg border border-[#2a2c34]">
              {(['INR', 'USD', 'PTS'] as const).map((unit) => (
                <button
                  key={unit}
                  onClick={() => setCurrencyUnit(unit)}
                  className={`px-1.5 py-0.5 text-[10px] font-bold rounded transition ${
                    currencyUnit === unit
                      ? 'bg-rose-600 text-white shadow-sm'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                  title={`Toggle display notation to ${unit}`}
                >
                  {unit === 'INR' ? '₹' : unit === 'USD' ? '$' : 'PTS'}
                </button>
              ))}
            </div>

            <div className="text-neutral-400">
              Total: <span className="font-bold text-rose-400 font-mono">{formatAmount(totalStake)}</span>
            </div>
          </div>

          {/* Table column headers */}
          <div className="grid grid-cols-12 px-3 py-1.5 text-[11px] font-semibold text-neutral-400 uppercase tracking-wider bg-[#131417] border-b border-[#26282e]">
            <div className="col-span-5">Player (UID)</div>
            <div className="col-span-3 text-right">Bet</div>
            <div className="col-span-1 text-center">X</div>
            <div className="col-span-3 text-right">Cash Out</div>
          </div>

          {/* Bets Rows List */}
          <div className="flex-1 overflow-y-auto no-scrollbar divide-y divide-[#202227]">
            {displayedBets.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40 text-neutral-400 text-xs gap-1">
                <Users className="w-6 h-6 opacity-40 text-neutral-400" />
                <span>No bets in this view</span>
              </div>
            ) : (
              displayedBets.map((b, idx) => {
                const isMe = b.userId === currentUserId;
                const playerUid = format7DigitUid(b.uid, b.userId);
                const displayName = maskUsername(b.userName || 'Player');
                const isTopBettor = activeTab === 'all' && idx === 0 && b.amount > 0;
                return (
                  <div
                    key={b.id}
                    className={`grid grid-cols-12 items-center px-3 py-2 text-xs transition ${
                      isTopBettor
                        ? 'bg-amber-500/10 border-y border-amber-500/30'
                        : b.cashedOut
                        ? 'bg-emerald-950/20 hover:bg-emerald-950/30'
                        : 'hover:bg-[#1a1c20]'
                    }`}
                  >
                    <div className="col-span-5 flex flex-col justify-center truncate pr-1">
                      <div className="flex items-center gap-1.5 truncate">
                        {isTopBettor ? (
                          <span className="flex items-center gap-0.5 px-1 py-0.5 text-[9px] font-bold bg-amber-500/30 text-amber-300 rounded border border-amber-400/60 shadow-[0_0_8px_rgba(251,191,36,0.4)] shrink-0 animate-pulse">
                            <Crown className="w-2.5 h-2.5 text-amber-300" />
                            TOP
                          </span>
                        ) : (
                          <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${b.isBot ? 'bg-purple-500' : 'bg-emerald-500'}`} />
                        )}
                        <span
                          className={`truncate font-medium font-mono ${
                            isTopBettor
                              ? 'text-amber-300 font-bold'
                              : isMe
                              ? 'text-amber-400 font-bold'
                              : 'text-neutral-300'
                          }`}
                        >
                          {isMe ? `${displayName} (YOU)` : displayName}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 text-[10px] text-neutral-500 font-mono pl-3">
                        <span>{playerUid}</span>
                      </div>
                    </div>

                    <div className="col-span-3 text-right font-mono font-bold text-neutral-200">
                      {formatAmount(b.amount)}
                    </div>

                    <div className="col-span-1 text-center">
                      {b.cashedOut ? (
                        <span className="inline-block px-1 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-900/60 text-purple-300 border border-purple-500/30">
                          {b.cashedOutMultiplier?.toFixed(2)}x
                        </span>
                      ) : (
                        <span className="text-neutral-500 font-mono text-[10px]">-</span>
                      )}
                    </div>

                    <div className="col-span-3 text-right font-mono font-bold">
                      {b.cashedOut ? (
                        <span className="text-emerald-400 drop-shadow-[0_0_8px_rgba(52,211,153,0.3)]">
                          {formatAmount(b.winAmount)}
                        </span>
                      ) : (
                        <span className="text-neutral-500 text-[10px]">-</span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </>
      ) : (
        /* MODULE 4: REAL-TIME HIGH ROLLERS LEADERBOARD */
        <div className="flex-1 flex flex-col min-h-0 bg-[#141518]">
          <div className="bg-[#171920] px-3 py-2 border-b border-[#26282e] flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" />
              <span className="text-amber-300 font-bold">Hall of Fame</span>
            </div>
            <span className="text-[10px] text-neutral-400">Live 24H Records</span>
          </div>

          <div className="grid grid-cols-12 px-3 py-1.5 text-[11px] font-semibold text-neutral-400 uppercase tracking-wider bg-[#131417] border-b border-[#26282e]">
            <div className="col-span-5">Player</div>
            <div className="col-span-3 text-center">Multiplier</div>
            <div className="col-span-4 text-right">Win Cash</div>
          </div>

          <div className="flex-1 overflow-y-auto no-scrollbar divide-y divide-[#202227]">
            {safeHighRollers.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40 text-neutral-400 text-xs gap-1">
                <Flame className="w-6 h-6 opacity-40 text-amber-500" />
                <span>No high rollers recorded yet</span>
              </div>
            ) : (
              safeHighRollers.map((hr, idx) => (
                <div
                  key={hr.id}
                  className="grid grid-cols-12 items-center px-3 py-2 text-xs hover:bg-[#1c1e24] transition group"
                >
                  <div className="col-span-5 flex items-center gap-1.5 truncate">
                    <span
                      className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold shrink-0 ${
                        idx === 0
                          ? 'bg-amber-400 text-black shadow-[0_0_8px_rgba(251,191,36,0.6)]'
                          : idx === 1
                          ? 'bg-neutral-300 text-black'
                          : idx === 2
                          ? 'bg-amber-700 text-white'
                          : 'bg-[#22242c] text-neutral-400'
                      }`}
                    >
                      {idx + 1}
                    </span>
                    <span className="font-mono text-neutral-200 font-medium truncate">
                      {hr.anonymizedName}
                    </span>
                  </div>

                  <div className="col-span-3 text-center">
                    <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm">
                      {hr.multiplier.toFixed(2)}x
                    </span>
                  </div>

                  <div className="col-span-4 text-right font-mono font-bold text-emerald-400 drop-shadow-[0_0_8px_rgba(52,211,153,0.3)]">
                    ₹{hr.winAmount.toLocaleString('en-IN')}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
