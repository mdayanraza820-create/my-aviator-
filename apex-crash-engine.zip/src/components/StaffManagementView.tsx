import React, { useState, useEffect } from 'react';
import { SubAdminAccount } from '../types';
import { ShieldAlert, Users, Plus, Key, Lock, CheckCircle2, XCircle, Trash2, RefreshCw, AlertTriangle, ShieldCheck } from 'lucide-react';

interface StaffManagementViewProps {
  adminKey: string;
}

export const StaffManagementView: React.FC<StaffManagementViewProps> = ({ adminKey }) => {
  const [staffList, setStaffList] = useState<SubAdminAccount[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // New staff form states
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [canManageWithdrawals, setCanManageWithdrawals] = useState<boolean>(true);
  const [canManageDeposits, setCanManageDeposits] = useState<boolean>(true);
  const [canViewGameEngine, setCanViewGameEngine] = useState<boolean>(true);
  const [canViewMetrics, setCanViewMetrics] = useState<boolean>(true);
  const [canSendNotificationsWithMoney, setCanSendNotificationsWithMoney] = useState<boolean>(false);

  const fetchStaff = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/staff/list', {
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        const data = await res.json();
        setStaffList(data.staff || []);
      }
    } catch {
      // Fallback
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStaff();
  }, [adminKey]);

  const handleCreateStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    setLoading(true);
    setFeedback(null);
    try {
      const res = await fetch('/api/admin/staff/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminKey
        },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          permissions: {
            canManageWithdrawals,
            canManageDeposits,
            canViewGameEngine,
            canViewMetrics,
            canSendNotifications: true,
            canSendNotificationsWithMoney
          }
        })
      });

      const data = await res.json();
      if (res.ok) {
        const createdStaff = data.staff || data.subAdmin;
        setFeedback(`Approved Admin account generated successfully. Secret token: ${createdStaff?.token || 'Generated'}`);
        setShowAddForm(false);
        setName('');
        setEmail('');
        fetchStaff();
      } else {
        setFeedback(data.error || 'Failed to create Sub-Admin account.');
      }
    } catch {
      setFeedback('Error communicating with server.');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleStatus = async (id: string, currentActive: boolean) => {
    try {
      const res = await fetch('/api/admin/staff/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminKey
        },
        body: JSON.stringify({ id, isActive: !currentActive })
      });
      if (res.ok) {
        setStaffList((prev) =>
          prev.map((s) => (s.id === id ? { ...s, isActive: !currentActive } : s))
        );
      }
    } catch {
      // Error handling
    }
  };

  const handleDeleteStaff = async (id: string) => {
    try {
      const res = await fetch('/api/admin/staff/delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminKey
        },
        body: JSON.stringify({ id })
      });
      if (res.ok) {
        setFeedback('Staff credential archived via Soft-Delete policy (is_deleted=true, deleted_at recorded).');
        setStaffList((prev) => prev.filter((s) => s.id !== id));
      }
    } catch {
      // Error handling
    }
  };

  return (
    <div className="space-y-4 text-xs">
      {/* Top Banner */}
      <div className="bg-[#14151a] border border-[#262832] rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">Staff Management & Role-Based Access Control (RBAC)</h3>
          </div>
          <p className="text-[11px] text-neutral-400 mt-1">
            Create secondary Sub-Admin credentials. Sub-Admins have access to withdrawal processing and game flight telemetry, but are <span className="text-rose-400 font-bold">strictly prohibited from modifying deposit ledgers</span>.
          </p>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-bold rounded-lg flex items-center gap-1.5 transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Generate Sub-Admin</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 bg-emerald-950/70 border border-emerald-500/60 rounded-xl text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Creation Modal / Inline Form */}
      {showAddForm && (
        <form onSubmit={handleCreateStaff} className="bg-[#171922] border border-[#2d3042] rounded-xl p-4 space-y-3 animate-in fade-in duration-150">
          <div className="font-bold text-white text-xs flex items-center gap-2">
            <Key className="w-4 h-4 text-amber-400" />
            <span>Provision New Sub-Admin Operator</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-neutral-400 text-[10px] mb-1 font-semibold">Operator Name</label>
              <input
                type="text"
                required
                placeholder="e.g. Operations Manager Rohit"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#101115] border border-[#2e3140] rounded-lg px-2.5 py-1.5 text-white text-xs focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-neutral-400 text-[10px] mb-1 font-semibold">Corporate Email Address</label>
              <input
                type="email"
                required
                placeholder="e.g. rohit.ops@winnova.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#101115] border border-[#2e3140] rounded-lg px-2.5 py-1.5 text-white text-xs focus:border-emerald-500 outline-none"
              />
            </div>
          </div>

          {/* Granular RBAC Permissions */}
          <div className="space-y-2 pt-1">
            <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
              Enforced Granular Permissions (RBAC)
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 bg-[#121318] p-3 rounded-lg border border-[#252834]">
              <label className="flex items-center gap-2 text-neutral-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={canManageWithdrawals}
                  onChange={(e) => setCanManageWithdrawals(e.target.checked)}
                  className="rounded border-neutral-700 text-emerald-500 focus:ring-0"
                />
                <span>Approve / Reject User Withdrawals</span>
              </label>

              <label className="flex items-center gap-2 text-neutral-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={canViewGameEngine}
                  onChange={(e) => setCanViewGameEngine(e.target.checked)}
                  className="rounded border-neutral-700 text-emerald-500 focus:ring-0"
                />
                <span>Monitor Flight Telemetry & Crash Overrides</span>
              </label>

              <label className="flex items-center gap-2 text-neutral-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={canViewMetrics}
                  onChange={(e) => setCanViewMetrics(e.target.checked)}
                  className="rounded border-neutral-700 text-emerald-500 focus:ring-0"
                />
                <span>View Platform Financial Overview Metrics</span>
              </label>

              <label className="flex items-center gap-2 text-amber-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={canSendNotificationsWithMoney}
                  onChange={(e) => setCanSendNotificationsWithMoney(e.target.checked)}
                  className="rounded border-neutral-700 text-amber-500 focus:ring-0"
                />
                <span>Send Money/Rewards to Notification Centre (Requires Super Admin Gate ON)</span>
              </label>

              <label className="flex items-center gap-2 text-neutral-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={canManageDeposits}
                  onChange={(e) => setCanManageDeposits(e.target.checked)}
                  className="rounded border-neutral-700 text-emerald-500 focus:ring-0"
                />
                <span className="font-semibold text-emerald-300">Order ID Confirmation: Approve / Reject Deposit Orders</span>
              </label>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-3 py-1.5 bg-[#20222a] hover:bg-[#282a35] text-neutral-300 rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition flex items-center gap-1.5"
            >
              {loading && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
              <span>Generate Credentials</span>
            </button>
          </div>
        </form>
      )}

      {/* Staff Accounts List */}
      <div className="bg-[#14151a] border border-[#262832] rounded-xl overflow-hidden shadow-inner">
        <div className="grid grid-cols-12 px-3 py-2 text-[10px] font-semibold text-neutral-400 uppercase tracking-wider bg-[#101114] border-b border-[#242630]">
          <div className="col-span-3">Operator / UID</div>
          <div className="col-span-3">Assigned Token</div>
          <div className="col-span-4">Active RBAC Permissions</div>
          <div className="col-span-2 text-right">Actions</div>
        </div>

        <div className="divide-y divide-[#202228]">
          {staffList.length === 0 ? (
            <div className="p-8 text-center text-neutral-500">
              No Sub-Admin operators currently provisioned. Click "Generate Sub-Admin" to create credentials.
            </div>
          ) : (
            staffList.map((staff) => (
              <div key={staff.id} className="grid grid-cols-12 items-center px-3 py-2.5 hover:bg-[#181920] transition">
                <div className="col-span-3">
                  <div className="font-bold text-white">{staff.name}</div>
                  <div className="text-[11px] text-neutral-400 font-mono">{staff.email}</div>
                  <div className="text-[10px] text-neutral-500 font-mono">UID_{staff.id.slice(-4)}</div>
                </div>

                <div className="col-span-3">
                  <div className="inline-flex items-center gap-1.5 px-2 py-1 rounded bg-[#1c1e28] border border-[#2d3040] text-[11px] font-mono text-amber-300">
                    <Key className="w-3 h-3 text-amber-400 shrink-0" />
                    <span>{staff.token}</span>
                  </div>
                </div>

                <div className="col-span-4 space-y-1">
                  <div className="flex flex-wrap gap-1">
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold font-mono ${staff.permissions.canManageWithdrawals ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30' : 'bg-neutral-800 text-neutral-500'}`}>
                      WITHDRAWALS: {staff.permissions.canManageWithdrawals ? 'YES' : 'NO'}
                    </span>
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold font-mono bg-rose-950/80 text-rose-300 border border-rose-500/30">
                      DEPOSITS: BLOCKED (403)
                    </span>
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold font-mono ${staff.permissions.canSendNotificationsWithMoney ? 'bg-amber-950/80 text-amber-300 border border-amber-500/30' : 'bg-neutral-800 text-neutral-500'}`}>
                      BELL REWARDS: {staff.permissions.canSendNotificationsWithMoney ? 'YES (IF SA GATE ON)' : 'BLOCKED'}
                    </span>
                  </div>
                  <div className="text-[10px] text-neutral-400">
                    Engine Telemetry: {staff.permissions.canViewGameEngine ? 'Enabled' : 'Disabled'} &bull; Metrics: {staff.permissions.canViewMetrics ? 'Enabled' : 'Disabled'}
                  </div>
                </div>

                <div className="col-span-2 flex items-center justify-end gap-2">
                  <button
                    onClick={() => handleToggleStatus(staff.id, staff.isActive)}
                    className={`px-2 py-1 rounded text-[10px] font-bold transition cursor-pointer ${
                      staff.isActive
                        ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-900/60'
                        : 'bg-neutral-800 text-neutral-500 hover:bg-neutral-700'
                    }`}
                  >
                    {staff.isActive ? 'Active' : 'Suspended'}
                  </button>

                  <button
                    onClick={() => handleDeleteStaff(staff.id)}
                    className="p-1 text-neutral-500 hover:text-red-400 rounded hover:bg-neutral-800 transition"
                    title="Terminate Staff Account"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Security Statement */}
      <div className="p-3 bg-[#111216] border border-[#22242c] rounded-xl text-[10px] text-neutral-400 flex items-start gap-2">
        <Lock className="w-3.5 h-3.5 text-neutral-500 shrink-0 mt-0.5" />
        <span>
          <strong>Stealth Integration:</strong> All Sub-Admin operator records, active sessions, and access tokens are strictly invisible across general public player listings, chat streams, and public leaderboards.
        </span>
      </div>
    </div>
  );
};
