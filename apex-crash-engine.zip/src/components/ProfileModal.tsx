import React, { useState } from 'react';
import { User, getVipConfig, VIP_TIERS, format7DigitUid } from '../types.ts';
import {
  User as UserIcon,
  Crown,
  ShieldCheck,
  Wallet,
  Sparkles,
  Lock,
  Clock,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  Copy,
  Check,
  X,
  Gift,
  LogOut,
  ChevronRight,
  ArrowLeft,
  Home,
  CreditCard,
  Download,
  Calendar,
  DollarSign,
  TrendingUp,
  FileText
} from 'lucide-react';
import { VipSpinWheel } from './VipSpinWheel';

interface ProfileModalProps {
  isOpen: boolean;
  user: User;
  onClose: () => void;
  onOpenCashier: (tab: 'deposit' | 'withdraw') => void;
  onRefreshUser: () => void;
  onLogout?: () => void;
}

type ProfileView = 'dashboard' | 'vip_details' | 'balance_record' | 'balance_report' | 'personal_info';

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  user,
  onClose,
  onOpenCashier,
  onRefreshUser,
  onLogout
}) => {
  const [currentView, setCurrentView] = useState<ProfileView>('dashboard');
  const [copiedUid, setCopiedUid] = useState(false);
  const [isWheelOpen, setIsWheelOpen] = useState(false);
  const [isEditingName, setIsEditingName] = useState(false);
  const [editedName, setEditedName] = useState(user.name || '');
  const [editedPhone, setEditedPhone] = useState(user.phone || '');
  const [nameSaveLoading, setNameSaveLoading] = useState(false);
  const [nameSaveSuccess, setNameSaveSuccess] = useState<string | null>(null);
  const [nameSaveError, setNameSaveError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSaveName = async () => {
    const trimmed = editedName.trim();
    if (!trimmed || trimmed.length < 2) {
      setNameSaveError('Player name must be at least 2 characters.');
      return;
    }
    setNameSaveLoading(true);
    setNameSaveError(null);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/user/update-name', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({ name: trimmed, phone: editedPhone })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update player name');
      setNameSaveSuccess('Profile updated successfully!');
      setIsEditingName(false);
      onRefreshUser();
      setTimeout(() => setNameSaveSuccess(null), 3000);
    } catch (err: any) {
      setNameSaveError(err.message || 'Failed to update name');
    } finally {
      setNameSaveLoading(false);
    }
  };

  const clean7DigitUid = format7DigitUid(user.uid, user.id);
  const isSuper = user.role === 'superadmin' || user.mainBalance >= 900000000;
  const vipConfig = isSuper ? VIP_TIERS[10] : getVipConfig(user.lifetimeDeposit || 0);
  const vipLevel = isSuper ? 10 : (user.vipLevel ?? vipConfig.level);
  const isVipEligible = isSuper || vipLevel >= 1;

  // Next VIP tier calculation
  const nextTier = VIP_TIERS.find((t) => t.level === vipLevel + 1);
  const currentMin = vipConfig.minLifetimeDeposit;
  const nextMin = nextTier ? nextTier.minLifetimeDeposit : currentMin;
  const effectiveLifetimeDeposit = isSuper ? Math.max(500000, user.lifetimeDeposit || 0) : (user.lifetimeDeposit || 200);
  const progressToNext = nextTier
    ? Math.min(100, Math.max(0, ((effectiveLifetimeDeposit - currentMin) / (nextMin - currentMin)) * 100))
    : 100;

  // Spin cooldown calculation
  const cooldown = 24 * 60 * 60 * 1000;
  const lastSpin = user.lastVipSpinAt || 0;
  const now = Date.now();
  const canSpin = isVipEligible && (now - lastSpin >= cooldown || !lastSpin);
  const timeRemainingMs = Math.max(0, lastSpin + cooldown - now);
  const hoursLeft = Math.floor(timeRemainingMs / (1000 * 60 * 60));
  const minsLeft = Math.floor((timeRemainingMs % (1000 * 60 * 60)) / 60000);

  const handleCopyUid = () => {
    navigator.clipboard.writeText(clean7DigitUid);
    setCopiedUid(true);
    setTimeout(() => setCopiedUid(false), 2000);
  };

  // Masked or formatted phone
  const displayPhone = user.phone || (user.email ? user.email.split('@')[0] : '97****2358');
  const userBalanceFormatted = (user.mainBalance !== undefined ? user.mainBalance : 0.98).toFixed(2);
  const accumulatedRechargesFormatted = (user.lifetimeDeposit !== undefined ? user.lifetimeDeposit : 200.00).toFixed(2);

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden w-full max-w-full animate-fadeIn select-none"
      style={{
        background: 'linear-gradient(180deg, #3a0d28 0%, #150511 100%)',
        color: '#ffffff',
        fontFamily: "'Outfit', sans-serif",
        padding: '16px',
        boxSizing: 'border-box'
      }}
    >
      <div className="max-w-md w-full max-w-full mx-auto min-h-screen flex flex-col justify-between pb-8 overflow-x-hidden">
        <div>
          {/* TOP NAVIGATION (Working Go Back & Home Buttons) */}
          <div className="flex justify-between items-center mb-6 pt-2">
            <button
              type="button"
              onClick={() => {
                if (currentView !== 'dashboard') {
                  setCurrentView('dashboard');
                } else {
                  onClose();
                }
              }}
              className="bg-transparent border-none text-[#ffcc00] text-lg font-bold cursor-pointer flex items-center gap-1 hover:opacity-80 transition"
            >
              <span className="text-xl">&lt;</span>
              <span>{currentView === 'dashboard' ? 'Myself' : 'Back'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="bg-transparent border-none text-[#ffcc00] text-2xl cursor-pointer hover:scale-110 transition"
              title="Home"
            >
              🏠
            </button>
          </div>

          {currentView === 'dashboard' && (
            <>
              {/* USER PROFILE INFO (Dynamic Data Ready) */}
              <div className="flex flex-col items-center mb-6">
                <div
                  className="w-20 h-20 rounded-full overflow-hidden border-2 border-[#ffcc00] mb-2.5 shadow-[0_0_20px_rgba(255,204,0,0.3)] bg-gradient-to-tr from-amber-600 to-yellow-300 flex items-center justify-center relative cursor-pointer"
                  onClick={() => setCurrentView('personal_info')}
                >
                  <img
                    src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80"
                    alt="User Avatar"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      // Fallback to avatar icon
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                    <UserIcon className="w-9 h-9 text-white drop-shadow" />
                  </div>
                </div>

                {/* Dynamic Mobile Number */}
                <div className="text-base font-bold tracking-wider mb-1 text-white">
                  {displayPhone}
                </div>

                {/* Dynamic UID with Clipboard Copy Feature */}
                <div className="flex items-center gap-2 text-neutral-300 text-sm">
                  <span>ID: {clean7DigitUid}</span>
                  <button
                    type="button"
                    onClick={handleCopyUid}
                    className="bg-transparent border-none text-white cursor-pointer text-sm hover:text-amber-400 transition"
                    title="Copy ID"
                  >
                    {copiedUid ? <Check className="w-4 h-4 text-emerald-400 inline" /> : '📋'}
                  </button>
                  {copiedUid && <span className="text-[10px] text-emerald-400 font-bold">Copied!</span>}
                </div>
              </div>

              {/* BALANCE AND WALLET ACTIONS CARD */}
              <div
                style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  borderRadius: '12px',
                  padding: '16px',
                  marginBottom: '20px',
                  border: '1px solid rgba(255, 255, 255, 0.08)'
                }}
              >
                <div className="flex justify-between text-center items-center">
                  <div className="flex-1">
                    <div className="text-[#ffcc00] text-base font-bold mb-1 font-mono">
                      INR {userBalanceFormatted}
                    </div>
                    <div className="text-[#aaaaaa] text-xs">Surplus</div>
                  </div>

                  {/* Working Deposit Redirect */}
                  <div
                    onClick={() => {
                      onClose();
                      onOpenCashier('deposit');
                    }}
                    className="flex-1 border-l border-r border-white/10 cursor-pointer hover:bg-white/5 py-1 rounded transition"
                  >
                    <div className="text-lg mb-1">💳</div>
                    <div className="text-white text-xs font-semibold">Deposit</div>
                  </div>

                  {/* Working Withdraw Redirect */}
                  <div
                    onClick={() => {
                      onClose();
                      onOpenCashier('withdraw');
                    }}
                    className="flex-1 cursor-pointer hover:bg-white/5 py-1 rounded transition"
                  >
                    <div className="text-lg mb-1">📥</div>
                    <div className="text-white text-xs font-semibold">Withdraw</div>
                  </div>
                </div>
              </div>

              {/* ACCUMULATED RECHARGES & RED PLANE VIP BAR */}
              <div
                style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  borderRadius: '12px',
                  padding: '16px',
                  marginBottom: '20px',
                  border: '1px solid rgba(255, 255, 255, 0.08)'
                }}
              >
                <div className="flex items-center gap-3 mb-3">
                  {/* 4. RED PLANE (Background Removed Styling via CSS + Neon Red Propeller Plane) */}
                  <img
                    src="/red_plane_vip.svg"
                    alt="VIP Red Plane"
                    style={{
                      width: '50px',
                      height: '50px',
                      objectFit: 'contain',
                      backgroundColor: 'transparent',
                      display: 'block'
                    }}
                    className="drop-shadow-[0_0_12px_rgba(255,0,59,0.7)]"
                  />

                  <div>
                    <div className="text-sm text-neutral-300">Currently accumulated recharges</div>
                    <div className="text-base font-bold text-white font-mono">
                      ₹{accumulatedRechargesFormatted}
                    </div>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs text-[#aaaaaa] mb-1.5 font-medium">
                  <span>Bet amount</span>
                  <span className="font-mono text-amber-400">VIP {vipLevel}</span>
                </div>
                <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${progressToNext}%`,
                      background: 'linear-gradient(90deg, #ffcc00, #ff5e00)'
                    }}
                  />
                </div>
              </div>

              {/* BOTTOM ACTION GRID LINKS */}
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-around',
                  textAlign: 'center',
                  background: 'rgba(0, 0, 0, 0.25)',
                  padding: '16px 0',
                  borderRadius: '12px',
                  marginBottom: '20px',
                  border: '1px solid rgba(255, 255, 255, 0.05)'
                }}
              >
                <div
                  onClick={() => setCurrentView('vip_details')}
                  className="cursor-pointer flex-1 hover:opacity-80 transition"
                >
                  <div className="text-2xl mb-1.5">🎖️</div>
                  <div className="text-[13px] text-[#dddddd] font-semibold">VIP Details</div>
                </div>
                <div
                  onClick={() => setCurrentView('balance_record')}
                  className="cursor-pointer flex-1 hover:opacity-80 transition border-l border-r border-white/10"
                >
                  <div className="text-2xl mb-1.5">📈</div>
                  <div className="text-[13px] text-[#dddddd] font-semibold">Balance record</div>
                </div>
                <div
                  onClick={() => setCurrentView('balance_report')}
                  className="cursor-pointer flex-1 hover:opacity-80 transition"
                >
                  <div className="text-2xl mb-1.5">🏦</div>
                  <div className="text-[13px] text-[#dddddd] font-semibold">Balance report</div>
                </div>
              </div>

              {/* PERSONAL INFORMATION TAB (Working Button) */}
              <div
                onClick={() => setCurrentView('personal_info')}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  background: 'rgba(255, 255, 255, 0.05)',
                  padding: '16px',
                  borderRadius: '12px',
                  cursor: 'pointer',
                  border: '1px solid rgba(255, 255, 255, 0.08)',
                  marginBottom: '20px'
                }}
                className="hover:bg-white/10 transition"
              >
                <div className="flex items-center gap-2.5 text-sm font-semibold text-white">
                  <span className="text-base">🪪</span>
                  <span>Personal information</span>
                </div>
                <div className="text-[#aaaaaa] text-sm font-bold">&gt;</div>
              </div>

              {/* Working Logout Button */}
              {onLogout && (
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onLogout();
                    }}
                    className="w-full py-3 px-4 bg-red-950/40 hover:bg-red-900/60 active:bg-red-900 text-red-300 hover:text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 border border-red-800/40 cursor-pointer shadow-sm"
                  >
                    <LogOut className="w-4 h-4 text-red-400" />
                    <span>Log Out Account</span>
                  </button>
                </div>
              )}
            </>
          )}

          {/* SUB-VIEW 1: VIP DETAILS */}
          {currentView === 'vip_details' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="bg-black/30 border border-amber-500/30 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Crown className="w-5 h-5 text-amber-400" />
                    <h3 className="font-bold text-lg text-white">VIP Club Tier Status</h3>
                  </div>
                  <span className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 font-mono text-xs font-bold border border-amber-500/40">
                    VIP {vipLevel}
                  </span>
                </div>

                <div className="space-y-2 text-sm text-neutral-300">
                  <div className="flex justify-between">
                    <span>Current Level:</span>
                    <span className="font-bold text-white">{vipConfig.label}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Accumulated Deposits:</span>
                    <span className="font-bold text-amber-400 font-mono">₹{accumulatedRechargesFormatted}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Max Single Cashout:</span>
                    <span className="font-bold text-white font-mono">₹{vipConfig.maxSingleWithdrawal.toLocaleString()}</span>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-white/10">
                  <div className="flex justify-between text-xs text-neutral-400 mb-1">
                    <span>Progress to next tier</span>
                    <span>{progressToNext.toFixed(0)}%</span>
                  </div>
                  <div className="w-full h-2.5 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all"
                      style={{ width: `${progressToNext}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* VIP Lucky Spin Wheel Card */}
              {isVipEligible ? (
                <div className="p-4 bg-gradient-to-r from-purple-950/50 to-pink-950/50 border border-purple-500/40 rounded-xl shadow-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-yellow-300 animate-spin" />
                      <h4 className="font-bold text-white text-base">VIP Daily Lucky Spin</h4>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-500 text-black">
                      ACTIVE
                    </span>
                  </div>
                  <p className="text-xs text-purple-200/80 mb-3">
                    Spin once every 24 hours for guaranteed instant cash prizes, free chips, and bonus multipliers!
                  </p>
                  <button
                    type="button"
                    onClick={() => setIsWheelOpen(true)}
                    className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-500 via-purple-600 to-pink-600 hover:opacity-90 text-white font-bold text-sm rounded-xl cursor-pointer shadow-md flex items-center justify-center gap-2"
                  >
                    <Gift className="w-4 h-4" />
                    <span>{canSpin ? 'Spin Wheel Now!' : `Next Spin in ${hoursLeft}h ${minsLeft}m`}</span>
                  </button>
                </div>
              ) : (
                <div className="p-4 bg-black/40 border border-white/10 rounded-xl text-center space-y-2">
                  <Lock className="w-6 h-6 text-amber-400 mx-auto" />
                  <div className="font-bold text-sm text-white">VIP Lucky Wheel Locked</div>
                  <p className="text-xs text-neutral-400">
                    Deposit ₹500 or more to unlock daily guaranteed spin wheel rewards!
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenCashier('deposit');
                    }}
                    className="mt-2 py-2 px-4 bg-amber-500 text-black font-bold text-xs rounded-lg cursor-pointer"
                  >
                    Deposit to Unlock VIP
                  </button>
                </div>
              )}
            </div>
          )}

          {/* SUB-VIEW 2: BALANCE RECORD */}
          {currentView === 'balance_record' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="bg-black/30 border border-white/10 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                  <h3 className="font-bold text-base text-white">Recent Balance Records</h3>
                </div>
                <div className="space-y-2.5 text-xs">
                  <div className="flex justify-between items-center p-2.5 bg-white/5 rounded-lg border border-white/5">
                    <div>
                      <div className="font-bold text-emerald-400">+ ₹{accumulatedRechargesFormatted}</div>
                      <div className="text-[10px] text-neutral-400">Account Deposit / Recharge</div>
                    </div>
                    <div className="text-right">
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold text-[10px]">
                        COMPLETED
                      </span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center p-2.5 bg-white/5 rounded-lg border border-white/5">
                    <div>
                      <div className="font-bold text-[#ffcc00]">₹{userBalanceFormatted}</div>
                      <div className="text-[10px] text-neutral-400">Current Surplus Balance</div>
                    </div>
                    <div className="text-right">
                      <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold text-[10px]">
                        ACTIVE
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SUB-VIEW 3: BALANCE REPORT */}
          {currentView === 'balance_report' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="bg-black/30 border border-white/10 rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-2 mb-2">
                  <FileText className="w-5 h-5 text-amber-400" />
                  <h3 className="font-bold text-base text-white">Financial Balance Report</h3>
                </div>
                <div className="grid grid-cols-2 gap-2 text-center">
                  <div className="p-3 bg-white/5 rounded-lg">
                    <div className="text-[10px] text-neutral-400">Total Recharge</div>
                    <div className="text-base font-bold font-mono text-emerald-400">₹{accumulatedRechargesFormatted}</div>
                  </div>
                  <div className="p-3 bg-white/5 rounded-lg">
                    <div className="text-[10px] text-neutral-400">Wallet Surplus</div>
                    <div className="text-base font-bold font-mono text-[#ffcc00]">₹{userBalanceFormatted}</div>
                  </div>
                  <div className="p-3 bg-white/5 rounded-lg">
                    <div className="text-[10px] text-neutral-400">Wager Status</div>
                    <div className="text-xs font-bold text-neutral-200 mt-1">
                      {user.requiredWager && user.requiredWager > 0 ? `₹${user.requiredWager.toFixed(2)} Remaining` : 'Turnover Met'}
                    </div>
                  </div>
                  <div className="p-3 bg-white/5 rounded-lg">
                    <div className="text-[10px] text-neutral-400">VIP Grade</div>
                    <div className="text-xs font-bold text-amber-400 mt-1">Level {vipLevel}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SUB-VIEW 4: PERSONAL INFORMATION */}
          {currentView === 'personal_info' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="bg-black/30 border border-white/10 rounded-xl p-4 space-y-3">
                <h3 className="font-bold text-base text-white mb-2 flex items-center gap-2">
                  <span>🪪</span>
                  <span>Personal Profile Details</span>
                </h3>

                <div>
                  <label className="text-xs text-neutral-400 block mb-1">Player Display Name</label>
                  <input
                    type="text"
                    value={editedName}
                    onChange={(e) => setEditedName(e.target.value)}
                    placeholder="Enter display name"
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white font-bold text-sm focus:border-amber-400 outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs text-neutral-400 block mb-1">Mobile Number</label>
                  <input
                    type="text"
                    value={editedPhone}
                    onChange={(e) => setEditedPhone(e.target.value)}
                    placeholder="Enter phone number"
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white font-mono text-sm focus:border-amber-400 outline-none"
                  />
                </div>

                <div className="pt-1">
                  <div className="text-xs text-neutral-400 block mb-1">User 7-Digit UID</div>
                  <div className="p-2.5 bg-white/5 rounded-lg font-mono text-amber-400 font-bold text-sm flex justify-between items-center">
                    <span>{clean7DigitUid}</span>
                    <button
                      type="button"
                      onClick={handleCopyUid}
                      className="text-xs bg-amber-500/20 px-2 py-1 rounded text-amber-300 font-sans"
                    >
                      {copiedUid ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                </div>

                {nameSaveError && (
                  <div className="text-xs text-red-400 bg-red-950/40 p-2 rounded border border-red-500/30">
                    {nameSaveError}
                  </div>
                )}
                {nameSaveSuccess && (
                  <div className="text-xs text-emerald-400 bg-emerald-950/40 p-2 rounded border border-emerald-500/30">
                    {nameSaveSuccess}
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleSaveName}
                  disabled={nameSaveLoading}
                  className="w-full mt-2 py-2.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-bold text-sm rounded-lg cursor-pointer transition shadow-md"
                >
                  {nameSaveLoading ? 'Saving Changes...' : 'Save Profile Information'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Render VIP Spin Wheel modal */}
      {isWheelOpen && (
        <VipSpinWheel
          isOpen={isWheelOpen}
          user={user}
          onClose={() => setIsWheelOpen(false)}
          onRewardClaimed={() => {
            onRefreshUser();
          }}
        />
      )}
    </div>
  );
};
