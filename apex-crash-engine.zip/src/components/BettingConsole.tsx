import React, { useState, useEffect, useRef } from 'react';
import { GameStatus, Bet } from '../types';
import { Minus, Plus, Zap, RefreshCw, CheckCircle2, AlertTriangle, XCircle, Loader2 } from 'lucide-react';

interface BettingConsoleProps {
  consoleIndex: 0 | 1;
  status: GameStatus;
  multiplier: number;
  userBalance: number;
  activeBet: Bet | null;
  countdownSeconds?: number;
  onPlaceBet: (amount: number, autoCashout?: number) => void;
  onCashOut: (betId: string) => void;
  onOpenDeposit?: () => void;
}

export const BettingConsole: React.FC<BettingConsoleProps> = ({
  consoleIndex,
  status,
  multiplier,
  userBalance,
  activeBet,
  countdownSeconds = 5,
  onPlaceBet,
  onCashOut,
  onOpenDeposit
}) => {
  const [tab, setTab] = useState<'bet' | 'auto'>('bet');
  const [amount, setAmount] = useState<number>(100);
  const [autoCashoutEnabled, setAutoCashoutEnabled] = useState<boolean>(false);
  const [autoCashoutTarget, setAutoCashoutTarget] = useState<number>(2.00);
  const [autoBetEnabled, setAutoBetEnabled] = useState<boolean>(false);
  const [queuedForNextRound, setQueuedForNextRound] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const hasPlacedThisWaitingRef = useRef<boolean>(false);
  const amountRef = useRef(amount);
  amountRef.current = amount;
  const autoCashoutEnabledRef = useRef(autoCashoutEnabled);
  autoCashoutEnabledRef.current = autoCashoutEnabled;
  const autoCashoutTargetRef = useRef(autoCashoutTarget);
  autoCashoutTargetRef.current = autoCashoutTarget;
  const userBalanceRef = useRef(userBalance);
  userBalanceRef.current = userBalance;
  const onPlaceBetRef = useRef(onPlaceBet);
  onPlaceBetRef.current = onPlaceBet;

  // Clear isSubmitting once activeBet arrives or when leaving WAITING phase
  useEffect(() => {
    if (activeBet || status !== 'WAITING') {
      setIsSubmitting(false);
    }
  }, [activeBet, status]);

  // Safety fallback timeout to prevent stuck spinner
  useEffect(() => {
    if (isSubmitting) {
      const timer = setTimeout(() => {
        setIsSubmitting(false);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [isSubmitting]);

  // Quick chip amounts
  const chips = [10, 50, 100, 500, 1000];

  // Auto-Bet & Queued Bet Trigger when entering WAITING phase
  useEffect(() => {
    if (status === 'WAITING') {
      if (!hasPlacedThisWaitingRef.current && (autoBetEnabled || queuedForNextRound) && !activeBet) {
        if (userBalanceRef.current >= amountRef.current) {
          hasPlacedThisWaitingRef.current = true;
          setQueuedForNextRound(false);
          setIsSubmitting(true);
          onPlaceBetRef.current(
            amountRef.current,
            autoCashoutEnabledRef.current ? autoCashoutTargetRef.current : undefined
          );
        }
      }
    } else {
      hasPlacedThisWaitingRef.current = false;
    }
  }, [status, autoBetEnabled, queuedForNextRound, Boolean(activeBet)]);

  const handleAmountChange = (newVal: number) => {
    const val = Math.max(10, Math.min(100000, Math.floor(newVal)));
    setAmount(val);
  };

  const handleActionClick = () => {
    if (status === 'WAITING') {
      if (!currentActiveBet && !isSubmitting) {
        if (userBalance < amount) {
          if (onOpenDeposit) {
            onOpenDeposit();
          }
          return;
        }
        setIsSubmitting(true);
        onPlaceBet(amount, autoCashoutEnabled ? autoCashoutTarget : undefined);
      }
    } else if (status === 'FLYING') {
      if (currentActiveBet && !currentActiveBet.cashedOut) {
        onCashOut(currentActiveBet.id);
      } else {
        if (userBalance < amount) {
          if (onOpenDeposit) onOpenDeposit();
          return;
        }
        setQueuedForNextRound(true);
        onPlaceBet(amount, autoCashoutEnabled ? autoCashoutTarget : undefined);
      }
    } else if (status === 'CRASHED') {
      if (userBalance < amount) {
        if (onOpenDeposit) onOpenDeposit();
        return;
      }
      setQueuedForNextRound(true);
      onPlaceBet(amount, autoCashoutEnabled ? autoCashoutTarget : undefined);
    }
  };

  // Stale bet protection: if a bet was already cashed out or round is waiting, prevent stale blocking
  const isStaleWaitingBet = status === 'WAITING' && activeBet && activeBet.cashedOut;
  const currentActiveBet = isStaleWaitingBet ? null : activeBet;

  const isFlying = status === 'FLYING';
  const hasLiveBetInFlight = isFlying && !!currentActiveBet && !currentActiveBet.cashedOut;
  const cashedOut = isFlying && !!currentActiveBet && currentActiveBet.cashedOut;
  const currentLiveWin = currentActiveBet ? +(currentActiveBet.amount * multiplier).toFixed(2) : 0;
  const isInsufficient = userBalance < amount && status === 'WAITING' && !currentActiveBet;

  return (
    <div
      id={`betting-console-${consoleIndex}`}
      className={`relative bg-[#18191d] border rounded-xl p-3 sm:p-4 transition-all duration-200 flex flex-col justify-between ${
        hasLiveBetInFlight
          ? 'border-amber-500/80 shadow-[0_0_25px_rgba(245,158,11,0.25)] ring-1 ring-amber-500/50'
          : activeBet && status === 'WAITING'
          ? 'border-emerald-500/60 shadow-[0_0_15px_rgba(16,185,129,0.15)] ring-1 ring-emerald-500/40'
          : 'border-[#292b33] hover:border-[#373a45]'
      }`}
    >
      {/* Console Header Tabs */}
      <div className="flex items-center justify-between border-b border-[#262830] pb-2 mb-3">
        <div className="flex items-center gap-1 bg-[#121316] p-0.5 rounded-lg border border-[#262830]">
          <button
            onClick={() => setTab('bet')}
            className={`px-3 py-1 text-xs font-bold rounded-md transition ${
              tab === 'bet'
                ? 'bg-[#292c35] text-white shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Manual
          </button>
          <button
            onClick={() => setTab('auto')}
            className={`px-3 py-1 text-xs font-bold rounded-md transition flex items-center gap-1 ${
              tab === 'auto'
                ? 'bg-rose-950/70 border border-rose-600/40 text-rose-300 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Zap className="w-3 h-3 text-rose-500" />
            Auto
          </button>
        </div>

        <span className="text-[11px] font-mono font-medium text-neutral-400">
          Console #{consoleIndex + 1}
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
        {/* Left section: Amount controls */}
        <div className="sm:col-span-7 flex flex-col gap-2">
          {/* Amount input row */}
          <div className="flex items-center gap-1.5 bg-[#121316] border border-[#2a2c35] rounded-lg p-1.5 focus-within:border-rose-500/60 transition">
            <button
              onClick={() => handleAmountChange(amount - 10)}
              disabled={!!activeBet && !cashedOut}
              className="w-8 h-8 rounded bg-[#202229] hover:bg-[#2c2e38] active:bg-[#353844] flex items-center justify-center text-neutral-300 disabled:opacity-40 transition cursor-pointer"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>

            <div className="flex-1 flex items-center justify-center gap-1">
              <span className="text-xs text-rose-400 font-bold">₹</span>
              <input
                type="number"
                min={10}
                max={100000}
                step={10}
                disabled={!!activeBet && !cashedOut}
                value={amount}
                onChange={(e) => handleAmountChange(Number(e.target.value))}
                className="w-full text-center font-mono font-bold text-lg text-white bg-transparent focus:outline-none disabled:opacity-50"
              />
            </div>

            <button
              onClick={() => handleAmountChange(amount + 10)}
              disabled={!!activeBet && !cashedOut}
              className="w-8 h-8 rounded bg-[#202229] hover:bg-[#2c2e38] active:bg-[#353844] flex items-center justify-center text-neutral-300 disabled:opacity-40 transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Quick chips & Multiplier selectors */}
          <div className="flex items-center gap-1 flex-wrap">
            {chips.map((chip) => (
              <button
                key={chip}
                disabled={!!activeBet && !cashedOut}
                onClick={() => handleAmountChange(chip)}
                className={`text-[11px] font-mono px-2 py-1 rounded bg-[#202229] hover:bg-[#2a2c36] text-neutral-300 font-semibold border border-transparent hover:border-[#3a3d4a] transition disabled:opacity-40 cursor-pointer ${
                  amount === chip ? 'border-rose-500/50 text-rose-400 bg-rose-950/20' : ''
                }`}
              >
                +{chip}
              </button>
            ))}
            <button
              disabled={!!activeBet && !cashedOut}
              onClick={() => handleAmountChange(amount * 2)}
              className="text-[11px] font-mono px-2 py-1 rounded bg-[#202229] hover:bg-[#2a2c36] text-neutral-300 font-semibold transition disabled:opacity-40 cursor-pointer"
            >
              2X
            </button>
            <button
              disabled={!!activeBet && !cashedOut}
              onClick={() => handleAmountChange(Math.max(10, Math.floor(amount / 2)))}
              className="text-[11px] font-mono px-2 py-1 rounded bg-[#202229] hover:bg-[#2a2c36] text-neutral-300 font-semibold transition disabled:opacity-40 cursor-pointer"
            >
              ½
            </button>
          </div>

          {/* Auto-Cashout Row */}
          <div className="flex items-center justify-between pt-1 border-t border-[#23252e]">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={autoCashoutEnabled}
                onChange={(e) => setAutoCashoutEnabled(e.target.checked)}
                className="w-3.5 h-3.5 rounded bg-[#121316] border-neutral-700 text-rose-600 focus:ring-0 cursor-pointer"
              />
              <span className="text-xs text-neutral-300 font-medium">Auto Cashout</span>
            </label>

            <div className="flex items-center gap-1">
              <input
                type="number"
                min={1.05}
                max={10000}
                step={0.1}
                disabled={!autoCashoutEnabled}
                value={autoCashoutTarget}
                onChange={(e) => setAutoCashoutTarget(Math.min(10000, Math.max(1.05, Number(e.target.value))))}
                className="w-20 text-center font-mono font-bold text-xs py-1 px-1.5 rounded bg-[#121316] border border-[#2a2c35] text-amber-400 focus:border-amber-500 focus:outline-none disabled:opacity-30"
              />
              <span className="text-xs font-bold text-neutral-400">x</span>
            </div>
          </div>

          {/* Auto-Bet Switch (Only in Auto Tab) */}
          {tab === 'auto' && (
            <div className="flex items-center justify-between pt-1 text-xs">
              <span className="text-neutral-400 flex items-center gap-1">
                <RefreshCw className={`w-3 h-3 text-rose-400 ${autoBetEnabled ? 'animate-spin' : ''}`} />
                Auto Bet every round
              </span>
              <button
                type="button"
                onClick={() => setAutoBetEnabled(!autoBetEnabled)}
                className={`px-2.5 py-0.5 rounded text-[11px] font-bold uppercase transition cursor-pointer ${
                  autoBetEnabled
                    ? 'bg-rose-600 text-white shadow-[0_0_8px_#f43f5e]'
                    : 'bg-[#22242b] text-neutral-400 hover:text-white'
                }`}
              >
                {autoBetEnabled ? 'ON' : 'OFF'}
              </button>
            </div>
          )}
        </div>

        {/* Right section: Master Big Action Button */}
        <div className="sm:col-span-5 h-full flex flex-col justify-center">
          {/* STATE 1: WAITING WITH PLACED BET (LOCKED & CONFIRMED) */}
          {status === 'WAITING' && currentActiveBet ? (
            <div
              id={`bet-accepted-${consoleIndex}`}
              className="w-full h-24 sm:h-28 rounded-xl bg-gradient-to-b from-[#092218] to-[#0e2c20] border border-emerald-500/70 p-2 flex flex-col items-center justify-center text-center shadow-[0_0_20px_rgba(16,185,129,0.3)] select-none relative overflow-hidden"
            >
              <div className="flex items-center gap-1.5 text-emerald-400 mb-0.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-black uppercase tracking-wider font-mono">
                  BET ACCEPTED & PENDING
                </span>
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-white leading-tight">
                ₹{currentActiveBet.amount}
              </div>
              {/* Visual countdown progress bar */}
              <div className="w-4/5 h-1.5 bg-emerald-950/90 rounded-full overflow-hidden mt-1.5 border border-emerald-500/30">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-1000 ease-linear rounded-full"
                  style={{ width: `${Math.max(5, (countdownSeconds / 5) * 100)}%` }}
                />
              </div>
              <div className="text-[10px] font-mono text-emerald-300/90 mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                Takeoff in {countdownSeconds}s • Ready for flight
              </div>
            </div>
          ) : /* STATE 1B: WAITING - TRANSMITTING BET WITH SPINNER & PROGRESS BAR */
          status === 'WAITING' && isSubmitting ? (
            <div
              id={`bet-submitting-${consoleIndex}`}
              className="w-full h-24 sm:h-28 rounded-xl bg-gradient-to-b from-[#1c1a24] to-[#12131a] border border-amber-500/70 p-2 flex flex-col items-center justify-center text-center shadow-[0_0_20px_rgba(245,158,11,0.25)] select-none relative overflow-hidden"
            >
              <div className="flex items-center gap-1.5 text-amber-400 mb-0.5">
                <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                <span className="text-xs font-black uppercase tracking-wider font-mono">
                  TRANSMITTING BET...
                </span>
              </div>
              <div className="text-2xl sm:text-3xl font-black font-mono text-white leading-tight">
                ₹{amount}
              </div>
              {/* Visual animated transmission progress bar */}
              <div className="w-4/5 h-1.5 bg-[#252530] rounded-full overflow-hidden mt-1.5 border border-amber-500/40">
                <div className="h-full bg-gradient-to-r from-amber-500 via-rose-500 to-amber-400 animate-pulse w-full rounded-full" />
              </div>
              <div className="text-[10px] font-mono text-amber-300/90 mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                Confirming stake with server engine...
              </div>
            </div>
          ) : /* STATE 2: CASHED OUT */
          cashedOut ? (
            <div
              id={`bet-cashedout-${consoleIndex}`}
              className="w-full h-24 sm:h-28 rounded-xl bg-emerald-950/60 border border-emerald-500/50 p-2 flex flex-col items-center justify-center text-center shadow-[0_0_15px_rgba(16,185,129,0.2)] select-none"
            >
              <CheckCircle2 className="w-5 h-5 text-emerald-400 mb-0.5" />
              <div className="text-xs font-bold uppercase tracking-wider text-emerald-300 font-mono">
                CASHED OUT
              </div>
              <div className="text-xl sm:text-2xl font-black font-mono text-emerald-400">
                ₹{currentActiveBet?.winAmount?.toFixed(2)}
              </div>
              <div className="text-[11px] font-mono text-emerald-200/70">
                @ {currentActiveBet?.cashedOutMultiplier?.toFixed(2)}x
              </div>
            </div>
          ) : /* STATE 3: LIVE IN-FLIGHT BET (CLICK TO CASHOUT) */
          hasLiveBetInFlight ? (
            <button
              id={`cashout-btn-${consoleIndex}`}
              onClick={handleActionClick}
              className="w-full h-24 sm:h-28 rounded-xl bg-gradient-to-b from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 active:scale-[0.98] border border-amber-200 shadow-[0_0_30px_rgba(245,158,11,0.5)] p-2 flex flex-col items-center justify-center text-center transition-all cursor-pointer select-none group animate-pulse"
            >
              <span className="text-xs font-black uppercase tracking-wider text-amber-950 font-mono">
                CASH OUT NOW
              </span>
              <span className="text-2xl sm:text-3xl font-black font-mono text-neutral-950 leading-tight drop-shadow-sm">
                ₹{currentLiveWin.toFixed(2)}
              </span>
              <span className="text-xs font-bold font-mono text-amber-950 bg-amber-300/80 px-2 py-0.5 rounded-full mt-1 border border-amber-950/20">
                @ {multiplier.toFixed(2)}x
              </span>
            </button>
          ) : /* STATE 4: CRASHED WITH UN-CASHED BET */
          status === 'CRASHED' && currentActiveBet && !currentActiveBet.cashedOut ? (
            <div
              id={`bet-crashed-${consoleIndex}`}
              className="w-full h-24 sm:h-28 rounded-xl bg-rose-950/70 border border-rose-500/60 p-2 flex flex-col items-center justify-center text-center shadow-[0_0_15px_rgba(244,63,94,0.3)] select-none"
            >
              <XCircle className="w-5 h-5 text-rose-400 mb-0.5" />
              <div className="text-xs font-black uppercase tracking-wider text-rose-300 font-mono">
                CRASHED @ {multiplier.toFixed(2)}x
              </div>
              <div className="text-lg font-mono font-bold text-neutral-300 line-through">
                ₹{currentActiveBet.amount}
              </div>
              <div className="text-[10px] text-rose-300/70">
                Better luck next round!
              </div>
            </div>
          ) : /* STATE 5: WAITING PHASE - PLACE BET */
          status === 'WAITING' ? (
            <button
              id={`place-bet-btn-${consoleIndex}`}
              onClick={handleActionClick}
              className={`w-full h-24 sm:h-28 rounded-xl p-2 flex flex-col items-center justify-center text-center transition-all cursor-pointer select-none ${
                isInsufficient
                  ? 'bg-gradient-to-b from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 border border-amber-400/50 text-amber-100 shadow-[0_0_20px_rgba(245,158,11,0.3)]'
                  : 'bg-gradient-to-b from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 active:scale-[0.98] border border-rose-400/50 shadow-[0_0_20px_rgba(225,29,72,0.3)] text-white'
              }`}
            >
              <span className="text-xs font-black uppercase tracking-wider font-mono">
                {isInsufficient ? 'DEPOSIT TO BET' : 'PLACE BET'}
              </span>
              <span className="text-2xl sm:text-3xl font-black font-mono leading-tight">
                ₹{amount}
              </span>
              <span className="text-[10px] font-medium opacity-90 uppercase tracking-widest mt-1">
                {isInsufficient ? 'Tap to open cashier' : 'Click to enter round'}
              </span>
            </button>
          ) : (
            /* STATE 6: IN-FLIGHT OR CRASHED WITHOUT BET - QUEUE BET */
            <button
              id={`queue-bet-btn-${consoleIndex}`}
              onClick={handleActionClick}
              className={`w-full h-24 sm:h-28 rounded-xl border p-2 flex flex-col items-center justify-center text-center transition-all cursor-pointer select-none ${
                queuedForNextRound
                  ? 'bg-amber-950/60 border-amber-500/60 text-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.25)]'
                  : 'bg-[#22242c] hover:bg-[#2a2d37] border-[#373a46] text-neutral-300'
              }`}
            >
              <span className="text-xs font-bold uppercase tracking-wider font-mono">
                {queuedForNextRound ? 'BET QUEUED' : 'BET NEXT ROUND'}
              </span>
              <span className="text-xl sm:text-2xl font-bold font-mono text-white mt-0.5">
                ₹{amount}
              </span>
              <span className="text-[10px] text-neutral-400 mt-1">
                {queuedForNextRound ? 'Will enter when countdown begins' : 'Click to queue'}
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
