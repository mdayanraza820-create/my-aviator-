import React, { useEffect, useRef } from 'react';
import { GameStatus } from '../types';
import { socketService } from '../services/socket';
import { subscribeToGameControl } from '../firebase';
import {
  AVIATOR_SPEED_FACTOR,
  calculateExponentialMultiplier,
  calculateNaturalFlightDuration
} from '../services/aviatorPrecisionEngine';

interface GameCanvasProps {
  status: GameStatus;
  multiplier: number;
  countdownSeconds: number;
  elapsedSeconds: number;
  crashMultiplier?: number;
}

interface PooledParticle {
  active: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  color: string;
}

const EXHAUST_POOL_SIZE = 250;
const EXPLOSION_POOL_SIZE = 120;

interface ServerTickSample {
  multiplier: number;
  elapsedSeconds: number;
  clientTime: number; // performance.now()
}

/**
 * PURE MATHEMATICAL EXPONENTIAL SPEED CURVE (8-SEC 2X LOCK)
 * Multiplier = Math.pow(Math.E, 0.08664 * elapsed_seconds)
 * Completely eliminates any artificial duration stretching or 2.50x desync freeze.
 */
export const getMultiplierAtElapsed = (t: number): number => {
  return calculateExponentialMultiplier(t);
};

export const calculateUltraSlow111sCurve = getMultiplierAtElapsed;

// 1. Background removed vector red plane direct SVG definition
export const PURE_RED_PLANE_SVG = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M15,65 L35,55 L75,42 L80,32 L82,45 L85,48 L83,55 L70,62 L40,75 L25,82 L15,84 Z M60,47 L80,18 L83,19 L78,43 Z M45,52 L52,78 L49,79 L40,54 Z M75,42 L88,52 L87,54 L73,44 Z' fill='%23ff0033'/><circle cx='81' cy='43' r='2' fill='%23ff0033'/><line x1='75' y1='20' x2='87' y2='66' stroke='%23ff0033' stroke-width='2.5'/></svg>";

export const GameCanvas: React.FC<GameCanvasProps> = ({
  status,
  multiplier,
  countdownSeconds,
  elapsedSeconds,
  crashMultiplier
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Object pools for zero-allocation particle animations
  const exhaustPoolRef = useRef<PooledParticle[]>(
    Array.from({ length: EXHAUST_POOL_SIZE }, () => ({
      active: false,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      size: 0,
      alpha: 0,
      color: '#f43f5e'
    }))
  );
  const exhaustPoolIdxRef = useRef<number>(0);
  const particleEmissionAccumulatorRef = useRef<number>(0);

  const explosionPoolRef = useRef<PooledParticle[]>(
    Array.from({ length: EXPLOSION_POOL_SIZE }, () => ({
      active: false,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      size: 0,
      alpha: 0,
      color: '#ff003b'
    }))
  );

  const animFrameId = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  const renderFrameRef = useRef<(() => void) | null>(null);
  const updateMultiplierRef = useRef<(() => void) | null>(null);

  // High precision time anchors
  const flightStartPerfRef = useRef<number>(0);

  // Performance buffer for incoming flight_tick events
  const tickBufferRef = useRef<ServerTickSample[]>([]);

  // References for smooth animation & instant crash lock
  const currentMultRef = useRef<number>(multiplier);
  const isCrashedRef = useRef<boolean>(status === 'CRASHED');
  const crashMultiplierRef = useRef<number | undefined>(crashMultiplier);
  const plannedCrashPointRef = useRef<number>(0);
  const statusRef = useRef<GameStatus>(status);
  const elapsedRef = useRef<number>(elapsedSeconds);

  const syncDomMultiplierDisplay = (val: number, crashed: boolean) => {
    const text = `${val.toFixed(2)}x`;
    const displayEl1 = document.getElementById('multiplierDisplay');
    if (displayEl1) {
      displayEl1.innerText = text;
    }
    const displayEl2 = document.getElementById('multiplier-display');
    if (displayEl2) {
      displayEl2.innerText = text;
      if (crashed) {
        displayEl2.classList.add('crashed', 'text-red-500');
        displayEl2.classList.remove('text-white', 'text-emerald-400');
      } else {
        displayEl2.classList.remove('crashed', 'text-red-500');
        displayEl2.classList.add('text-white');
      }
    }
  };

  // 💥 2. CRASH FIX FUNCTION (Jab backend se signal aaye)
  const triggerCrashOnCanvas = (backendCrashPoint: number) => {
    isCrashedRef.current = true;
    statusRef.current = 'CRASHED';

    // ⚡ CRITICAL FIX: Timer loop ko usi microsecond par kill kar dena
    if (animFrameId.current) {
      cancelAnimationFrame(animFrameId.current);
      animFrameId.current = 0;
    }

    tickBufferRef.current = [];

    // Screen par wahi fixed multiplier dikhana jo backend se aaya hai, na ki jo lag ki wajah se aage badha thha
    const fixedMultiplier = +(Number(backendCrashPoint) > 0 ? Number(backendCrashPoint) : (currentMultRef.current || 1.00)).toFixed(2);
    currentMultRef.current = fixedMultiplier;
    crashMultiplierRef.current = fixedMultiplier;

    syncDomMultiplierDisplay(fixedMultiplier, true);

    if (renderFrameRef.current) {
      renderFrameRef.current();
    }
  };

  // Direct socket subscriber to bypass React state latency
  useEffect(() => {
    const unsubTick = socketService.on('flight_tick', (data: { multiplier: number; elapsedSeconds: number; plannedCrashMultiplier?: number }) => {
      // Agar crash ho chuka hai toh screen par ek point bhi aage nahi badhna chahiye
      if (isCrashedRef.current || statusRef.current === 'CRASHED') return;

      if (typeof data.plannedCrashMultiplier === 'number' && data.plannedCrashMultiplier > 0) {
        plannedCrashPointRef.current = data.plannedCrashMultiplier;
      }

      const now = performance.now();
      const sample: ServerTickSample = {
        multiplier: data.multiplier,
        elapsedSeconds: data.elapsedSeconds,
        clientTime: now
      };

      // Push into sliding window ring buffer (keep last 20 samples)
      const buf = tickBufferRef.current;
      buf.push(sample);
      if (buf.length > 20) {
        buf.shift();
      }

      // Synchronize client flight clock with server flight time
      const estimatedStart = now - (data.elapsedSeconds * 1000);
      if (flightStartPerfRef.current === 0) {
        flightStartPerfRef.current = estimatedStart;
      } else {
        // Low-pass filter to smooth jitter and eliminate clock skew
        flightStartPerfRef.current = flightStartPerfRef.current * 0.85 + estimatedStart * 0.15;
      }

      if (!animFrameId.current && updateMultiplierRef.current && !isCrashedRef.current && statusRef.current === 'FLYING') {
        animFrameId.current = requestAnimationFrame(updateMultiplierRef.current);
      }
    });

    const unsubStart = socketService.on('flight_started', (data?: any) => {
      if (animFrameId.current) {
        cancelAnimationFrame(animFrameId.current);
        animFrameId.current = 0;
      }
      isCrashedRef.current = false;
      statusRef.current = 'FLYING';
      crashMultiplierRef.current = undefined;
      plannedCrashPointRef.current = (typeof data?.plannedCrashMultiplier === 'number' && data.plannedCrashMultiplier > 0)
        ? data.plannedCrashMultiplier
        : 0;
      tickBufferRef.current = [];
      flightStartPerfRef.current = performance.now();
      currentMultRef.current = 1.00;
      syncDomMultiplierDisplay(1.00, false);

      if (updateMultiplierRef.current) {
        animFrameId.current = requestAnimationFrame(updateMultiplierRef.current);
      }
    });

    const unsubCrash = (data: any) => {
      const crashVal = (typeof data?.crashMultiplier === 'number' && data.crashMultiplier > 0)
        ? data.crashMultiplier
        : (typeof data?.finalMultiplier === 'number' && data.finalMultiplier > 0)
        ? data.finalMultiplier
        : (plannedCrashPointRef.current > 0 ? plannedCrashPointRef.current : (currentMultRef.current || 1.00));

      triggerCrashOnCanvas(crashVal);
    };

    const unsubCrash1 = socketService.on('flight_crashed', unsubCrash);
    const unsubCrash2 = socketService.on('round_crashed', unsubCrash);

    // Database listener: Intercepts real-time Firestore crash signal
    const unsubDatabase = subscribeToGameControl((control) => {
      if (!control) return;
      const isCrashed = control.status === 'crashed' || (control.status as string) === 'ended';
      if (isCrashed) {
        const rawFinal = (typeof control.crashMultiplier === 'number' && control.crashMultiplier > 0)
          ? control.crashMultiplier
          : ((typeof control.finalMultiplier === 'number' && control.finalMultiplier > 0)
            ? control.finalMultiplier
            : (typeof control.currentMultiplier === 'number' && control.currentMultiplier > 0
              ? control.currentMultiplier
              : (currentMultRef.current || 1.00)));

        triggerCrashOnCanvas(rawFinal);
      }
    });

    (window as any).canvasTriggerCrash = (val: number) => {
      triggerCrashOnCanvas(val);
    };

    (window as any).renderMultiplierText = (val: number) => {
      currentMultRef.current = val;
      crashMultiplierRef.current = val;
      syncDomMultiplierDisplay(val, isCrashedRef.current);
      if (renderFrameRef.current) {
        renderFrameRef.current();
      }
    };

    (window as any).triggerVisualFlewAwayBanner = () => {
      isCrashedRef.current = true;
      statusRef.current = 'CRASHED';
      if (animFrameId.current) {
        cancelAnimationFrame(animFrameId.current);
        animFrameId.current = 0;
      }
      if (renderFrameRef.current) {
        renderFrameRef.current();
      }
    };

    return () => {
      unsubTick();
      unsubStart();
      unsubCrash1();
      unsubCrash2();
      unsubDatabase();
    };
  }, []);

  useEffect(() => {
    if (status === 'CRASHED') {
      const finalVal = (typeof crashMultiplier === 'number' && crashMultiplier > 0)
        ? crashMultiplier
        : (crashMultiplierRef.current || multiplier || currentMultRef.current || 1.00);
      triggerCrashOnCanvas(finalVal);
      elapsedRef.current = elapsedSeconds;
      return;
    }

    if (status === 'WAITING') {
      if (animFrameId.current) {
        cancelAnimationFrame(animFrameId.current);
        animFrameId.current = 0;
      }
      isCrashedRef.current = false;
      statusRef.current = 'WAITING';
      flightStartPerfRef.current = 0;
      plannedCrashPointRef.current = 0;
      crashMultiplierRef.current = undefined;
      tickBufferRef.current = [];
      currentMultRef.current = 1.00;
      elapsedRef.current = 0;
      syncDomMultiplierDisplay(1.00, false);
      if (typeof window !== 'undefined') {
        if ((window as any).stopFlightSound) (window as any).stopFlightSound();
        else if ((window as any).GameSounds?.stopFly) (window as any).GameSounds.stopFly();
      }
      if (renderFrameRef.current) {
        renderFrameRef.current();
      }
      return;
    }

    // Ignore delayed FLYING React state updates if direct socket already triggered crash
    if (isCrashedRef.current) {
      if (typeof window !== 'undefined') {
        if ((window as any).stopFlightSound) (window as any).stopFlightSound();
        else if ((window as any).GameSounds?.stopFly) (window as any).GameSounds.stopFly();
      }
      return;
    }

    if (status === 'FLYING') {
      if (statusRef.current !== 'FLYING') {
        statusRef.current = 'FLYING';
        if (typeof window !== 'undefined') {
          if ((window as any).playFlightSound) (window as any).playFlightSound();
          else if ((window as any).GameSounds?.startFly) (window as any).GameSounds.startFly();
        }
        if (flightStartPerfRef.current === 0) {
          flightStartPerfRef.current = performance.now() - (elapsedSeconds > 0 ? elapsedSeconds * 1000 : 0);
        }
        currentMultRef.current = Math.max(1.00, multiplier);
        if (!animFrameId.current && updateMultiplierRef.current) {
          animFrameId.current = requestAnimationFrame(updateMultiplierRef.current);
        }
      }
    }
    elapsedRef.current = elapsedSeconds;
  }, [multiplier, status, elapsedSeconds, crashMultiplier]);

  // Handle explosion trigger on crash using pre-allocated pool (zero GC)
  useEffect(() => {
    if (status === 'CRASHED' && canvasRef.current) {
      if (typeof window !== 'undefined') {
        if ((window as any).stopFlightSound) (window as any).stopFlightSound();
        else if ((window as any).GameSounds?.triggerCrash) (window as any).GameSounds.triggerCrash();
      }
      const canvas = canvasRef.current;
      const w = canvas.width / (window.devicePixelRatio || 1);
      const h = canvas.height / (window.devicePixelRatio || 1);

      const pool = explosionPoolRef.current;
      const colors = ['#ff003b', '#ff4d00', '#ffaa00', '#fff'];
      for (let i = 0; i < 45; i++) {
        const p = pool[i % pool.length];
        const angle = Math.random() * Math.PI * 2;
        const speed = 2 + Math.random() * 8;
        p.active = true;
        p.x = w * 0.75;
        p.y = h * 0.35;
        p.vx = Math.cos(angle) * speed;
        p.vy = Math.sin(angle) * speed;
        p.size = 3 + Math.random() * 6;
        p.alpha = 1.0;
        p.color = colors[Math.floor(Math.random() * colors.length)];
      }
    }
  }, [status]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = 0;
    let height = 0;

    const handleResize = () => {
      if (!containerRef.current || !canvas) return;
      width = containerRef.current.clientWidth;
      height = containerRef.current.clientHeight;
      const dpr = window.devicePixelRatio || 1;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (renderFrameRef.current) {
        renderFrameRef.current();
      }
    };

    handleResize();
    const resizeObserver = new ResizeObserver(handleResize);
    if (containerRef.current) resizeObserver.observe(containerRef.current);

    // Pre-load Background Removed Transparent Red Plane Vector
    const planeImg = new Image();
    planeImg.src = PURE_RED_PLANE_SVG;

    // Jet shape drawer - Background Removed Transparent Red Plane
    const drawJet = (x: number, y: number, angle: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(angle);

      // Jet body glow
      ctx.shadowColor = '#ff0033';
      ctx.shadowBlur = 16;

      // Draw Transparent Red Plane Image if loaded, or draw direct SVG vector paths
      if (planeImg.complete && planeImg.naturalWidth > 0) {
        const pSize = 64;
        ctx.drawImage(planeImg, -pSize * 0.45, -pSize * 0.5, pSize, pSize);
      } else {
        // Direct Vector rendering of the exact Red Plane Path on transparent background
        ctx.save();
        ctx.scale(0.65, 0.65);
        ctx.translate(-50, -50);
        ctx.fillStyle = '#ff0033';
        const p = new Path2D(
          "M15,65 L35,55 L75,42 L80,32 L82,45 L85,48 L83,55 L70,62 L40,75 L25,82 L15,84 Z M60,47 L80,18 L83,19 L78,43 Z M45,52 L52,78 L49,79 L40,54 Z M75,42 L88,52 L87,54 L73,44 Z"
        );
        ctx.fill(p);
        ctx.beginPath();
        ctx.arc(81, 43, 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ff0033';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(75, 20);
        ctx.lineTo(87, 66);
        ctx.stroke();
        ctx.restore();
      }

      // Afterburner flame
      const flameLength = 16 + Math.random() * 12;
      ctx.beginPath();
      ctx.moveTo(-24, -3);
      ctx.lineTo(-24 - flameLength, 0);
      ctx.lineTo(-24, 3);
      ctx.closePath();

      const flameGrad = ctx.createLinearGradient(-24, 0, -24 - flameLength, 0);
      flameGrad.addColorStop(0, '#ffffff');
      flameGrad.addColorStop(0.3, '#f59e0b');
      flameGrad.addColorStop(1, 'rgba(239, 68, 68, 0)');
      ctx.fillStyle = flameGrad;
      ctx.shadowColor = '#f97316';
      ctx.shadowBlur = 14;
      ctx.fill();

      ctx.restore();
    };

    // High-performance uncapped rendering loop (supports 60Hz, 120Hz, 144Hz+)
    const render = () => {
      if (!ctx) return;
      const w = width;
      const h = height;

      // Calculate delta-time for frame-rate independent physics across all display refresh rates
      const now = performance.now();
      const dt = lastTimeRef.current > 0 ? Math.min(0.05, (now - lastTimeRef.current) / 1000) : 0.016;
      lastTimeRef.current = now;
      const timeFactor = dt * 60; // 60fps unit factor

      ctx.clearRect(0, 0, w, h);

      // 1. Draw subtle grid in a single batched draw call
      ctx.lineWidth = 1;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.beginPath();
      const gridSpacingX = w / 8;
      const gridSpacingY = h / 6;

      for (let x = 0; x < w; x += gridSpacingX) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
      }
      for (let y = 0; y < h; y += gridSpacingY) {
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
      }
      ctx.stroke();

      // X and Y axis base markers
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
      ctx.beginPath();
      ctx.moveTo(0, h - 2);
      ctx.lineTo(w, h - 2);
      ctx.stroke();

      const currentStatus = isCrashedRef.current ? 'CRASHED' : statusRef.current;
      let currentMult = currentMultRef.current;
      const elapsed = elapsedRef.current;

      if (currentStatus === 'CRASHED') {
        // INSTANT FORCE-SNAP ON CRASH: Use exact backend crashMultiplierRef
        const definitiveFinal = (typeof crashMultiplierRef.current === 'number' && crashMultiplierRef.current > 0)
          ? crashMultiplierRef.current
          : (currentMultRef.current || 1.00);
        currentMult = definitiveFinal;
        currentMultRef.current = definitiveFinal;
        syncDomMultiplierDisplay(definitiveFinal, true);
      }

      if (currentStatus === 'FLYING' && !isCrashedRef.current) {
        if (flightStartPerfRef.current === 0) {
          flightStartPerfRef.current = now;
        }
        const flightTime = Math.max(0, (now - flightStartPerfRef.current) / 1000);

        // Pure mathematical exponential speed curve
        const modelMult = getMultiplierAtElapsed(flightTime);

        // Reconcile with authoritative server tick sample without overshooting backend crash point
        let reconciledMult = modelMult;
        const buf = tickBufferRef.current;
        if (buf.length > 0) {
          const latestSample = buf[buf.length - 1];
          const sampleCurveAtElapsed = getMultiplierAtElapsed(latestSample.elapsedSeconds);
          const deltaFromSample = Math.max(0, modelMult - sampleCurveAtElapsed);
          const extrapolated = latestSample.multiplier + deltaFromSample;
          reconciledMult = Math.max(modelMult, Math.max(latestSample.multiplier, extrapolated));

          const lagDelta = latestSample.multiplier - currentMultRef.current;
          if (lagDelta > 0.15) {
            const catchUp = lagDelta > 1.0 ? lagDelta * 0.8 : Math.max(lagDelta * 0.5, lagDelta * (dt * 15));
            reconciledMult = Math.max(reconciledMult, currentMultRef.current + catchUp);
          }
        }

        // Strictly monotonic non-decreasing multiplier throughout flight
        currentMult = Math.max(currentMultRef.current, reconciledMult);

        // ⚡ CRITICAL CLAMP: Never allow client animation frame to overshoot backend's plannedCrashPoint!
        if (plannedCrashPointRef.current > 0 && currentMult >= plannedCrashPointRef.current) {
          currentMult = plannedCrashPointRef.current;
        }

        currentMultRef.current = currentMult;
        syncDomMultiplierDisplay(currentMult, false);
      }

      if (currentStatus === 'FLYING' || currentStatus === 'CRASHED') {
        // Calculate curve progress based on both elapsed time and current multiplier
        const multProgress = Math.min(1, Math.log10(Math.max(1, currentMult)) / 2.0);
        const timeProgress = elapsed > 0 ? Math.min(1, elapsed / 111.0) : multProgress;
        const progressX = Math.min(1, Math.max(timeProgress, multProgress));
        const startX = 30;
        const startY = h - 20;

        const endX = startX + (w * 0.75 - startX) * Math.min(1, Math.pow(progressX, 0.8));
        // Vertical height climbs based on logarithmic multiplier progress up to 10,000x
        const multLog = Math.log10(Math.max(1, currentMult));
        const progressY = Math.min(0.85, (multLog / 4.0) * 0.75 + 0.10);
        const endY = startY - (startY - 40) * progressY;

        // Control point for smooth parabola
        const cpX = startX + (endX - startX) * 0.55;
        const cpY = startY - (startY - endY) * 0.2;

        // Gradient under the curve
        const curveGrad = ctx.createLinearGradient(0, endY, 0, startY);
        curveGrad.addColorStop(0, 'rgba(225, 29, 72, 0.35)');
        curveGrad.addColorStop(0.6, 'rgba(159, 18, 57, 0.15)');
        curveGrad.addColorStop(1, 'rgba(88, 28, 135, 0.0)');

        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.quadraticCurveTo(cpX, cpY, endX, endY);
        ctx.lineTo(endX, startY);
        ctx.closePath();
        ctx.fillStyle = curveGrad;
        ctx.fill();

        // Parabolic red glowing line
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.quadraticCurveTo(cpX, cpY, endX, endY);
        ctx.strokeStyle = '#e11d48';
        ctx.lineWidth = 4;
        ctx.shadowColor = '#ff003b';
        ctx.shadowBlur = 18;
        ctx.stroke();
        ctx.shadowBlur = 0; // reset

        // Jet Angle calculation from derivative of quadratic curve
        const t = 1.0;
        const dx = 2 * (1 - t) * (cpX - startX) + 2 * t * (endX - cpX);
        const dy = 2 * (1 - t) * (cpY - startY) + 2 * t * (endY - cpY);
        const angle = Math.atan2(dy, dx);

        if (currentStatus === 'FLYING') {
          // Zero-allocation exhaust particle emission driven by delta-time
          // Constant density across 60Hz, 120Hz, or temporary frame drops
          particleEmissionAccumulatorRef.current += dt;
          while (particleEmissionAccumulatorRef.current >= 0.018) {
            particleEmissionAccumulatorRef.current -= 0.018;
            const pool = exhaustPoolRef.current;
            const idx = exhaustPoolIdxRef.current;
            exhaustPoolIdxRef.current = (idx + 1) % EXHAUST_POOL_SIZE;
            const p = pool[idx];
            p.active = true;
            p.x = endX - Math.cos(angle) * 25;
            p.y = endY - Math.sin(angle) * 25;
            p.vx = -Math.cos(angle) * (1 + Math.random() * 2) + (Math.random() - 0.5);
            p.vy = -Math.sin(angle) * (1 + Math.random() * 2) + (Math.random() - 0.5);
            p.size = 3 + Math.random() * 4;
            p.alpha = 0.8;
            p.color = Math.random() > 0.5 ? '#f43f5e' : '#fb923c';
          }

          // Draw jet
          drawJet(endX, endY, angle);
        }

        // Draw and update pooled smoke particles with delta-time scaling
        const exhaustPool = exhaustPoolRef.current;
        for (let i = 0; i < EXHAUST_POOL_SIZE; i++) {
          const p = exhaustPool[i];
          if (!p.active) continue;

          p.x += p.vx * timeFactor;
          p.y += p.vy * timeFactor;
          p.size += 0.15 * timeFactor;
          p.alpha -= 0.025 * timeFactor;

          if (p.alpha <= 0) {
            p.active = false;
            continue;
          }

          ctx.globalAlpha = p.alpha;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.globalAlpha = 1.0;
      }

      // Draw and update pooled explosion shockwave if crashed
      if (currentStatus === 'CRASHED') {
        const expPool = explosionPoolRef.current;
        for (let i = 0; i < EXPLOSION_POOL_SIZE; i++) {
          const p = expPool[i];
          if (!p.active) continue;

          p.x += p.vx * timeFactor;
          p.y += p.vy * timeFactor;
          p.alpha -= 0.02 * timeFactor;

          if (p.alpha <= 0) {
            p.active = false;
            continue;
          }

          ctx.globalAlpha = p.alpha;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.globalAlpha = 1.0;
      }

      // Render Multiplier and Flight Status directly in HTML5 Canvas 2D context
      // (Eliminates DOM innerText churn and guarantees 60fps/120fps display lock)
      if (currentStatus === 'FLYING') {
        ctx.save();
        const multStr = currentMult.toFixed(2);
        const baseSize = Math.max(50, Math.min(94, Math.floor(w * 0.145)));

        // Setup font for measuring
        ctx.font = `900 ${baseSize}px 'Chakra Petch', Rajdhani, 'JetBrains Mono', sans-serif`;
        ctx.textBaseline = 'middle';
        const numMetrics = ctx.measureText(multStr);

        const xSymbolSize = Math.floor(baseSize * 0.52);
        ctx.font = `700 ${xSymbolSize}px 'Chakra Petch', Rajdhani, sans-serif`;
        const xMetrics = ctx.measureText('x');

        const spacing = Math.max(4, Math.floor(baseSize * 0.06));
        const totalWidth = numMetrics.width + spacing + xMetrics.width;

        const startX = (w - totalWidth) / 2;
        const centerY = h * 0.44;

        // Draw primary multiplier value with red glow
        ctx.font = `900 ${baseSize}px 'Chakra Petch', Rajdhani, 'JetBrains Mono', sans-serif`;
        ctx.textAlign = 'left';
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = 'rgba(225, 29, 72, 0.55)';
        ctx.shadowBlur = 24;
        ctx.fillText(multStr, startX, centerY);

        // Draw 'x' symbol in rose red
        ctx.font = `700 ${xSymbolSize}px 'Chakra Petch', Rajdhani, sans-serif`;
        ctx.fillStyle = '#f43f5e';
        ctx.shadowColor = 'rgba(244, 63, 94, 0.7)';
        ctx.shadowBlur = 18;
        ctx.fillText('x', startX + numMetrics.width + spacing, centerY + (baseSize * 0.08));

        // Draw subtext label
        ctx.shadowBlur = 0;
        const subSize = Math.max(10, Math.min(13, Math.floor(baseSize * 0.16)));
        ctx.font = `600 ${subSize}px 'JetBrains Mono', monospace`;
        ctx.textAlign = 'center';
        ctx.fillStyle = '#94a3b8';
        ctx.fillText('SPEED MULTIPLIER', w * 0.5, centerY + (baseSize * 0.56));
        ctx.restore();
      } else if (currentStatus === 'CRASHED') {
        ctx.save();
        const baseCrashSize = Math.max(46, Math.min(84, Math.floor(w * 0.13)));
        const centerY = h * 0.44;

        // "FLEW AWAY"
        ctx.font = `700 ${Math.max(12, Math.floor(baseCrashSize * 0.22))}px 'Chakra Petch', sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#fb7185';
        ctx.shadowBlur = 0;
        ctx.fillText('FLEW AWAY', w * 0.5, centerY - (baseCrashSize * 0.52));

        // "@ XX.XXx" — strictly locked to backend crashMultiplierRef
        const finalVal = (typeof crashMultiplierRef.current === 'number' && crashMultiplierRef.current > 0)
          ? crashMultiplierRef.current
          : (currentMultRef.current || currentMult || 1.00);
        const crashStr = `@ ${finalVal.toFixed(2)}x`;
        ctx.font = `900 ${baseCrashSize}px 'Chakra Petch', sans-serif`;
        ctx.fillStyle = '#f43f5e';
        ctx.shadowColor = 'rgba(225, 29, 72, 0.85)';
        ctx.shadowBlur = 28;
        ctx.fillText(crashStr, w * 0.5, centerY);

        // "PREPARING NEXT TAKEOFF..."
        ctx.font = `500 ${Math.max(11, Math.floor(baseCrashSize * 0.18))}px 'JetBrains Mono', monospace`;
        ctx.fillStyle = '#94a3b8';
        ctx.shadowBlur = 0;
        ctx.fillText('PREPARING NEXT TAKEOFF...', w * 0.5, centerY + (baseCrashSize * 0.55));
        ctx.restore();
      }
    };

    // ✈️ 1. Multiplier ko screen par badhane wala function (requestAnimationFrame loop)
    const updateMultiplier = () => {
      if (isCrashedRef.current) {
        animFrameId.current = 0;
        return; // Agar crash ho chuka hai toh screen par ek point bhi aage nahi badhna chahiye
      }
      render();
      if (!isCrashedRef.current && statusRef.current === 'FLYING') {
        animFrameId.current = requestAnimationFrame(updateMultiplier);
      } else {
        animFrameId.current = 0;
      }
    };

    renderFrameRef.current = () => {
      render();
    };
    updateMultiplierRef.current = updateMultiplier;

    render();
    if (!isCrashedRef.current && statusRef.current === 'FLYING') {
      animFrameId.current = requestAnimationFrame(updateMultiplier);
    }

    return () => {
      if (animFrameId.current) {
        cancelAnimationFrame(animFrameId.current);
        animFrameId.current = 0;
      }
      resizeObserver.disconnect();
    };
  }, []);

  return (
    <div
      id="game-canvas-wrapper"
      ref={containerRef}
      className="relative w-full h-[280px] sm:h-[340px] md:h-[400px] lg:h-[430px] bg-[#141518] rounded-b-xl overflow-hidden shadow-inner flex items-center justify-center select-none"
    >
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />
      <span id="multiplierDisplay" className="sr-only">{`${currentMultRef.current.toFixed(2)}x`}</span>
      <span id="multiplier-display" className="sr-only">{`${currentMultRef.current.toFixed(2)}x`}</span>

      {/* Top Left Game ID / Status badge */}
      <div className="absolute top-3 left-3 flex items-center gap-2 z-10 pointer-events-none">
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#1f2127]/90 border border-[#2f323c] text-xs">
          <span
            className={`w-2 h-2 rounded-full animate-pulse ${
              status === 'FLYING'
                ? 'bg-rose-500 shadow-[0_0_8px_#f43f5e]'
                : status === 'WAITING'
                ? 'bg-amber-400 shadow-[0_0_8px_#fbbf24]'
                : 'bg-red-700'
            }`}
          />
          <span className="font-bold text-neutral-300 uppercase tracking-wide">
            {status === 'FLYING' ? 'AIRBORNE' : status === 'WAITING' ? 'STARTING' : 'ROUND OVER'}
          </span>
        </div>
      </div>

      {/* Waiting Countdown Display (Rendered in DOM only while resting/waiting; flight and crash are 100% Canvas rendered) */}
      {status === 'WAITING' && (
        <div
          className="countdown-container timer-wrapper z-10 text-center pointer-events-none flex flex-col items-center justify-center w-full mx-auto relative"
          style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', position: 'relative', margin: '0 auto', width: '100%' }}
        >
          <div
            className="flex flex-col items-center justify-center gap-3 animate-in fade-in zoom-in-95 w-full mx-auto"
            style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', margin: '0 auto', width: '100%' }}
          >
            {/* Circular SVG Countdown timer */}
            <div
              className="relative w-24 h-24 flex items-center justify-center mx-auto"
              style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', position: 'relative', margin: '0 auto', width: '96px', height: '96px' }}
            >
              <svg
                className="w-24 h-24 -rotate-90 block mx-auto"
                viewBox="0 0 96 96"
                width="96"
                height="96"
                style={{ display: 'block', margin: '0 auto', padding: 0, transformOrigin: 'center center' }}
              >
                <circle
                  cx="48"
                  cy="48"
                  r="42"
                  stroke="#26282e"
                  strokeWidth="6"
                  fill="transparent"
                  style={{ transformOrigin: 'center center' }}
                />
                <circle
                  cx="48"
                  cy="48"
                  r="42"
                  stroke="#f59e0b"
                  strokeWidth="6"
                  strokeDasharray={264}
                  strokeDashoffset={264 - 264 * Math.min(1, Math.max(0, countdownSeconds / 10))}
                  strokeLinecap="round"
                  fill="transparent"
                  className="transition-all duration-300 ease-linear"
                  style={{ transformOrigin: 'center center' }}
                />
              </svg>
              <div
                className="countdown-text timer-number absolute flex flex-col items-center justify-center font-bold text-white font-mono pointer-events-none text-center"
                style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', margin: 0, padding: 0, textAlign: 'center' }}
              >
                <span className="text-3xl font-black text-amber-400 leading-none">{countdownSeconds}</span>
                <span className="text-[10px] text-neutral-400 uppercase tracking-widest mt-0.5">SEC</span>
              </div>
            </div>

            <div className="text-sm font-bold uppercase tracking-wider text-neutral-200 text-center">
              Next Round Starting
            </div>
            <div className="w-44 h-1.5 bg-[#22242a] rounded-full overflow-hidden mx-auto">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-rose-500 transition-all duration-300 ease-linear mx-auto"
                style={{ width: `${Math.min(100, Math.max(0, (countdownSeconds / 10) * 100))}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Grid axis labels */}
      <div className="absolute bottom-1 right-3 text-[10px] text-neutral-600 font-mono pointer-events-none">
        TIME (S)
      </div>
      <div className="absolute top-2 right-3 text-[10px] text-neutral-600 font-mono pointer-events-none">
        RATE (X)
      </div>
    </div>
  );
};
