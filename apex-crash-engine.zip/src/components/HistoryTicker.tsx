import React, { useState, useRef, useEffect } from 'react';
import { MultiplierHistoryItem } from '../types';
import { History, ChevronDown, Award, X } from 'lucide-react';

interface HistoryTickerProps {
  history?: MultiplierHistoryItem[];
}

declare global {
  interface Window {
    appendNewCrashToMiniHistoryBar?: (newCrashPoint: number | string) => void;
  }
}

export const getMiniBadgeColorClass = (numericVal: number): string => {
  if (numericVal < 2.00) {
    return 'm-blue-low bg-[#2c52e2] text-white';
  } else if (numericVal >= 2.00 && numericVal < 10.00) {
    return 'm-purple-mid bg-[#913ffb] text-white';
  } else {
    return 'm-gold-high bg-[#c99c1a] text-[#141518]';
  }
};

const miniHistorySubscribers = new Set<(val: number) => void>();

export const appendNewCrashToMiniHistoryBar = (newCrashPoint: number | string) => {
  const numericVal = parseFloat(String(newCrashPoint));
  if (isNaN(numericVal)) return;

  // If React HistoryTicker is mounted, notify subscribers so React updates the 12 badges without DOM node conflicts
  if (miniHistorySubscribers.size > 0) {
    miniHistorySubscribers.forEach((cb) => {
      try {
        cb(numericVal);
      } catch {}
    });
    return;
  }

  // Fallback imperative DOM update only if no React HistoryTicker component is mounted
  if (typeof document === 'undefined') return;
  const horizontalRowSlot = document.getElementById('miniHistoryRowViewContainer');
  if (!horizontalRowSlot) return;

  const formattedText = numericVal.toFixed(2) + 'x';
  const freshNodeSpan = document.createElement('span');
  freshNodeSpan.className = `mini-badge-item inline-block py-[4px] px-[10px] rounded-[12px] text-[11.5px] font-bold text-center min-w-[46px] shadow-[0_2px_4px_rgba(0,0,0,0.3)] select-none shrink-0 ${getMiniBadgeColorClass(numericVal)}`;
  freshNodeSpan.innerText = formattedText;

  if (horizontalRowSlot.firstChild) {
    horizontalRowSlot.insertBefore(freshNodeSpan, horizontalRowSlot.firstChild);
  } else {
    horizontalRowSlot.appendChild(freshNodeSpan);
  }

  while (horizontalRowSlot.children.length > 12) {
    if (horizontalRowSlot.lastChild) {
      horizontalRowSlot.removeChild(horizontalRowSlot.lastChild);
    } else {
      break;
    }
  }
};

export const HistoryTicker: React.FC<HistoryTickerProps> = ({ history = [] }) => {
  const [showFullHistory, setShowFullHistory] = useState(false);
  const [instantPrepended, setInstantPrepended] = useState<MultiplierHistoryItem | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const fallbackInitial: MultiplierHistoryItem[] = [
    { roundId: 'R-init-1', multiplier: 1.50, crashedAt: Date.now() - 40000 },
    { roundId: 'R-init-2', multiplier: 3.40, crashedAt: Date.now() - 30000 },
    { roundId: 'R-init-3', multiplier: 1.25, crashedAt: Date.now() - 20000 },
    { roundId: 'R-init-4', multiplier: 12.80, crashedAt: Date.now() - 10000 }
  ];

  const baseHistory = Array.isArray(history) && history.length > 0 ? history.slice(0, 60) : fallbackInitial;
  const safeHistory =
    instantPrepended && (!baseHistory[0] || Number(baseHistory[0].multiplier).toFixed(2) !== Number(instantPrepended.multiplier).toFixed(2))
      ? [instantPrepended, ...baseHistory].slice(0, 60)
      : baseHistory;
  const horizontal12History = safeHistory.slice(0, 12);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.appendNewCrashToMiniHistoryBar = appendNewCrashToMiniHistoryBar;
    }
    const handleInstantCrash = (numericVal: number) => {
      setInstantPrepended({
        roundId: `R-live-${Date.now()}`,
        multiplier: +numericVal.toFixed(2),
        crashedAt: Date.now()
      });
    };
    miniHistorySubscribers.add(handleInstantCrash);
    return () => {
      miniHistorySubscribers.delete(handleInstantCrash);
    };
  }, []);

  // Clear temporary instantPrepended once parent history prop catches up
  useEffect(() => {
    if (instantPrepended && Array.isArray(history) && history.length > 0) {
      setInstantPrepended(null);
    }
  }, [history]);

  useEffect(() => {
    if (!showFullHistory) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowFullHistory(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showFullHistory]);

  return (
    <div
      id="history-ticker-container"
      ref={containerRef}
      className={`aviator-mini-history-panel w-full bg-[#141518] py-[6px] px-[12px] border-b-2 border-[#282a32] box-border flex items-center justify-between gap-[8px] relative rounded-t-xl select-none ${showFullHistory ? 'z-[9999]' : 'z-20'}`}
    >
      {/* Dynamic scroll row view injection hub slot (Max 12 horizontal badges) */}
      <div
        id="miniHistoryRowViewContainer"
        className="mini-history-scroll-slot flex gap-[6px] overflow-x-auto whitespace-nowrap no-scrollbar grow items-center"
      >
        {horizontal12History.map((item, idx) => {
          const displayName = item.roundName || item.roundId;
          const mult = Number(item.multiplier) || 1.00;
          return (
            <span
              key={`mini-slot-${idx}`}
              className={`mini-badge-item inline-block py-[4px] px-[10px] rounded-[12px] text-[11.5px] font-bold text-center min-w-[46px] shadow-[0_2px_4px_rgba(0,0,0,0.3)] select-none shrink-0 ${getMiniBadgeColorClass(
                mult
              )}`}
              title={`${displayName} — Crashed at ${mult.toFixed(2)}x`}
            >
              {mult.toFixed(2)}x
            </span>
          );
        })}
      </div>

      <button
        id="toggle-full-history-btn"
        type="button"
        onClick={() => setShowFullHistory((prev) => !prev)}
        title="Tap to view Full Round History"
        className={`shrink-0 flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border transition cursor-pointer ${
          showFullHistory
            ? 'bg-rose-600/20 border-rose-500/50 text-white shadow-[0_0_10px_rgba(244,63,94,0.25)]'
            : 'text-neutral-300 hover:text-white bg-[#22242a] hover:bg-[#2b2d35] border-[#2e313a]'
        }`}
      >
        <History className="w-3.5 h-3.5 text-rose-400" />
        <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${showFullHistory ? 'rotate-180 text-rose-400' : ''}`} />
      </button>

      {/* Top-Right Full History Popover */}
      {showFullHistory && (
        <div
          id="full-history-dropdown"
          className="round-history-modal history-popup history-panel absolute top-full right-2 mt-1.5 z-[9999] w-80 sm:w-96 max-w-[calc(100vw-20px)] bg-[#18191e] border border-[#323542] rounded-xl shadow-[0_12px_40px_rgba(0,0,0,0.85)] p-3 max-h-80 overflow-y-auto overflow-x-hidden"
          style={{ zIndex: 9999, position: 'absolute' }}
        >
          <div className="flex items-center justify-between border-b border-[#2a2d37] pb-2 mb-2.5">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-200 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>Round History</span>
            </span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-neutral-400 bg-[#22242c] px-1.5 py-0.5 rounded">
                Last {safeHistory.length} Rounds
              </span>
              <button
                type="button"
                onClick={() => setShowFullHistory(false)}
                className="text-neutral-400 hover:text-white p-0.5 rounded hover:bg-[#252830] transition cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-5 gap-1.5">
            {safeHistory.map((item, i) => {
              const displayName = item.roundName || item.roundId;
              const mult = Number(item.multiplier) || 1.00;
              return (
                <div
                  key={`full-${item.roundId}-${i}`}
                  className={`mini-badge-item py-1 px-1 rounded-[12px] text-[11px] font-bold text-center shadow-[0_2px_4px_rgba(0,0,0,0.3)] ${getMiniBadgeColorClass(
                    mult
                  )}`}
                  title={`${displayName} - ${mult.toFixed(2)}x`}
                >
                  {mult.toFixed(2)}x
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
