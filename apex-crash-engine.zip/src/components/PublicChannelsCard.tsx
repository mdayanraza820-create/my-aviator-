import React from 'react';
import { ExternalLink, ShieldCheck, Sparkles, Send } from 'lucide-react';

export interface TelegramChannelItem {
  name: string;
  subTitle?: string;
  handle: string;
  url: string;
  borderColor: string;
  actionText: string;
  badge?: string;
}

export const TELEGRAM_CHANNELS: TelegramChannelItem[] = [
  {
    name: '🤖 VIP Prediction Bot',
    subTitle: 'Ghost AI 7-Sec Signals',
    handle: '@Thakku67bot',
    url: 'https://t.me/Thakku67bot',
    borderColor: '#45f3ff',
    actionText: '@Thakku67bot ⏩',
    badge: 'LIVE BOT'
  },
  {
    name: '🎁 Free Loot & Codes',
    subTitle: 'Exclusive Daily Promo Drops',
    handle: '@flyloots',
    url: 'https://t.me/flyloots',
    borderColor: '#28a745',
    actionText: 'Join Channel ⏩',
    badge: 'FREE CODES'
  },
  {
    name: '💰 Free Live Deposit Logs',
    subTitle: 'Transparent Proof & Approvals',
    handle: '@winnovadeposit',
    url: 'https://t.me/winnovadeposit',
    borderColor: '#ffc107',
    actionText: 'View Trans ⏩',
    badge: 'TRANSPARENCY'
  },
  {
    name: '💼 Work & Earn Alpha',
    subTitle: 'Community Partner Network 77',
    handle: '@workandearn77',
    url: 'https://t.me/workandearn77',
    borderColor: '#e94560',
    actionText: 'Join Network ⏩',
    badge: 'ALPHA'
  },
  {
    name: '🚀 Work & Earn Elite',
    subTitle: 'VIP High Roller Syndicates 777',
    handle: '@workandearn777',
    url: 'https://t.me/workandearn777',
    borderColor: '#8a2be2',
    actionText: 'Join Network ⏩',
    badge: 'ELITE'
  }
];

interface PublicChannelsCardProps {
  compact?: boolean;
  className?: string;
}

export const PublicChannelsCard: React.FC<PublicChannelsCardProps> = ({ compact = false, className = '' }) => {
  return (
    <div
      className={`public-channels-card relative overflow-hidden transition-all duration-300 ${className}`}
      style={{
        background: '#1f2833',
        border: '2px solid #66fcf1',
        borderRadius: '12px',
        padding: compact ? '14px' : '20px',
        fontFamily: 'sans-serif',
        maxWidth: '520px',
        margin: '12px auto',
        boxShadow: '0 4px 20px rgba(102, 252, 241, 0.25)'
      }}
    >
      {/* Background glow element */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-[#66fcf1]/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header */}
      <div className="text-center mb-3">
        <h3
          className="m-0 font-bold tracking-wide flex items-center justify-center gap-1.5"
          style={{ color: '#66fcf1', fontSize: compact ? '16px' : '19px', letterSpacing: '1px' }}
        >
          <Send className="w-4 h-4 text-[#66fcf1]" />
          <span>📢 OUR OFFICIAL TELEGRAM NETWORKS</span>
        </h3>
        <p
          className="m-0 mt-1"
          style={{ color: '#8c92ac', fontSize: compact ? '11px' : '13px' }}
        >
          Join our official channels for real-time hacks, loot codes, and transparent live logs.
        </p>
      </div>

      {/* Channels List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: compact ? '9px' : '12px' }}>
        {TELEGRAM_CHANNELS.map((ch) => (
          <a
            key={ch.handle}
            href={ch.url}
            target="_blank"
            rel="noopener noreferrer"
            className="group hover:scale-[1.01] active:scale-[0.99] transition duration-150"
            style={{
              background: '#0f172a',
              color: '#fff',
              padding: compact ? '10px 12px' : '12px 14px',
              borderRadius: '8px',
              textDecoration: 'none',
              fontWeight: 'bold',
              borderLeft: `4px solid ${ch.borderColor}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              boxShadow: '0 2px 8px rgba(0,0,0,0.35)'
            }}
          >
            <div className="flex items-center gap-2">
              <span className="text-sm sm:text-base font-bold text-white group-hover:text-neutral-100">{ch.name}</span>
              {ch.badge && (
                <span
                  className="hidden sm:inline text-[9px] font-mono font-bold px-1.5 py-0.5 rounded"
                  style={{
                    background: `${ch.borderColor}22`,
                    color: ch.borderColor,
                    border: `1px solid ${ch.borderColor}55`
                  }}
                >
                  {ch.badge}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1 shrink-0 font-mono text-xs sm:text-sm font-bold" style={{ color: ch.borderColor }}>
              <span>{ch.actionText}</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-80 group-hover:translate-x-0.5 transition" />
            </div>
          </a>
        ))}
      </div>

      {/* Bottom Info note */}
      <div className="mt-3 pt-2.5 border-t border-[#313b47] flex items-center justify-between text-[11px] text-[#8c92ac]">
        <div className="flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Strict Anti-Forward & Bot Protection</span>
        </div>
        <div className="flex items-center gap-1 text-[#66fcf1] font-mono">
          <Sparkles className="w-3 h-3" />
          <span>7-Sec Signals Active</span>
        </div>
      </div>
    </div>
  );
};
