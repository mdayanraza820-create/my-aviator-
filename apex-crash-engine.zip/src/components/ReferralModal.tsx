import React, { useState, useEffect } from 'react';
import { User, ReferralStat } from '../types';
import { Gift, Copy, Check, Users, Percent, ShieldCheck, X } from 'lucide-react';

interface ReferralModalProps {
  isOpen: boolean;
  user: User;
  onClose: () => void;
}

export const ReferralModal: React.FC<ReferralModalProps> = ({
  isOpen,
  user,
  onClose
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [referralStats, setReferralStats] = useState<ReferralStat[]>([]);
  const [promoWallet, setPromoWallet] = useState<number>(user.promoWallet);
  const [totalReferrals, setTotalReferrals] = useState<number>(0);

  const inviteLink = `${window.location.origin}/?ref=${user.referralCode}`;

  useEffect(() => {
    if (isOpen) {
      fetchReferrals();
    }
  }, [isOpen, user.id]);

  const fetchReferrals = async () => {
    try {
      const res = await fetch(`/api/user/referrals?userId=${user.id}`);
      if (res.ok) {
        const data = await res.json();
        setReferralStats(data.referralList || []);
        setPromoWallet(data.promoWallet || 0);
        setTotalReferrals(data.totalReferrals || 0);
      }
    } catch {}
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(inviteLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(user.referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div id="referral-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md">
      <div
        id="referral-modal-container"
        className="w-full max-w-xl max-w-[calc(100vw-20px)] bg-[#18191d] border border-[#2d303b] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-[#141518] border-b border-[#262830]">
          <div className="flex items-center gap-2">
            <Gift className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-white font-['Chakra_Petch']">
              TWO-TIER REFERRAL & REBATE ENGINE
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-[#202229] hover:bg-[#2c2f38] text-neutral-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-3 sm:p-5 overflow-y-auto overflow-x-hidden flex-1 space-y-4">
          {/* Top 2-Tier Reward Architecture Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Tier 1: Instant Bonus */}
            <div className="bg-gradient-to-br from-[#1a1c22] to-[#24171a] border border-rose-500/30 rounded-xl p-3.5 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">
                    Tier 1: Instant Bounty
                  </span>
                  <span className="text-xs font-mono font-bold bg-rose-950 px-2 py-0.5 rounded text-rose-300 border border-rose-600/40">
                    ₹20 / Friend
                  </span>
                </div>
                <p className="text-[11px] text-neutral-300 leading-relaxed">
                  Earn ₹20 credited directly to your promotional wallet when your invited friend fulfills the first deposit requirement (min ₹100).
                </p>
              </div>
              <div className="mt-3 flex items-center gap-1.5 text-[10px] text-rose-300/80 font-mono">
                <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
                <span>Anti-fraud protected</span>
              </div>
            </div>

            {/* Tier 2: Lifetime 0.02% Rebate */}
            <div className="bg-gradient-to-br from-[#1a1c22] to-[#1c1826] border border-purple-500/30 rounded-xl p-3.5 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">
                    Tier 2: 0.02% Lifetime Rebate
                  </span>
                  <span className="text-xs font-mono font-bold bg-purple-950 px-2 py-0.5 rounded text-purple-300 border border-purple-600/40">
                    0.02% on every bet
                  </span>
                </div>
                <p className="text-[11px] text-neutral-300 leading-relaxed">
                  Every time your referred friend places a bet, 0.02% of the stake amount is credited to your wallet in real-time — whether they win or lose!
                </p>
              </div>
              <div className="mt-3 flex items-center gap-1.5 text-[10px] text-purple-300/80 font-mono">
                <Percent className="w-3.5 h-3.5 text-purple-400" />
                <span>Real-time server-side credit</span>
              </div>
            </div>
          </div>

          {/* User's Invite Token & Link */}
          <div className="bg-[#121316] border border-[#282a33] rounded-xl p-4 space-y-3">
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">
                Your Unique Invite Code
              </label>
              <div className="flex items-center justify-between bg-[#191b22] border border-[#2e313c] px-3 py-2 rounded-lg">
                <span className="font-mono font-black text-sm text-amber-400 tracking-wider">
                  {user.referralCode}
                </span>
                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1 text-xs font-bold text-neutral-300 hover:text-white bg-[#262833] hover:bg-[#323544] px-2.5 py-1 rounded transition"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Copied' : 'Copy Code'}</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">
                Direct Invite Link
              </label>
              <div className="flex items-center justify-between bg-[#191b22] border border-[#2e313c] px-3 py-2 rounded-lg">
                <span className="font-mono text-xs text-neutral-300 truncate max-w-[280px]">
                  {inviteLink}
                </span>
                <button
                  onClick={handleCopyLink}
                  className="flex items-center gap-1 text-xs font-bold text-neutral-300 hover:text-white bg-[#262833] hover:bg-[#323544] px-2.5 py-1 rounded transition"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedLink ? 'Copied' : 'Copy Link'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#121316] border border-[#282a33] p-3 rounded-xl">
              <span className="text-[11px] text-neutral-400">Total Referred Friends</span>
              <div className="text-xl font-bold font-mono text-white mt-0.5">
                {totalReferrals}
              </div>
            </div>

            <div className="bg-[#121316] border border-[#282a33] p-3 rounded-xl">
              <span className="text-[11px] text-neutral-400">Promo / Rebate Wallet</span>
              <div className="text-xl font-bold font-mono text-purple-400 mt-0.5">
                ₹{promoWallet.toFixed(2)}
              </div>
            </div>
          </div>

          {/* Referred Users Ledger */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-amber-400" />
                <span>Referred Friends Activity</span>
              </h4>
              <span className="text-[10px] text-neutral-400">{referralStats.length} records</span>
            </div>

            {referralStats.length === 0 ? (
              <div className="bg-[#121316] border border-[#262830] p-6 rounded-xl text-center text-xs text-neutral-400">
                Share your invite code with friends to start earning instant bounties and 0.02% betting rebates!
              </div>
            ) : (
              <div className="bg-[#121316] border border-[#262830] rounded-xl overflow-hidden divide-y divide-[#202228]">
                {referralStats.map((ref, idx) => (
                  <div key={idx} className="p-2.5 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-white">{ref.userName}</div>
                      <div className="text-[10px] font-mono text-neutral-400">
                        {ref.userPhone}
                      </div>
                    </div>
                    <div className="text-right space-y-0.5">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${
                          ref.instantBonusStatus === 'RELEASED'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-600/40'
                            : 'bg-amber-950 text-amber-400 border border-amber-600/40'
                        }`}
                      >
                        {ref.instantBonusStatus === 'RELEASED' ? '₹20 Released' : '₹20 Pending 1st Deposit'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
