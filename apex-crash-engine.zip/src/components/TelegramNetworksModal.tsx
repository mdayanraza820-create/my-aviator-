import React, { useState } from 'react';
import { X, Send, Bot, ShieldCheck, Play, Lock, CheckCircle2, RefreshCw, Zap } from 'lucide-react';
import { PublicChannelsCard } from './PublicChannelsCard';

interface TelegramNetworksModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SimulatorMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  time: string;
  multiplier?: string;
  isProtected?: boolean;
}

// 🔮 Smart Fluctuation Masking (Isse numbers ekdum real-looking lagenge)
function applySmartIllusion(rawX: number | string): string {
  const parsed = parseFloat(String(rawX));
  if (isNaN(parsed)) return '2.14x';
  if (parsed > 10.0) {
    return (parsed - (Math.random() * 0.15)).toFixed(2) + 'x';
  }
  return parsed.toFixed(2) + 'x';
}

export const TelegramNetworksModal: React.FC<TelegramNetworksModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'networks' | 'simulator'>('networks');
  const [simulatorCredits, setSimulatorCredits] = useState<number>(10);
  const [loadingSignal, setLoadingSignal] = useState<boolean>(false);
  const [messages, setMessages] = useState<SimulatorMessage[]>([
    {
      id: 'm1',
      sender: 'user',
      text: '/start',
      time: 'Just now'
    },
    {
      id: 'm2',
      sender: 'bot',
      text: '⚡ GHOST VIP PREDICTOR ENGINE ACTIVE ⚡\n\n🎁 Welcome Pack: 10 Free Credits Active.\n📊 Available Quota: 10 Credits\n\n🔒 Security parameters applied. Content copying, direct message forwarding, or saving signals is completely blocked by system firewall.',
      time: 'Just now',
      isProtected: true
    }
  ]);

  if (!isOpen) return null;

  const handleRunStart = async () => {
    try {
      const res = await fetch('/api/telegram/test-start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chatId: 999999999, firstName: 'Player' })
      });
      const data = await res.json();
      if (data.success) {
        setSimulatorCredits(data.user?.credits ?? 10);
        setMessages(prev => [
          ...prev,
          { id: 'm_' + Date.now(), sender: 'user', text: '/start', time: new Date().toLocaleTimeString() },
          {
            id: 'm_bot_' + Date.now(),
            sender: 'bot',
            text: `⚡ GHOST VIP PREDICTOR ENGINE ACTIVE ⚡\n\n🎁 Welcome Pack: 10 Free Credits Active.\n📊 Available Quota: ${data.user?.credits ?? 10} Credits\n\n🔒 Anti-Forward Content Protection: ACTIVE`,
            time: new Date().toLocaleTimeString(),
            isProtected: true
          }
        ]);
      }
    } catch {
      setMessages(prev => [
        ...prev,
        { id: 'm_' + Date.now(), sender: 'user', text: '/start', time: new Date().toLocaleTimeString() },
        {
          id: 'm_bot_' + Date.now(),
          sender: 'bot',
          text: `⚡ GHOST VIP PREDICTOR ENGINE ACTIVE ⚡\n\n🎁 Welcome Pack: 10 Free Credits Active.\n📊 Available Quota: ${simulatorCredits} Credits`,
          time: new Date().toLocaleTimeString(),
          isProtected: true
        }
      ]);
    }
  };

  const handleFetchSignal = async () => {
    if (loadingSignal) return;
    if (simulatorCredits <= 0) {
      setMessages(prev => [
        ...prev,
        { id: 'm_' + Date.now(), sender: 'user', text: '🚀 Fetch Signal (7 Seconds Advance)', time: new Date().toLocaleTimeString() },
        { id: 'm_bot_' + Date.now(), sender: 'bot', text: '❌ Zero Credits Available! Please recharge via UPI or VIP pass.', time: new Date().toLocaleTimeString() }
      ]);
      return;
    }

    setLoadingSignal(true);
    setMessages(prev => [
      ...prev,
      { id: 'm_' + Date.now(), sender: 'user', text: '🚀 Fetch Signal (7 Seconds Advance)', time: new Date().toLocaleTimeString() },
      { id: 'm_bot_load_' + Date.now(), sender: 'bot', text: '⏳ Connecting to Google AI Studio Live Stream Matrix...', time: new Date().toLocaleTimeString() }
    ]);

    try {
      const res = await fetch('/api/telegram/test-signal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chatId: 999999999 })
      });
      const data = await res.json();
      if (data.success) {
        setSimulatorCredits(data.remainingCredits ?? (simulatorCredits - 1));
        const maskedMult = data.multiplier.endsWith('x') ? data.multiplier : applySmartIllusion(data.multiplier);
        setTimeout(() => {
          setMessages(prev => [
            ...prev,
            {
              id: 'm_sig_' + Date.now(),
              sender: 'bot',
              text: `🔮 GHOST GOOGLE AI LIVE SIGNAL 🔮\n⏱️ [ Dispatched exactly 7 seconds before takeoff ]\n────────────────────────\n📈 TARGET VALUE: ${maskedMult}\n🎯 AI CONFIDENCE LEVEL: 99.6% Stable\n────────────────────────\n📉 Remaining Balance: ${data.remainingCredits} Loops left`,
              multiplier: maskedMult,
              time: new Date().toLocaleTimeString(),
              isProtected: true
            }
          ]);
          setLoadingSignal(false);
        }, 1200);
      } else {
        setLoadingSignal(false);
      }
    } catch {
      const fallbackRaw = (Math.random() * (9.5 - 1.2) + 1.2).toFixed(2);
      const fallbackMult = applySmartIllusion(fallbackRaw);
      setSimulatorCredits(prev => Math.max(0, prev - 1));
      setTimeout(() => {
        setMessages(prev => [
          ...prev,
          {
            id: 'm_sig_' + Date.now(),
            sender: 'bot',
            text: `🔮 GHOST GOOGLE AI LIVE SIGNAL 🔮\n⏱️ [ Dispatched exactly 7 seconds before takeoff ]\n────────────────────────\n📈 TARGET VALUE: ${fallbackMult}\n🎯 AI CONFIDENCE: 99.6% Stable\n────────────────────────`,
            multiplier: fallbackMult,
            time: new Date().toLocaleTimeString(),
            isProtected: true
          }
        ]);
        setLoadingSignal(false);
      }, 1200);
    }
  };

  return (
    <div
      id="telegram-networks-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="telegram-networks-modal-container"
        className="w-full max-w-lg max-w-[calc(100vw-20px)] max-h-[90vh] bg-[#141519] border-2 border-[#66fcf1]/80 rounded-2xl shadow-[0_0_50px_rgba(102,252,241,0.25)] overflow-hidden flex flex-col relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gradient-to-r from-[#0f172a] via-[#1a2333] to-[#0f172a] border-b border-[#313e4e]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#0088cc] flex items-center justify-center text-white shadow-[0_0_12px_rgba(0,136,204,0.6)]">
              <Send className="w-4 h-4 -rotate-12 translate-x-0.5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white font-['Chakra_Petch'] tracking-wide">
                  OFFICIAL TELEGRAM HUB
                </h3>
                <span className="text-[10px] font-mono uppercase bg-[#66fcf1]/20 text-[#66fcf1] border border-[#66fcf1]/40 px-2 py-0.5 rounded-full font-bold">
                  Verified
                </span>
              </div>
              <span className="text-[10px] text-neutral-400 font-mono">
                Real-time signals, deposit proof ledger & exclusive loots
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-[#1e2430] hover:bg-[#2b3345] text-neutral-300 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center border-b border-[#252f3e] bg-[#0c1017] px-3 pt-2">
          <button
            type="button"
            onClick={() => setActiveTab('networks')}
            className={`flex-1 py-2 text-xs font-bold font-['Chakra_Petch'] transition flex items-center justify-center gap-1.5 border-b-2 ${
              activeTab === 'networks'
                ? 'text-[#66fcf1] border-[#66fcf1] bg-[#1a2333]/50'
                : 'text-neutral-400 border-transparent hover:text-neutral-200'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>Official Networks</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('simulator')}
            className={`flex-1 py-2 text-xs font-bold font-['Chakra_Petch'] transition flex items-center justify-center gap-1.5 border-b-2 ${
              activeTab === 'simulator'
                ? 'text-[#45f3ff] border-[#45f3ff] bg-[#1a2333]/50'
                : 'text-neutral-400 border-transparent hover:text-neutral-200'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            <span>🤖 /start Live Simulator</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto max-h-[75vh] space-y-4">
          {activeTab === 'networks' ? (
            <>
              {/* Exact User Requested Card */}
              <PublicChannelsCard />

              {/* Quick instructions for players */}
              <div className="bg-[#12161f] border border-[#2b3545] rounded-xl p-3.5 space-y-2 text-xs text-neutral-300">
                <div className="flex items-center gap-2 text-[#66fcf1] font-bold font-mono">
                  <Bot className="w-4 h-4" />
                  <span>HOW TO USE THE VIP PREDICTION BOT:</span>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-neutral-400 text-[11px] leading-relaxed">
                  <li>Open <a href="https://t.me/Thakku67bot" target="_blank" rel="noopener noreferrer" className="text-[#66fcf1] underline font-bold">@Thakku67bot</a> on Telegram and tap <b>/start</b>.</li>
                  <li>Verify membership in all 4 mandatory community channels to unlock the bot.</li>
                  <li>Get <b>10 Free Premium Signals</b> delivered 7 seconds before every round takes off!</li>
                  <li>Upload deposit screenshots directly to the bot for instant automated VIP credit top-up.</li>
                </ol>
              </div>
            </>
          ) : (
            /* Simulator Tab */
            <div className="space-y-3">
              <div className="bg-[#0f172a] border border-[#334155] rounded-xl p-3 flex items-center justify-between text-xs font-mono">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-white font-bold">Bot: @Thakku67bot</span>
                </div>
                <div className="flex items-center gap-1.5 text-[#45f3ff]">
                  <Zap className="w-3.5 h-3.5" />
                  <span>Credits: {simulatorCredits}</span>
                </div>
              </div>

              {/* Chat Window */}
              <div className="bg-[#0b0e14] border border-[#1e293b] rounded-xl p-3 h-64 overflow-y-auto space-y-2.5 text-xs">
                {messages.map((m) => (
                  <div
                    key={m.id}
                    className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-lg p-2.5 whitespace-pre-wrap ${
                        m.sender === 'user'
                          ? 'bg-[#0088cc] text-white'
                          : 'bg-[#1e293b] border border-[#334155] text-neutral-200'
                      }`}
                    >
                      {m.isProtected && (
                        <div className="flex items-center gap-1 text-[10px] text-amber-400 font-mono mb-1">
                          <Lock className="w-3 h-3" />
                          <span>Protected Message (Anti-Forward Lock)</span>
                        </div>
                      )}
                      <div>{m.text}</div>
                      {m.multiplier && (
                        <div className="mt-2 text-center py-1.5 bg-[#0f172a] border border-[#45f3ff]/40 rounded font-mono font-black text-base text-[#45f3ff]">
                          🚀 {m.multiplier}x
                        </div>
                      )}
                    </div>
                    <span className="text-[9px] text-neutral-500 mt-0.5 px-1">{m.time}</span>
                  </div>
                ))}
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleRunStart}
                  className="py-2 px-3 bg-[#1e293b] hover:bg-[#334155] text-white border border-[#475569] rounded-lg text-xs font-mono font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-[#66fcf1]" />
                  <span>Run /start</span>
                </button>
                <button
                  type="button"
                  onClick={handleFetchSignal}
                  disabled={loadingSignal}
                  className="py-2 px-3 bg-gradient-to-r from-[#0088cc] to-[#00b4d8] hover:from-[#0099e6] hover:to-[#48cae4] text-white rounded-lg text-xs font-mono font-bold flex items-center justify-center gap-1.5 shadow-md cursor-pointer disabled:opacity-50"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{loadingSignal ? 'Calculating...' : '🚀 Fetch 7-Sec Signal'}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-[#0d1017] border-t border-[#252f3e] flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-neutral-400 font-mono text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Official Win Nova Network</span>
          </div>

          <a
            href="https://t.me/Thakku67bot"
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-1.5 bg-gradient-to-r from-[#0088cc] to-[#00b4d8] hover:from-[#0099e6] hover:to-[#48cae4] text-white font-bold text-xs rounded-lg shadow-md transition flex items-center gap-1.5"
          >
            <span>Open Bot @Thakku67bot</span>
            <Send className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
};

