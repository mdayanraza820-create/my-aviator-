import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Smartphone, Share, PlusSquare, X } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, promptInstall } = usePWAInstall();
  const [showIosGuide, setShowIosGuide] = useState(false);

  // Detect iOS Safari
  const isIos =
    typeof navigator !== 'undefined' &&
    /iPad|iPhone|iPod/.test(navigator.userAgent) &&
    !(window as any).MSStream;

  if (isInstalled) return null;

  const handleClick = async () => {
    if (isInstallable) {
      await promptInstall();
    } else if (isIos) {
      setShowIosGuide(true);
    } else {
      // Prompt user or inform them
      alert('To install WIN NOVA: Open your browser menu (⋮) and select "Install app" or "Add to Home Screen".');
    }
  };

  return (
    <>
      <button
        id="pwa-install-header-btn"
        onClick={handleClick}
        className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold rounded-lg bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white shadow-[0_0_12px_rgba(225,29,72,0.35)] transition cursor-pointer border border-rose-400/40 animate-pulse"
        title="Install WIN NOVA App for Ultra Low Latency"
      >
        <Smartphone className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">Install App</span>
        <span className="sm:hidden">App</span>
      </button>

      {/* iOS Safari Installation Guide Modal */}
      {showIosGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#18191d] border border-[#2d303b] rounded-2xl p-5 max-w-sm w-full text-white shadow-2xl relative">
            <button
              onClick={() => setShowIosGuide(false)}
              className="absolute top-3 right-3 p-1 rounded text-neutral-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2 mb-3">
              <div className="p-2 rounded-xl bg-rose-600/20 text-rose-400 border border-rose-500/30">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm">Install on iPhone / iPad</h3>
                <p className="text-[11px] text-neutral-400">Play in full-screen standalone mode</p>
              </div>
            </div>

            <div className="space-y-2.5 text-xs text-neutral-300">
              <div className="flex items-start gap-2 bg-[#121316] p-2.5 rounded-lg border border-[#252830]">
                <Share className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <span>1. Tap the <strong>Share</strong> button at the bottom of Safari.</span>
              </div>

              <div className="flex items-start gap-2 bg-[#121316] p-2.5 rounded-lg border border-[#252830]">
                <PlusSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>2. Scroll down and select <strong>"Add to Home Screen"</strong>.</span>
              </div>

              <div className="flex items-start gap-2 bg-[#121316] p-2.5 rounded-lg border border-[#252830]">
                <Download className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>3. Tap <strong>Add</strong> in the top-right corner to launch WIN NOVA.</span>
              </div>
            </div>

            <button
              onClick={() => setShowIosGuide(false)}
              className="w-full mt-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </>
  );
};
