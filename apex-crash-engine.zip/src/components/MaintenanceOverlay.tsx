import React from 'react';
import { ShieldAlert, RefreshCw, Lock, Database, Clock } from 'lucide-react';

interface MaintenanceOverlayProps {
  active: boolean;
}

export const MaintenanceOverlay: React.FC<MaintenanceOverlayProps> = ({ active }) => {
  if (!active) return null;

  return (
    <div
      id="system-maintenance-overlay"
      className="w-full bg-[#16171d]/95 border-2 border-amber-500/40 rounded-2xl p-4 sm:p-5 shadow-2xl backdrop-blur-md relative overflow-hidden my-3 animate-in fade-in duration-300"
    >
      {/* Top Accent Strip */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 animate-pulse" />

      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 shrink-0">
            <ShieldAlert className="w-6 h-6 animate-pulse" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-bold text-white font-['Chakra_Petch'] tracking-wide">
                SCHEDULED SERVER INFRASTRUCTURE UPGRADE
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/25 border border-amber-500/40 text-amber-300 font-bold text-[10px] uppercase font-mono">
                Maintenance Mode
              </span>
            </div>

            <p className="text-xs text-neutral-300 mt-1 max-w-2xl leading-relaxed">
              Platform security clustering is currently undergoing scheduled latency optimization. 
              <strong className="text-amber-300"> New bets are temporarily suspended</strong>, but all historical outcome logs, wallet balances, and cashier ledgers remain securely stored and accessible.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 self-stretch md:self-auto justify-end">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1f212a] border border-[#2e313d] text-[11px] text-neutral-300 font-mono">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span>Funds Preserved</span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1f212a] border border-[#2e313d] text-[11px] text-neutral-300 font-mono">
            <Database className="w-3.5 h-3.5 text-cyan-400" />
            <span>Read-Only Graph Active</span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-950/40 border border-amber-500/30 text-[11px] text-amber-300 font-mono">
            <Clock className="w-3.5 h-3.5 animate-spin" />
            <span>Resuming Shortly</span>
          </div>
        </div>
      </div>
    </div>
  );
};
