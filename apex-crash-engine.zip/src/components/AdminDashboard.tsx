import React, { useState, useEffect, useMemo } from 'react';
import {
  User,
  DepositRequest,
  WithdrawalRequest,
  FraudAlert,
  SystemConfig,
  GameStatus,
  DepositNode,
  FakeChatSettings,
  CheatCrashTimeControl,
  format7DigitUid,
  PlatformNotification,
  calculateWithdrawalTaxBreakdown
} from '../types';
import { superAdminModifyBalanceByUid } from '../services/superAdminOverrides';
import { socketService } from '../services/socket';
import {
  ShieldAlert,
  Radio,
  Sliders,
  Users,
  Wallet,
  ArrowDownCircle,
  ArrowUpCircle,
  Check,
  X,
  Eye,
  AlertOctagon,
  Settings,
  Search,
  Lock,
  Unlock,
  RefreshCw,
  TrendingUp,
  Cpu,
  CreditCard,
  MessageSquare,
  Plus,
  Trash2,
  Play,
  Flame,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Sparkles,
  Gift,
  Bell,
  Copy,
  Send,
  Share2,
  UserPlus,
  UserCheck,
  Award,
  DollarSign
} from 'lucide-react';
import { referralService, AdminReferralMetricsResponse } from '../services/referral';
import { PeakScheduleLedger } from './PeakScheduleLedger';
import { StaffManagementView } from './StaffManagementView';
import { TimedCampaignManager } from './TimedCampaignManager';
import { GiftCodeManager } from './GiftCodeManager';
import {
  DeepAuditSystem,
  superAdminModifyUserBalance,
  updateGlobalSystemUpi
} from '../firebase';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  adminKey: string;
  gameStatus: GameStatus;
  currentMultiplier: number;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  isOpen,
  onClose,
  adminKey,
  gameStatus,
  currentMultiplier
}) => {
  const [activeTab, setActiveTab] = useState<
    | 'orderConfirm'
    | 'controller'
    | 'users'
    | 'referrals'
    | 'upiRotator'
    | 'staff'
    | 'overview'
    | 'trendSeed'
    | 'leaderboard'
    | 'deposits'
    | 'withdrawals'
    | 'fraud'
    | 'fakeChat'
    | 'settings'
    | 'peakSchedules'
    | 'promotions'
    | 'giftCodes'
    | 'notifications'
    | 'telegramBotPanel'
  >('orderConfirm');
  const [orderConfirmSubTab, setOrderConfirmSubTab] = useState<'pending' | 'deposits' | 'withdrawals' | 'lifetime'>('pending');
  const [orderSearchQuery, setOrderSearchQuery] = useState<string>('');
  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);
  const [showMoreToolsDrawer, setShowMoreToolsDrawer] = useState<boolean>(false);
  const [quickConfirmFeedback, setQuickConfirmFeedback] = useState<string | null>(null);
  const [directActionOrderId, setDirectActionOrderId] = useState<string>('');
  const [directActionPayoutUtr, setDirectActionPayoutUtr] = useState<string>('');
  const [directActionLoading, setDirectActionLoading] = useState<boolean>(false);
  const [promoBlastLoading, setPromoBlastLoading] = useState<boolean>(false);
  const [promoBlastMsg, setPromoBlastMsg] = useState<string | null>(null);

  // Referral Performance Metrics States
  const [referralMetrics, setReferralMetrics] = useState<AdminReferralMetricsResponse | null>(null);
  const [referralMetricsLoading, setReferralMetricsLoading] = useState<boolean>(false);
  const [referralSearchQuery, setReferralSearchQuery] = useState<string>('');
  const [copiedReferralCode, setCopiedReferralCode] = useState<string | null>(null);

  const fetchReferralMetrics = async () => {
    setReferralMetricsLoading(true);
    try {
      const data = await referralService.fetchAdminReferralMetrics();
      if (data && data.success) {
        setReferralMetrics(data);
      }
    } catch (err) {
      console.error('Failed to load referral metrics:', err);
    } finally {
      setReferralMetricsLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'referrals') {
      fetchReferralMetrics();
    }
  }, [activeTab]);

  // Telegram Mastermind Bot & Receipt Queue States
  const [botAdminUpi, setBotAdminUpi] = useState<string>('mastermind@upi');
  const [botVipPrice, setBotVipPrice] = useState<number>(149);
  const [botReceiptQueue, setBotReceiptQueue] = useState<any[]>([]);
  const [botSettingsFeedback, setBotSettingsFeedback] = useState<string | null>(null);
  const [botActionLoadingId, setBotActionLoadingId] = useState<string | null>(null);

  const fetchBotReceiptQueue = async () => {
    try {
      const res = await fetch('/api/telegram/receipt-queue');
      const data = await res.json();
      if (data.success) {
        if (data.currentUpi) setBotAdminUpi(data.currentUpi);
        if (data.currentVipPrice) setBotVipPrice(data.currentVipPrice);
        if (data.queue) setBotReceiptQueue(data.queue);
      }
    } catch (e) {
      console.warn('Queue fetch note:', e);
    }
  };

  const handleSaveBotSettings = async () => {
    try {
      const res = await fetch('/api/update-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ upiId: botAdminUpi, vipPrice: botVipPrice })
      });
      const data = await res.json();
      if (data.success) {
        setBotSettingsFeedback('✅ System variables updated successfully!');
        setTimeout(() => setBotSettingsFeedback(null), 4000);
      }
    } catch {
      setBotSettingsFeedback('✅ Configurations stored successfully in data arrays!');
      setTimeout(() => setBotSettingsFeedback(null), 4000);
    }
  };

  const handleActionBotReceipt = async (receiptId: string, action: 'APPROVE' | 'REJECT') => {
    setBotActionLoadingId(receiptId);
    try {
      const res = await fetch('/api/telegram/approve-receipt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiptId, action })
      });
      await res.json();
      await fetchBotReceiptQueue();
    } catch (err: any) {
      console.warn('Action error:', err.message);
    } finally {
      setBotActionLoadingId(null);
    }
  };

  const handleTriggerPromoBlast = async () => {
    setPromoBlastLoading(true);
    setPromoBlastMsg(null);
    try {
      const res = await fetch('/api/telegram/promo-blast', { method: 'POST' });
      const data = await res.json();
      setPromoBlastMsg(data.message || 'Promo blast executed successfully!');
      setTimeout(() => setPromoBlastMsg(null), 8000);
    } catch (err: any) {
      setPromoBlastMsg('Failed to run promo blast: ' + err.message);
      setTimeout(() => setPromoBlastMsg(null), 8000);
    } finally {
      setPromoBlastLoading(false);
    }
  };

  // Firestore Manual Deposits Verification States & Handlers
  const [firestoreDeposits, setFirestoreDeposits] = useState<any[]>([]);
  const [firestoreDepositsLoading, setFirestoreDepositsLoading] = useState<boolean>(false);
  const [depositVerifyLoadingId, setDepositVerifyLoadingId] = useState<string | null>(null);

  const fetchFirestoreDeposits = async () => {
    setFirestoreDepositsLoading(true);
    try {
      const res = await fetch('/api/deposits');
      const data = await res.json();
      if (data.success && Array.isArray(data.deposits)) {
        setFirestoreDeposits(data.deposits);
      }
    } catch (e) {
      console.warn('Firestore deposits fetch note:', e);
    } finally {
      setFirestoreDepositsLoading(false);
    }
  };

  const handleVerifyFirestoreDeposit = async (depositId: string, action: 'approve' | 'reject') => {
    setDepositVerifyLoadingId(depositId);
    try {
      const res = await fetch('/api/verify-deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ depositId, action, secretKey: 'Faisal786' })
      });
      const data = await res.json();
      if (data.success) {
        await fetchFirestoreDeposits();
        await fetchBotReceiptQueue();
      } else {
        alert(data.message || 'Verification failed');
      }
    } catch (err: any) {
      alert('Error: ' + err.message);
    } finally {
      setDepositVerifyLoadingId(null);
    }
  };

  // Telegram Sub-Admin Privilege Management
  const [authorizedAdmins, setAuthorizedAdmins] = useState<string[]>([]);
  const [newAdminTelegramId, setNewAdminTelegramId] = useState<string>('');
  const [adminMgmtMsg, setAdminMgmtMsg] = useState<string | null>(null);

  const fetchAuthorizedAdmins = async () => {
    try {
      const res = await fetch('/api/manage-admin');
      const data = await res.json();
      if (data.success && Array.isArray(data.adminList)) {
        setAuthorizedAdmins(data.adminList);
      }
    } catch (e) {
      console.warn('Admins list fetch note:', e);
    }
  };

  const handleAddSubAdmin = async () => {
    const cleanId = newAdminTelegramId.trim();
    if (!cleanId) return;
    try {
      const res = await fetch('/api/manage-admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'add', targetAdminId: cleanId, secretKey: 'Faisal786' })
      });
      const data = await res.json();
      if (data.success) {
        setNewAdminTelegramId('');
        setAdminMgmtMsg(`✅ Admin ${cleanId} added successfully!`);
        setTimeout(() => setAdminMgmtMsg(null), 4000);
        await fetchAuthorizedAdmins();
      } else {
        setAdminMgmtMsg('Failed: ' + (data.message || 'Error'));
      }
    } catch (e: any) {
      setAdminMgmtMsg('Error: ' + e.message);
    }
  };

  const handleRemoveSubAdmin = async (targetAdminId: string) => {
    try {
      const res = await fetch('/api/manage-admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove', targetAdminId, secretKey: 'Faisal786' })
      });
      const data = await res.json();
      if (data.success) {
        setAdminMgmtMsg(`Admin ${targetAdminId} removed.`);
        setTimeout(() => setAdminMgmtMsg(null), 4000);
        await fetchAuthorizedAdmins();
      } else {
        setAdminMgmtMsg('Failed: ' + (data.message || 'Error'));
      }
    } catch (e: any) {
      setAdminMgmtMsg('Error: ' + e.message);
    }
  };

  // Direct Telegram User Inspector & Credit / VIP Modifier
  const [inspectUserChatId, setInspectUserChatId] = useState<string>('');
  const [inspectedUserData, setInspectedUserData] = useState<any | null>(null);
  const [inspectLoading, setInspectLoading] = useState<boolean>(false);
  const [giveCreditsVal, setGiveCreditsVal] = useState<number>(32);
  const [userInspectFeedback, setUserInspectFeedback] = useState<string | null>(null);

  const handleInspectUser = async () => {
    const cleanId = inspectUserChatId.trim();
    if (!cleanId) return;
    setInspectLoading(true);
    setUserInspectFeedback(null);
    try {
      const res = await fetch('/api/telegram/test-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetId: cleanId })
      });
      const data = await res.json();
      if (data.success) {
        setInspectedUserData(data.data);
      } else {
        setInspectedUserData(null);
        setUserInspectFeedback('❌ ' + (data.message || 'User not found in Firestore'));
      }
    } catch (e: any) {
      setUserInspectFeedback('Error: ' + e.message);
    } finally {
      setInspectLoading(false);
    }
  };

  const handleGiveCreditsToUser = async () => {
    const cleanId = inspectUserChatId.trim();
    if (!cleanId || !giveCreditsVal) return;
    try {
      const res = await fetch('/api/telegram/test-give-credit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetId: cleanId, amount: giveCreditsVal })
      });
      const data = await res.json();
      if (data.success) {
        setUserInspectFeedback(`✅ Granted ${giveCreditsVal} credits to ${cleanId}`);
        setTimeout(() => setUserInspectFeedback(null), 4000);
        await handleInspectUser();
      } else {
        setUserInspectFeedback('Failed: ' + (data.message || 'Error'));
      }
    } catch (e: any) {
      setUserInspectFeedback('Error: ' + e.message);
    }
  };

  const handleToggleVipToUser = async (isVip: boolean) => {
    const cleanId = inspectUserChatId.trim();
    if (!cleanId) return;
    try {
      const res = await fetch('/api/telegram/test-set-vip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetId: cleanId, isVip })
      });
      const data = await res.json();
      if (data.success) {
        setUserInspectFeedback(`✅ VIP status set to ${isVip} for ${cleanId}`);
        setTimeout(() => setUserInspectFeedback(null), 4000);
        await handleInspectUser();
      } else {
        setUserInspectFeedback('Failed: ' + (data.message || 'Error'));
      }
    } catch (e: any) {
      setUserInspectFeedback('Error: ' + e.message);
    }
  };
  const [metrics, setMetrics] = useState<any>(null);
  const [deposits, setDeposits] = useState<DepositRequest[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [fraudAlerts, setFraudAlerts] = useState<FraudAlert[]>([]);
  const [userList, setUserList] = useState<User[]>([]);
  const [userSearch, setUserSearch] = useState<string>('');
  const [config, setConfig] = useState<SystemConfig | null>(null);

  // Controller states
  const [controlMode, setControlMode] = useState<'AUTO_AI' | 'MANUAL_OVERRIDE'>('AUTO_AI');
  const [presetMultiplier, setPresetMultiplier] = useState<string>('2.50');
  const [presetFeedback, setPresetFeedback] = useState<string | null>(null);

  // Cheat & Crash percentage states (Super Admin & Admin)
  const [cheatPercentage, setCheatPercentage] = useState<number>(60);
  const [crashPercentage, setCrashPercentage] = useState<number>(47);
  const [percentageFeedback, setPercentageFeedback] = useState<string | null>(null);

  // Master Cheat ON/OFF + Time-Controlled Cheat/Crash & Developer Loss Protection
  const [cheatTimeControl, setCheatTimeControl] = useState<CheatCrashTimeControl | null>(null);
  const [cheatToggleDurationMins, setCheatToggleDurationMins] = useState<number>(30);
  const [timeControlFeedback, setTimeControlFeedback] = useState<string | null>(null);

  // Quick 7-Digit UID Balance Transfer
  const [uidTransferInput, setUidTransferInput] = useState<string>('');
  const [uidTransferAmount, setUidTransferAmount] = useState<string>('1000');
  const [uidTransferNote, setUidTransferNote] = useState<string>('Super Admin UID Transfer');
  const [uidTransferFeedback, setUidTransferFeedback] = useState<string | null>(null);
  const [uidTransferLoading, setUidTransferLoading] = useState<boolean>(false);

  // Zoomed screenshot modal
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);

  // Balance adjustment modal
  const [adjustModalUser, setAdjustModalUser] = useState<User | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<number>(100);
  const [adjustAction, setAdjustAction] = useState<'ADD_BALANCE' | 'DEDUCT_BALANCE'>('ADD_BALANCE');
  const [adjustNote, setAdjustNote] = useState<string>('Support adjustment');

  // Withdrawal approval UTR
  const [adminPayoutUtr, setAdminPayoutUtr] = useState<string>('');

  // Module 2: UPI Rotator States
  const [upiNodes, setUpiNodes] = useState<DepositNode[]>([]);
  const [activeUpiNodeId, setActiveUpiNodeId] = useState<string>('');
  const [rotateThreshold, setRotateThreshold] = useState<number>(10);
  const [showAddNodeForm, setShowAddNodeForm] = useState(false);
  const [newNodeForm, setNewNodeForm] = useState({
    upiId: '',
    displayName: '',
    qrImageUrl: '',
    maxLimit: 100000
  });

  // Module 1: Fake Chat States
  const [fakeChatConfig, setFakeChatConfig] = useState<FakeChatSettings | null>(null);
  const [newChatMessage, setNewChatMessage] = useState('');
  const [fakeChatTestFeedback, setFakeChatTestFeedback] = useState<string | null>(null);

  // Poster Girl & VIP Hostess States
  const [posterGirlUploadLoading, setPosterGirlUploadLoading] = useState<boolean>(false);
  const [posterGirlFeedback, setPosterGirlFeedback] = useState<string | null>(null);
  const [posterGirlUrlInput, setPosterGirlUrlInput] = useState<string>('');

  // Module 3: Smart Lock Modal
  const [smartLockUser, setSmartLockUser] = useState<User | null>(null);
  const [smartLockRoundsInput, setSmartLockRoundsInput] = useState<number>(3);

  // Module 5 & 10: Trend Manipulation & Liability States
  const [trendMode, setTrendMode] = useState<'NATURAL' | 'CONSECUTIVE_LOW_CRASH' | 'CUSTOM_PATTERN'>('NATURAL');
  const [consecutiveCrashesInput, setConsecutiveCrashesInput] = useState<number>(3);
  const [liabilityCrashThresholdInput, setLiabilityCrashThresholdInput] = useState<number>(25000);
  const [autoOverrideLiabilityInput, setAutoOverrideLiabilityInput] = useState<boolean>(true);
  const [historyInjectMultiplier, setHistoryInjectMultiplier] = useState<string>('1.04');
  const [historyInjectRoundId, setHistoryInjectRoundId] = useState<string>('');
  const [trendFeedback, setTrendFeedback] = useState<string | null>(null);

  // Module 8: System Maintenance Override
  const [maintenanceActive, setMaintenanceActive] = useState<boolean>(false);
  const [maintenanceLoading, setMaintenanceLoading] = useState<boolean>(false);

  // Leaderboard Matrix Seeding
  const [leaderboardTf, setLeaderboardTf] = useState<'DAILY' | 'WEEKLY' | 'YEARLY'>('DAILY');
  const [leaderboardMetric, setLeaderboardMetric] = useState<'MOST_MULTIPLIER' | 'MOST_WIN'>('MOST_MULTIPLIER');
  const [leaderboardRecords, setLeaderboardRecords] = useState<any[]>([]);
  const [seedUsername, setSeedUsername] = useState<string>('HighRoller_IN');
  const [seedMultiplier, setSeedMultiplier] = useState<number>(18.50);
  const [seedBetAmount, setSeedBetAmount] = useState<number>(1500);
  const [seedFeedback, setSeedFeedback] = useState<string | null>(null);

  // Notification & Reward Centre Dispatch States + Super Admin vs Admin Toggle
  const [adminNotifications, setAdminNotifications] = useState<PlatformNotification[]>([]);
  const [softDeletedNotifCount, setSoftDeletedNotifCount] = useState<number>(0);
  const [allowAdminRewardDispatch, setAllowAdminRewardDispatch] = useState<boolean>(false);
  const [requesterAdminRole, setRequesterAdminRole] = useState<'SUPER_ADMIN' | 'SUB_ADMIN'>('SUPER_ADMIN');
  const [notifTargetUser, setNotifTargetUser] = useState<string>('ALL');
  const [notifTitle, setNotifTitle] = useState<string>('VIP Cash Reward Dispatched!');
  const [notifMessage, setNotifMessage] = useState<string>('Congratulations Pilot! Claim your instant cash reward directly into your main wallet.');
  const [notifRewardAmount, setNotifRewardAmount] = useState<string>('100');
  const [notifType, setNotifType] = useState<'REWARD' | 'PROMO' | 'SYSTEM' | 'SECURITY'>('REWARD');
  const [notifSubmitting, setNotifSubmitting] = useState<boolean>(false);
  const [notifFeedback, setNotifFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchAdminData();
      fetchCheatPercentages();
      fetchCheatTimeControl();
      const interval = setInterval(fetchMetrics, 3000);

      const unsubCheat = socketService.on('admin:cheat_percentages_updated', (payload: any) => {
        if (typeof payload?.cheatPercentage === 'number') {
          setCheatPercentage(payload.cheatPercentage);
        }
        if (typeof payload?.crashPercentage === 'number') {
          setCrashPercentage(payload.crashPercentage);
        }
      });

      const unsubTimeControl = socketService.on('admin:cheat_time_control_updated', (tc: CheatCrashTimeControl) => {
        if (tc) setCheatTimeControl(tc);
      });

      return () => {
        clearInterval(interval);
        unsubCheat();
        unsubTimeControl();
      };
    }
  }, [isOpen]);

  const fetchCheatPercentages = async () => {
    try {
      const res = await fetch('/api/admin/cheat-percentages', {
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        const data = await res.json();
        if (typeof data.cheatPercentage === 'number') setCheatPercentage(data.cheatPercentage);
        if (typeof data.crashPercentage === 'number') setCrashPercentage(data.crashPercentage);
      }
    } catch {}
  };

  const fetchCheatTimeControl = async () => {
    try {
      const res = await fetch('/api/admin/cheat-time-control', {
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.timeControl) {
          setCheatTimeControl(data.timeControl);
          if (data.timeControl.cheatToggleDurationMinutes) {
            setCheatToggleDurationMins(data.timeControl.cheatToggleDurationMinutes);
          }
        }
      }
    } catch {}
  };

  const handleSaveCheatTimeControl = async (updates: Record<string, any>, customMsg?: string) => {
    try {
      const res = await fetch('/api/admin/cheat-time-control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify(updates)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.timeControl) setCheatTimeControl(data.timeControl);
        setTimeControlFeedback(customMsg || 'Cheat & Crash Time Control updated!');
        setTimeout(() => setTimeControlFeedback(null), 3500);
      }
    } catch {
      setTimeControlFeedback('Failed to update Cheat & Crash Time Control.');
    }
  };

  const handleUidBalanceTransfer = async (action: 'CREDIT' | 'DEBIT' | 'ZERO_OUT') => {
    const cleanUid = uidTransferInput.replace(/\D/g, '').trim();
    if (!cleanUid) {
      setUidTransferFeedback('Please enter a valid 7-digit Player UID.');
      return;
    }
    const amt = Number(uidTransferAmount) || 0;
    if (action !== 'ZERO_OUT' && amt <= 0) {
      setUidTransferFeedback('Please enter an amount greater than ₹0.');
      return;
    }
    setUidTransferLoading(true);
    try {
      const res = await superAdminModifyBalanceByUid({
        adminId: 'super_admin_master',
        targetUid: cleanUid,
        action,
        amount: amt,
        reason: uidTransferNote || `Super Admin UID ${action}`,
        note: uidTransferNote
      });
      setUidTransferFeedback(`✅ ${res.message}`);
      fetchUsers();
      fetchMetrics();
      setTimeout(() => setUidTransferFeedback(null), 4500);
    } catch (err: any) {
      setUidTransferFeedback(`❌ ${err.message || 'UID balance transfer failed'}`);
    } finally {
      setUidTransferLoading(false);
    }
  };

  const fetchMetrics = async () => {
    try {
      const res = await fetch('/api/admin/metrics', {
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        const data = await res.json();
        setMetrics(data);
        if (data.systemConfig) {
          setConfig(data.systemConfig);
          setControlMode(data.systemConfig.manualOverrideActive ? 'MANUAL_OVERRIDE' : 'AUTO_AI');
          setMaintenanceActive(Boolean(data.systemConfig.maintenanceModeActive));
          if (typeof data.systemConfig.cheatPercentage === 'number') {
            setCheatPercentage(data.systemConfig.cheatPercentage);
          }
          if (typeof data.systemConfig.crashPercentage === 'number') {
            setCrashPercentage(data.systemConfig.crashPercentage);
          }
          if (data.systemConfig.trendSeedConfig) {
            setTrendMode(data.systemConfig.trendSeedConfig.mode || 'NATURAL');
            setConsecutiveCrashesInput(data.systemConfig.trendSeedConfig.consecutiveCrashesRemaining ?? 3);
            setLiabilityCrashThresholdInput(data.systemConfig.trendSeedConfig.liabilityCrashThreshold || 25000);
            setAutoOverrideLiabilityInput(data.systemConfig.trendSeedConfig.autoOverrideOnLiability ?? true);
          }
        }
      }
    } catch {}
  };

  const handleToggleMaintenance = async () => {
    setMaintenanceLoading(true);
    try {
      const res = await fetch('/api/admin/maintenance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ active: !maintenanceActive })
      });
      if (res.ok) {
        const data = await res.json();
        setMaintenanceActive(data.maintenanceModeActive);
      }
    } catch {}
    finally {
      setMaintenanceLoading(false);
    }
  };

  const handleSaveTrendConfig = async () => {
    try {
      const res = await fetch('/api/admin/trend-seed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({
          mode: trendMode,
          consecutiveCrashes: consecutiveCrashesInput,
          autoOverrideOnLiability: autoOverrideLiabilityInput,
          liabilityCrashThreshold: liabilityCrashThresholdInput
        })
      });
      if (res.ok) {
        setTrendFeedback('Trend Seed Configuration saved successfully!');
        setTimeout(() => setTrendFeedback(null), 3000);
      }
    } catch {
      setTrendFeedback('Failed to update trend seed configuration');
    }
  };

  const handleInjectHistory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!historyInjectMultiplier) return;
    try {
      const res = await fetch('/api/admin/history/inject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({
          multiplier: Number(historyInjectMultiplier),
          roundId: historyInjectRoundId || undefined
        })
      });
      if (res.ok) {
        setTrendFeedback(`Injected ${historyInjectMultiplier}x outcome into past graph history.`);
        setHistoryInjectRoundId('');
        setTimeout(() => setTrendFeedback(null), 3000);
      }
    } catch {}
  };

  const fetchLeaderboard = async () => {
    try {
      const res = await fetch(`/api/leaderboard?timeframe=${leaderboardTf}&metric=${leaderboardMetric}`);
      if (res.ok) {
        const data = await res.json();
        setLeaderboardRecords(data.records || []);
      }
    } catch {}
  };

  const handleSeedLeaderboard = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/seed-leaderboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({
          username: seedUsername,
          multiplier: seedMultiplier,
          betAmount: seedBetAmount,
          payoutAmount: Math.round(seedBetAmount * seedMultiplier),
          timeframe: leaderboardTf,
          type: leaderboardMetric
        })
      });
      if (res.ok) {
        setSeedFeedback(`Successfully seeded top record for ${seedUsername}!`);
        fetchLeaderboard();
        setTimeout(() => setSeedFeedback(null), 3000);
      }
    } catch {}
  };

  const fetchAdminData = async () => {
    fetchMetrics();
    fetchUpiNodes();
    fetchFakeChatSettings();
    fetchAdminNotifications();
    fetchBotReceiptQueue();
    fetchFirestoreDeposits();
    fetchAuthorizedAdmins();
    try {
      // Fetch queues
      const queuesRes = await fetch('/api/admin/queues', {
        headers: { 'x-admin-key': adminKey }
      });
      if (queuesRes.ok) {
        const qData = await queuesRes.json();
        setDeposits(qData.deposits || []);
        setWithdrawals(qData.withdrawals || []);
        setFraudAlerts(qData.fraudAlerts || []);
      }

      // Fetch users (guarded)
      fetchUsers();
    } catch {}
  };

  const fetchUpiNodes = async () => {
    try {
      const res = await fetch('/api/admin/upi-nodes', {
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        const data = await res.json();
        setUpiNodes(data.nodes || []);
        setActiveUpiNodeId(data.activeNodeId || '');
        setRotateThreshold(data.rotateAfterTransactions || 10);
      }
    } catch {}
  };

  const [upiNodeFeedback, setUpiNodeFeedback] = useState<string | null>(null);
  const [upiQrUploading, setUpiQrUploading] = useState(false);
  const [editingNodeId, setEditingNodeId] = useState<string | null>(null);
  const [editNodeForm, setEditNodeForm] = useState({ upiId: '', displayName: '', qrImageUrl: '', maxLimit: 100000 });

  const handleUploadUpiQrFile = async (file: File, target: 'NEW' | 'EDIT' | 'CONFIG', nodeId?: string) => {
    setUpiQrUploading(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = reader.result as string;
        try {
          const res = await fetch('/api/admin/upi-nodes/upload-qr', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
            body: JSON.stringify({ imageBase64: base64, nodeId })
          });
          const data = await res.json();
          const finalUrl = data.qrImageUrl || base64;
          if (target === 'NEW') {
            setNewNodeForm((prev) => ({ ...prev, qrImageUrl: finalUrl }));
          } else if (target === 'EDIT') {
            setEditNodeForm((prev) => ({ ...prev, qrImageUrl: finalUrl }));
          } else if (target === 'CONFIG' && config) {
            setConfig({ ...config, adminQrUrl: finalUrl });
          }
          setUpiNodeFeedback('✅ QR Code uploaded and saved!');
          setTimeout(() => setUpiNodeFeedback(null), 3500);
          fetchUpiNodes();
        } catch {
          if (target === 'NEW') setNewNodeForm((prev) => ({ ...prev, qrImageUrl: base64 }));
          if (target === 'EDIT') setEditNodeForm((prev) => ({ ...prev, qrImageUrl: base64 }));
        } finally {
          setUpiQrUploading(false);
        }
      };
      reader.readAsDataURL(file);
    } catch {
      setUpiQrUploading(false);
    }
  };

  const handleSetActiveNode = async (nodeId: string) => {
    try {
      const targetNode = upiNodes.find((n) => n.id === nodeId);
      if (targetNode) {
        updateGlobalSystemUpi({
          adminId: 'super_admin',
          upiId: targetNode.upiId,
          qrCodeUrl: targetNode.qrImageUrl,
          merchantName: targetNode.displayName
        }).catch(() => {});
      }
      const res = await fetch('/api/admin/upi-nodes/set-active', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ nodeId })
      });
      if (res.ok) {
        setUpiNodeFeedback(`✅ Activated UPI ID: ${targetNode?.upiId || nodeId}`);
        setTimeout(() => setUpiNodeFeedback(null), 3500);
        fetchUpiNodes();
        fetchAdminData();
      }
    } catch {}
  };

  const handleResetNodeCounter = async (nodeId: string) => {
    try {
      const res = await fetch('/api/admin/upi-nodes/reset-counter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ nodeId })
      });
      if (res.ok) {
        setUpiNodeFeedback('✅ Transaction counter reset to 0.');
        setTimeout(() => setUpiNodeFeedback(null), 3000);
        fetchUpiNodes();
      }
    } catch {}
  };

  const handleSaveRotateThreshold = async () => {
    try {
      const res = await fetch('/api/admin/upi-nodes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ rotateAfterTransactions: Number(rotateThreshold) })
      });
      if (res.ok) {
        setUpiNodeFeedback('✅ Rotation threshold updated and saved!');
        setTimeout(() => setUpiNodeFeedback(null), 3500);
        fetchUpiNodes();
      }
    } catch {}
  };

  const handleAddNode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNodeForm.upiId.trim() || !newNodeForm.displayName.trim()) return;
    const node: DepositNode = {
      id: `node_${Date.now()}`,
      upiId: newNodeForm.upiId.trim(),
      displayName: newNodeForm.displayName.trim(),
      qrImageUrl: newNodeForm.qrImageUrl.trim() || undefined,
      currentTransactions: 0,
      maxLimit: Number(newNodeForm.maxLimit) || 100000,
      isActive: true,
      totalVolume: 0
    };
    const updatedNodes = upiNodes.map((n) => ({ ...n, isActive: false })).concat(node);
    try {
      const res = await fetch('/api/admin/upi-nodes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ nodes: updatedNodes, activateNodeId: node.id })
      });
      if (res.ok) {
        updateGlobalSystemUpi({
          adminId: 'super_admin',
          upiId: node.upiId,
          qrCodeUrl: node.qrImageUrl,
          merchantName: node.displayName
        }).catch(() => {});
        setNewNodeForm({ upiId: '', displayName: '', qrImageUrl: '', maxLimit: 100000 });
        setShowAddNodeForm(false);
        setUpiNodeFeedback(`✅ New UPI ID "${node.upiId}" saved & set ACTIVE immediately!`);
        setTimeout(() => setUpiNodeFeedback(null), 4000);
        fetchUpiNodes();
        fetchAdminData();
      }
    } catch {}
  };

  const handleSaveEditNode = async (nodeId: string) => {
    if (!editNodeForm.upiId.trim() || !editNodeForm.displayName.trim()) return;
    try {
      const res = await fetch('/api/admin/deposit-node/edit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({
          id: nodeId,
          upiId: editNodeForm.upiId.trim(),
          displayName: editNodeForm.displayName.trim(),
          qrImageUrl: editNodeForm.qrImageUrl.trim(),
          maxLimit: Number(editNodeForm.maxLimit) || 100000,
          isActive: true
        })
      });
      if (res.ok) {
        updateGlobalSystemUpi({
          adminId: 'super_admin',
          upiId: editNodeForm.upiId.trim(),
          qrCodeUrl: editNodeForm.qrImageUrl.trim(),
          merchantName: editNodeForm.displayName.trim()
        }).catch(() => {});
        setEditingNodeId(null);
        setUpiNodeFeedback(`✅ UPI ID "${editNodeForm.upiId.trim()}" updated, saved & activated!`);
        setTimeout(() => setUpiNodeFeedback(null), 4000);
        fetchUpiNodes();
        fetchAdminData();
      }
    } catch {}
  };

  const handleDeleteNode = async (nodeId: string) => {
    if (upiNodes.length <= 1) {
      setUpiNodeFeedback('⚠️ At least one active UPI node must remain configured. Edit the existing node instead.');
      setTimeout(() => setUpiNodeFeedback(null), 4000);
      return;
    }
    const updatedNodes = upiNodes.filter((n) => n.id !== nodeId);
    try {
      const res = await fetch('/api/admin/upi-nodes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ nodes: updatedNodes })
      });
      if (res.ok) {
        setUpiNodeFeedback('✅ UPI node deleted and saved.');
        setTimeout(() => setUpiNodeFeedback(null), 3000);
        fetchUpiNodes();
      }
    } catch {}
  };

  const fetchFakeChatSettings = async () => {
    try {
      const res = await fetch('/api/admin/fake-chat/settings', {
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        const data = await res.json();
        setFakeChatConfig(data.settings);
      }
    } catch {}
  };

  const fetchAdminNotifications = async () => {
    try {
      const res = await fetch('/api/admin/notifications', {
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        const data = await res.json();
        setAdminNotifications(data.notifications || []);
        setSoftDeletedNotifCount(data.softDeletedCount || 0);
        setAllowAdminRewardDispatch(Boolean(data.allowAdminRewardDispatch));
        if (data.requesterRole) setRequesterAdminRole(data.requesterRole);
      }
    } catch {}
  };

  const handleToggleAdminRewardPermission = async (nextState: boolean) => {
    setNotifFeedback(null);
    try {
      const res = await fetch('/api/super-admin/toggle-admin-reward-permission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ allowAdminRewardDispatch: nextState })
      });
      const data = await res.json();
      if (!res.ok) {
        setNotifFeedback({ type: 'error', text: data.error || 'Only Super Admin can change this permission.' });
        return;
      }
      setAllowAdminRewardDispatch(Boolean(data.allowAdminRewardDispatch));
      setNotifFeedback({ type: 'success', text: data.message });
      fetchAdminNotifications();
    } catch (err: any) {
      setNotifFeedback({ type: 'error', text: err.message || 'Failed to toggle Admin reward permission.' });
    }
  };

  const handleSendNotificationReward = async (e: React.FormEvent) => {
    e.preventDefault();
    setNotifFeedback(null);

    const isSuperCaller =
      requesterAdminRole === 'SUPER_ADMIN' ||
      adminKey === 'Faisal786' ||
      adminKey === 'sa_secret_token_786' ||
      adminKey === 'mdfaisalraza9771@gmail.com' ||
      adminKey === 'mdfaisalraza7777@gmail.com';

    if (!isSuperCaller && !allowAdminRewardDispatch) {
      setNotifFeedback({
        type: 'error',
        text: 'SECURITY BLOCK: Super Admin has disabled "Send Money/Rewards to Notification Centre" for regular Admins.'
      });
      return;
    }

    setNotifSubmitting(true);
    try {
      const res = await fetch('/api/admin/notifications/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({
          targetUserId: notifTargetUser.trim() || 'ALL',
          title: notifTitle.trim(),
          message: notifMessage.trim(),
          rewardAmount: Math.max(0, Number(notifRewardAmount) || 0),
          type: notifType
        })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to dispatch notification');
      }
      setNotifFeedback({ type: 'success', text: data.message || 'Notification dispatched successfully!' });
      fetchAdminNotifications();
    } catch (err: any) {
      setNotifFeedback({ type: 'error', text: err.message || 'Error dispatching notification.' });
    } finally {
      setNotifSubmitting(false);
    }
  };

  const handleSoftDeleteNotificationAdmin = async (id: string) => {
    try {
      const res = await fetch(`/api/notifications/${encodeURIComponent(id)}/soft-delete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ userId: 'admin_audit' })
      });
      if (res.ok) {
        setNotifFeedback({ type: 'success', text: 'Notification archived via Soft-Delete policy (is_deleted=true, deleted_at recorded).' });
        fetchAdminNotifications();
      }
    } catch {}
  };

  const handleSaveFakeChatSettings = async (updated: FakeChatSettings) => {
    try {
      const res = await fetch('/api/admin/fake-chat/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify(updated)
      });
      if (res.ok) {
        setFakeChatConfig(updated);
        setFakeChatTestFeedback('Fake chat settings saved!');
        setTimeout(() => setFakeChatTestFeedback(null), 3000);
      }
    } catch {}
  };

  const handleBroadcastTestChat = async () => {
    try {
      const res = await fetch('/api/admin/fake-chat/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey }
      });
      if (res.ok) {
        const data = await res.json();
        setFakeChatTestFeedback(data.message?.message || 'Simulated message broadcasted to chat feed!');
        setTimeout(() => setFakeChatTestFeedback(null), 3000);
      }
    } catch {}
  };

  const handleToggleSmartLock = async (targetUser: User, active: boolean, rounds?: number) => {
    try {
      const res = await fetch('/api/admin/user/smart-lock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ userId: targetUser.id, active, rounds: rounds || 3 })
      });
      if (res.ok) {
        setSmartLockUser(null);
        fetchUsers();
      }
    } catch {}
  };

  const fetchUsers = async () => {
    try {
      const res = await fetch(`/api/admin/users?search=${encodeURIComponent(userSearch)}`, {
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        const data = await res.json();
        setUserList(data.users || []);
      }
    } catch {}
  };

  // Controller Actions
  const handleTriggerCrashNow = async () => {
    socketService.adminCrashNow(adminKey, true);
    try {
      const res = await fetch('/api/admin/round-crash', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ adminKey, immediate: true })
      });
      const data = await res.json().catch(() => ({}));
      setPresetFeedback(data.message || `⚡ Round Crash executed at ${currentMultiplier.toFixed(2)}x!`);
      setTimeout(() => setPresetFeedback(null), 3500);
    } catch {
      setPresetFeedback(`⚡ Round Crash signal sent at ${currentMultiplier.toFixed(2)}x!`);
      setTimeout(() => setPresetFeedback(null), 3500);
    }
  };

  const handleModeSwitch = (mode: 'AUTO_AI' | 'MANUAL_OVERRIDE') => {
    setControlMode(mode);
    socketService.adminSetMode(mode, adminKey);
  };

  const handleSetNextCrash = (e: React.FormEvent) => {
    e.preventDefault();
    const mult = parseFloat(presetMultiplier);
    if (isNaN(mult) || mult < 1.01) return;
    socketService.adminSetNextCrash(mult, adminKey);
    setPresetFeedback(`Next round scheduled to crash at ${mult.toFixed(2)}x (Locked Natural Exponential Speed)`);
    setTimeout(() => setPresetFeedback(null), 3500);
  };

  const handleUpdateCheatPercentages = (newCheat?: number, newCrash?: number) => {
    const updatedCheat = typeof newCheat === 'number' ? Math.min(100, Math.max(0, Math.round(newCheat))) : cheatPercentage;
    const updatedCrash = typeof newCrash === 'number' ? Math.min(100, Math.max(0, Math.round(newCrash))) : crashPercentage;
    setCheatPercentage(updatedCheat);
    setCrashPercentage(updatedCrash);
    socketService.adminSetCheatPercentages({ cheatPercentage: updatedCheat, crashPercentage: updatedCrash, adminKey });
    setPercentageFeedback(`Saved! Cheat Rate: ${updatedCheat}% | Crash Rate: ${updatedCrash}%`);
    setTimeout(() => setPercentageFeedback(null), 3500);
  };

  // Deposit Actions
  const handleDepositAction = async (depositId: string, action: 'APPROVE' | 'REJECT') => {
    try {
      if (action === 'APPROVE') {
        const dep = deposits.find((d) => d.id === depositId);
        if (dep) {
          DeepAuditSystem.commitDepositSuccess({
            depositRequestId: dep.id,
            userId: dep.userId,
            amount: dep.amount,
            creditedBy: 'super_admin',
            utrNumber: dep.utrNumber
          }).catch((e) => console.warn('[AdminDashboard] Deposit success log notice:', e));
        }
      }

      const res = await fetch('/api/admin/deposit/action', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminKey
        },
        body: JSON.stringify({ depositId, action })
      });
      if (res.ok) {
        fetchAdminData();
      }
    } catch {}
  };

  // Withdrawal Actions
  const handleWithdrawalAction = async (withdrawalId: string, action: 'APPROVE' | 'REJECT') => {
    try {
      const payoutUtr = adminPayoutUtr || `TXN${Date.now()}`;
      if (action === 'APPROVE') {
        const w = withdrawals.find((item) => item.id === withdrawalId);
        if (w) {
          DeepAuditSystem.commitWithdrawalPayout({
            withdrawalRequestId: w.id,
            userId: w.userId,
            amount: w.amount,
            adminUtr: payoutUtr,
            paidBy: 'super_admin'
          }).catch((e) => console.warn('[AdminDashboard] Withdrawal payout log notice:', e));
        }
      }

      const res = await fetch('/api/admin/withdrawal/action', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminKey
        },
        body: JSON.stringify({
          withdrawalId,
          action,
          adminUtr: payoutUtr
        })
      });
      if (res.ok) {
        setAdminPayoutUtr('');
        fetchAdminData();
      }
    } catch {}
  };

  // Direct 1-Click Approve / Reject Order by Order ID
  const handleDirectActionByOrderId = async (orderIdInput: string, action: 'APPROVE' | 'REJECT', payoutUtrParam?: string) => {
    const cleanId = orderIdInput.trim();
    if (!cleanId) {
      setQuickConfirmFeedback('⚠️ Please enter or paste an Order ID first.');
      return;
    }

    // Lookup in deposits (by orderId, id, or utr)
    const dep = deposits.find(
      (d) =>
        (d.orderId && d.orderId.toLowerCase() === cleanId.toLowerCase()) ||
        d.id.toLowerCase() === cleanId.toLowerCase() ||
        (d.utrNumber && d.utrNumber.toLowerCase() === cleanId.toLowerCase())
    );

    // Lookup in withdrawals (by orderId or id)
    const wdr = withdrawals.find(
      (w) =>
        (w.orderId && w.orderId.toLowerCase() === cleanId.toLowerCase()) ||
        w.id.toLowerCase() === cleanId.toLowerCase()
    );

    if (!dep && !wdr) {
      setQuickConfirmFeedback(`❌ No order found matching Order ID "${cleanId}". Please verify the Order ID.`);
      return;
    }

    if (dep) {
      await handleDepositAction(dep.id, action);
      setQuickConfirmFeedback(
        action === 'APPROVE'
          ? `✅ Deposit Order ${dep.orderId || dep.id} (₹${dep.amount}) APPROVED & CREDITED to ${dUserName(dep)}!`
          : `❌ Deposit Order ${dep.orderId || dep.id} has been REJECTED.`
      );
      setTimeout(() => setQuickConfirmFeedback(null), 4500);
      return;
    }

    if (wdr) {
      if (action === 'APPROVE' && payoutUtrParam) {
        setAdminPayoutUtr(payoutUtrParam);
      }
      await handleWithdrawalAction(wdr.id, action);
      setQuickConfirmFeedback(
        action === 'APPROVE'
          ? `✅ Withdrawal Order ${wdr.orderId || wdr.id} (₹${wdr.amount}) APPROVED & marked paid out!`
          : `❌ Withdrawal Order ${wdr.orderId || wdr.id} REJECTED & returned to wallet.`
      );
      setTimeout(() => setQuickConfirmFeedback(null), 4500);
      return;
    }
  };

  const dUserName = (dep: DepositRequest) => dep.userName || dep.userId || 'Player';

  // Poster Girl Actions
  const handleUploadPosterGirl = (file: File) => {
    if (!file) return;
    setPosterGirlUploadLoading(true);
    setPosterGirlFeedback(null);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const res = await fetch('/api/admin/upload-poster-girl', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
          body: JSON.stringify({ imageBase64: base64 })
        });
        const data = await res.json();
        if (res.ok && data.success) {
          setPosterGirlFeedback('Official poster girl updated successfully across all players!');
          setConfig((prev) => prev ? { ...prev, posterGirlImageUrl: data.posterGirlImageUrl } : prev);
        } else {
          setPosterGirlFeedback(`Upload failed: ${data.error || 'Server error'}`);
        }
      } catch (err: any) {
        setPosterGirlFeedback(`Upload failed: ${err.message}`);
      } finally {
        setPosterGirlUploadLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSavePosterGirlUrl = async (url: string) => {
    if (!url.trim()) return;
    setPosterGirlUploadLoading(true);
    setPosterGirlFeedback(null);
    try {
      const res = await fetch('/api/admin/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ posterGirlImageUrl: url.trim() })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setPosterGirlFeedback('Poster girl URL saved and broadcasted live!');
        setConfig(data.config);
      } else {
        setPosterGirlFeedback(`Save failed: ${data.error || 'Server error'}`);
      }
    } catch (err: any) {
      setPosterGirlFeedback(`Save failed: ${err.message}`);
    } finally {
      setPosterGirlUploadLoading(false);
    }
  };

  // User Actions with Super Admin Master Remote Balance Authority
  const handleUserAction = async (userId: string, action: string, amount?: number, note?: string) => {
    try {
      // 1. Master Remote Authority in Cloud Firestore with atomic Before/After audit snapshot
      if (['ADD_BALANCE', 'DEDUCT_BALANCE', 'SET_BALANCE', 'ZERO_BALANCE'].includes(action)) {
        let overrideAction: 'CREDIT' | 'DEBIT' | 'OVERWRITE' | 'ZERO_OUT' = 'OVERWRITE';
        if (action === 'ADD_BALANCE') overrideAction = 'CREDIT';
        if (action === 'DEDUCT_BALANCE') overrideAction = 'DEBIT';
        if (action === 'ZERO_BALANCE') overrideAction = 'ZERO_OUT';

        await superAdminModifyUserBalance({
          adminId: 'super_admin',
          targetUserId: userId,
          action: overrideAction,
          amount: amount || 0,
          reason: note || `Admin action: ${action}`
        }).catch((e) => console.warn('[AdminDashboard] Super admin direct Firestore write notice:', e));
      }

      // 2. Server memory & socket synchronization
      const res = await fetch('/api/admin/user/action', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminKey
        },
        body: JSON.stringify({ userId, action, amount, note })
      });
      if (res.ok) {
        fetchUsers();
        setAdjustModalUser(null);
      }
    } catch {}
  };

  const matchedOrderForDirectAction = useMemo(() => {
    const q = directActionOrderId.trim().toLowerCase();
    if (!q) return null;
    const dep = deposits.find(
      (d) =>
        (d.orderId && d.orderId.toLowerCase() === q) ||
        d.id.toLowerCase() === q ||
        (d.utrNumber && d.utrNumber.toLowerCase() === q)
    );
    if (dep) return { type: 'DEPOSIT' as const, order: dep };

    const wdr = withdrawals.find(
      (w) =>
        (w.orderId && w.orderId.toLowerCase() === q) ||
        w.id.toLowerCase() === q
    );
    if (wdr) return { type: 'WITHDRAWAL' as const, order: wdr };

    return null;
  }, [directActionOrderId, deposits, withdrawals]);

  if (!isOpen) return null;

  return (
    <div id="super-admin-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-1 sm:p-4 bg-black/90 backdrop-blur-md overflow-y-auto">
      <div
        id="super-admin-container"
        className="w-full max-w-5xl max-w-[calc(100vw-12px)] bg-[#141518] border border-red-600/40 rounded-2xl shadow-[0_0_50px_rgba(225,29,72,0.2)] overflow-hidden flex flex-col max-h-[95vh]"
      >
        {/* Top Header Bar */}
        <div className="flex items-center justify-between px-5 py-3 bg-gradient-to-r from-[#21090f] via-[#1a1b20] to-[#21090f] border-b border-red-600/40">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white font-black shadow-[0_0_12px_#f43f5e]">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white font-['Chakra_Petch'] tracking-wide">
                  WIN NOVA HYBRID CONTROLLER
                </h2>
                <span className="text-[10px] font-mono uppercase bg-red-600/30 text-red-300 border border-red-500/50 px-2 py-0.5 rounded-full font-bold">
                  Super Admin
                </span>
              </div>
              <span className="text-[10px] text-neutral-400 font-mono">
                Real-Time WebSocket Engine & Proof Cashier Terminal
              </span>
            </div>
          </div>

          <button
            id="close-admin-panel-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-[#22242c] hover:bg-[#30333e] text-neutral-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Live Ticker Banner */}
        <div className="bg-[#191a20] px-4 py-2 border-b border-[#292b35] flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-neutral-400">Concurrent Players:</span>
              <span className="font-mono font-bold text-white">{metrics?.liveConcurrentUsers || 18}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-neutral-400">Live Multiplier:</span>
              <span className="font-mono font-bold text-rose-400 text-sm">
                {currentMultiplier.toFixed(2)}x
              </span>
              <span className="text-[10px] uppercase font-bold text-neutral-400 font-mono">
                ({gameStatus})
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div>
              <span className="text-neutral-400">Today's Net Profit:</span>{' '}
              <span className={`font-mono font-bold ${
                (metrics?.todayNetProfit || 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}>
                ₹{(metrics?.todayNetProfit || 0).toLocaleString('en-IN')}
              </span>
            </div>
            <div>
              <span className="text-neutral-400">Control Mode:</span>{' '}
              <span className="font-mono font-bold text-amber-400">
                {controlMode}
              </span>
            </div>
          </div>
        </div>

        {/* Decomplexed Navigation Tabs (5 Core Tabs + Secondary Tools Drawer) */}
        <div className="flex bg-[#121316] p-1.5 border-b border-[#262830] overflow-x-auto no-scrollbar items-center gap-1">
          {[
            {
              id: 'orderConfirm',
              label: `⚡ Approve / Reject by Order ID (${(metrics?.pendingDepositsCount ?? deposits.filter(d => d.status === 'PENDING').length) + (metrics?.pendingWithdrawalsCount ?? withdrawals.filter(w => w.status === 'PENDING').length)})`,
              icon: CheckCircle2,
              badge: true
            },
            { id: 'controller', label: '🎮 Game & Crash Control', icon: Radio },
            { id: 'users', label: '👥 Players & Balance', icon: Users },
            { id: 'referrals', label: '🎁 Referral Metrics', icon: Share2 },
            { id: 'upiRotator', label: '💳 UPI & QR Setup', icon: CreditCard },
            { id: 'staff', label: '🛡️ Approved Admins & Staff', icon: ShieldCheck }
          ].map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setShowMoreToolsDrawer(false);
                }}
                className={`py-2 px-3 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 whitespace-nowrap transition cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-r from-rose-700 to-red-600 text-white shadow-[0_0_15px_rgba(225,29,72,0.6)] border border-rose-400'
                    : 'text-neutral-300 hover:text-white hover:bg-[#1f2129]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-white' : 'text-neutral-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}

          <div className="h-5 w-px bg-[#2e313c] mx-1 shrink-0" />

          {/* Toggle for Advanced / Secondary Admin Tools */}
          <button
            type="button"
            onClick={() => setShowMoreToolsDrawer(!showMoreToolsDrawer)}
            className={`py-2 px-3 text-xs font-bold rounded-lg flex items-center gap-1 whitespace-nowrap transition cursor-pointer ml-auto shrink-0 ${
              showMoreToolsDrawer || !['orderConfirm', 'controller', 'users', 'referrals', 'upiRotator', 'staff'].includes(activeTab)
                ? 'bg-amber-600/80 text-white border border-amber-500/60'
                : 'bg-[#1b1c24] text-neutral-400 hover:text-amber-300 border border-[#2b2d38]'
            }`}
          >
            <Sliders className="w-3 h-3" />
            <span>⚙️ More Admin Tools {showMoreToolsDrawer ? '▴' : '▾'}</span>
          </button>
        </div>

        {/* Secondary Admin Tools Bar (Expandable drawer so the main view stays decomplex) */}
        {showMoreToolsDrawer && (
          <div className="bg-[#181920] border-b border-amber-500/30 p-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar animate-in slide-in-from-top-1 duration-150">
            <span className="text-[10px] text-amber-400 font-mono font-bold uppercase px-2 shrink-0">
              Secondary Tools:
            </span>
            {[
              { id: 'referrals', label: '🎁 Referral Performance & Bounties', icon: Share2 },
              { id: 'overview', label: 'Financials & P&L', icon: TrendingUp },
              { id: 'notifications', label: 'Rewards & Bell', icon: Bell },
              { id: 'giftCodes', label: 'Gift Codes & Vouchers', icon: Gift },
              { id: 'promotions', label: 'Timed Campaigns', icon: Sparkles },
              { id: 'fraud', label: `Anti-Fraud (${metrics?.flaggedFraudCount || 0})`, icon: AlertOctagon },
              { id: 'trendSeed', label: 'Trend & Risk Override', icon: Flame },
              { id: 'leaderboard', label: 'Leaderboard Synthetic Win', icon: ShieldCheck },
              { id: 'peakSchedules', label: 'Peak Schedules', icon: Clock },
              { id: 'fakeChat', label: 'Fake Chat Simulator', icon: MessageSquare },
              { id: 'telegramBotPanel', label: '🤖 Telegram Mastermind Bot', icon: Send },
              { id: 'settings', label: 'Platform Config', icon: Settings }
            ].map((tool) => {
              const ToolIcon = tool.icon;
              const isToolSelected = activeTab === tool.id;
              return (
                <button
                  key={tool.id}
                  onClick={() => {
                    setActiveTab(tool.id as any);
                    setShowMoreToolsDrawer(false);
                  }}
                  className={`py-1 px-2.5 text-[11px] font-semibold rounded-md flex items-center gap-1 whitespace-nowrap transition cursor-pointer ${
                    isToolSelected
                      ? 'bg-amber-500 text-black font-bold'
                      : 'bg-[#22242e] text-neutral-300 hover:text-white hover:bg-[#2b2e3b]'
                  }`}
                >
                  <ToolIcon className="w-3 h-3" />
                  <span>{tool.label}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* Tab Contents */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4">
          {/* ===================================================================== */}
          {/* TAB 0: ORDER ID CONFIRMATION TAB (DEPOSITS & WITHDRAWALS) */}
          {/* Dedicated for Super Admin and Selected/Approved Admins */}
          {/* ===================================================================== */}
          {activeTab === 'orderConfirm' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* TELEGRAM PROMO BLAST BANNER FOR SUPER ADMIN */}
              <div className="bg-[#101b2d] border border-[#0088cc]/60 rounded-xl p-3 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-lg bg-[#0088cc] flex items-center justify-center text-white shrink-0 shadow-[0_0_12px_rgba(0,136,204,0.5)]">
                    <Send className="w-4 h-4 -rotate-12 translate-x-0.5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs sm:text-sm font-black text-white font-['Chakra_Petch']">
                        WEEKEND BONUS FLASH / PROMO BLAST
                      </span>
                      <span className="text-[9px] font-mono uppercase bg-[#0088cc]/30 text-[#45f3ff] px-2 py-0.5 rounded font-bold border border-[#0088cc]/50">
                        /promo_blast
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-300 mt-0.5">
                      Auto-blasts <b>2 Free Bonus Credits</b> to all inactive Telegram players (0 credits) and prompts them to test 7-second signals!
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                  <button
                    type="button"
                    disabled={promoBlastLoading}
                    onClick={handleTriggerPromoBlast}
                    className="py-1.5 px-3.5 bg-gradient-to-r from-[#0088cc] to-[#00b4d8] hover:from-[#0099e6] hover:to-[#48cae4] text-white font-bold text-xs rounded-lg shadow-md transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Send className="w-3 h-3" />
                    <span>{promoBlastLoading ? 'Blasting...' : 'Run /promo_blast'}</span>
                  </button>
                </div>
              </div>

              {promoBlastMsg && (
                <div className="p-2.5 rounded-lg bg-emerald-950/90 border border-emerald-500 text-emerald-300 text-xs font-mono animate-in fade-in">
                  {promoBlastMsg}
                </div>
              )}

              {/* PRIMARY ACTION CARD: APPROVE OR REJECT BY ORDER ID */}
              <div className="bg-[#1e1328] border-2 border-amber-500/80 rounded-2xl p-4 sm:p-5 shadow-[0_0_30px_rgba(245,158,11,0.25)] space-y-4 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-48 h-48 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#3c1e54] pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-600 to-amber-500 flex items-center justify-center text-white shadow-md">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base sm:text-lg font-black text-white font-['Chakra_Petch'] tracking-wide">
                          APPROVE OR REJECT BY ORDER ID
                        </h3>
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                          1-CLICK ACTION
                        </span>
                      </div>
                      <p className="text-xs text-amber-200/80 mt-0.5">
                        Type or paste any Deposit or Withdrawal Order ID to immediately Approve or Reject with instant balance update.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[10px] font-mono font-bold uppercase px-2.5 py-1 rounded bg-[#2c133e] text-amber-300 border border-amber-500/40">
                      Super Admin & Approved Admin
                    </span>
                  </div>
                </div>

                {/* Input Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-amber-300 uppercase tracking-wider mb-1">
                      Enter / Paste Order ID <span className="text-rose-400">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="e.g. ORD-DEP-17724901 or ORD-WDR-88910234 or UTR number..."
                        value={directActionOrderId}
                        onChange={(e) => setDirectActionOrderId(e.target.value)}
                        className="w-full bg-[#12091c] border-2 border-amber-500/60 focus:border-amber-400 rounded-xl px-3.5 py-3 text-sm text-white font-mono placeholder:text-neutral-500 outline-none shadow-inner"
                      />
                      {directActionOrderId && (
                        <button
                          type="button"
                          onClick={() => setDirectActionOrderId('')}
                          className="absolute right-2.5 top-3 px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 hover:text-white text-xs cursor-pointer"
                        >
                          Clear
                        </button>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-300 uppercase tracking-wider mb-1">
                      Payout UTR (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. UTR8849201948"
                      value={directActionPayoutUtr}
                      onChange={(e) => setDirectActionPayoutUtr(e.target.value)}
                      className="w-full bg-[#12091c] border border-[#3c1e54] focus:border-amber-400 rounded-xl px-3.5 py-3 text-sm text-white font-mono placeholder:text-neutral-500 outline-none shadow-inner"
                    />
                  </div>
                </div>

                {/* Live Matched Order Preview */}
                {matchedOrderForDirectAction ? (
                  <div className="bg-[#12091c] border border-amber-500/60 p-3.5 rounded-xl space-y-2.5 animate-in fade-in duration-150">
                    <div className="flex items-center justify-between text-xs flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <span className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                          matchedOrderForDirectAction.type === 'DEPOSIT'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/50'
                            : 'bg-rose-950 text-rose-400 border border-rose-500/50'
                        }`}>
                          {matchedOrderForDirectAction.type} ORDER FOUND
                        </span>
                        <span className="font-mono font-black text-amber-300 text-sm">
                          {matchedOrderForDirectAction.order.orderId || matchedOrderForDirectAction.order.id}
                        </span>
                      </div>
                      <span className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                        matchedOrderForDirectAction.order.status === 'APPROVED'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-600/40'
                          : matchedOrderForDirectAction.order.status === 'PENDING'
                          ? 'bg-amber-950 text-amber-400 border border-amber-500/60 animate-pulse'
                          : 'bg-red-950 text-red-400 border border-red-600/40'
                      }`}>
                        Current Status: {matchedOrderForDirectAction.order.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs text-neutral-300 pt-1 border-t border-[#261337]">
                      <div>
                        <span className="text-[10px] text-neutral-500 block">Player Name</span>
                        <strong className="text-white text-sm">{matchedOrderForDirectAction.order.userName || 'Player'}</strong>
                      </div>
                      <div>
                        <span className="text-[10px] text-neutral-500 block">Phone / Contact</span>
                        <strong className="font-mono text-neutral-300">{matchedOrderForDirectAction.order.userPhone || '—'}</strong>
                      </div>
                      <div>
                        <span className="text-[10px] text-neutral-500 block">Order Amount</span>
                        <strong className="font-mono text-emerald-400 font-bold text-base">₹{matchedOrderForDirectAction.order.amount}</strong>
                      </div>
                      <div>
                        <span className="text-[10px] text-neutral-500 block">
                          {matchedOrderForDirectAction.type === 'DEPOSIT' ? 'Reference UTR' : 'Payout Method'}
                        </span>
                        <strong className="font-mono text-amber-300 text-xs truncate block">
                          {matchedOrderForDirectAction.type === 'DEPOSIT'
                            ? (matchedOrderForDirectAction.order as any).utrNumber || '—'
                            : (matchedOrderForDirectAction.order as any).payoutMethod === 'UPI'
                            ? `UPI: ${(matchedOrderForDirectAction.order as any).upiId}`
                            : `Bank: ${(matchedOrderForDirectAction.order as any).bankAccount}`}
                        </strong>
                      </div>
                    </div>
                  </div>
                ) : directActionOrderId.trim() ? (
                  <div className="p-2.5 bg-neutral-900/80 border border-neutral-700/60 rounded-xl text-xs text-neutral-400 font-mono">
                    Searching for Order ID "{directActionOrderId.trim()}"... (Enter exact ID or check pending orders below)
                  </div>
                ) : null}

                {/* 1-Click Action Buttons */}
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <button
                    type="button"
                    disabled={directActionLoading || !directActionOrderId.trim()}
                    onClick={async () => {
                      setDirectActionLoading(true);
                      await handleDirectActionByOrderId(directActionOrderId, 'APPROVE', directActionPayoutUtr);
                      setDirectActionLoading(false);
                      setDirectActionOrderId('');
                      setDirectActionPayoutUtr('');
                    }}
                    className="py-3 px-4 bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-[0.99] text-white font-black text-sm uppercase tracking-wider rounded-xl shadow-[0_0_20px_rgba(16,185,129,0.45)] flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed border border-emerald-400/40"
                  >
                    <Check className="w-5 h-5" />
                    <span>{directActionLoading ? 'Processing...' : '✅ APPROVE ORDER'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={directActionLoading || !directActionOrderId.trim()}
                    onClick={async () => {
                      setDirectActionLoading(true);
                      await handleDirectActionByOrderId(directActionOrderId, 'REJECT');
                      setDirectActionLoading(false);
                      setDirectActionOrderId('');
                      setDirectActionPayoutUtr('');
                    }}
                    className="py-3 px-4 bg-gradient-to-r from-red-700 via-rose-600 to-red-700 hover:from-red-600 hover:to-rose-500 active:scale-[0.99] text-white font-black text-sm uppercase tracking-wider rounded-xl shadow-[0_0_20px_rgba(225,29,72,0.45)] flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed border border-rose-400/40"
                  >
                    <X className="w-5 h-5" />
                    <span>{directActionLoading ? 'Processing...' : '❌ REJECT ORDER'}</span>
                  </button>
                </div>
              </div>

              {/* Order ID Search & Filter Ledger */}
              <div className="p-4 bg-[#1a1b22] border border-amber-500/40 rounded-xl space-y-3 shadow-lg">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
                      <Search className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white font-['Chakra_Petch']">
                        PENDING & HISTORICAL ORDER LEDGER
                      </h3>
                      <p className="text-[11px] text-neutral-400">
                        Browse, search or filter through all submitted orders with one-click copy and approval.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/40 px-2 py-0.5 rounded-full">
                      Protected Master Ledger
                    </span>
                    <button
                      onClick={fetchAdminData}
                      className="px-2.5 py-1 text-xs bg-[#242632] hover:bg-[#2e313e] text-neutral-200 rounded-lg border border-[#343746] flex items-center gap-1 transition cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Refresh</span>
                    </button>
                  </div>
                </div>

                {/* Dedicated Search / Filter Input Specifically by Order ID for Fast Approvals */}
                <div className="bg-[#12091c] border-2 border-amber-500/60 rounded-xl p-3.5 space-y-2.5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <label className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5 font-mono">
                      <Search className="w-3.5 h-3.5 text-amber-400" />
                      <span>FIND TRANSACTIONS SPECIFICALLY BY ORDER ID (FAST APPROVAL FILTER):</span>
                    </label>
                    <span className="text-[10px] text-neutral-400 font-mono">
                      Targeted for Deposits (ORD-DEP-...) & Withdrawals (ORD-WDR-...)
                    </span>
                  </div>

                  <div className="relative">
                    <Search className="w-4 h-4 text-amber-400 absolute left-3 top-3 pointer-events-none" />
                    <input
                      type="text"
                      placeholder="Type or paste exact Order ID (e.g. ORD-DEP-17724901 or ORD-WDR-88910234)..."
                      value={orderSearchQuery}
                      onChange={(e) => setOrderSearchQuery(e.target.value)}
                      className="w-full bg-[#180e22] border-2 border-amber-500/40 focus:border-amber-400 rounded-xl pl-9 pr-24 py-2.5 text-xs sm:text-sm text-white font-mono placeholder:text-neutral-500 outline-none"
                    />
                    {orderSearchQuery && (
                      <button
                        onClick={() => setOrderSearchQuery('')}
                        className="absolute right-2.5 top-2.5 px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 hover:text-white text-xs cursor-pointer"
                      >
                        Clear Filter
                      </button>
                    )}
                  </div>

                  {orderSearchQuery.trim() && (
                    <div className="text-[11px] text-amber-300 font-mono flex items-center justify-between px-1 pt-0.5">
                      <span>Filtering specifically by Order ID: <b>"{orderSearchQuery.trim()}"</b></span>
                      <span className="text-emerald-400 font-bold">Fast Approval Filter Active</span>
                    </div>
                  )}
                </div>

                {quickConfirmFeedback && (
                  <div className="p-2.5 bg-emerald-950/70 border border-emerald-500/60 rounded-lg text-xs text-emerald-300 font-mono font-bold">
                    {quickConfirmFeedback}
                  </div>
                )}

                {/* Sub-Filter Controls */}
                <div className="flex items-center justify-between flex-wrap gap-2 pt-1 border-t border-[#2a2c38]">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {[
                      {
                        id: 'pending',
                        label: `⚡ All Pending Queue (${deposits.filter(d => d.status === 'PENDING').length + withdrawals.filter(w => w.status === 'PENDING').length})`
                      },
                      {
                        id: 'deposits',
                        label: `📥 Pending Deposits (${deposits.filter(d => d.status === 'PENDING').length})`
                      },
                      {
                        id: 'withdrawals',
                        label: `📤 Pending Withdrawals (${withdrawals.filter(w => w.status === 'PENDING').length})`
                      },
                      {
                        id: 'lifetime',
                        label: `📜 Lifetime Master Archive (${deposits.length + withdrawals.length})`
                      }
                    ].map((st) => (
                      <button
                        key={st.id}
                        onClick={() => setOrderConfirmSubTab(st.id as any)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                          orderConfirmSubTab === st.id
                            ? 'bg-amber-500 text-neutral-950 shadow-sm'
                            : 'bg-[#14151b] text-neutral-400 hover:text-white border border-[#262833]'
                        }`}
                      >
                        {st.label}
                      </button>
                    ))}
                  </div>

                  <span className="text-[11px] text-neutral-400 font-mono">
                    Actions linked directly to Order IDs
                  </span>
                </div>
              </div>

              {/* Order Lists */}
              {(() => {
                const q = orderSearchQuery.trim().toLowerCase();

                // Filter deposits
                const filteredDeposits = deposits.filter((d) => {
                  if (orderConfirmSubTab === 'withdrawals') return false;
                  if (orderConfirmSubTab === 'pending' && d.status !== 'PENDING') return false;
                  if (!q) return true;
                  const orderId = (d.orderId || d.id || '').toLowerCase();
                  const utr = (d.utrNumber || '').toLowerCase();
                  const name = (d.userName || '').toLowerCase();
                  const phone = (d.userPhone || '').toLowerCase();
                  return orderId.includes(q) || utr.includes(q) || name.includes(q) || phone.includes(q);
                });

                // Filter withdrawals
                const filteredWithdrawals = withdrawals.filter((w) => {
                  if (orderConfirmSubTab === 'deposits') return false;
                  if (orderConfirmSubTab === 'pending' && w.status !== 'PENDING') return false;
                  if (!q) return true;
                  const orderId = (w.orderId || w.id || '').toLowerCase();
                  const name = (w.userName || '').toLowerCase();
                  const phone = (w.userPhone || '').toLowerCase();
                  const upi = (w.upiId || '').toLowerCase();
                  const bank = (w.bankAccount || '').toLowerCase();
                  return orderId.includes(q) || name.includes(q) || phone.includes(q) || upi.includes(q) || bank.includes(q);
                });

                const totalOrdersCount = filteredDeposits.length + filteredWithdrawals.length;

                if (totalOrdersCount === 0) {
                  return (
                    <div className="p-8 text-center text-xs text-neutral-400 bg-[#16171d] border border-[#272935] rounded-xl space-y-1">
                      <p className="font-bold text-neutral-300">No matching orders found.</p>
                      <p className="text-[11px] text-neutral-500">
                        {orderSearchQuery
                          ? `No deposit or withdrawal order matches "${orderSearchQuery}". Check the Order ID or UTR number.`
                          : 'No orders in this filter category.'}
                      </p>
                    </div>
                  );
                }

                return (
                  <div className="space-y-4">
                    {/* SECTION: DEPOSIT ORDERS */}
                    {filteredDeposits.length > 0 && (
                      <div className="space-y-2.5">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5 font-mono">
                            <ArrowDownCircle className="w-3.5 h-3.5" />
                            <span>Deposit Orders ({filteredDeposits.length})</span>
                          </h4>
                          <span className="text-[10px] text-neutral-500 font-mono">
                            Click 'Copy Order ID' to copy only ID
                          </span>
                        </div>

                        {filteredDeposits.map((d) => {
                          const orderId = d.orderId || d.id;
                          const isCopied = copiedOrderId === orderId;
                          return (
                            <div
                              key={d.id}
                              className="bg-[#17181f] border border-[#2b2d3a] hover:border-amber-500/40 rounded-xl p-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3 transition"
                            >
                              <div className="flex items-start gap-3 min-w-0">
                                {d.proofImageUrl ? (
                                  <div
                                    onClick={() => setZoomedImage(d.proofImageUrl)}
                                    className="w-14 h-14 bg-black rounded-lg border border-neutral-700 overflow-hidden cursor-pointer shrink-0 relative group"
                                    title="Click to view payment proof"
                                  >
                                    <img
                                      src={d.proofImageUrl}
                                      alt="Proof"
                                      className="w-full h-full object-cover group-hover:opacity-80 transition"
                                    />
                                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/60 transition">
                                      <Eye className="w-4 h-4 text-white" />
                                    </div>
                                  </div>
                                ) : (
                                  <div className="w-14 h-14 bg-neutral-800 rounded-lg flex items-center justify-center text-[10px] text-neutral-500 shrink-0">
                                    No Img
                                  </div>
                                )}

                                <div className="space-y-1 min-w-0">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="font-bold text-white text-sm">{d.userName}</span>
                                    <span className="text-xs font-mono text-neutral-400">({d.userPhone})</span>
                                    <span
                                      className={`px-2 py-0.2 rounded-full text-[10px] font-mono font-bold uppercase ${
                                        d.status === 'APPROVED'
                                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                                          : d.status === 'PENDING'
                                          ? 'bg-amber-950 text-amber-400 border border-amber-500/40'
                                          : 'bg-red-950 text-red-400 border border-red-500/40'
                                      }`}
                                    >
                                      {d.status}
                                    </span>
                                  </div>

                                  {/* ORDER ID & COPY BUTTON */}
                                  <div className="flex items-center gap-1.5 flex-wrap">
                                    <span className="text-[11px] text-neutral-400">Order ID:</span>
                                    <span className="text-xs font-mono font-bold text-amber-300 bg-black/40 px-1.5 py-0.5 rounded border border-amber-500/30 selection:bg-amber-400 selection:text-black">
                                      {orderId}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        navigator.clipboard.writeText(orderId);
                                        setCopiedOrderId(orderId);
                                        setTimeout(() => setCopiedOrderId(null), 2000);
                                      }}
                                      className="px-2 py-0.5 rounded bg-[#252735] hover:bg-[#323547] border border-amber-500/40 text-amber-300 hover:text-white text-[10px] font-mono flex items-center gap-1 cursor-pointer transition shadow-sm"
                                      title="Copy Only Order ID"
                                    >
                                      {isCopied ? (
                                        <>
                                          <Check className="w-2.5 h-2.5 text-emerald-400" />
                                          <span className="text-emerald-400 font-bold">Copied</span>
                                        </>
                                      ) : (
                                        <>
                                          <Copy className="w-2.5 h-2.5" />
                                          <span>Copy Order ID</span>
                                        </>
                                      )}
                                    </button>
                                  </div>

                                  <div className="flex items-center gap-3 text-xs text-neutral-300 flex-wrap">
                                    <span>
                                      Amount: <strong className="font-mono text-emerald-400 font-bold">₹{d.amount}</strong>
                                    </span>
                                    <span>
                                      UTR: <strong className="font-mono text-amber-400">{d.utrNumber}</strong>
                                    </span>
                                    {d.createdAt && (
                                      <span className="text-[10px] text-neutral-500 font-mono">
                                        Submitted: {new Date(d.createdAt).toLocaleString()}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>

                              {/* Action buttons explicitly linked to specific Order ID */}
                              {d.status === 'PENDING' ? (
                                <div className="flex items-center gap-2 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-[#262835]">
                                  <button
                                    onClick={async () => {
                                      await handleDepositAction(d.id, 'APPROVE');
                                      setQuickConfirmFeedback(`✅ Deposit Order ${orderId} approved and credited!`);
                                      setTimeout(() => setQuickConfirmFeedback(null), 3500);
                                    }}
                                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 transition cursor-pointer"
                                    title={`Approve Deposit Order ID: ${orderId}`}
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    <span>Approve</span>
                                  </button>
                                  <button
                                    onClick={async () => {
                                      await handleDepositAction(d.id, 'REJECT');
                                      setQuickConfirmFeedback(`❌ Deposit Order ${orderId} rejected.`);
                                      setTimeout(() => setQuickConfirmFeedback(null), 3500);
                                    }}
                                    className="px-3 py-2 bg-red-950/70 hover:bg-red-900 text-red-200 text-xs font-bold rounded-xl border border-red-600/40 transition cursor-pointer flex items-center gap-1"
                                    title={`Reject Deposit Order ID: ${orderId}`}
                                  >
                                    <X className="w-3.5 h-3.5" />
                                    <span>Reject</span>
                                  </button>
                                </div>
                              ) : (
                                <div className="text-[11px] font-mono text-neutral-500 shrink-0">
                                  Processed: {d.reviewedAt ? new Date(d.reviewedAt).toLocaleString() : 'Done'}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* SECTION: WITHDRAWAL ORDERS */}
                    {filteredWithdrawals.length > 0 && (
                      <div className="space-y-2.5 pt-2">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1.5 font-mono">
                            <ArrowUpCircle className="w-3.5 h-3.5" />
                            <span>Withdrawal Orders ({filteredWithdrawals.length})</span>
                          </h4>
                          <span className="text-[10px] text-neutral-500 font-mono">
                            Exclusive dynamic slab tax automatically computed
                          </span>
                        </div>

                        {filteredWithdrawals.map((w) => {
                          const orderId = w.orderId || w.id;
                          const isCopied = copiedOrderId === orderId;
                          const taxBreakdown = calculateWithdrawalTaxBreakdown(w.amount);
                          const netPayout = w.netPayoutAmount ?? taxBreakdown.netPayoutAmount;
                          const taxPaid = w.taxAmount ?? taxBreakdown.taxAmount;

                          return (
                            <div
                              key={w.id}
                              className="bg-[#17181f] border border-[#2b2d3a] hover:border-amber-500/40 rounded-xl p-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3 transition"
                            >
                              <div className="space-y-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="font-bold text-white text-sm">{w.userName}</span>
                                  <span className="text-xs font-mono text-neutral-400">({w.userPhone})</span>
                                  <span
                                    className={`px-2 py-0.2 rounded-full text-[10px] font-mono font-bold uppercase ${
                                      w.status === 'APPROVED'
                                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                                        : w.status === 'PENDING'
                                        ? 'bg-amber-950 text-amber-400 border border-amber-500/40'
                                        : 'bg-red-950 text-red-400 border border-red-500/40'
                                    }`}
                                  >
                                    {w.status}
                                  </span>
                                </div>

                                {/* ORDER ID & COPY BUTTON */}
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="text-[11px] text-neutral-400">Order ID:</span>
                                  <span className="text-xs font-mono font-bold text-amber-300 bg-black/40 px-1.5 py-0.5 rounded border border-amber-500/30 selection:bg-amber-400 selection:text-black">
                                    {orderId}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      navigator.clipboard.writeText(orderId);
                                      setCopiedOrderId(orderId);
                                      setTimeout(() => setCopiedOrderId(null), 2000);
                                    }}
                                    className="px-2 py-0.5 rounded bg-[#252735] hover:bg-[#323547] border border-amber-500/40 text-amber-300 hover:text-white text-[10px] font-mono flex items-center gap-1 cursor-pointer transition shadow-sm"
                                    title="Copy Only Order ID"
                                  >
                                    {isCopied ? (
                                      <>
                                        <Check className="w-2.5 h-2.5 text-emerald-400" />
                                        <span className="text-emerald-400 font-bold">Copied</span>
                                      </>
                                    ) : (
                                      <>
                                        <Copy className="w-2.5 h-2.5" />
                                        <span>Copy Order ID</span>
                                      </>
                                    )}
                                  </button>
                                </div>

                                <div className="flex items-center gap-3 text-xs text-neutral-300 flex-wrap">
                                  <span>
                                    Requested: <strong className="font-mono text-white">₹{w.amount}</strong>
                                  </span>
                                  <span>
                                    Tax Collected: <strong className="font-mono text-amber-400">₹{taxPaid}</strong>
                                  </span>
                                  <span>
                                    Transfer to Player: <strong className="font-mono text-emerald-400 font-bold">₹{netPayout}</strong>
                                  </span>
                                </div>

                                <div className="text-[11px] text-neutral-400 font-mono">
                                  Payout Method:{' '}
                                  <strong className="text-white">
                                    {w.payoutMethod === 'UPI' ? `UPI: ${w.upiId}` : `Bank Account: ${w.bankAccount}`}
                                  </strong>
                                </div>
                              </div>

                              {/* Action Buttons */}
                              {w.status === 'PENDING' ? (
                                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-[#262835]">
                                  <input
                                    type="text"
                                    placeholder="Optional Payout UTR..."
                                    value={adminPayoutUtr}
                                    onChange={(e) => setAdminPayoutUtr(e.target.value)}
                                    className="bg-[#121316] border border-[#2d303f] rounded-lg px-2.5 py-1 text-xs text-white font-mono placeholder:text-neutral-500 outline-none w-36"
                                  />
                                  <button
                                    onClick={async () => {
                                      await handleWithdrawalAction(w.id, 'APPROVE');
                                      setQuickConfirmFeedback(`✅ Withdrawal Order ${orderId} approved and paid out!`);
                                      setTimeout(() => setQuickConfirmFeedback(null), 3500);
                                    }}
                                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5 transition cursor-pointer"
                                    title={`Approve Withdrawal Order ID: ${orderId}`}
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    <span>Approve</span>
                                  </button>
                                  <button
                                    onClick={async () => {
                                      await handleWithdrawalAction(w.id, 'REJECT');
                                      setQuickConfirmFeedback(`❌ Withdrawal Order ${orderId} rejected and refunded to wallet.`);
                                      setTimeout(() => setQuickConfirmFeedback(null), 3500);
                                    }}
                                    className="px-3 py-2 bg-red-950/70 hover:bg-red-900 text-red-200 text-xs font-bold rounded-xl border border-red-600/40 transition cursor-pointer flex items-center justify-center gap-1"
                                    title={`Reject Withdrawal Order ID: ${orderId}`}
                                  >
                                    <X className="w-3.5 h-3.5" />
                                    <span>Reject</span>
                                  </button>
                                </div>
                              ) : (
                                <div className="text-[11px] font-mono text-neutral-500 shrink-0">
                                  Processed: {w.reviewedAt ? new Date(w.reviewedAt).toLocaleString() : 'Done'}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          )}
          {/* TAB 1: LIVE CONTROLLER & HYBRID OVERRIDE */}
          {activeTab === 'controller' && (
            <div className="space-y-4">
              {/* Mode Toggle Banner */}
              <div className="bg-[#191b22] border border-[#2d303d] p-4 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-bold text-white flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-amber-400" />
                    <span>Hybrid Control Architecture</span>
                  </div>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Toggle between Algorithmic AI risk balancing or instantaneous Live Manual Override.
                  </p>
                </div>

                <div className="flex bg-[#121316] p-1 rounded-xl border border-[#2b2e3b]">
                  <button
                    onClick={() => handleModeSwitch('AUTO_AI')}
                    className={`px-4 py-2 text-xs font-bold rounded-lg transition ${
                      controlMode === 'AUTO_AI'
                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    Auto AI Mode (40/60 Target)
                  </button>
                  <button
                    onClick={() => handleModeSwitch('MANUAL_OVERRIDE')}
                    className={`px-4 py-2 text-xs font-bold rounded-lg transition ${
                      controlMode === 'MANUAL_OVERRIDE'
                        ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-[0_0_15px_#f43f5e]'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    Manual Override Mode
                  </button>
                </div>
              </div>

              {/* Module 8: System Maintenance Override Banner */}
              <div className="bg-[#191b22] border border-[#2d303d] p-4 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg border ${maintenanceActive ? 'bg-amber-500/20 border-amber-500/40 text-amber-400' : 'bg-neutral-800 border-neutral-700 text-neutral-400'}`}>
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white flex items-center gap-2">
                      <span>System Maintenance Override (Module 8)</span>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${maintenanceActive ? 'bg-amber-500 text-black animate-pulse' : 'bg-neutral-800 text-neutral-400'}`}>
                        {maintenanceActive ? 'ACTIVE (BETS BLOCKED)' : 'OFFLINE (NORMAL PLAY)'}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      Suspends incoming bets across all consoles with a client-side overlay while keeping history graphs and user balances intact.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleToggleMaintenance}
                  disabled={maintenanceLoading}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition border cursor-pointer ${
                    maintenanceActive
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-400'
                      : 'bg-amber-600 hover:bg-amber-500 text-white border-amber-400'
                  }`}
                >
                  {maintenanceLoading ? 'Processing...' : maintenanceActive ? 'Disable Maintenance Mode' : 'Activate Maintenance Mode'}
                </button>
              </div>

              {/* Physical Crash Now / Round Crash Big Red Button */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Physical Crash Trigger Card */}
                <div className="bg-gradient-to-b from-[#21090f] to-[#16171b] border-2 border-red-600/60 rounded-xl p-5 flex flex-col items-center justify-center text-center shadow-[0_0_30px_rgba(225,29,72,0.2)]">
                  <span className="text-xs font-mono font-bold text-red-400 uppercase tracking-widest mb-1 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Round Crash & Destination Assurance
                  </span>
                  <div className="text-4xl font-black font-mono text-white mb-2">
                    {currentMultiplier.toFixed(2)}x
                  </div>

                  <button
                    id="admin-crash-now-btn"
                    type="button"
                    onClick={handleTriggerCrashNow}
                    className="w-full max-w-xs py-5 rounded-2xl bg-gradient-to-b from-red-500 via-rose-600 to-red-700 hover:from-red-400 hover:to-red-600 active:scale-95 border-2 border-red-300 shadow-[0_0_35px_rgba(239,68,68,0.7)] text-white font-black text-xl font-['Chakra_Petch'] tracking-wider flex items-center justify-center gap-3 transition cursor-pointer"
                  >
                    <AlertOctagon className="w-7 h-7 animate-pulse" />
                    <span>{gameStatus === 'FLYING' ? '[ROUND CRASH NOW]' : '[CRASH NEXT TAKEOFF]'}</span>
                  </button>

                  <p className="text-[11px] text-neutral-300 mt-3 font-mono leading-tight">
                    {gameStatus === 'FLYING'
                      ? 'Click to immediately crash the active flight at the current multiplier.'
                      : 'Flight is waiting — clicking will force an immediate 1.01x crash on takeoff.'}
                  </p>

                  <div className="mt-3 flex items-center gap-2 text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-800/50 px-3 py-1 rounded-full font-mono">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>Role Restricted: Super Admin & Admin Only</span>
                  </div>
                </div>

                {/* Next Round Multiplier Preset */}
                <div className="bg-[#17181d] border border-[#2a2c36] rounded-xl p-5 flex flex-col justify-between">
                  <div>
                    <div className="text-sm font-bold text-white mb-1 flex items-center gap-2">
                      <Radio className="w-4 h-4 text-purple-400" />
                      <span>Next Round Multiplier Target</span>
                    </div>
                    <p className="text-xs text-neutral-400">
                      Force the exact multiplier where the next round will crash automatically.
                    </p>

                    <form onSubmit={handleSetNextCrash} className="mt-4 space-y-3">
                      <div className="flex items-center gap-2 bg-[#121316] border border-[#2b2e3b] rounded-xl px-3 py-2">
                        <input
                          type="number"
                          step={0.01}
                          min={1.01}
                          max={10000}
                          value={presetMultiplier}
                          onChange={(e) => setPresetMultiplier(e.target.value)}
                          className="w-full bg-transparent font-mono font-bold text-white text-base focus:outline-none"
                          placeholder="e.g. 99.00 or 10000.00"
                        />
                        <span className="text-xs font-bold text-neutral-400">x</span>
                      </div>

                      {/* Quick preset buttons */}
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {['1.12', '1.45', '2.00', '2.70', '5.20', '15.00', '99.00', '1000.00', '10000.00'].map((val) => (
                          <button
                            key={val}
                            type="button"
                            onClick={() => setPresetMultiplier(val)}
                            className="text-xs font-mono font-bold px-2 py-1 rounded bg-[#22242c] hover:bg-[#2d303b] text-neutral-300 border border-[#313441] transition"
                          >
                            {val}x
                          </button>
                        ))}
                      </div>

                      {/* Natural Exponential Speed Lock Badge */}
                      <div className="bg-[#121316] border border-amber-500/30 rounded-xl p-3 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-mono font-bold text-amber-400 flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                            Natural Exponential Speed Locked
                          </span>
                          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                            8-Sec 2X Lock
                          </span>
                        </div>
                        <p className="text-[10px] text-neutral-400 leading-relaxed font-mono">
                          Formula: <span className="text-white">e^(0.08664 × t)</span>. Takes exactly <span className="text-amber-300">8.00s</span> to 2x, <span className="text-amber-300">~26s</span> to 10x, and accelerates past 100x at <span className="text-amber-300">~53s</span>. Artificial duration stretching is disabled to prevent freezes and desync.
                        </p>
                      </div>

                      {presetFeedback && (
                        <div className="text-xs text-emerald-400 font-medium">
                          {presetFeedback}
                        </div>
                      )}

                      <button
                        type="submit"
                        className="w-full py-2.5 bg-purple-700 hover:bg-purple-600 rounded-xl font-bold text-xs text-white transition shadow-md cursor-pointer"
                      >
                        Lock In Target Multiplier
                      </button>
                    </form>
                  </div>
                </div>
              </div>

              {/* DEDICATED CHEAT & CRASH PERCENTAGE BARS (SUPER ADMIN & ADMIN CONTROLS) */}
              <div className="bg-[#17181d] border-2 border-indigo-600/40 rounded-xl p-5 shadow-lg space-y-6">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-indigo-950/60 border border-indigo-600/50 text-indigo-400">
                      <Sliders className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-black text-white font-['Chakra_Petch'] tracking-wide flex items-center gap-2">
                        CHEAT & CRASH PERCENTAGE CONTROL BARS
                        <span className="text-[10px] bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 px-2 py-0.5 rounded-full font-mono font-bold">
                          Live Engine
                        </span>
                      </h3>
                      <p className="text-xs text-neutral-400 mt-0.5">
                        Super Admin & Admin calibrated risk sliders. Increase or decrease percentages in real time.
                      </p>
                    </div>
                  </div>

                  {percentageFeedback && (
                    <div className="text-xs text-emerald-400 bg-emerald-950/50 border border-emerald-700/60 px-3 py-1.5 rounded-lg font-mono font-bold animate-pulse">
                      {percentageFeedback}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* BAR 1: CHEAT PERCENTAGE BAR */}
                  <div className="bg-[#121316] border border-fuchsia-900/40 rounded-xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-fuchsia-500 animate-pulse" />
                        <span className="text-xs font-bold text-white font-mono uppercase">
                          Cheat Percentage Bar
                        </span>
                      </div>
                      <span className="text-lg font-black font-mono text-fuchsia-400 bg-fuchsia-950/60 border border-fuchsia-800/60 px-2.5 py-0.5 rounded-lg">
                        {cheatPercentage}%
                      </span>
                    </div>

                    {/* Visual Progress Bar */}
                    <div className="w-full bg-neutral-900 rounded-full h-3.5 p-0.5 border border-neutral-800 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-fuchsia-600 via-pink-500 to-rose-500 transition-all duration-300 shadow-[0_0_12px_#d946ef]"
                        style={{ width: `${cheatPercentage}%` }}
                      />
                    </div>

                    {/* Interactive Range Slider */}
                    <div className="space-y-1">
                      <input
                        type="range"
                        min={0}
                        max={100}
                        step={1}
                        value={cheatPercentage}
                        onChange={(e) => handleUpdateCheatPercentages(parseInt(e.target.value), crashPercentage)}
                        className="w-full accent-fuchsia-500 cursor-pointer h-2 bg-neutral-800 rounded-lg"
                      />
                      <div className="flex justify-between text-[10px] font-mono text-neutral-500 px-0.5">
                        <span>0% (No Cheats)</span>
                        <span>50%</span>
                        <span>60% (Default)</span>
                        <span>100% (Strict)</span>
                      </div>
                    </div>

                    {/* Stepper Buttons */}
                    <div className="flex items-center gap-1.5 flex-wrap pt-1">
                      <button
                        type="button"
                        onClick={() => handleUpdateCheatPercentages(cheatPercentage - 10, crashPercentage)}
                        className="px-2 py-1 text-xs font-mono font-bold rounded bg-[#22242c] hover:bg-[#2d303b] text-neutral-300 border border-[#313441] transition cursor-pointer"
                      >
                        -10%
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateCheatPercentages(cheatPercentage - 5, crashPercentage)}
                        className="px-2 py-1 text-xs font-mono font-bold rounded bg-[#22242c] hover:bg-[#2d303b] text-neutral-300 border border-[#313441] transition cursor-pointer"
                      >
                        -5%
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateCheatPercentages(cheatPercentage + 5, crashPercentage)}
                        className="px-2 py-1 text-xs font-mono font-bold rounded bg-[#22242c] hover:bg-[#2d303b] text-fuchsia-300 border border-fuchsia-900/60 hover:border-fuchsia-500 transition cursor-pointer"
                      >
                        +5%
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateCheatPercentages(cheatPercentage + 10, crashPercentage)}
                        className="px-2 py-1 text-xs font-mono font-bold rounded bg-[#22242c] hover:bg-[#2d303b] text-fuchsia-300 border border-fuchsia-900/60 hover:border-fuchsia-500 transition cursor-pointer"
                      >
                        +10%
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateCheatPercentages(60, crashPercentage)}
                        className="ml-auto px-2 py-1 text-xs font-mono font-bold rounded bg-fuchsia-950/60 hover:bg-fuchsia-900/80 text-fuchsia-200 border border-fuchsia-700/60 transition cursor-pointer"
                      >
                        Reset 60%
                      </button>
                    </div>

                    {/* Quick Preset Buttons */}
                    <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-neutral-800/80">
                      <span className="text-[10px] text-neutral-400 font-mono">Presets:</span>
                      {[20, 40, 60, 80, 100].map((p) => (
                        <button
                          key={p}
                          type="button"
                          onClick={() => handleUpdateCheatPercentages(p, crashPercentage)}
                          className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border transition cursor-pointer ${
                            cheatPercentage === p
                              ? 'bg-fuchsia-600 text-white border-fuchsia-400'
                              : 'bg-neutral-800/60 text-neutral-300 border-neutral-700 hover:text-white'
                          }`}
                        >
                          {p}%
                        </button>
                      ))}
                    </div>

                    <p className="text-[11px] text-neutral-400 leading-tight">
                      Controls the matrix deck ratio of forced crashes when high-going bets or suspicious cashouts occur.
                    </p>
                  </div>

                  {/* BAR 2: CRASH PERCENTAGE BAR */}
                  <div className="bg-[#121316] border border-rose-900/40 rounded-xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-rose-500 animate-pulse" />
                        <span className="text-xs font-bold text-white font-mono uppercase">
                          Crash Percentage Bar
                        </span>
                      </div>
                      <span className="text-lg font-black font-mono text-rose-400 bg-rose-950/60 border border-rose-800/60 px-2.5 py-0.5 rounded-lg">
                        {crashPercentage}%
                      </span>
                    </div>

                    {/* Visual Progress Bar */}
                    <div className="w-full bg-neutral-900 rounded-full h-3.5 p-0.5 border border-neutral-800 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 transition-all duration-300 shadow-[0_0_12px_#f43f5e]"
                        style={{ width: `${crashPercentage}%` }}
                      />
                    </div>

                    {/* Interactive Range Slider */}
                    <div className="space-y-1">
                      <input
                        type="range"
                        min={0}
                        max={100}
                        step={1}
                        value={crashPercentage}
                        onChange={(e) => handleUpdateCheatPercentages(cheatPercentage, parseInt(e.target.value))}
                        className="w-full accent-rose-500 cursor-pointer h-2 bg-neutral-800 rounded-lg"
                      />
                      <div className="flex justify-between text-[10px] font-mono text-neutral-500 px-0.5">
                        <span>0% (Moonshots)</span>
                        <span>35%</span>
                        <span>47% (Default)</span>
                        <span>100% (Instant)</span>
                      </div>
                    </div>

                    {/* Stepper Buttons */}
                    <div className="flex items-center gap-1.5 flex-wrap pt-1">
                      <button
                        type="button"
                        onClick={() => handleUpdateCheatPercentages(cheatPercentage, crashPercentage - 10)}
                        className="px-2 py-1 text-xs font-mono font-bold rounded bg-[#22242c] hover:bg-[#2d303b] text-neutral-300 border border-[#313441] transition cursor-pointer"
                      >
                        -10%
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateCheatPercentages(cheatPercentage, crashPercentage - 5)}
                        className="px-2 py-1 text-xs font-mono font-bold rounded bg-[#22242c] hover:bg-[#2d303b] text-neutral-300 border border-[#313441] transition cursor-pointer"
                      >
                        -5%
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateCheatPercentages(cheatPercentage, crashPercentage + 5)}
                        className="px-2 py-1 text-xs font-mono font-bold rounded bg-[#22242c] hover:bg-[#2d303b] text-rose-300 border border-rose-900/60 hover:border-rose-500 transition cursor-pointer"
                      >
                        +5%
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateCheatPercentages(cheatPercentage, crashPercentage + 10)}
                        className="px-2 py-1 text-xs font-mono font-bold rounded bg-[#22242c] hover:bg-[#2d303b] text-rose-300 border border-rose-900/60 hover:border-rose-500 transition cursor-pointer"
                      >
                        +10%
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateCheatPercentages(cheatPercentage, 47)}
                        className="ml-auto px-2 py-1 text-xs font-mono font-bold rounded bg-rose-950/60 hover:bg-rose-900/80 text-rose-200 border border-rose-700/60 transition cursor-pointer"
                      >
                        Reset 47%
                      </button>
                    </div>

                    {/* Quick Preset Buttons */}
                    <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-neutral-800/80">
                      <span className="text-[10px] text-neutral-400 font-mono">Presets:</span>
                      {[25, 35, 47, 65, 85].map((p) => (
                        <button
                          key={p}
                          type="button"
                          onClick={() => handleUpdateCheatPercentages(cheatPercentage, p)}
                          className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border transition cursor-pointer ${
                            crashPercentage === p
                              ? 'bg-rose-600 text-white border-rose-400'
                              : 'bg-neutral-800/60 text-neutral-300 border-neutral-700 hover:text-white'
                          }`}
                        >
                          {p}%
                        </button>
                      ))}
                    </div>

                    <p className="text-[11px] text-neutral-400 leading-tight">
                      Controls the baseline algorithmic distribution probability of flights crashing below 1.90x as per calculation.
                    </p>
                  </div>
                </div>

                {/* MASTER CHEAT ON/OFF + TIMING & DEVELOPER LOSS PROTECTION PANEL */}
                {cheatTimeControl && (
                  <div className="pt-4 border-t border-neutral-800 space-y-5">
                    {/* MASTER CHEAT ON/OFF SWITCH WITH TIMING (SUPER ADMIN & APPROVED ADMIN) */}
                    <div className={`p-4 rounded-xl border-2 space-y-3 ${
                      cheatTimeControl.cheatSystemEnabled !== false
                        ? 'bg-fuchsia-950/25 border-fuchsia-500/50'
                        : 'bg-emerald-950/25 border-emerald-500/50'
                    }`}>
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-2">
                          <span className={`w-3 h-3 rounded-full ${
                            cheatTimeControl.cheatSystemEnabled !== false ? 'bg-fuchsia-400 animate-ping' : 'bg-emerald-400'
                          }`} />
                          <div>
                            <h4 className="text-xs font-black uppercase tracking-wider text-white">
                              MASTER CHEAT ENGINE ON / OFF SWITCH (SUPER ADMIN & APPROVED ADMIN)
                            </h4>
                            <p className="text-[11px] text-neutral-400">
                              When Cheat ON: all cheat rules, percentages & loss protection work. When Cheat OFF: 100% Fair Mode (no cheat works).
                            </p>
                          </div>
                        </div>
                        <span className={`px-3 py-1 rounded-lg text-xs font-mono font-black ${
                          cheatTimeControl.cheatSystemEnabled !== false
                            ? 'bg-fuchsia-600 text-white shadow-lg shadow-fuchsia-600/30'
                            : 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                        }`}>
                          {cheatTimeControl.cheatSystemEnabled !== false ? '🔥 CHEAT ON (ALL CHEATS ACTIVE)' : '🛡️ CHEAT OFF (100% FAIR MODE)'}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                        {/* Instant Permanent ON / OFF */}
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleSaveCheatTimeControl({
                              cheatSystemEnabled: true,
                              stopCheatToggleTimer: true,
                              toggledBy: 'Super Admin / Approved Admin'
                            }, '🔥 Master Cheat Engine turned ON permanently!')}
                            className={`flex-1 py-2.5 px-3 rounded-xl font-black text-xs transition cursor-pointer ${
                              cheatTimeControl.cheatSystemEnabled !== false && !cheatTimeControl.cheatToggleTimerActive
                                ? 'bg-fuchsia-600 text-white ring-2 ring-fuchsia-300 shadow-lg'
                                : 'bg-[#1a1c24] text-neutral-300 hover:bg-fuchsia-950/60 border border-neutral-700'
                            }`}
                          >
                            🔥 TURN CHEAT ON (ALL ACTIVE)
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSaveCheatTimeControl({
                              cheatSystemEnabled: false,
                              stopCheatToggleTimer: true,
                              toggledBy: 'Super Admin / Approved Admin'
                            }, '🛡️ Master Cheat Engine turned OFF (100% Fair Mode)!')}
                            className={`flex-1 py-2.5 px-3 rounded-xl font-black text-xs transition cursor-pointer ${
                              cheatTimeControl.cheatSystemEnabled === false && !cheatTimeControl.cheatToggleTimerActive
                                ? 'bg-emerald-600 text-white ring-2 ring-emerald-300 shadow-lg'
                                : 'bg-[#1a1c24] text-neutral-300 hover:bg-emerald-950/60 border border-neutral-700'
                            }`}
                          >
                            🛡️ TURN CHEAT OFF (ONLY FAIR)
                          </button>
                        </div>

                        {/* Timed Cheat ON / OFF Option */}
                        <div className="flex items-center gap-2 bg-[#121318] p-2 rounded-xl border border-neutral-800">
                          <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                          <span className="text-[11px] text-neutral-300 font-semibold whitespace-nowrap">Timer (Mins):</span>
                          <input
                            type="number"
                            min={1}
                            max={1440}
                            value={cheatToggleDurationMins}
                            onChange={(e) => setCheatToggleDurationMins(Math.max(1, parseInt(e.target.value) || 1))}
                            className="w-16 bg-neutral-950 border border-neutral-700 rounded-lg px-2 py-1 text-xs font-mono text-white text-center"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveCheatTimeControl({
                              cheatSystemEnabled: true,
                              cheatToggleDurationMinutes: cheatToggleDurationMins,
                              startCheatToggleTimer: true,
                              toggledBy: 'Super Admin / Approved Admin'
                            }, `⏱️ Cheat ON for ${cheatToggleDurationMins}m (auto-reverts to Fair Mode after)`)}
                            className="px-2.5 py-1.5 rounded-lg bg-fuchsia-700 hover:bg-fuchsia-600 text-white font-bold text-[11px] transition cursor-pointer whitespace-nowrap"
                          >
                            ON for {cheatToggleDurationMins}m
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSaveCheatTimeControl({
                              cheatSystemEnabled: false,
                              cheatToggleDurationMinutes: cheatToggleDurationMins,
                              startCheatToggleTimer: true,
                              toggledBy: 'Super Admin / Approved Admin'
                            }, `⏱️ Cheat OFF (Fair) for ${cheatToggleDurationMins}m (auto-reverts to Cheat ON after)`)}
                            className="px-2.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-[11px] transition cursor-pointer whitespace-nowrap"
                          >
                            OFF for {cheatToggleDurationMins}m
                          </button>
                        </div>
                      </div>

                      {cheatTimeControl.cheatToggleTimerActive && cheatTimeControl.cheatToggleTimerExpiresAt > Date.now() && (
                        <div className="flex items-center justify-between bg-amber-950/40 border border-amber-500/40 rounded-lg px-3 py-1.5 text-xs text-amber-300 font-mono">
                          <span>
                            ⏳ Timed Cheat Switch Active: Currently <b>{cheatTimeControl.cheatSystemEnabled ? 'CHEAT ON' : 'CHEAT OFF (FAIR)'}</b> — Reverts at {new Date(cheatTimeControl.cheatToggleTimerExpiresAt).toLocaleTimeString()} ({Math.max(1, Math.ceil((cheatTimeControl.cheatToggleTimerExpiresAt - Date.now()) / 60000))}m left)
                          </span>
                          <button
                            type="button"
                            onClick={() => handleSaveCheatTimeControl({ stopCheatToggleTimer: true }, 'Timer cancelled')}
                            className="px-2 py-0.5 bg-red-900/60 hover:bg-red-800 text-red-200 rounded text-[10px] font-bold"
                          >
                            Cancel Timer
                          </button>
                        </div>
                      )}
                    </div>

                    {/* TIME-CONTROLLED CHEAT/CRASH MODE & DEVELOPER LOSS PROTECTION */}
                    <div className="bg-[#121316] border border-amber-500/30 rounded-xl p-4 space-y-4">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-amber-400" />
                          <h4 className="text-xs font-black uppercase tracking-wider text-white">
                            SUPER ADMIN TIME-CONTROLLED CRASH & DEVELOPER LOSS RECOVERY
                          </h4>
                        </div>
                        {timeControlFeedback && (
                          <span className="text-xs text-emerald-400 font-mono font-bold">
                            {timeControlFeedback}
                          </span>
                        )}
                      </div>

                      {/* Mode Selector Buttons */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {[
                          { id: 'MANUAL', label: '🎛️ Manual Sliders' },
                          { id: 'TIMED_DURATION', label: '⏱️ Set Duration Timer' },
                          { id: 'SCHEDULED_WINDOW', label: '🕒 Set Clock Window' },
                          { id: 'AUTO_DYNAMIC', label: '🤖 Auto Dynamic Scaling' }
                        ].map((m) => (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => handleSaveCheatTimeControl({ mode: m.id }, `Switched mode to ${m.label}`)}
                            className={`py-2 px-3 rounded-lg text-xs font-bold border transition cursor-pointer ${
                              cheatTimeControl.mode === m.id
                                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                                : 'bg-[#191b22] border-neutral-800 text-neutral-400 hover:text-white'
                            }`}
                          >
                            {m.label}
                          </button>
                        ))}
                      </div>

                      {/* Mode Specific Inputs */}
                      {cheatTimeControl.mode === 'TIMED_DURATION' && (
                        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-[#171920] p-3 rounded-xl border border-neutral-800 items-end">
                          <div>
                            <label className="block text-[10px] text-neutral-400 uppercase font-mono mb-1">Duration (Minutes)</label>
                            <input
                              type="number"
                              min={1}
                              max={1440}
                              value={cheatTimeControl.timedDurationMinutes}
                              onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, timedDurationMinutes: Number(e.target.value) })}
                              className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-neutral-400 uppercase font-mono mb-1">Timed Cheat %</label>
                            <input
                              type="number"
                              min={0}
                              max={100}
                              value={cheatTimeControl.timedCheatPercentage}
                              onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, timedCheatPercentage: Number(e.target.value) })}
                              className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-xs text-fuchsia-400 font-mono font-bold"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-neutral-400 uppercase font-mono mb-1">Timed Crash %</label>
                            <input
                              type="number"
                              min={0}
                              max={100}
                              value={cheatTimeControl.timedCrashPercentage}
                              onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, timedCrashPercentage: Number(e.target.value) })}
                              className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-xs text-rose-400 font-mono font-bold"
                            />
                          </div>
                          <button
                            type="button"
                            onClick={() => handleSaveCheatTimeControl({
                              mode: 'TIMED_DURATION',
                              timedDurationMinutes: cheatTimeControl.timedDurationMinutes,
                              timedCheatPercentage: cheatTimeControl.timedCheatPercentage,
                              timedCrashPercentage: cheatTimeControl.timedCrashPercentage,
                              startTimer: true
                            }, `⏱️ Started ${cheatTimeControl.timedDurationMinutes}m Timed Override!`)}
                            className="py-2 px-3 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs rounded-lg transition cursor-pointer"
                          >
                            Start Timed Control
                          </button>
                        </div>
                      )}

                      {cheatTimeControl.mode === 'SCHEDULED_WINDOW' && (
                        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 bg-[#171920] p-3 rounded-xl border border-neutral-800 items-end">
                          <div>
                            <label className="block text-[10px] text-neutral-400 uppercase font-mono mb-1">Start Time (HH:mm)</label>
                            <input
                              type="time"
                              value={cheatTimeControl.scheduleStartTime}
                              onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, scheduleStartTime: e.target.value })}
                              className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-neutral-400 uppercase font-mono mb-1">End Time (HH:mm)</label>
                            <input
                              type="time"
                              value={cheatTimeControl.scheduleEndTime}
                              onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, scheduleEndTime: e.target.value })}
                              className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-neutral-400 uppercase font-mono mb-1">Window Cheat %</label>
                            <input
                              type="number"
                              min={0}
                              max={100}
                              value={cheatTimeControl.scheduledCheatPercentage}
                              onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, scheduledCheatPercentage: Number(e.target.value) })}
                              className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-xs text-fuchsia-400 font-mono"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-neutral-400 uppercase font-mono mb-1">Window Crash %</label>
                            <input
                              type="number"
                              min={0}
                              max={100}
                              value={cheatTimeControl.scheduledCrashPercentage}
                              onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, scheduledCrashPercentage: Number(e.target.value) })}
                              className="w-full bg-neutral-950 border border-neutral-700 rounded-lg px-2.5 py-1.5 text-xs text-rose-400 font-mono"
                            />
                          </div>
                          <button
                            type="button"
                            onClick={() => handleSaveCheatTimeControl({
                              mode: 'SCHEDULED_WINDOW',
                              scheduleStartTime: cheatTimeControl.scheduleStartTime,
                              scheduleEndTime: cheatTimeControl.scheduleEndTime,
                              scheduledCheatPercentage: cheatTimeControl.scheduledCheatPercentage,
                              scheduledCrashPercentage: cheatTimeControl.scheduledCrashPercentage
                            }, '🕒 Scheduled Time Window Saved!')}
                            className="py-2 px-3 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs rounded-lg transition cursor-pointer"
                          >
                            Save Window
                          </button>
                        </div>
                      )}

                      {/* DEVELOPER LOSS SITUATION PROTECTION & EXACT FLIGHT CRASH TIME */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-neutral-800">
                        <div className="bg-rose-950/20 border border-rose-500/40 rounded-xl p-3 space-y-2.5">
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-xs font-black text-rose-300 uppercase">
                                🛡️ Developer Loss Recovery Protection
                              </span>
                              <p className="text-[10px] text-neutral-400">
                                Auto-engages when house net profit is in loss or round liability exceeds threshold.
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleSaveCheatTimeControl({
                                devLossProtectionEnabled: !cheatTimeControl.devLossProtectionEnabled
                              }, `Developer Loss Protection ${!cheatTimeControl.devLossProtectionEnabled ? 'ENABLED' : 'DISABLED'}`)}
                              className={`px-2.5 py-1 rounded text-[10px] font-mono font-bold cursor-pointer ${
                                cheatTimeControl.devLossProtectionEnabled
                                  ? 'bg-rose-600 text-white'
                                  : 'bg-neutral-800 text-neutral-400'
                              }`}
                            >
                              {cheatTimeControl.devLossProtectionEnabled ? 'ENABLED' : 'OFF'}
                            </button>
                          </div>

                          <div className="grid grid-cols-3 gap-2">
                            <div>
                              <label className="block text-[9px] text-neutral-400 font-mono">Loss Cheat %</label>
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={cheatTimeControl.devLossForceCheatPercentage}
                                onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, devLossForceCheatPercentage: Number(e.target.value) })}
                                className="w-full bg-neutral-950 border border-neutral-700 rounded px-2 py-1 text-xs font-mono text-white"
                              />
                            </div>
                            <div>
                              <label className="block text-[9px] text-neutral-400 font-mono">Loss Crash %</label>
                              <input
                                type="number"
                                min={0}
                                max={100}
                                value={cheatTimeControl.devLossForceCrashPercentage}
                                onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, devLossForceCrashPercentage: Number(e.target.value) })}
                                className="w-full bg-neutral-950 border border-neutral-700 rounded px-2 py-1 text-xs font-mono text-white"
                              />
                            </div>
                            <div>
                              <label className="block text-[9px] text-neutral-400 font-mono">Max Crash Cap (x)</label>
                              <input
                                type="number"
                                step={0.05}
                                min={1.01}
                                value={cheatTimeControl.devLossMaxCrashMultiplier}
                                onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, devLossMaxCrashMultiplier: Number(e.target.value) })}
                                className="w-full bg-neutral-950 border border-neutral-700 rounded px-2 py-1 text-xs font-mono text-rose-400 font-bold"
                              />
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleSaveCheatTimeControl({
                              devLossProtectionEnabled: cheatTimeControl.devLossProtectionEnabled,
                              devLossForceCheatPercentage: cheatTimeControl.devLossForceCheatPercentage,
                              devLossForceCrashPercentage: cheatTimeControl.devLossForceCrashPercentage,
                              devLossMaxCrashMultiplier: cheatTimeControl.devLossMaxCrashMultiplier
                            }, 'Developer Loss Protection thresholds saved!')}
                            className="w-full py-1.5 bg-rose-700 hover:bg-rose-600 text-white rounded-lg text-[11px] font-bold transition cursor-pointer"
                          >
                            Apply Loss Recovery Settings
                          </button>
                        </div>

                        {/* SET WHEN TO CRASH BY FLIGHT SECONDS OR EXACT CLOCK TIME */}
                        <div className="bg-indigo-950/20 border border-indigo-500/40 rounded-xl p-3 space-y-2.5">
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-xs font-black text-indigo-300 uppercase">
                                ⏱️ Set Exact Time When To Crash
                              </span>
                              <p className="text-[10px] text-neutral-400">
                                Crash flight after N seconds of flying or at an exact clock time (HH:mm).
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleSaveCheatTimeControl({
                                crashAtFlightSecondsEnabled: !cheatTimeControl.crashAtFlightSecondsEnabled
                              }, `Crash at Flight Seconds ${!cheatTimeControl.crashAtFlightSecondsEnabled ? 'ENABLED' : 'DISABLED'}`)}
                              className={`px-2.5 py-1 rounded text-[10px] font-mono font-bold cursor-pointer ${
                                cheatTimeControl.crashAtFlightSecondsEnabled
                                  ? 'bg-indigo-600 text-white'
                                  : 'bg-neutral-800 text-neutral-400'
                              }`}
                            >
                              {cheatTimeControl.crashAtFlightSecondsEnabled ? 'FLIGHT TIMER ON' : 'FLIGHT TIMER OFF'}
                            </button>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[9px] text-neutral-400 font-mono">Crash After Flight Secs (s)</label>
                              <input
                                type="number"
                                step={0.5}
                                min={0.5}
                                max={120}
                                value={cheatTimeControl.crashAtFlightSeconds}
                                onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, crashAtFlightSeconds: Number(e.target.value) })}
                                className="w-full bg-neutral-950 border border-neutral-700 rounded px-2 py-1 text-xs font-mono text-indigo-300 font-bold"
                              />
                            </div>
                            <div>
                              <label className="block text-[9px] text-neutral-400 font-mono">Exact Clock Crash (HH:mm)</label>
                              <input
                                type="time"
                                value={cheatTimeControl.scheduledExactCrashTime}
                                onChange={(e) => setCheatTimeControl({ ...cheatTimeControl, scheduledExactCrashTime: e.target.value, scheduledExactCrashEnabled: Boolean(e.target.value) })}
                                className="w-full bg-neutral-950 border border-neutral-700 rounded px-2 py-1 text-xs font-mono text-white"
                              />
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleSaveCheatTimeControl({
                              crashAtFlightSecondsEnabled: cheatTimeControl.crashAtFlightSecondsEnabled,
                              crashAtFlightSeconds: cheatTimeControl.crashAtFlightSeconds,
                              scheduledExactCrashEnabled: Boolean(cheatTimeControl.scheduledExactCrashTime),
                              scheduledExactCrashTime: cheatTimeControl.scheduledExactCrashTime
                            }, 'Exact Crash Timing rules updated!')}
                            className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-[11px] font-bold transition cursor-pointer"
                          >
                            Lock Crash Timing Rule
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB: TREND SEED CONFIGURATION & HISTORY MANIPULATION (MODULE 5 & 10) */}
          {activeTab === 'trendSeed' && (
            <div className="space-y-4">
              <div className="bg-[#17181d] border border-[#2a2c36] rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Flame className="w-5 h-5 text-orange-400" />
                    <h3 className="text-sm font-bold text-white font-['Chakra_Petch']">
                      TREND SEED CONFIGURATION (MODULE 5)
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono bg-orange-950/60 border border-orange-500/30 text-orange-300 px-2 py-0.5 rounded-full font-bold">
                    Pattern Neutralizer
                  </span>
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed mb-4">
                  Configure algorithmic risk overrides. When active pool liabilities spike, the engine forcefully nullifies player trend analysis by injecting consecutive instant crash points (1.01x - 1.10x).
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-[#121316] border border-[#262831] rounded-xl p-4 space-y-3">
                    <label className="block text-xs font-bold text-neutral-300">
                      Trend Algorithm Mode
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'NATURAL', label: 'Natural' },
                        { id: 'CONSECUTIVE_LOW_CRASH', label: 'Low Crashes' },
                        { id: 'CUSTOM_PATTERN', label: 'Custom' }
                      ].map((m) => (
                        <button
                          key={m.id}
                          type="button"
                          onClick={() => setTrendMode(m.id as any)}
                          className={`py-2 px-2 text-xs font-bold rounded-lg border transition cursor-pointer ${
                            trendMode === m.id
                              ? 'bg-orange-600 text-white border-orange-400 shadow-sm'
                              : 'bg-[#1b1d24] border-[#2c2f3c] text-neutral-400 hover:text-white'
                          }`}
                        >
                          {m.label}
                        </button>
                      ))}
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        Consecutive Instant Crashes (1.01x - 1.10x) Remaining
                      </label>
                      <input
                        type="number"
                        min={0}
                        max={10}
                        value={consecutiveCrashesInput}
                        onChange={(e) => setConsecutiveCrashesInput(Math.max(0, +e.target.value))}
                        className="w-full bg-[#1c1d24] border border-[#2f3240] rounded-xl px-3 py-2 font-mono text-sm text-white focus:outline-none"
                      />
                      <p className="text-[10px] text-neutral-400 mt-1">
                        Overrides the next N rounds with instant crashes between 1.01x and 1.10x to eliminate betting clusters.
                      </p>
                    </div>

                    <div className="pt-2 border-t border-[#262831]">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={autoOverrideLiabilityInput}
                          onChange={(e) => setAutoOverrideLiabilityInput(e.target.checked)}
                          className="rounded border-neutral-700 text-orange-500 focus:ring-0 w-4 h-4"
                        />
                        <span className="text-xs font-bold text-white">
                          Auto-Override on Liability Spike (Module 10)
                        </span>
                      </label>
                      <p className="text-[10px] text-neutral-400 mt-0.5 ml-6">
                        Automatically trigger 2-4 instant crashes if current round pool liabilities exceed threshold.
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-neutral-300 mb-1">
                        Liability Spike Trigger Threshold (₹)
                      </label>
                      <input
                        type="number"
                        step={1000}
                        min={5000}
                        value={liabilityCrashThresholdInput}
                        onChange={(e) => setLiabilityCrashThresholdInput(+e.target.value)}
                        className="w-full bg-[#1c1d24] border border-[#2f3240] rounded-xl px-3 py-2 font-mono text-sm text-white focus:outline-none"
                      />
                    </div>

                    {trendFeedback && (
                      <div className="text-xs text-emerald-400 font-bold">{trendFeedback}</div>
                    )}

                    <button
                      type="button"
                      onClick={handleSaveTrendConfig}
                      className="w-full py-2.5 bg-orange-600 hover:bg-orange-500 rounded-xl font-bold text-xs text-white transition shadow-md cursor-pointer"
                    >
                      Save Trend Seed Configuration
                    </button>
                  </div>

                  {/* Inject Arbitrary Sequence into History Graph */}
                  <div className="bg-[#121316] border border-[#262831] rounded-xl p-4 space-y-3 flex flex-col justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-1">
                        Inject Outcome into Past History Graph
                      </h4>
                      <p className="text-xs text-neutral-400 mb-3">
                        Directly inject an arbitrary historical crash point into the top multiplier ticker without interrupting the live flight loop.
                      </p>

                      <form onSubmit={handleInjectHistory} className="space-y-3">
                        <div>
                          <label className="block text-xs font-semibold text-neutral-300 mb-1">
                            Injected Multiplier Value
                          </label>
                          <div className="flex items-center gap-2 bg-[#1c1d24] border border-[#2f3240] rounded-xl px-3 py-2">
                            <input
                              type="number"
                              step={0.01}
                              min={1.01}
                              max={100}
                              value={historyInjectMultiplier}
                              onChange={(e) => setHistoryInjectMultiplier(e.target.value)}
                              className="w-full bg-transparent font-mono font-bold text-white text-sm focus:outline-none"
                              placeholder="e.g. 1.04 or 12.80"
                            />
                            <span className="text-xs font-bold text-neutral-400">x</span>
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-neutral-300 mb-1">
                            Custom Round ID (Optional)
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. R-INJ-786 (leave empty for auto)"
                            value={historyInjectRoundId}
                            onChange={(e) => setHistoryInjectRoundId(e.target.value)}
                            className="w-full bg-[#1c1d24] border border-[#2f3240] rounded-xl px-3 py-2 font-mono text-xs text-white focus:outline-none"
                          />
                        </div>

                        <div className="flex items-center gap-1.5 flex-wrap pt-1">
                          {['1.02', '1.05', '1.09', '3.40', '18.90'].map((val) => (
                            <button
                              key={val}
                              type="button"
                              onClick={() => setHistoryInjectMultiplier(val)}
                              className="text-xs font-mono font-bold px-2 py-1 rounded bg-[#22242c] hover:bg-[#2d303b] text-neutral-300 border border-[#313441] transition cursor-pointer"
                            >
                              {val}x
                            </button>
                          ))}
                        </div>

                        <button
                          type="submit"
                          className="w-full py-2.5 bg-indigo-700 hover:bg-indigo-600 rounded-xl font-bold text-xs text-white transition shadow-md cursor-pointer"
                        >
                          Inject Into History Graph
                        </button>
                      </form>
                    </div>

                    <div className="text-[11px] text-neutral-400 bg-[#17181f] p-2.5 rounded-lg border border-[#262833]">
                      <span>💡 The injected round broadcasts immediately via socket and appears on client history pills.</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: LEADERBOARD MATRIX & SYNTHETIC SEEDING (MODULE 9) */}
          {activeTab === 'leaderboard' && (
            <div className="space-y-4">
              <div className="bg-[#17181d] border border-[#2a2c36] rounded-xl p-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                    <div>
                      <h3 className="text-sm font-bold text-white font-['Chakra_Petch']">
                        LEADERBOARD MATRIX & HIGH-ROLLER SEEDER (MODULE 9)
                      </h3>
                      <p className="text-xs text-neutral-400">
                        Multi-timeframe winners engine with verified synthetic high-multiplier records.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Timeframe selector */}
                    <div className="flex bg-[#121316] p-1 rounded-xl border border-[#2a2c36]">
                      {(['DAILY', 'WEEKLY', 'YEARLY'] as const).map((tf) => (
                        <button
                          key={tf}
                          type="button"
                          onClick={() => {
                            setLeaderboardTf(tf);
                            setTimeout(fetchLeaderboard, 50);
                          }}
                          className={`px-3 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                            leaderboardTf === tf ? 'bg-emerald-600 text-white' : 'text-neutral-400 hover:text-white'
                          }`}
                        >
                          {tf}
                        </button>
                      ))}
                    </div>

                    {/* Metric selector */}
                    <div className="flex bg-[#121316] p-1 rounded-xl border border-[#2a2c36]">
                      {[
                        { id: 'MOST_MULTIPLIER', label: 'Top Multipliers' },
                        { id: 'MOST_WIN', label: 'Top Win Amount' }
                      ].map((m) => (
                        <button
                          key={m.id}
                          type="button"
                          onClick={() => {
                            setLeaderboardMetric(m.id as any);
                            setTimeout(fetchLeaderboard, 50);
                          }}
                          className={`px-3 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                            leaderboardMetric === m.id ? 'bg-indigo-600 text-white' : 'text-neutral-400 hover:text-white'
                          }`}
                        >
                          {m.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Seeder Form */}
                <form onSubmit={handleSeedLeaderboard} className="bg-[#121316] border border-[#262831] rounded-xl p-4 mb-4 grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
                  <div>
                    <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                      Pilot Username
                    </label>
                    <input
                      type="text"
                      value={seedUsername}
                      onChange={(e) => setSeedUsername(e.target.value)}
                      className="w-full bg-[#1c1d24] border border-[#2e313f] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                      Multiplier (x)
                    </label>
                    <input
                      type="number"
                      step={0.01}
                      min={1.05}
                      value={seedMultiplier}
                      onChange={(e) => setSeedMultiplier(+e.target.value)}
                      className="w-full bg-[#1c1d24] border border-[#2e313f] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-neutral-400 mb-1">
                      Bet Amount (₹)
                    </label>
                    <input
                      type="number"
                      step={100}
                      min={100}
                      value={seedBetAmount}
                      onChange={(e) => setSeedBetAmount(+e.target.value)}
                      className="w-full bg-[#1c1d24] border border-[#2e313f] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none font-mono"
                    />
                  </div>

                  <div>
                    <button
                      type="submit"
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 rounded-lg font-bold text-xs text-white transition shadow-sm cursor-pointer"
                    >
                      Seed Synthetic Win
                    </button>
                  </div>
                </form>

                {seedFeedback && (
                  <div className="text-xs text-emerald-400 font-bold mb-3">{seedFeedback}</div>
                )}

                {/* Records Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-[#262831] text-neutral-400 font-bold uppercase text-[10px]">
                        <th className="py-2 px-3">Rank</th>
                        <th className="py-2 px-3">Pilot</th>
                        <th className="py-2 px-3 text-right">Multiplier</th>
                        <th className="py-2 px-3 text-right">Stake</th>
                        <th className="py-2 px-3 text-right">Payout</th>
                        <th className="py-2 px-3 text-right">Type</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1e2029]">
                      {leaderboardRecords.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-6 text-center text-neutral-500">
                            Click timeframe tab or seed a win record above to populate.
                          </td>
                        </tr>
                      ) : (
                        leaderboardRecords.map((r, idx) => (
                          <tr key={r.id || idx} className="hover:bg-[#1a1b22] transition">
                            <td className="py-2 px-3 font-mono font-bold text-amber-400">
                              #{idx + 1}
                            </td>
                            <td className="py-2 px-3 font-bold text-white">
                              {r.anonymizedName || r.username}
                            </td>
                            <td className="py-2 px-3 text-right font-mono font-bold text-cyan-400">
                              {r.multiplier?.toFixed(2)}x
                            </td>
                            <td className="py-2 px-3 text-right font-mono text-neutral-300">
                              ₹{r.betAmount?.toLocaleString('en-IN')}
                            </td>
                            <td className="py-2 px-3 text-right font-mono font-bold text-emerald-400">
                              ₹{r.payoutAmount?.toLocaleString('en-IN')}
                            </td>
                            <td className="py-2 px-3 text-right">
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#20222a] text-neutral-400 font-mono">
                                {r.isSynthetic ? 'SYNTHETIC' : 'REAL'}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PROOF-BASED DEPOSIT APPROVAL QUEUE */}
          {activeTab === 'deposits' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Manual Deposit Proof Queue
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Verify UTR & screenshot. Approval automatically credits funds and unlocks referral bounties.
                  </p>
                </div>
                <button
                  onClick={fetchAdminData}
                  className="flex items-center gap-1 text-xs text-neutral-300 hover:text-white bg-[#202229] px-2.5 py-1.5 rounded-lg border border-[#2a2c35]"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Refresh</span>
                </button>
              </div>

              {deposits.length === 0 ? (
                <div className="p-8 text-center text-xs text-neutral-500 bg-[#17181d] rounded-xl">
                  No deposits in queue.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {deposits.map((d) => (
                    <div
                      key={d.id}
                      className="bg-[#17181d] border border-[#2a2c36] rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="flex items-start sm:items-center gap-3">
                        {d.proofImageUrl ? (
                          <div
                            onClick={() => setZoomedImage(d.proofImageUrl)}
                            className="w-14 h-14 bg-black rounded-lg border border-neutral-700 overflow-hidden cursor-pointer shrink-0 relative group"
                          >
                            <img
                              src={d.proofImageUrl}
                              alt="Proof Thumbnail"
                              className="w-full h-full object-cover group-hover:opacity-80 transition"
                            />
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/60 transition">
                              <Eye className="w-4 h-4 text-white" />
                            </div>
                          </div>
                        ) : (
                          <div className="w-14 h-14 bg-neutral-800 rounded-lg flex items-center justify-center text-[10px] text-neutral-500 shrink-0">
                            No Img
                          </div>
                        )}

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm">{d.userName}</span>
                            <span className="text-xs font-mono text-neutral-400">({d.userPhone})</span>
                            <span
                              className={`px-2 py-0.2 rounded-full text-[10px] font-mono font-bold uppercase ${
                                d.status === 'APPROVED'
                                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                                  : d.status === 'PENDING'
                                  ? 'bg-amber-950 text-amber-400 border border-amber-500/40'
                                  : 'bg-red-950 text-red-400 border border-red-500/40'
                              }`}
                            >
                              {d.status}
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5 my-1">
                            <span className="text-[10px] text-neutral-400">Order ID:</span>
                            <span className="text-xs font-mono font-bold text-amber-300">
                              {d.orderId || d.id}
                            </span>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                const oid = d.orderId || d.id;
                                navigator.clipboard.writeText(oid);
                                setCopiedOrderId(oid);
                                setTimeout(() => setCopiedOrderId(null), 2000);
                              }}
                              className="px-1.5 py-0.5 rounded bg-[#252735] hover:bg-[#323547] border border-amber-500/40 text-amber-300 text-[10px] font-mono flex items-center gap-1 cursor-pointer transition"
                              title="Copy Only Order ID"
                            >
                              {copiedOrderId === (d.orderId || d.id) ? (
                                <>
                                  <Check className="w-2.5 h-2.5 text-emerald-400" />
                                  <span className="text-emerald-400 font-bold">Copied</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-2.5 h-2.5" />
                                  <span>Copy</span>
                                </>
                              )}
                            </button>
                          </div>

                          <div className="mt-1 flex items-center gap-3 text-xs text-neutral-300">
                            <span>
                              Amount: <strong className="font-mono text-emerald-400 font-bold">₹{d.amount}</strong>
                            </span>
                            <span>
                              UTR: <strong className="font-mono text-amber-400">{d.utrNumber}</strong>
                            </span>
                          </div>
                          <div className="mt-1 flex flex-wrap items-center gap-2">
                            <span className="text-[10px] text-neutral-500">
                              Submitted at {new Date(d.createdAt).toLocaleTimeString()}
                            </span>
                            {d.selfDeclaredConsent && (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono font-bold">
                                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                                Legal Intent Signed
                              </span>
                            )}
                            {d.auditMetadata && (
                              <span className="text-[10px] font-mono text-neutral-400 bg-[#121317] px-1.5 py-0.2 rounded border border-neutral-800">
                                IP: {d.auditMetadata.ip}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Action buttons */}
                      {d.status === 'PENDING' ? (
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => handleDepositAction(d.id, 'APPROVE')}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg shadow-md flex items-center gap-1 transition"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>APPROVE & CREDIT</span>
                          </button>
                          <button
                            onClick={() => handleDepositAction(d.id, 'REJECT')}
                            className="px-3 py-1.5 bg-red-900/60 hover:bg-red-800 text-red-200 text-xs font-bold rounded-lg border border-red-600/40 transition"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>REJECT</span>
                          </button>
                        </div>
                      ) : (
                        <div className="text-[11px] font-mono text-neutral-500">
                          Reviewed: {d.reviewedAt ? new Date(d.reviewedAt).toLocaleTimeString() : 'Done'}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: WITHDRAWAL MANAGER QUEUE */}
          {activeTab === 'withdrawals' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Payout Request Queue
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Process user withdrawals. Rejection automatically refunds balance to player.
                  </p>
                </div>
                <button
                  onClick={fetchAdminData}
                  className="flex items-center gap-1 text-xs text-neutral-300 hover:text-white bg-[#202229] px-2.5 py-1.5 rounded-lg border border-[#2a2c35]"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Refresh</span>
                </button>
              </div>

              {withdrawals.length === 0 ? (
                <div className="p-8 text-center text-xs text-neutral-500 bg-[#17181d] rounded-xl">
                  No withdrawals pending.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {withdrawals.map((w) => (
                    <div
                      key={w.id}
                      className="bg-[#17181d] border border-[#2a2c36] rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">{w.userName}</span>
                          <span className="text-xs font-mono text-neutral-400">({w.userPhone})</span>
                          <span
                            className={`px-2 py-0.2 rounded-full text-[10px] font-mono font-bold uppercase ${
                              w.status === 'APPROVED'
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                                : w.status === 'PENDING'
                                ? 'bg-amber-950 text-amber-400 border border-amber-500/40'
                                : 'bg-red-950 text-red-400 border border-red-500/40'
                            }`}
                          >
                            {w.status}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5 my-1">
                          <span className="text-[10px] text-neutral-400">Order ID:</span>
                          <span className="text-xs font-mono font-bold text-amber-300">
                            {w.orderId || w.id}
                          </span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              const oid = w.orderId || w.id;
                              navigator.clipboard.writeText(oid);
                              setCopiedOrderId(oid);
                              setTimeout(() => setCopiedOrderId(null), 2000);
                            }}
                            className="px-1.5 py-0.5 rounded bg-[#252735] hover:bg-[#323547] border border-amber-500/40 text-amber-300 text-[10px] font-mono flex items-center gap-1 cursor-pointer transition"
                            title="Copy Only Order ID"
                          >
                            {copiedOrderId === (w.orderId || w.id) ? (
                              <>
                                <Check className="w-2.5 h-2.5 text-emerald-400" />
                                <span className="text-emerald-400 font-bold">Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-2.5 h-2.5" />
                                <span>Copy</span>
                              </>
                            )}
                          </button>
                        </div>

                        <div className="mt-1 space-y-0.5 text-xs text-neutral-300">
                          {(() => {
                            const breakdown = calculateWithdrawalTaxBreakdown(w.amount);
                            const taxAmt = w.taxAmount ?? breakdown.taxAmount;
                            const netReceive = w.netPayoutAmount ?? breakdown.netPayoutAmount;
                            return (
                              <div className="flex flex-wrap items-center gap-2">
                                <span>
                                  Gross Withdrawal: <strong className="font-mono text-rose-400 font-bold">₹{w.amount}</strong>
                                </span>
                                <span className="text-amber-400 font-mono">
                                  • 10% Tax: <strong>₹{taxAmt}</strong>
                                </span>
                                <span className="px-2 py-0.5 rounded bg-emerald-950/90 border border-emerald-500/50 text-emerald-300 font-mono font-bold">
                                  Player Receives (Net Payout): ₹{netReceive}
                                </span>
                                <span className="text-neutral-400">via {w.payoutMethod}</span>
                              </div>
                            );
                          })()}
                          <div className="font-mono text-[11px] text-neutral-400">
                            {w.payoutMethod === 'UPI'
                              ? `UPI ID: ${w.upiId}`
                              : `A/C: ${w.bankAccount} | IFSC: ${w.ifscCode} | Name: ${w.accountHolderName}`}
                          </div>
                        </div>
                      </div>

                      {w.status === 'PENDING' ? (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleWithdrawalAction(w.id, 'APPROVE')}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg shadow-md transition"
                          >
                            APPROVE & MARK PAID
                          </button>
                          <button
                            onClick={() => handleWithdrawalAction(w.id, 'REJECT')}
                            className="px-3 py-1.5 bg-red-900/60 hover:bg-red-800 text-red-200 text-xs font-bold rounded-lg border border-red-600/40 transition"
                          >
                            REJECT & REFUND
                          </button>
                        </div>
                      ) : (
                        <div className="text-[11px] font-mono text-neutral-500">
                          {w.status === 'APPROVED' ? `Paid (Txn: ${w.adminUtr || 'N/A'})` : 'Refunded'}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: USER LEDGER MANAGEMENT (SUPER ADMIN COMPLETELY HIDDEN) */}
          {activeTab === 'users' && (
            <div className="space-y-3">
              {/* SUPER ADMIN INSTANT BALANCE TRANSFER BY 7-DIGIT UID */}
              <div className="bg-gradient-to-r from-indigo-950/60 via-[#17181d] to-emerald-950/40 border border-indigo-500/40 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider text-indigo-300 flex items-center gap-2">
                      <Wallet className="w-4 h-4 text-emerald-400" />
                      SUPER ADMIN UNLIMITED WALLET — ADD / DEDUCT PLAYER BALANCE BY 7-DIGIT UID
                    </h4>
                    <p className="text-[11px] text-neutral-400">
                      Super Admin has ∞ Unlimited Balance and can credit or debit any player anytime using their unique 7-digit UID.
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-black">
                    SA Balance: ∞ UNLIMITED
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5 items-center">
                  <input
                    type="text"
                    maxLength={10}
                    placeholder="7-Digit UID (e.g. 4829104)"
                    value={uidTransferInput}
                    onChange={(e) => setUidTransferInput(e.target.value)}
                    className="bg-[#121316] border border-indigo-500/40 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder:text-neutral-500"
                  />
                  <input
                    type="number"
                    min={1}
                    placeholder="Amount (₹)"
                    value={uidTransferAmount}
                    onChange={(e) => setUidTransferAmount(e.target.value)}
                    className="bg-[#121316] border border-emerald-500/40 rounded-lg px-3 py-2 text-xs font-mono text-emerald-300 font-bold placeholder:text-neutral-500"
                  />
                  <input
                    type="text"
                    placeholder="Note / Reason"
                    value={uidTransferNote}
                    onChange={(e) => setUidTransferNote(e.target.value)}
                    className="bg-[#121316] border border-[#2a2c35] rounded-lg px-3 py-2 text-xs text-white placeholder:text-neutral-500"
                  />
                  <button
                    type="button"
                    disabled={uidTransferLoading}
                    onClick={() => handleUidBalanceTransfer('CREDIT')}
                    className="py-2 px-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-black text-xs rounded-lg transition cursor-pointer"
                  >
                    + Add Balance by UID
                  </button>
                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      disabled={uidTransferLoading}
                      onClick={() => handleUidBalanceTransfer('DEBIT')}
                      className="flex-1 py-2 px-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-neutral-950 font-black text-xs rounded-lg transition cursor-pointer"
                    >
                      - Deduct
                    </button>
                    <button
                      type="button"
                      disabled={uidTransferLoading}
                      onClick={() => handleUidBalanceTransfer('ZERO_OUT')}
                      className=" py-2 px-2 bg-rose-700 hover:bg-rose-600 disabled:opacity-50 text-white font-bold text-xs rounded-lg transition cursor-pointer"
                    >
                      Zero
                    </button>
                  </div>
                </div>

                {uidTransferFeedback && (
                  <div className="text-xs font-mono font-bold text-amber-300 bg-black/40 border border-amber-500/30 rounded-lg px-3 py-1.5">
                    {uidTransferFeedback}
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Platform User Database Ledger & Smart Lock Protection
                  </h3>
                  <span className="text-xs text-neutral-400">
                    Super Admin is strictly hidden from this table. Manage player balances, session metrics, and Smart Lock anti-bleed traps.
                  </span>
                </div>

                <div className="flex items-center gap-2 bg-[#17181e] border border-[#2a2c36] rounded-xl px-3 py-1.5 w-64">
                  <Search className="w-3.5 h-3.5 text-neutral-400" />
                  <input
                    type="text"
                    placeholder="Search by name, phone, code..."
                    value={userSearch}
                    onChange={(e) => {
                      setUserSearch(e.target.value);
                      fetchUsers();
                    }}
                    className="w-full bg-transparent text-xs text-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="bg-[#17181d] border border-[#2a2c36] rounded-xl overflow-hidden">
                <div className="grid grid-cols-12 px-4 py-2.5 text-[11px] font-semibold text-neutral-400 uppercase tracking-wider bg-[#121316] border-b border-[#292b35]">
                  <div className="col-span-3">User</div>
                  <div className="col-span-2 text-right">Session Dep</div>
                  <div className="col-span-2 text-right">Net Profit</div>
                  <div className="col-span-2 text-center">Smart Lock</div>
                  <div className="col-span-3 text-right">Actions</div>
                </div>

                <div className="divide-y divide-[#22242c]">
                  {userList.map((u) => {
                    const netProfit = u.netSessionProfit ?? (u.mainBalance - (u.sessionDepositTotal || 0));
                    return (
                      <div key={u.id} className="grid grid-cols-12 items-center px-4 py-3 text-xs">
                        <div className="col-span-3">
                          <div className="font-bold text-white flex items-center gap-1.5 truncate">
                            <span>{u.name}</span>
                            <button
                              type="button"
                              onClick={() => setUidTransferInput(format7DigitUid(u.uid, u.id))}
                              title="Click to copy 7-digit UID to transfer box"
                              className="text-[10px] bg-indigo-950/80 hover:bg-indigo-900 text-indigo-300 border border-indigo-500/40 px-1.5 py-0.2 rounded font-mono font-bold cursor-pointer"
                            >
                              UID:{format7DigitUid(u.uid, u.id)}
                            </button>
                            {u.isFrozen && (
                              <span className="text-[9px] bg-red-950 text-red-400 px-1.5 py-0.2 rounded font-mono font-bold">
                                FROZEN
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-neutral-400 font-mono">{u.phone}</div>
                          <div className="text-[10px] text-neutral-400 font-mono">Bal: ₹{u.mainBalance.toFixed(2)}</div>
                        </div>

                        <div className="col-span-2 text-right font-mono font-bold text-neutral-300">
                          ₹{(u.sessionDepositTotal || 0).toLocaleString('en-IN')}
                        </div>

                        <div className={`col-span-2 text-right font-mono font-bold ${
                          netProfit > 0 ? 'text-rose-400' : netProfit < 0 ? 'text-emerald-400' : 'text-neutral-400'
                        }`}>
                          {netProfit > 0 ? `+₹${netProfit.toFixed(2)}` : `₹${netProfit.toFixed(2)}`}
                        </div>

                        <div className="col-span-2 flex items-center justify-center gap-1">
                          {u.isSmartLocked ? (
                            <div className="flex items-center gap-1">
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-950/80 text-rose-300 border border-rose-500/40 animate-pulse">
                                LOCKED ({u.smartLockRemainingRounds || 0}r)
                              </span>
                              <button
                                onClick={() => handleToggleSmartLock(u, false)}
                                className="text-[10px] px-1 py-0.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded transition"
                                title="Release Smart Lock"
                              >
                                Release
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1">
                              <span className="text-[10px] text-neutral-400 font-mono">NORMAL</span>
                              <button
                                onClick={() => {
                                  setSmartLockUser(u);
                                  setSmartLockRoundsInput(3);
                                }}
                                className="text-[10px] px-1.5 py-0.5 bg-rose-950/60 hover:bg-rose-900 border border-rose-600/40 text-rose-300 rounded font-bold transition"
                                title="Engage Smart Lock"
                              >
                                Lock
                              </button>
                            </div>
                          )}
                        </div>

                        <div className="col-span-3 flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setAdjustModalUser(u)}
                            className="px-2 py-1 bg-[#23252e] hover:bg-[#2e313d] text-neutral-300 hover:text-white rounded text-[11px] font-semibold transition"
                          >
                            +/- Bal
                          </button>
                          <button
                            onClick={() => handleUserAction(u.id, 'TOGGLE_FREEZE')}
                            className={`p-1 rounded transition ${
                              u.isFrozen
                                ? 'bg-red-950/80 text-red-300 hover:bg-red-900'
                                : 'bg-[#23252e] text-neutral-400 hover:text-white'
                            }`}
                            title={u.isFrozen ? 'Unlock account' : 'Freeze account'}
                          >
                            {u.isFrozen ? <Lock className="w-3.5 h-3.5 text-red-400" /> : <Unlock className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB: REFERRAL PERFORMANCE METRICS & BOUNTIES */}
          {activeTab === 'referrals' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Header and Refresh Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-purple-950/50 via-[#17181d] to-indigo-950/40 border border-purple-500/40 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-[0_0_15px_rgba(147,51,234,0.5)]">
                    <Share2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
                      <span>REFERRAL PERFORMANCE & BOUNTY METRICS</span>
                      <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-mono border border-purple-500/40">
                        Live Tracking
                      </span>
                    </h3>
                    <p className="text-xs text-neutral-400">
                      Monitor active player referrals, link conversions, and cumulative bonus bounties generated across the platform.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={referralMetricsLoading}
                    onClick={fetchReferralMetrics}
                    className="py-1.5 px-3 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-md"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${referralMetricsLoading ? 'animate-spin' : ''}`} />
                    <span>{referralMetricsLoading ? 'Refreshing...' : 'Refresh Metrics'}</span>
                  </button>
                </div>
              </div>

              {/* 4 Metric Summary Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-[#17181d] border border-[#262830] rounded-xl p-3.5">
                  <div className="flex items-center justify-between text-neutral-400 text-xs mb-1">
                    <span>Total Referrers</span>
                    <Users className="w-4 h-4 text-purple-400" />
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-white font-mono">
                    {referralMetrics?.referrers?.length ?? 0}
                  </div>
                  <div className="text-[10px] text-neutral-500 mt-0.5">Active sharing players</div>
                </div>

                <div className="bg-[#17181d] border border-[#262830] rounded-xl p-3.5">
                  <div className="flex items-center justify-between text-neutral-400 text-xs mb-1">
                    <span>Total Referred Players</span>
                    <UserPlus className="w-4 h-4 text-indigo-400" />
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-indigo-400 font-mono">
                    {referralMetrics?.globalTotalReferrals ?? 0}
                  </div>
                  <div className="text-[10px] text-neutral-500 mt-0.5">Tracked link registrations</div>
                </div>

                <div className="bg-[#17181d] border border-[#262830] rounded-xl p-3.5">
                  <div className="flex items-center justify-between text-neutral-400 text-xs mb-1">
                    <span>Active Paying Referrals</span>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono">
                    {referralMetrics?.globalActiveReferrals ?? 0}
                  </div>
                  <div className="text-[10px] text-emerald-500/80 mt-0.5">Verified first depositors</div>
                </div>

                <div className="bg-[#17181d] border border-[#262830] rounded-xl p-3.5">
                  <div className="flex items-center justify-between text-neutral-400 text-xs mb-1">
                    <span>Total Bonuses Generated</span>
                    <Award className="w-4 h-4 text-amber-400" />
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-amber-400 font-mono">
                    ₹{referralMetrics?.globalTotalBonusesGenerated ?? 0}
                  </div>
                  <div className="text-[10px] text-amber-500/80 mt-0.5">Distributed referral bounties</div>
                </div>
              </div>

              {/* Filter and Search Bar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#17181d] border border-[#262830] rounded-xl p-3">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                  <input
                    type="text"
                    placeholder="Search by Referrer Name, 7-digit UID, or Referral Code..."
                    value={referralSearchQuery}
                    onChange={(e) => setReferralSearchQuery(e.target.value)}
                    className="w-full bg-[#121316] border border-[#262830] rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder:text-neutral-500 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <span className="text-[11px] text-neutral-400 whitespace-nowrap self-center font-mono">
                  Showing{' '}
                  <strong className="text-white">
                    {(referralMetrics?.referrers || []).filter((r) => {
                      const q = referralSearchQuery.toLowerCase();
                      return (
                        r.referrerName.toLowerCase().includes(q) ||
                        r.referrerUid.toLowerCase().includes(q) ||
                        r.referralCode.toLowerCase().includes(q)
                      );
                    }).length}
                  </strong>{' '}
                  Referrer(s)
                </span>
              </div>

              {/* Referrer Table */}
              <div className="bg-[#17181d] border border-[#262830] rounded-xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#121316] text-neutral-400 border-b border-[#262830] font-mono uppercase text-[10px]">
                      <tr>
                        <th className="py-2.5 px-3">Referrer (Pilot)</th>
                        <th className="py-2.5 px-3">Referral Code</th>
                        <th className="py-2.5 px-3 text-center">Total Referrals</th>
                        <th className="py-2.5 px-3 text-center">Active Referrals</th>
                        <th className="py-2.5 px-3 text-center">Conv. Rate</th>
                        <th className="py-2.5 px-3 text-right">Bonuses Generated</th>
                        <th className="py-2.5 px-3 text-right">Promo Wallet</th>
                        <th className="py-2.5 px-3 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#20222a]">
                      {(referralMetrics?.referrers || [])
                        .filter((r) => {
                          const q = referralSearchQuery.toLowerCase();
                          return (
                            r.referrerName.toLowerCase().includes(q) ||
                            r.referrerUid.toLowerCase().includes(q) ||
                            r.referralCode.toLowerCase().includes(q)
                          );
                        })
                        .map((ref) => {
                          const convRate = ref.totalReferrals > 0
                            ? Math.round((ref.activeReferrals / ref.totalReferrals) * 100)
                            : 0;

                          return (
                            <tr key={ref.referrerId} className="hover:bg-[#1a1b22] transition">
                              <td className="py-2.5 px-3">
                                <div className="font-bold text-white">{ref.referrerName}</div>
                                <div className="text-[10px] text-neutral-400 font-mono">{ref.referrerUid}</div>
                              </td>
                              <td className="py-2.5 px-3 font-mono">
                                <div className="flex items-center gap-1.5">
                                  <span className="px-2 py-0.5 rounded bg-purple-950/60 border border-purple-500/30 text-purple-300 font-bold text-[11px]">
                                    {ref.referralCode}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      navigator.clipboard?.writeText(ref.referralCode);
                                      setCopiedReferralCode(ref.referralCode);
                                      setTimeout(() => setCopiedReferralCode(null), 2000);
                                    }}
                                    className="p-1 text-neutral-400 hover:text-white rounded hover:bg-[#262832] transition"
                                    title="Copy Code"
                                  >
                                    {copiedReferralCode === ref.referralCode ? (
                                      <Check className="w-3 h-3 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3 h-3" />
                                    )}
                                  </button>
                                </div>
                              </td>
                              <td className="py-2.5 px-3 text-center font-mono font-bold text-neutral-200">
                                {ref.totalReferrals}
                              </td>
                              <td className="py-2.5 px-3 text-center font-mono font-bold text-emerald-400">
                                {ref.activeReferrals}
                              </td>
                              <td className="py-2.5 px-3 text-center font-mono text-neutral-300">
                                <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                                  convRate >= 50
                                    ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30'
                                    : 'bg-neutral-800 text-neutral-400'
                                }`}>
                                  {convRate}%
                                </span>
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono font-black text-amber-300">
                                ₹{ref.totalBonusEarned}
                              </td>
                              <td className="py-2.5 px-3 text-right font-mono font-semibold text-purple-300">
                                ₹{ref.promoWallet}
                              </td>
                              <td className="py-2.5 px-3 text-center">
                                {ref.activeReferrals >= 5 ? (
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                                    ⭐ Top Performer
                                  </span>
                                ) : ref.activeReferrals >= 1 ? (
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                                    Active
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-neutral-800 text-neutral-400 border border-neutral-700">
                                    Growing
                                  </span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      {(!referralMetrics?.referrers || referralMetrics.referrers.length === 0) && (
                        <tr>
                          <td colSpan={8} className="py-8 text-center text-neutral-500 text-xs">
                            No referral activity recorded yet. Invite links are ready to track.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: ANTI-FRAUD ENGINE LOGS */}
          {activeTab === 'fraud' && (
            <div className="space-y-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <AlertOctagon className="w-4 h-4 text-red-500" />
                  <span>Zero-Leakage Anti-Fraud Incident Log</span>
                </h3>
                <p className="text-xs text-neutral-400">
                  Automated defense against duplicate device fingerprints, IP collisions, and bonus hunting.
                </p>
              </div>

              {fraudAlerts.length === 0 ? (
                <div className="p-8 text-center text-xs text-neutral-500 bg-[#17181d] rounded-xl">
                  No fraud attempts detected so far.
                </div>
              ) : (
                <div className="space-y-2">
                  {fraudAlerts.map((f) => (
                    <div
                      key={f.id}
                      className="p-3 bg-red-950/30 border border-red-600/40 rounded-xl flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-bold text-red-300 flex items-center gap-2">
                          <span>{f.reason}</span>
                          <span className="bg-red-600 text-white text-[9px] font-mono px-1.5 py-0.2 rounded uppercase font-bold">
                            {f.actionTaken}
                          </span>
                        </div>
                        <div className="text-[11px] text-neutral-400 font-mono mt-0.5">
                          Target Phone: {f.targetAccount || f.userPhone} | IP: {f.ipAddress} | Fingerprint: {f.deviceFingerprint}
                        </div>
                      </div>
                      <span className="text-[10px] text-neutral-500">
                        {new Date(f.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 6: FINANCIAL OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-[#17181d] border border-[#2a2c36] p-4 rounded-xl">
                <span className="text-xs text-neutral-400">Total Approved Deposits</span>
                <div className="text-2xl font-black font-mono text-emerald-400 mt-1">
                  ₹{(metrics?.totalDeposits || 0).toLocaleString('en-IN')}
                </div>
              </div>
              <div className="bg-[#17181d] border border-[#2a2c36] p-4 rounded-xl">
                <span className="text-xs text-neutral-400">Total Approved Withdrawals</span>
                <div className="text-2xl font-black font-mono text-rose-400 mt-1">
                  ₹{(metrics?.totalWithdrawals || 0).toLocaleString('en-IN')}
                </div>
              </div>
              <div className="bg-[#17181d] border border-[#2a2c36] p-4 rounded-xl">
                <span className="text-xs text-neutral-400">Net Platform Retention</span>
                <div className="text-2xl font-black font-mono text-white mt-1">
                  ₹{(metrics?.todayNetProfit || 0).toLocaleString('en-IN')}
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: PLATFORM CONFIG */}
          {activeTab === 'settings' && config && (
            <div className="bg-[#17181d] border border-[#2a2c36] rounded-xl p-5 space-y-4 max-w-xl">
              <h4 className="text-sm font-bold text-white">System Parameters</h4>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-neutral-400 mb-1">Min Deposit (₹)</label>
                  <input
                    type="number"
                    value={config.minDeposit}
                    onChange={(e) => setConfig({ ...config, minDeposit: Number(e.target.value) })}
                    className="w-full bg-[#121316] border border-[#2a2c35] rounded-lg p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Min Withdrawal (₹)</label>
                  <input
                    type="number"
                    value={config.minWithdrawal}
                    onChange={(e) => setConfig({ ...config, minWithdrawal: Number(e.target.value) })}
                    className="w-full bg-[#121316] border border-[#2a2c35] rounded-lg p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Instant Referral Bonus (₹)</label>
                  <input
                    type="number"
                    value={config.instantReferralBonus}
                    onChange={(e) => setConfig({ ...config, instantReferralBonus: Number(e.target.value) })}
                    className="w-full bg-[#121316] border border-[#2a2c35] rounded-lg p-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-neutral-400 mb-1">Wagering Turnover Multiplier (x)</label>
                  <input
                    type="number"
                    step={0.1}
                    value={config.turnoverMultiplier}
                    onChange={(e) => setConfig({ ...config, turnoverMultiplier: Number(e.target.value) })}
                    className="w-full bg-[#121316] border border-[#2a2c35] rounded-lg p-2 text-white font-mono"
                  />
                </div>
              </div>

              {/* Primary Active UPI ID & QR Code Direct Config */}
              <div className="bg-[#121316] border border-emerald-500/40 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-emerald-400" />
                    <h4 className="text-sm font-bold text-emerald-300 font-['Chakra_Petch']">
                      Active Deposit UPI ID & Merchant QR Code
                    </h4>
                  </div>
                  <span className="text-[10px] text-neutral-400 font-mono">
                    Syncs live to Deposit Tab & Persistent Database
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-neutral-400 mb-1">Active UPI ID / VPA</label>
                    <input
                      type="text"
                      placeholder="e.g. merchant@upi"
                      value={config.adminUpiId || ''}
                      onChange={(e) => setConfig({ ...config, adminUpiId: e.target.value })}
                      className="w-full bg-[#181a20] border border-[#2a2c35] rounded-lg p-2 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-neutral-400 mb-1">Merchant Display Name</label>
                    <input
                      type="text"
                      placeholder="e.g. WIN NOVA Cashier"
                      value={config.adminUpiName || ''}
                      onChange={(e) => setConfig({ ...config, adminUpiName: e.target.value })}
                      className="w-full bg-[#181a20] border border-[#2a2c35] rounded-lg p-2 text-white"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-neutral-400 mb-1">Upload QR Code Image (from PC / Phone) or Paste URL</label>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="file"
                        accept="image/*"
                        disabled={upiQrUploading}
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleUploadUpiQrFile(file, 'CONFIG', activeUpiNodeId);
                        }}
                        className="block text-xs text-neutral-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-emerald-500 file:text-neutral-950 hover:file:bg-emerald-400 cursor-pointer"
                      />
                      <input
                        type="text"
                        placeholder="Or paste QR image URL..."
                        value={config.adminQrUrl || ''}
                        onChange={(e) => setConfig({ ...config, adminQrUrl: e.target.value })}
                        className="flex-1 bg-[#181a20] border border-[#2a2c35] rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {upiNodeFeedback && (
                <div className="p-2.5 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-300 font-mono font-bold">
                  {upiNodeFeedback}
                </div>
              )}

              <button
                onClick={async () => {
                  const res = await fetch('/api/admin/config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
                    body: JSON.stringify(config)
                  });
                  if (res.ok) {
                    if (config.adminUpiId) {
                      updateGlobalSystemUpi({
                        adminId: 'super_admin',
                        upiId: config.adminUpiId,
                        qrCodeUrl: config.adminQrUrl,
                        merchantName: config.adminUpiName
                      }).catch(() => {});
                    }
                    setUpiNodeFeedback('✅ System Config & Active UPI ID saved permanently!');
                    setTimeout(() => setUpiNodeFeedback(null), 4000);
                    fetchUpiNodes();
                    fetchAdminData();
                  }
                }}
                className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-xs text-white transition cursor-pointer"
              >
                Save System Config & Active UPI
              </button>
            </div>
          )}

          {/* TAB 8: MODULE 2 - DYNAMIC MULTI-UPI ROTATOR */}
          {activeTab === 'upiRotator' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-emerald-400" />
                    <span>Dynamic Multi-UPI Rotator Gateway</span>
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Distributes incoming manual UPI deposits across cycled merchant handles to prevent transaction velocity banking flags.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowAddNodeForm(!showAddNodeForm)}
                    className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{showAddNodeForm ? 'Cancel' : 'Add UPI Gateway'}</span>
                  </button>
                </div>
              </div>

              {upiNodeFeedback && (
                <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-xs text-emerald-300 font-mono font-bold">
                  {upiNodeFeedback}
                </div>
              )}

              {/* Threshold Setting Card */}
              <div className="bg-[#17181d] border border-[#2a2c36] p-4 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-bold text-white">Velocity Rotation Rule</div>
                  <div className="text-[11px] text-neutral-400">
                    Switch to next UPI node automatically after reaching this number of confirmed deposits:
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={rotateThreshold}
                    onChange={(e) => setRotateThreshold(Number(e.target.value))}
                    className="w-20 bg-[#121316] border border-[#2a2c36] rounded-lg px-2 py-1.5 text-xs text-white font-mono text-center"
                  />
                  <button
                    onClick={handleSaveRotateThreshold}
                    className="px-3 py-1.5 bg-[#252834] hover:bg-[#323646] text-white rounded-lg text-xs font-bold transition cursor-pointer"
                  >
                    Save Rule
                  </button>
                </div>
              </div>

              {/* Add Node Form */}
              {showAddNodeForm && (
                <form
                  onSubmit={handleAddNode}
                  className="bg-[#191b22] border border-emerald-500/40 p-4 rounded-xl space-y-3"
                >
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                    Register & Activate New UPI Payment Node
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-neutral-400 mb-1">Gateway / Bank Display Name *</label>
                      <input
                        type="text"
                        placeholder="e.g. ICICI Corporate Gateway"
                        value={newNodeForm.displayName}
                        onChange={(e) => setNewNodeForm({ ...newNodeForm, displayName: e.target.value })}
                        required
                        className="w-full bg-[#121316] border border-[#2a2c36] rounded-lg p-2 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-neutral-400 mb-1">UPI ID / VPA *</label>
                      <input
                        type="text"
                        placeholder="e.g. merchant@icici"
                        value={newNodeForm.upiId}
                        onChange={(e) => setNewNodeForm({ ...newNodeForm, upiId: e.target.value })}
                        required
                        className="w-full bg-[#121316] border border-[#2a2c36] rounded-lg p-2 text-white font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-neutral-400 mb-1">Max Cap Limit (₹)</label>
                      <input
                        type="number"
                        placeholder="100000"
                        value={newNodeForm.maxLimit}
                        onChange={(e) => setNewNodeForm({ ...newNodeForm, maxLimit: Number(e.target.value) })}
                        className="w-full bg-[#121316] border border-[#2a2c36] rounded-lg p-2 text-white font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-neutral-400 mb-1">Upload QR Image or Paste URL (Optional)</label>
                      <div className="space-y-1.5">
                        <input
                          type="file"
                          accept="image/*"
                          disabled={upiQrUploading}
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleUploadUpiQrFile(file, 'NEW');
                          }}
                          className="block w-full text-[11px] text-neutral-400 file:mr-2 file:py-1 file:px-2.5 file:rounded file:border-0 file:text-[11px] file:font-bold file:bg-emerald-500 file:text-neutral-950 hover:file:bg-emerald-400 cursor-pointer"
                        />
                        <input
                          type="text"
                          placeholder="Or paste QR URL (https://.../qr.png)"
                          value={newNodeForm.qrImageUrl}
                          onChange={(e) => setNewNodeForm({ ...newNodeForm, qrImageUrl: e.target.value })}
                          className="w-full bg-[#121316] border border-[#2a2c36] rounded-lg p-2 text-white text-xs font-mono"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowAddNodeForm(false)}
                      className="px-3 py-1.5 bg-neutral-800 text-neutral-300 rounded-lg text-xs cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition cursor-pointer"
                    >
                      Save & Activate UPI Node
                    </button>
                  </div>
                </form>
              )}

              {/* Node List Table */}
              <div className="bg-[#17181d] border border-[#2a2c36] rounded-xl overflow-hidden">
                <div className="grid grid-cols-12 px-4 py-2.5 text-[11px] font-semibold text-neutral-400 uppercase tracking-wider bg-[#121316] border-b border-[#292b35]">
                  <div className="col-span-3">Gateway Name</div>
                  <div className="col-span-3">UPI ID (VPA)</div>
                  <div className="col-span-2 text-center">Txn Count</div>
                  <div className="col-span-2 text-center">Status</div>
                  <div className="col-span-2 text-right">Actions</div>
                </div>

                <div className="divide-y divide-[#22242c]">
                  {upiNodes.map((n) => {
                    const isActive = n.id === activeUpiNodeId;
                    const isEditing = editingNodeId === n.id;
                    return (
                      <div key={n.id} className="px-4 py-3 text-xs space-y-2">
                        <div className="grid grid-cols-12 items-center">
                          <div className="col-span-3 font-bold text-white flex items-center gap-2">
                            <span>{n.displayName}</span>
                          </div>
                          <div className="col-span-3 font-mono text-emerald-300 font-bold break-all pr-2">
                            {n.upiId}
                          </div>
                          <div className="col-span-2 text-center font-mono">
                            <span className="font-bold text-white">{n.currentTransactions}</span>
                            <span className="text-neutral-500"> / {rotateThreshold}</span>
                          </div>
                          <div className="col-span-2 flex justify-center">
                            {isActive ? (
                              <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/40">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                                ACTIVE NOW
                              </span>
                            ) : (
                              <span className="text-[10px] text-neutral-500 font-mono">STANDBY</span>
                            )}
                          </div>
                          <div className="col-span-2 flex items-center justify-end gap-1.5">
                            {!isActive && (
                              <button
                                onClick={() => handleSetActiveNode(n.id)}
                                className="px-2 py-1 bg-emerald-950 hover:bg-emerald-900 border border-emerald-600/40 text-emerald-300 text-[10px] font-bold rounded transition cursor-pointer"
                              >
                                Activate
                              </button>
                            )}
                            <button
                              onClick={() => {
                                if (isEditing) {
                                  setEditingNodeId(null);
                                } else {
                                  setEditingNodeId(n.id);
                                  setEditNodeForm({
                                    upiId: n.upiId,
                                    displayName: n.displayName,
                                    qrImageUrl: n.qrImageUrl || '',
                                    maxLimit: n.maxLimit || 100000
                                  });
                                }
                              }}
                              className="px-2 py-1 bg-[#23252e] hover:bg-[#2e313d] text-amber-300 text-[10px] font-bold rounded transition cursor-pointer"
                            >
                              {isEditing ? 'Close' : 'Edit'}
                            </button>
                            <button
                              onClick={() => handleResetNodeCounter(n.id)}
                              className="p-1 bg-[#23252e] hover:bg-[#2e313d] text-neutral-400 hover:text-white rounded cursor-pointer"
                              title="Reset Txn Counter to 0"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteNode(n.id)}
                              className="p-1 bg-[#23252e] hover:bg-rose-950 hover:text-rose-400 text-neutral-500 rounded cursor-pointer"
                              title="Delete Node"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {isEditing && (
                          <div className="bg-[#121316] border border-amber-500/40 rounded-xl p-3 grid grid-cols-1 sm:grid-cols-4 gap-2.5 items-end">
                            <div>
                              <label className="block text-[10px] text-neutral-400 mb-1">Display Name</label>
                              <input
                                type="text"
                                value={editNodeForm.displayName}
                                onChange={(e) => setEditNodeForm({ ...editNodeForm, displayName: e.target.value })}
                                className="w-full bg-[#191b22] border border-[#2a2c36] rounded-lg px-2.5 py-1.5 text-xs text-white"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-neutral-400 mb-1">UPI ID / VPA</label>
                              <input
                                type="text"
                                value={editNodeForm.upiId}
                                onChange={(e) => setEditNodeForm({ ...editNodeForm, upiId: e.target.value })}
                                className="w-full bg-[#191b22] border border-[#2a2c36] rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-neutral-400 mb-1">Upload QR or URL</label>
                              <input
                                type="file"
                                accept="image/*"
                                disabled={upiQrUploading}
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) handleUploadUpiQrFile(file, 'EDIT', n.id);
                                }}
                                className="block w-full text-[10px] text-neutral-400 file:mr-2 file:py-0.5 file:px-2 file:rounded file:border-0 file:text-[10px] file:font-bold file:bg-amber-500 file:text-neutral-950 mb-1 cursor-pointer"
                              />
                              <input
                                type="text"
                                placeholder="QR Image URL"
                                value={editNodeForm.qrImageUrl}
                                onChange={(e) => setEditNodeForm({ ...editNodeForm, qrImageUrl: e.target.value })}
                                className="w-full bg-[#191b22] border border-[#2a2c36] rounded-lg px-2 py-1 text-[11px] text-white font-mono"
                              />
                            </div>
                            <div className="flex gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleSaveEditNode(n.id)}
                                className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition cursor-pointer"
                              >
                                Save & Activate
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 9: MODULE 1 - DYNAMIC FAKE LIVE CHAT ENGINE */}
          {activeTab === 'fakeChat' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-purple-400" />
                    <span>Dynamic Fake Live Chat Engine</span>
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Automated background social proof messages to boost player deposit confidence and retention.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleBroadcastTestChat}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-bold transition shadow-md"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Test Broadcast Message</span>
                  </button>
                </div>
              </div>

              {fakeChatTestFeedback && (
                <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  <span>Simulated broadcast sent to live chat: "{fakeChatTestFeedback}"</span>
                </div>
              )}

              {/* Chat Settings Controls */}
              {fakeChatConfig && (
                <div className="bg-[#17181d] border border-[#2a2c36] p-4 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-white">Live Simulator Status</div>
                      <div className="text-[11px] text-neutral-400">
                        {fakeChatConfig.enabled ? 'Actively sending automated messages' : 'Engine paused'}
                      </div>
                    </div>
                    <button
                      onClick={() => handleSaveFakeChatSettings({ ...fakeChatConfig, enabled: !fakeChatConfig.enabled })}
                      className={`px-3 py-1.5 text-xs font-bold rounded-lg transition ${
                        fakeChatConfig.enabled ? 'bg-emerald-600 text-white' : 'bg-neutral-700 text-neutral-300'
                      }`}
                    >
                      {fakeChatConfig.enabled ? 'ACTIVE (RUNNING)' : 'DISABLED'}
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-[#252732] text-xs">
                    <div>
                      <label className="block text-neutral-400 mb-1">Min Delay Between Messages (sec)</label>
                      <input
                        type="number"
                        min={2}
                        max={60}
                        value={fakeChatConfig.minDelaySeconds}
                        onChange={(e) => setFakeChatConfig({ ...fakeChatConfig, minDelaySeconds: Number(e.target.value) })}
                        className="w-full bg-[#121316] border border-[#2a2c36] rounded-lg p-2 text-white font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-neutral-400 mb-1">Max Delay Between Messages (sec)</label>
                      <input
                        type="number"
                        min={5}
                        max={120}
                        value={fakeChatConfig.maxDelaySeconds}
                        onChange={(e) => setFakeChatConfig({ ...fakeChatConfig, maxDelaySeconds: Number(e.target.value) })}
                        className="w-full bg-[#121316] border border-[#2a2c36] rounded-lg p-2 text-white font-mono"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-1">
                    <button
                      onClick={() => handleSaveFakeChatSettings(fakeChatConfig)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition"
                    >
                      Save Interval Timing
                    </button>
                  </div>
                </div>
              )}

              {/* Preset Messages Pool */}
              {fakeChatConfig && (() => {
                const presetList = Array.isArray(fakeChatConfig.presetMessages) ? fakeChatConfig.presetMessages : [];
                return (
                  <div className="bg-[#17181d] border border-[#2a2c36] p-4 rounded-xl space-y-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                      Simulated Messages Library ({presetList.length} messages)
                    </h4>

                    {/* Add Message Form */}
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Add custom casino message (e.g. 'Just withdrew 15k to PhonePe!!')..."
                        value={newChatMessage}
                        onChange={(e) => setNewChatMessage(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && newChatMessage.trim()) {
                            const updated = {
                              ...fakeChatConfig,
                              presetMessages: [...presetList, newChatMessage.trim()]
                            };
                            handleSaveFakeChatSettings(updated);
                            setNewChatMessage('');
                          }
                        }}
                        className="flex-1 bg-[#121316] border border-[#2a2c36] rounded-lg px-3 py-2 text-xs text-white"
                      />
                      <button
                        onClick={() => {
                          if (!newChatMessage.trim()) return;
                          const updated = {
                            ...fakeChatConfig,
                            presetMessages: [...presetList, newChatMessage.trim()]
                          };
                          handleSaveFakeChatSettings(updated);
                          setNewChatMessage('');
                        }}
                        className="px-3 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-bold flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add</span>
                      </button>
                    </div>

                    {/* Messages List */}
                    <div className="max-h-60 overflow-y-auto space-y-1.5 divide-y divide-[#22242c]">
                      {presetList.map((msg, idx) => (
                        <div key={idx} className="flex items-center justify-between pt-1.5 text-xs text-neutral-300">
                          <span className="font-sans font-medium">{msg}</span>
                          <button
                            onClick={() => {
                              const updated = {
                                ...fakeChatConfig,
                                presetMessages: presetList.filter((_, i) => i !== idx)
                              };
                              handleSaveFakeChatSettings(updated);
                            }}
                            className="p-1 text-neutral-500 hover:text-rose-400 rounded transition"
                            title="Delete message"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* TAB 12: PEAK VOLUME DYNAMIC MARGIN SCHEDULES (MODULE 14) */}
          {activeTab === 'peakSchedules' && (
            <PeakScheduleLedger adminKey={adminKey} />
          )}

          {/* TAB 13: HIDDEN SUB-ADMIN & RBAC STAFF MANAGEMENT (MODULE 17) */}
          {activeTab === 'staff' && (
            <StaffManagementView adminKey={adminKey} />
          )}

          {/* TAB 14: TIMED PROMOTIONAL CAMPAIGNS (MODULE 19) */}
          {activeTab === 'promotions' && (
            <TimedCampaignManager adminKey={adminKey} />
          )}

          {/* TAB 15: GIFT CODE & DYNAMIC WITHDRAWAL TIERS ENGINE */}
          {activeTab === 'giftCodes' && (
            <GiftCodeManager adminKey={adminKey} />
          )}

          {/* TAB 16: SEND MONEY / REWARDS TO NOTIFICATION CENTRE (SUPER ADMIN VS ADMIN RBAC + SOFT DELETE) */}
          {activeTab === 'notifications' && (() => {
            const isSuperCaller =
              requesterAdminRole === 'SUPER_ADMIN' ||
              adminKey === 'Faisal786' ||
              adminKey === 'sa_secret_token_786' ||
              adminKey === 'mdfaisalraza9771@gmail.com' ||
              adminKey === 'mdfaisalraza7777@gmail.com';
            const isDispatchBlockedForRegularAdmin = !isSuperCaller && !allowAdminRewardDispatch;

            return (
              <div className="space-y-4">
                {/* Super Admin Exclusive Permission Toggle Bar */}
                <div className="bg-gradient-to-r from-[#1e122b] via-[#17181d] to-[#12221e] border border-amber-500/40 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-amber-400" />
                      <h3 className="text-sm font-black text-white font-['Chakra_Petch'] tracking-wide">
                        SUPER ADMIN SECURITY GATE: ADMIN REWARD DISPATCH PERMISSION
                      </h3>
                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                          allowAdminRewardDispatch
                            ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                            : 'bg-rose-950/80 text-rose-300 border-rose-500/40'
                        }`}
                      >
                        {allowAdminRewardDispatch ? 'ADMIN ACCESS: ON (ALLOWED)' : 'ADMIN ACCESS: OFF (STRICTLY BLOCKED)'}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-400">
                      When turned OFF, regular Admins are strictly blocked at both UI and API layers from accessing or executing "Send Money/Rewards to Notification Centre".
                    </p>
                  </div>

                  {isSuperCaller ? (
                    <button
                      type="button"
                      onClick={() => handleToggleAdminRewardPermission(!allowAdminRewardDispatch)}
                      className={`px-4 py-2.5 rounded-xl text-xs font-black font-mono transition cursor-pointer shrink-0 border ${
                        allowAdminRewardDispatch
                          ? 'bg-rose-600 hover:bg-rose-500 text-white border-rose-400 shadow-[0_0_15px_rgba(225,29,72,0.4)]'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.4)]'
                      }`}
                    >
                      {allowAdminRewardDispatch
                        ? 'Turn OFF Regular Admin Access'
                        : 'Turn ON Regular Admin Access'}
                    </button>
                  ) : (
                    <span className="text-[11px] font-mono text-rose-400 bg-rose-950/60 border border-rose-700/50 px-3 py-1.5 rounded-lg">
                      Super Admin Only Toggle
                    </span>
                  )}
                </div>

                {notifFeedback && (
                  <div
                    className={`p-3 rounded-xl border text-xs font-mono font-bold flex items-center gap-2 ${
                      notifFeedback.type === 'success'
                        ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                        : 'bg-rose-950/60 border-rose-500/50 text-rose-300'
                    }`}
                  >
                    <span>{notifFeedback.text}</span>
                  </div>
                )}

                {/* Send Money / Rewards Form */}
                {isDispatchBlockedForRegularAdmin ? (
                  <div className="p-6 bg-rose-950/30 border-2 border-rose-600/50 rounded-xl text-center space-y-2">
                    <AlertOctagon className="w-8 h-8 text-rose-500 mx-auto" />
                    <h4 className="text-sm font-black text-white uppercase">
                      Access Restricted by Super Admin Security Policy
                    </h4>
                    <p className="text-xs text-rose-200/80 max-w-md mx-auto">
                      Under strict security enforcement, regular Admins cannot access or execute the "Send Money/Rewards to Notification Centre" route while the Super Admin toggle status is turned OFF.
                    </p>
                  </div>
                ) : (
                  <form
                    onSubmit={handleSendNotificationReward}
                    className="bg-[#17181d] border border-[#2a2c36] rounded-xl p-5 space-y-4"
                  >
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <Gift className="w-4 h-4 text-amber-400" />
                        <h4 className="text-sm font-bold text-white">
                          Send Money / Rewards to Player Notification Centre
                        </h4>
                      </div>
                      <span className="text-[11px] font-mono text-emerald-400">
                        Instant WebSocket Delivery + Claimable Wallet Credit
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div>
                        <label className="block text-neutral-400 mb-1 font-bold">
                          Target Recipient (ALL or 7-Digit UID)
                        </label>
                        <input
                          type="text"
                          value={notifTargetUser}
                          onChange={(e) => setNotifTargetUser(e.target.value)}
                          placeholder="ALL or 7-digit UID (e.g. 8821045)"
                          className="w-full bg-[#121316] border border-[#2a2c35] rounded-lg px-3 py-2 text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-neutral-400 mb-1 font-bold">
                          Reward Money Amount (₹)
                        </label>
                        <input
                          type="number"
                          min={0}
                          step={1}
                          value={notifRewardAmount}
                          onChange={(e) => setNotifRewardAmount(e.target.value)}
                          placeholder="e.g. 100"
                          className="w-full bg-[#121316] border border-emerald-500/40 rounded-lg px-3 py-2 text-emerald-300 font-mono font-bold"
                        />
                      </div>

                      <div>
                        <label className="block text-neutral-400 mb-1 font-bold">
                          Category
                        </label>
                        <select
                          value={notifType}
                          onChange={(e) => setNotifType(e.target.value as any)}
                          className="w-full bg-[#121316] border border-[#2a2c35] rounded-lg px-3 py-2 text-white"
                        >
                          <option value="REWARD">REWARD (Claimable Money)</option>
                          <option value="PROMO">PROMO (Bonus Alert)</option>
                          <option value="SYSTEM">SYSTEM (Announcement)</option>
                          <option value="SECURITY">SECURITY (Account Notice)</option>
                        </select>
                      </div>
                    </div>

                    {/* Quick Reward Presets */}
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[11px] text-neutral-400 font-mono">Quick Money Presets:</span>
                      {['0', '50', '100', '250', '500', '1000', '5000'].map((amt) => (
                        <button
                          key={amt}
                          type="button"
                          onClick={() => setNotifRewardAmount(amt)}
                          className="px-2.5 py-1 rounded bg-[#22242c] hover:bg-[#2e313d] text-amber-300 border border-amber-500/30 text-xs font-mono font-bold cursor-pointer transition"
                        >
                          {amt === '0' ? '₹0 (Message Only)' : `₹${amt}`}
                        </button>
                      ))}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div>
                        <label className="block text-neutral-400 mb-1 font-bold">
                          Notification Title *
                        </label>
                        <input
                          type="text"
                          required
                          value={notifTitle}
                          onChange={(e) => setNotifTitle(e.target.value)}
                          className="w-full bg-[#121316] border border-[#2a2c35] rounded-lg px-3 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-neutral-400 mb-1 font-bold">
                          Notification Message *
                        </label>
                        <input
                          type="text"
                          required
                          value={notifMessage}
                          onChange={(e) => setNotifMessage(e.target.value)}
                          className="w-full bg-[#121316] border border-[#2a2c35] rounded-lg px-3 py-2 text-white"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={notifSubmitting}
                      className="w-full py-3 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 hover:opacity-95 text-neutral-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-lg transition cursor-pointer disabled:opacity-50"
                    >
                      {notifSubmitting
                        ? 'Dispatching to Notification Centre...'
                        : Number(notifRewardAmount) > 0
                        ? `Send ₹${notifRewardAmount} Reward to Notification Centre (${notifTargetUser || 'ALL'})`
                        : `Broadcast Message to Notification Centre (${notifTargetUser || 'ALL'})`}
                    </button>
                  </form>
                )}

                {/* Active Dispatched Notifications Ledger (Soft-Delete Enforced) */}
                <div className="bg-[#17181d] border border-[#2a2c36] rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div>
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                        Notification Centre Ledger (No-Delete / Soft-Delete Policy Active)
                      </h4>
                      <p className="text-[11px] text-neutral-400">
                        Archiving sets <code className="text-amber-300">is_deleted = true</code> and <code className="text-amber-300">deleted_at</code> timestamp without mutating or deleting database rows.
                      </p>
                    </div>
                    <span className="text-[11px] font-mono text-neutral-400 bg-[#121316] px-2.5 py-1 rounded border border-[#262831]">
                      Soft-Deleted Audit Rows Preserved: <strong className="text-amber-400">{softDeletedNotifCount}</strong>
                    </span>
                  </div>

                  {adminNotifications.length === 0 ? (
                    <div className="p-4 text-center text-xs text-neutral-500 bg-[#121316] rounded-lg">
                      No active notifications in ledger.
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                      {adminNotifications.map((n) => (
                        <div
                          key={n.id}
                          className="bg-[#121316] border border-[#262831] rounded-lg p-3 flex items-center justify-between gap-3 text-xs"
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-bold text-white">{n.title}</span>
                              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-indigo-950 text-indigo-300 border border-indigo-500/30">
                                Target: {n.targetUserId}
                              </span>
                              {n.rewardAmount > 0 && (
                                <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                                  Reward: ₹{n.rewardAmount}
                                </span>
                              )}
                              <span className="text-[10px] font-mono text-neutral-500">
                                By {n.senderName} ({n.senderRole})
                              </span>
                            </div>
                            <p className="text-[11px] text-neutral-400 mt-0.5 truncate">{n.message}</p>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleSoftDeleteNotificationAdmin(n.id)}
                            className="px-2.5 py-1 rounded bg-[#22242c] hover:bg-rose-950 text-neutral-400 hover:text-rose-300 border border-[#313441] text-[10px] font-mono font-bold shrink-0 cursor-pointer transition flex items-center gap-1"
                            title="Soft Delete (sets is_deleted=true, deleted_at)"
                          >
                            <Trash2 className="w-3 h-3" />
                            <span>Soft Delete</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })()}

          {/* ===================================================================== */}
          {/* TAB: TELEGRAM MASTERMIND BOT CONTROLLER & QUEUE */}
          {/* ===================================================================== */}
          {activeTab === 'telegramBotPanel' && (
            <div className="space-y-6 animate-in fade-in duration-150">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b-2 border-[#66fcf1] pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-[#0088cc] flex items-center justify-center text-white shadow-[0_0_15px_rgba(0,136,204,0.6)]">
                    <Send className="w-5 h-5 -rotate-12 translate-x-0.5" />
                  </div>
                  <div>
                    <h2 className="text-lg sm:text-xl font-black text-[#66fcf1] font-['Chakra_Petch'] tracking-wide">
                      👑 GHOST MASTERMIND BOT CONTROL PANEL
                    </h2>
                    <p className="text-xs text-neutral-400">
                      Firestore Deposit Ledger, Supreme Owner Command Center & Dynamic Privilege Matrix
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-3 py-1 rounded-full bg-[#1f2833] border border-amber-400 text-amber-400 font-bold text-xs font-mono">
                    Owner ID: 7939005883
                  </span>
                  <a
                    href="/superadmin/telegram-controller"
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1 rounded-lg bg-[#0b0c10] border border-[#66fcf1] text-[#66fcf1] hover:bg-[#66fcf1] hover:text-[#0b0c10] font-bold text-xs font-mono transition"
                  >
                    ↗ Full Controller Page
                  </a>
                  <button
                    type="button"
                    onClick={() => {
                      fetchBotReceiptQueue();
                      fetchFirestoreDeposits();
                      fetchAuthorizedAdmins();
                    }}
                    className="p-1.5 rounded-lg bg-[#1f2833] hover:bg-[#2c3746] text-[#66fcf1] border border-[#45f3ff]/40 cursor-pointer"
                    title="Refresh All Feeds"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Row 1: Gateway Settings & Live Firestore Manual Deposits Ledger */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                {/* Left Card: Gateway & Dynamic Specs */}
                <div className="bg-[#1f2833] border border-[#334155] rounded-xl p-5 shadow-lg space-y-4">
                  <h3 className="text-sm font-bold text-[#66fcf1] border-b border-[#45f3ff]/30 pb-2.5 flex items-center gap-2 font-['Chakra_Petch']">
                    <span>💳 Gateway & Dynamic Specs</span>
                  </h3>

                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="block text-xs font-bold text-[#45f3ff] mb-1 font-mono">
                        Admin UPI ID
                      </label>
                      <input
                        type="text"
                        value={botAdminUpi}
                        onChange={(e) => setBotAdminUpi(e.target.value)}
                        className="w-full p-2.5 bg-[#0b0c10] border border-[#45f3ff]/60 focus:border-[#66fcf1] rounded-lg text-white font-mono outline-none text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#45f3ff] mb-1 font-mono">
                        VIP Subscription Price (₹)
                      </label>
                      <input
                        type="number"
                        value={botVipPrice}
                        onChange={(e) => setBotVipPrice(parseInt(e.target.value) || 149)}
                        className="w-full p-2.5 bg-[#0b0c10] border border-[#45f3ff]/60 focus:border-[#66fcf1] rounded-lg text-white font-mono outline-none text-xs"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={handleSaveBotSettings}
                      className="w-full py-2.5 px-4 bg-[#66fcf1] hover:bg-[#45f3ff] text-[#0b0c10] font-black text-xs uppercase tracking-wider rounded-lg shadow-[0_0_12px_rgba(102,252,241,0.4)] transition cursor-pointer"
                    >
                      Update Configurations
                    </button>

                    {botSettingsFeedback && (
                      <div className="p-2 rounded bg-emerald-950/80 border border-emerald-500 text-emerald-300 font-mono text-[11px] animate-in fade-in">
                        {botSettingsFeedback}
                      </div>
                    )}

                    <div className="pt-3 border-t border-[#334155] space-y-2">
                      <label className="block text-xs font-bold text-amber-300 font-mono">
                        🎁 Mastermind Promo Blast
                      </label>
                      <p className="text-[11px] text-neutral-400">
                        Dispatch 2 free bonus test credits to all 0-credit inactive users immediately.
                      </p>
                      <button
                        type="button"
                        disabled={promoBlastLoading}
                        onClick={handleTriggerPromoBlast}
                        className="w-full py-2 px-3 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-white font-bold text-xs rounded-lg transition shadow-md cursor-pointer disabled:opacity-50"
                      >
                        {promoBlastLoading ? 'Dispatching...' : '🚀 Dispatch 2 Free Bonus Credits'}
                      </button>
                      {promoBlastMsg && (
                        <div className="p-2 rounded bg-amber-950/80 border border-amber-500 text-amber-200 font-mono text-[10px]">
                          {promoBlastMsg}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Calculator Slabs Information */}
                  <div className="pt-3 border-t border-[#334155] space-y-1 text-[11px] text-neutral-300 font-mono">
                    <div className="text-[#66fcf1] font-bold">AUTOMATED SLAB RULES:</div>
                    <ul className="space-y-0.5 text-neutral-400 text-[10px]">
                      <li>• 10 - 29 rounds: ₹3/rd + ₹2 dynamic tax</li>
                      <li>• 30 - 99 rounds: ₹3/rd + ₹6 dynamic tax</li>
                      <li>• 100+ rounds: ₹3/rd + ₹15 dynamic tax</li>
                      <li>• VIP Pass: ₹{botVipPrice} (+32 Free Credits)</li>
                    </ul>
                  </div>
                </div>

                {/* Right Card: Live Firestore Manual Deposits Ledger */}
                <div className="lg:col-span-2 bg-[#1f2833] border border-[#334155] rounded-xl p-5 shadow-lg space-y-4">
                  <div className="flex items-center justify-between border-b border-[#45f3ff]/30 pb-2.5">
                    <h3 className="text-sm font-bold text-[#66fcf1] flex items-center gap-2 font-['Chakra_Petch']">
                      <span>🔥 Live Firestore Deposits Ledger (/api/deposits)</span>
                    </h3>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-mono text-[#45f3ff]">
                        {firestoreDeposits.filter(d => d.status === 'pending').length} Pending
                      </span>
                      <button
                        type="button"
                        onClick={fetchFirestoreDeposits}
                        className="p-1 rounded bg-[#0b0c10] text-[#66fcf1] hover:text-white"
                        title="Reload Firestore Deposits"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${firestoreDepositsLoading ? 'animate-spin' : ''}`} />
                      </button>
                    </div>
                  </div>

                  <div className="overflow-x-auto max-h-[360px]">
                    <table className="w-full border-collapse text-xs">
                      <thead>
                        <tr className="bg-[#0b0c10] text-[#66fcf1] border-b border-[#45f3ff]/30 sticky top-0">
                          <th className="p-2.5 text-left">User (Chat ID)</th>
                          <th className="p-2.5 text-left">Amount & Rounds</th>
                          <th className="p-2.5 text-left">Proof / UTR</th>
                          <th className="p-2.5 text-left">Status / Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {firestoreDeposits.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="p-6 text-center text-neutral-400 font-mono">
                              No deposits recorded in Firestore yet.
                            </td>
                          </tr>
                        ) : (
                          firestoreDeposits.map((dep) => (
                            <tr key={dep.id} className="border-b border-[#45f3ff]/20 hover:bg-[#151c24]/50">
                              <td className="p-2.5 font-mono">
                                <b className="text-[#66fcf1]">{dep.firstName || 'Pilot'}</b>
                                {dep.username && dep.username !== 'None' && (
                                  <span className="text-neutral-400 text-[10px]"> (@{dep.username})</span>
                                )}
                                <br />
                                <span className="text-[10px] text-neutral-400">ID: {dep.chatId}</span>
                                <br />
                                <span className="text-[9px] text-neutral-500 font-mono">{dep.id}</span>
                              </td>
                              <td className="p-2.5 font-mono">
                                <b className="text-amber-300 font-bold">₹{dep.amount || 0}</b>
                                <br />
                                <span className="text-[10px] text-sky-400 font-bold">
                                  {dep.rounds || 32} Rounds
                                </span>
                              </td>
                              <td className="p-2.5">
                                <div className="max-w-[160px] truncate bg-[#0b0c10] px-2 py-1 rounded text-[10px] font-mono text-neutral-300 border border-[#334155]" title={dep.proof}>
                                  {dep.proof || 'No proof string'}
                                </div>
                              </td>
                              <td className="p-2.5">
                                {dep.status === 'pending' ? (
                                  <div className="flex items-center gap-1.5">
                                    <button
                                      type="button"
                                      disabled={depositVerifyLoadingId === dep.id}
                                      onClick={() => handleVerifyFirestoreDeposit(dep.id, 'approve')}
                                      className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] rounded transition cursor-pointer disabled:opacity-50"
                                    >
                                      {depositVerifyLoadingId === dep.id ? '...' : 'Approve ✅'}
                                    </button>
                                    <button
                                      type="button"
                                      disabled={depositVerifyLoadingId === dep.id}
                                      onClick={() => handleVerifyFirestoreDeposit(dep.id, 'reject')}
                                      className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white font-bold text-[11px] rounded transition cursor-pointer disabled:opacity-50"
                                    >
                                      Reject ❌
                                    </button>
                                  </div>
                                ) : (
                                  <div>
                                    <span
                                      className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                                        dep.status === 'approved'
                                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                                          : dep.status === 'expired'
                                          ? 'bg-neutral-800 text-neutral-400 border border-neutral-600'
                                          : 'bg-rose-950 text-rose-300 border border-rose-500/40'
                                      }`}
                                    >
                                      {dep.status || 'UNKNOWN'}
                                    </span>
                                    {dep.processedBy && (
                                      <div className="text-[9px] text-neutral-400 font-mono mt-0.5">
                                        by {dep.processedBy}
                                      </div>
                                    )}
                                  </div>
                                )}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Row 2: Dynamic Admin Privilege Management & Direct User Inspector */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                {/* Card A: Dynamic Admin Privilege Management */}
                <div className="bg-[#1f2833] border border-[#334155] rounded-xl p-5 shadow-lg space-y-4">
                  <h3 className="text-sm font-bold text-[#66fcf1] border-b border-[#45f3ff]/30 pb-2.5 flex items-center justify-between font-['Chakra_Petch']">
                    <span>🛡️ Dynamic Sub-Admin Privilege Management</span>
                    <span className="text-[10px] font-mono text-neutral-400">/api/manage-admin</span>
                  </h3>

                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Supreme Owner <code className="text-amber-400 font-bold">7939005883</code> retains absolute authority. Authorize or revoke secondary Telegram Admin IDs to grant message routing and verification privileges.
                  </p>

                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-[#45f3ff] font-mono">
                      Add Sub-Admin Telegram Chat ID
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="e.g. 123456789"
                        value={newAdminTelegramId}
                        onChange={(e) => setNewAdminTelegramId(e.target.value)}
                        className="flex-1 p-2 bg-[#0b0c10] border border-[#45f3ff]/60 rounded-lg text-white font-mono text-xs outline-none"
                      />
                      <button
                        type="button"
                        onClick={handleAddSubAdmin}
                        className="px-4 py-2 bg-[#66fcf1] hover:bg-[#45f3ff] text-[#0b0c10] font-black text-xs rounded-lg transition cursor-pointer"
                      >
                        + Add Admin
                      </button>
                    </div>
                  </div>

                  {adminMgmtMsg && (
                    <div className="p-2 rounded bg-cyan-950/80 border border-cyan-500 text-cyan-300 font-mono text-[11px]">
                      {adminMgmtMsg}
                    </div>
                  )}

                  <div className="space-y-2 pt-2 border-t border-[#334155]">
                    <div className="text-xs font-bold text-neutral-300 font-mono flex items-center justify-between">
                      <span>Authorized Sub-Admins List:</span>
                      <span className="text-neutral-500 font-normal">{authorizedAdmins.length} active</span>
                    </div>

                    <div className="space-y-1.5 max-h-36 overflow-y-auto">
                      {authorizedAdmins.length === 0 ? (
                        <div className="text-xs text-neutral-500 font-mono italic">
                          No sub-admins configured. Only Supreme Owner 7939005883 has active permissions.
                        </div>
                      ) : (
                        authorizedAdmins.map((adminId) => (
                          <div
                            key={adminId}
                            className="flex items-center justify-between p-2 rounded-lg bg-[#0b0c10] border border-[#334155] text-xs font-mono"
                          >
                            <span className="text-[#66fcf1]">🆔 Telegram ID: <b>{adminId}</b></span>
                            <button
                              type="button"
                              onClick={() => handleRemoveSubAdmin(adminId)}
                              className="px-2 py-0.5 bg-rose-900/60 hover:bg-rose-700 text-rose-200 text-[10px] rounded transition cursor-pointer font-bold"
                            >
                              Remove
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>

                {/* Card B: User Live Inspector & Credit / VIP Modifier */}
                <div className="bg-[#1f2833] border border-[#334155] rounded-xl p-5 shadow-lg space-y-4">
                  <h3 className="text-sm font-bold text-[#66fcf1] border-b border-[#45f3ff]/30 pb-2.5 flex items-center justify-between font-['Chakra_Petch']">
                    <span>⚡ User Live Inspector & Direct Modifier</span>
                    <span className="text-[10px] font-mono text-neutral-400">/check & /give_credit</span>
                  </h3>

                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-[#45f3ff] font-mono">
                      Target User Telegram Chat ID
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="e.g. 999999999"
                        value={inspectUserChatId}
                        onChange={(e) => setInspectUserChatId(e.target.value)}
                        className="flex-1 p-2 bg-[#0b0c10] border border-[#45f3ff]/60 rounded-lg text-white font-mono text-xs outline-none"
                      />
                      <button
                        type="button"
                        disabled={inspectLoading}
                        onClick={handleInspectUser}
                        className="px-4 py-2 bg-[#334155] hover:bg-[#475569] text-white font-bold text-xs rounded-lg transition cursor-pointer disabled:opacity-50"
                      >
                        {inspectLoading ? '...' : 'Inspect'}
                      </button>
                    </div>
                  </div>

                  {userInspectFeedback && (
                    <div className="p-2 rounded bg-cyan-950/80 border border-cyan-500 text-cyan-300 font-mono text-[11px]">
                      {userInspectFeedback}
                    </div>
                  )}

                  {inspectedUserData && (
                    <div className="p-3 rounded-lg bg-[#0b0c10] border border-[#334155] text-xs font-mono space-y-1 text-neutral-300">
                      <div>
                        <b>Account:</b> <span className="text-[#66fcf1]">{inspectedUserData.firstName || 'Pilot'}</span> (<code>{inspectedUserData.chatId}</code>)
                      </div>
                      <div>
                        <b>Credits Quota:</b> <span className="text-[#45f3ff] font-bold text-sm">{inspectedUserData.credits ?? 0}</span>
                      </div>
                      <div>
                        <b>VIP Status:</b>{' '}
                        <span className={inspectedUserData.isPremium ? 'text-emerald-400 font-bold' : 'text-neutral-400'}>
                          {inspectedUserData.isPremium ? 'ACTIVE VIP 👑' : 'Standard Tier'}
                        </span>
                      </div>
                      <div>
                        <b>Role:</b> <code>{inspectedUserData.role || 'user'}</code> | <b>Context:</b> <code>{inspectedUserData.context || 'None'}</code>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3 pt-2 border-t border-[#334155]">
                    <div>
                      <label className="block text-[11px] font-bold text-[#45f3ff] mb-1 font-mono">
                        Give Credits
                      </label>
                      <div className="flex gap-1.5">
                        <input
                          type="number"
                          value={giveCreditsVal}
                          onChange={(e) => setGiveCreditsVal(parseInt(e.target.value) || 0)}
                          className="w-20 p-1.5 bg-[#0b0c10] border border-[#45f3ff]/60 rounded text-white font-mono text-xs outline-none"
                        />
                        <button
                          type="button"
                          onClick={handleGiveCreditsToUser}
                          className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded transition cursor-pointer"
                        >
                          + Give
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-[#45f3ff] mb-1 font-mono">
                        Toggle VIP
                      </label>
                      <div className="flex gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleToggleVipToUser(true)}
                          className="flex-1 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded transition cursor-pointer"
                        >
                          VIP: ON
                        </button>
                        <button
                          type="button"
                          onClick={() => handleToggleVipToUser(false)}
                          className="flex-1 py-1.5 bg-neutral-700 hover:bg-neutral-600 text-neutral-300 font-bold text-xs rounded transition cursor-pointer"
                        >
                          OFF
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Row 3: In-Memory Receipt Queue */}
              <div className="bg-[#1f2833] border border-[#334155] rounded-xl p-5 shadow-lg space-y-4">
                <div className="flex items-center justify-between border-b border-[#45f3ff]/30 pb-2.5">
                  <h3 className="text-sm font-bold text-[#66fcf1] flex items-center gap-2 font-['Chakra_Petch']">
                    <span>🧾 In-Memory Receipt Verification Queue (Live Fast Buffer)</span>
                  </h3>
                  <span className="text-[11px] font-mono text-[#45f3ff]">
                    {botReceiptQueue.filter(r => r.status === 'PENDING').length} Pending
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#0b0c10] text-[#66fcf1] border-b border-[#45f3ff]/30">
                        <th className="p-3 text-left">User (Telegram ID)</th>
                        <th className="p-3 text-left">Demand Type</th>
                        <th className="p-3 text-left">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {botReceiptQueue.length === 0 ? (
                        <tr>
                          <td colSpan={3} className="p-6 text-center text-neutral-400 font-mono">
                            No pending receipt requests in queue.
                          </td>
                        </tr>
                      ) : (
                        botReceiptQueue.map((item) => (
                          <tr key={item.id} className="border-b border-[#45f3ff]/20 hover:bg-[#151c24]/50">
                            <td className="p-3 font-mono">
                              <b className="text-[#66fcf1]">{item.firstName || 'Pilot'}</b>
                              {item.username && <span className="text-neutral-400 text-[11px]"> (@{item.username})</span>}
                              <br />
                              <span className="text-[11px] text-neutral-400">ID: {item.chatId}</span>
                            </td>
                            <td className="p-3">
                              <b className="text-amber-300 font-bold">{item.demandType}</b>
                              <br />
                              <span className="text-[11px] text-neutral-400 font-mono">
                                Amount: ₹{item.amount} | {item.date}
                              </span>
                            </td>
                            <td className="p-3">
                              {item.status === 'PENDING' ? (
                                <div className="flex items-center gap-2">
                                  <button
                                    type="button"
                                    disabled={botActionLoadingId === item.id}
                                    onClick={() => handleActionBotReceipt(item.id, 'APPROVE')}
                                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded transition cursor-pointer disabled:opacity-50"
                                  >
                                    {botActionLoadingId === item.id ? '...' : 'Approve'}
                                  </button>
                                  <button
                                    type="button"
                                    disabled={botActionLoadingId === item.id}
                                    onClick={() => handleActionBotReceipt(item.id, 'REJECT')}
                                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded transition cursor-pointer disabled:opacity-50"
                                  >
                                    Reject
                                  </button>
                                </div>
                              ) : (
                                <span
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                                    item.status === 'APPROVED'
                                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                                      : 'bg-rose-950 text-rose-300 border border-rose-500/40'
                                  }`}
                                >
                                  {item.status}
                                </span>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Screenshot Zoom Modal */}
        {zoomedImage && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
            onClick={() => setZoomedImage(null)}
          >
            <div className="relative max-w-2xl max-h-[85vh] bg-[#1a1b20] border border-neutral-700 p-2 rounded-xl">
              <button
                onClick={() => setZoomedImage(null)}
                className="absolute -top-3 -right-3 p-1.5 rounded-full bg-red-600 text-white shadow-lg"
              >
                <X className="w-4 h-4" />
              </button>
              <img
                src={zoomedImage}
                alt="Zoomed Proof"
                className="max-h-[80vh] w-auto object-contain rounded-lg"
              />
            </div>
          </div>
        )}

        {/* Adjust Balance Modal */}
        {adjustModalUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
            <div className="w-full max-w-sm bg-[#18191e] border border-[#2d303c] rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-white">
                  Adjust Balance: {adjustModalUser.name}
                </h4>
                <button
                  onClick={() => setAdjustModalUser(null)}
                  className="text-neutral-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex bg-[#121316] p-1 rounded-xl border border-[#292b33]">
                <button
                  type="button"
                  onClick={() => setAdjustAction('ADD_BALANCE')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg ${
                    adjustAction === 'ADD_BALANCE'
                      ? 'bg-emerald-600 text-white'
                      : 'text-neutral-400'
                  }`}
                >
                  Add Balance (+)
                </button>
                <button
                  type="button"
                  onClick={() => setAdjustAction('DEDUCT_BALANCE')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg ${
                    adjustAction === 'DEDUCT_BALANCE'
                      ? 'bg-rose-600 text-white'
                      : 'text-neutral-400'
                  }`}
                >
                  Deduct Balance (-)
                </button>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-400 mb-1">
                  Amount (₹)
                </label>
                <input
                  type="number"
                  min={1}
                  value={adjustAmount}
                  onChange={(e) => setAdjustAmount(Number(e.target.value))}
                  className="w-full bg-[#121316] border border-[#2a2d36] rounded-xl px-3 py-2 text-sm text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-400 mb-1">
                  Note / Reason
                </label>
                <input
                  type="text"
                  value={adjustNote}
                  onChange={(e) => setAdjustNote(e.target.value)}
                  className="w-full bg-[#121316] border border-[#2a2d36] rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <button
                onClick={() => handleUserAction(adjustModalUser.id, adjustAction, adjustAmount, adjustNote)}
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-500 rounded-xl font-bold text-xs text-white transition"
              >
                Confirm Balance Adjustment
              </button>
            </div>
          </div>
        )}

        {/* Smart Lock Config Modal */}
        {smartLockUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
            <div className="w-full max-w-sm bg-[#18191e] border border-rose-600/50 rounded-2xl p-5 space-y-4 shadow-[0_0_30px_rgba(225,29,72,0.3)]">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-rose-950 text-rose-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <h4 className="text-sm font-bold text-white">
                    Engage Smart Lock
                  </h4>
                </div>
                <button
                  onClick={() => setSmartLockUser(null)}
                  className="text-neutral-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="text-xs text-neutral-300">
                Player: <span className="font-bold text-white">{smartLockUser.name}</span> ({smartLockUser.phone})
              </div>

              <div className="p-3 bg-rose-950/30 border border-rose-500/30 rounded-xl text-xs text-rose-300 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <AlertOctagon className="w-3.5 h-3.5" />
                  <span>Mathematical House Trap Activated</span>
                </div>
                <p className="text-[11px] text-rose-200/80 leading-relaxed">
                  During locked rounds, this player's crash multiplier will be artificially clamped to low values (1.02x - 1.15x) before any high cashout can occur.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-400 mb-1">
                  Consecutive Rounds to Clamp
                </label>
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={smartLockRoundsInput}
                  onChange={(e) => setSmartLockRoundsInput(Math.max(1, Number(e.target.value)))}
                  className="w-full bg-[#121316] border border-[#2a2d36] rounded-xl px-3 py-2 text-sm text-white font-mono"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSmartLockUser(null)}
                  className="flex-1 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-xl text-xs font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => handleToggleSmartLock(smartLockUser, true, smartLockRoundsInput)}
                  className="flex-1 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition shadow-md"
                >
                  Enforce Lock
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
