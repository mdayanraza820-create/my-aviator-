import React, { useState, useEffect } from 'react';
import { PeakVolumeSchedule } from '../types';
import { Clock, Plus, Trash2, ShieldAlert, Check, Calendar, Flame } from 'lucide-react';

interface PeakScheduleLedgerProps {
  adminKey: string;
}

export const PeakScheduleLedger: React.FC<PeakScheduleLedgerProps> = ({ adminKey }) => {
  const [schedules, setSchedules] = useState<PeakVolumeSchedule[]>([
    {
      id: 'peak_evening',
      name: 'Peak Evening Concurrency (18:00 - 23:00)',
      startHour: 18,
      endHour: 23,
      forcedCrashProbability: 0.65,
      isActive: true
    }
  ]);
  const [loading, setLoading] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // New schedule form
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [startHour, setStartHour] = useState<number>(19);
  const [endHour, setEndHour] = useState<number>(22);
  const [forcedProb, setForcedProb] = useState<number>(65);

  const currentHour = new Date().getHours();
  const isCurrentlyPeak = schedules.some(
    (s) => s.isActive && currentHour >= s.startHour && currentHour <= s.endHour
  );

  const fetchSchedules = async () => {
    try {
      const res = await fetch('/api/admin/schedules', {
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.schedules) setSchedules(data.schedules);
      }
    } catch {
      // Keep local defaults
    }
  };

  useEffect(() => {
    fetchSchedules();
  }, [adminKey]);

  const handleSaveSchedules = async (newSchedules: PeakVolumeSchedule[]) => {
    setLoading(true);
    setFeedback(null);
    try {
      const res = await fetch('/api/admin/schedules/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminKey
        },
        body: JSON.stringify({ schedules: newSchedules })
      });
      if (res.ok) {
        setSchedules(newSchedules);
        setFeedback('Schedule ledger synchronized with AI margin engine.');
      } else {
        setFeedback('Failed to update schedules. Check Super Admin privileges.');
      }
    } catch {
      setFeedback('Error updating schedules.');
    } finally {
      setLoading(false);
      setTimeout(() => setFeedback(null), 4000);
    }
  };

  const handleToggle = (id: string) => {
    const updated = schedules.map((s) =>
      s.id === id ? { ...s, isActive: !s.isActive } : s
    );
    handleSaveSchedules(updated);
  };

  const handleDelete = (id: string) => {
    const updated = schedules.filter((s) => s.id !== id);
    handleSaveSchedules(updated);
  };

  const handleAddSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newSched: PeakVolumeSchedule = {
      id: `sched_${Date.now()}`,
      name: name.trim(),
      startHour: Number(startHour),
      endHour: Number(endHour),
      forcedCrashProbability: Number(forcedProb) / 100,
      isActive: true
    };

    const updated = [...schedules, newSched];
    handleSaveSchedules(updated);
    setShowAddForm(false);
    setName('');
  };

  return (
    <div className="bg-[#14151a] border border-[#242630] rounded-xl p-4 space-y-4 text-xs">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#232530] pb-3">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-400" />
          <h3 className="text-sm font-bold text-white">Peak Volume Dynamic Margin Schedules</h3>
        </div>

        <div className="flex items-center gap-2">
          <div
            className={`px-2.5 py-1 rounded-full text-[10px] font-bold font-mono flex items-center gap-1.5 border ${
              isCurrentlyPeak
                ? 'bg-rose-950/80 border-rose-500/50 text-rose-300 animate-pulse'
                : 'bg-neutral-800/80 border-neutral-700 text-neutral-400'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                isCurrentlyPeak ? 'bg-rose-500' : 'bg-neutral-500'
              }`}
            />
            <span>
              {isCurrentlyPeak
                ? 'PEAK MARGIN CLAMP ACTIVE (65% < 1.90x)'
                : 'STANDARD AUTONOMOUS MATRIX (47% < 1.90x)'}
            </span>
          </div>

          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg flex items-center gap-1 transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Schedule</span>
          </button>
        </div>
      </div>

      <p className="text-[11px] text-neutral-400 leading-relaxed">
        Specify cron-style time-blocks during peak traffic concurrency. During active time-blocks,
        the server drops the autonomous baseline win threshold, forcing a{' '}
        <span className="text-rose-400 font-bold font-mono">65% pre-1.90x crash probability</span>{' '}
        to enforce maximum platform profitability.
      </p>

      {feedback && (
        <div className="p-2.5 bg-emerald-950/60 border border-emerald-500/50 rounded-lg text-emerald-300 font-medium">
          {feedback}
        </div>
      )}

      {/* Add Form Modal/Inline */}
      {showAddForm && (
        <form onSubmit={handleAddSchedule} className="bg-[#1a1c24] border border-[#2d3040] rounded-xl p-3.5 space-y-3 animate-in fade-in duration-150">
          <div className="font-bold text-white text-xs flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <span>Create New Peak Margin Time-Block</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-neutral-400 text-[10px] mb-1 font-semibold">Schedule Label</label>
              <input
                type="text"
                required
                placeholder="e.g. Late Night Rush"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#101115] border border-[#2e3140] rounded-lg px-2.5 py-1.5 text-white text-xs focus:border-amber-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-neutral-400 text-[10px] mb-1 font-semibold">Time Window (24h format)</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={0}
                  max={23}
                  value={startHour}
                  onChange={(e) => setStartHour(Number(e.target.value))}
                  className="w-16 bg-[#101115] border border-[#2e3140] rounded-lg px-2 py-1.5 text-white text-xs text-center font-mono focus:border-amber-500 outline-none"
                />
                <span className="text-neutral-500">to</span>
                <input
                  type="number"
                  min={0}
                  max={23}
                  value={endHour}
                  onChange={(e) => setEndHour(Number(e.target.value))}
                  className="w-16 bg-[#101115] border border-[#2e3140] rounded-lg px-2 py-1.5 text-white text-xs text-center font-mono focus:border-amber-500 outline-none"
                />
                <span className="text-neutral-400 text-[10px]">HRS</span>
              </div>
            </div>

            <div>
              <label className="block text-neutral-400 text-[10px] mb-1 font-semibold">Forced Pre-1.90x Crash %</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={47}
                  max={95}
                  value={forcedProb}
                  onChange={(e) => setForcedProb(Number(e.target.value))}
                  className="w-20 bg-[#101115] border border-[#2e3140] rounded-lg px-2 py-1.5 text-white text-xs text-center font-mono focus:border-amber-500 outline-none"
                />
                <span className="text-rose-400 font-bold font-mono">%</span>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-3 py-1.5 bg-[#20222a] hover:bg-[#282a35] text-neutral-300 rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg transition"
            >
              Save Schedule
            </button>
          </div>
        </form>
      )}

      {/* Schedule Items Table */}
      <div className="space-y-2">
        {schedules.map((s) => {
          const isActiveNow =
            s.isActive && currentHour >= s.startHour && currentHour <= s.endHour;

          return (
            <div
              key={s.id}
              className={`p-3 rounded-xl border flex flex-wrap items-center justify-between gap-3 transition ${
                isActiveNow
                  ? 'bg-rose-950/20 border-rose-500/40 shadow-sm'
                  : 'bg-[#181920] border-[#262832]'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                    isActiveNow
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                      : 'bg-neutral-800 text-neutral-400'
                  }`}
                >
                  <Flame className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{s.name}</span>
                    {isActiveNow && (
                      <span className="px-1.5 py-0.2 rounded bg-rose-600/30 text-rose-300 text-[10px] font-bold font-mono">
                        TRIGGERED NOW
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-neutral-400 font-mono flex items-center gap-3">
                    <span>
                      Window: {String(s.startHour).padStart(2, '0')}:00 – {String(s.endHour).padStart(2, '0')}:00
                    </span>
                    <span>&bull;</span>
                    <span className="text-rose-400 font-bold">
                      {(s.forcedCrashProbability * 100).toFixed(0)}% Crash Under 1.90x
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleToggle(s.id)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                    s.isActive
                      ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-900/60'
                      : 'bg-neutral-800 text-neutral-500 hover:bg-neutral-700'
                  }`}
                >
                  {s.isActive ? 'Active' : 'Disabled'}
                </button>

                <button
                  onClick={() => handleDelete(s.id)}
                  className="p-1.5 text-neutral-500 hover:text-red-400 rounded-lg hover:bg-neutral-800 transition"
                  title="Remove Schedule"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
