import React, { useState, useEffect } from 'react';
import { BASELINE_DEPOSIT_BONUSES, TimedCampaignState } from '../types';
import { Clock, Zap, RotateCcw, Save, AlertCircle, Sparkles, CheckCircle2 } from 'lucide-react';

interface TimedCampaignManagerProps {
  adminKey: string;
}

export const TimedCampaignManager: React.FC<TimedCampaignManagerProps> = ({ adminKey }) => {
  const [campaign, setCampaign] = useState<TimedCampaignState | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Form states
  const [campaignTitle, setCampaignTitle] = useState<string>('Weekend High-Roller Surge');
  const [durationMinutes, setDurationMinutes] = useState<number>(60);
  const [overrides, setOverrides] = useState<Record<number, { firstTime: number; recurring: number }>>({
    100: { firstTime: 35, recurring: 12 },
    200: { firstTime: 45, recurring: 20 },
    500: { firstTime: 75, recurring: 30 },
    1000: { firstTime: 120, recurring: 50 },
    2000: { firstTime: 180, recurring: 80 },
    5000: { firstTime: 250, recurring: 120 }
  });

  const [remainingTimeStr, setRemainingTimeStr] = useState<string>('');

  const fetchActiveCampaign = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/admin/promotions/active', {
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        const data = await res.json();
        setCampaign(data.campaign);
        if (data.campaign?.isActive) {
          setCampaignTitle(data.campaign.campaignTitle || 'Custom Promotional Event');
          if (data.campaign.overrides) {
            setOverrides(data.campaign.overrides);
          }
        }
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchActiveCampaign();
  }, [adminKey]);

  // Real-time ticking clock for remaining campaign duration
  useEffect(() => {
    if (!campaign?.isActive || !campaign.expiresAt) {
      setRemainingTimeStr('');
      return;
    }

    const interval = setInterval(() => {
      const now = Date.now();
      const diff = Math.max(0, Math.floor((campaign.expiresAt - now) / 1000));
      if (diff <= 0) {
        setRemainingTimeStr('Expired (Auto-Reverted to Baseline)');
        fetchActiveCampaign();
        return;
      }
      const mins = Math.floor(diff / 60);
      const secs = diff % 60;
      setRemainingTimeStr(`${mins}m ${secs.toString().padStart(2, '0')}s remaining`);
    }, 1000);

    return () => clearInterval(interval);
  }, [campaign]);

  const handleOverrideChange = (
    amount: number,
    field: 'firstTime' | 'recurring',
    val: number
  ) => {
    setOverrides((prev) => ({
      ...prev,
      [amount]: {
        ...(prev[amount] || { firstTime: 0, recurring: 0 }),
        [field]: Math.max(0, Math.floor(val))
      }
    }));
  };

  const handleLaunchCampaign = async () => {
    setSaving(true);
    setFeedback(null);
    try {
      const res = await fetch('/api/admin/promotions/override', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminKey
        },
        body: JSON.stringify({
          campaignTitle,
          durationMinutes: Number(durationMinutes) || 60,
          overrides
        })
      });

      if (res.ok) {
        const data = await res.json();
        setCampaign(data.campaign);
        setFeedback('Campaign override activated successfully! Real-time TTL timer is live.');
      } else {
        const err = await res.json();
        setFeedback(`Error: ${err.error || 'Failed to activate campaign'}`);
      }
    } catch {
      setFeedback('Failed to reach server');
    } finally {
      setSaving(false);
    }
  };

  const handleRevertBaseline = async () => {
    if (!confirm('Revert all deposit promotional bonuses to original Module 18 baseline parameters?')) {
      return;
    }
    setSaving(true);
    setFeedback(null);
    try {
      const res = await fetch('/api/admin/promotions/revert', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': adminKey
        }
      });
      if (res.ok) {
        const data = await res.json();
        setCampaign(data.campaign);
        setFeedback('Successfully reverted to baseline Module 18 indices.');
      }
    } catch {
      setFeedback('Failed to revert campaign');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#17181d] border border-[#2a2c36] rounded-xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <h3 className="text-sm font-bold text-white font-['Chakra_Petch'] uppercase tracking-wider">
                TIMED PROMOTIONAL CAMPAIGNS & DYNAMIC BONUS OVERRIDES (MODULE 19)
              </h3>
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              Mutate default first-time and recurring deposit rewards dynamically with real-time TTL countdown and auto-reversion.
            </p>
          </div>

          {/* Active Status Pill */}
          <div className="flex items-center gap-2">
            {campaign?.isActive ? (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-300 text-xs font-mono font-bold shadow-[0_0_12px_rgba(16,185,129,0.3)]">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>OVERRIDE ACTIVE</span>
                <span className="text-amber-400">({remainingTimeStr})</span>
              </div>
            ) : (
              <div className="px-3 py-1.5 rounded-xl bg-[#1c1d24] border border-[#2b2e3a] text-neutral-400 text-xs font-mono">
                BASELINE MODE (MODULE 18)
              </div>
            )}
          </div>
        </div>

        {feedback && (
          <div className="mt-4 p-3 bg-[#1e2029] border border-amber-500/40 rounded-xl text-xs text-amber-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}
      </div>

      {/* Campaign Configuration Form */}
      <div className="bg-[#17181d] border border-[#2a2c36] rounded-xl p-5 space-y-5">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider font-['Chakra_Petch']">
          Campaign Parameters & TTL
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-neutral-400 mb-1">
              Campaign Display Title
            </label>
            <input
              type="text"
              value={campaignTitle}
              onChange={(e) => setCampaignTitle(e.target.value)}
              placeholder="e.g. VIP Festive Deposit Surge"
              className="w-full bg-[#121316] border border-[#2a2c35] rounded-lg px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none font-medium"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-400 mb-1">
              Campaign Duration (TTL in Minutes)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min={1}
                max={1440}
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Math.max(1, Number(e.target.value)))}
                className="w-full bg-[#121316] border border-[#2a2c35] rounded-lg px-3 py-2 text-xs text-white focus:border-amber-500 focus:outline-none font-mono font-bold"
              />
              <span className="text-xs text-neutral-400 font-mono shrink-0">mins</span>
            </div>
            <span className="text-[10px] text-neutral-400 mt-1 block">
              Auto-reverts to baseline the instant the timer reaches 0.
            </span>
          </div>
        </div>

        {/* Deposit Bonus Overrides Matrix Table */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-bold text-neutral-300 uppercase tracking-wider">
              Deposit Tier Bonus Overrides (₹)
            </label>
            <span className="text-[10px] text-amber-400/80">
              Module 18 baseline displayed in brackets for comparison
            </span>
          </div>

          <div className="overflow-x-auto border border-[#262833] rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#121316] border-b border-[#262833] text-neutral-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Deposit Amount</th>
                  <th className="py-2.5 px-3">Baseline First-Time</th>
                  <th className="py-2.5 px-3">Campaign First-Time (Override)</th>
                  <th className="py-2.5 px-3">Baseline Recurring</th>
                  <th className="py-2.5 px-3">Campaign Recurring (Override)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e2029]">
                {BASELINE_DEPOSIT_BONUSES.map((tier) => {
                  const currentOverride = overrides[tier.depositAmount] || {
                    firstTime: tier.firstTimeBonus,
                    recurring: tier.recurringBonus
                  };

                  return (
                    <tr key={tier.depositAmount} className="hover:bg-[#1a1b22] transition">
                      <td className="py-2.5 px-3 font-mono font-bold text-white">
                        ₹{tier.depositAmount}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-neutral-400">
                        +₹{tier.firstTimeBonus}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-1">
                          <span className="text-xs text-emerald-400 font-bold">+₹</span>
                          <input
                            type="number"
                            min={0}
                            value={currentOverride.firstTime}
                            onChange={(e) =>
                              handleOverrideChange(tier.depositAmount, 'firstTime', +e.target.value)
                            }
                            className="w-20 bg-[#121316] border border-[#2e313f] rounded px-2 py-1 text-xs text-emerald-400 font-mono font-bold focus:border-emerald-500 focus:outline-none"
                          />
                        </div>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-neutral-400">
                        +₹{tier.recurringBonus}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-1">
                          <span className="text-xs text-amber-400 font-bold">+₹</span>
                          <input
                            type="number"
                            min={0}
                            value={currentOverride.recurring}
                            onChange={(e) =>
                              handleOverrideChange(tier.depositAmount, 'recurring', +e.target.value)
                            }
                            className="w-20 bg-[#121316] border border-[#2e313f] rounded px-2 py-1 text-xs text-amber-400 font-mono font-bold focus:border-amber-500 focus:outline-none"
                          />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-3 border-t border-[#262833]">
          {campaign?.isActive && (
            <button
              type="button"
              disabled={saving}
              onClick={handleRevertBaseline}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-red-950/60 hover:bg-red-900 border border-red-500/50 text-red-300 font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Cancel Campaign & Revert Baseline</span>
            </button>
          )}

          <button
            type="button"
            disabled={saving}
            onClick={handleLaunchCampaign}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 active:scale-95 text-black font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(245,158,11,0.4)] flex items-center justify-center gap-2 transition cursor-pointer"
          >
            <Zap className="w-4 h-4 fill-current" />
            <span>{saving ? 'Deploying...' : 'Launch Timed Campaign'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
