import React, { useState, useEffect, useRef } from 'react';
import { User, VIP_SPIN_PRIZES, VipPrize } from '../types';
import { Sparkles, Crown, Clock, X, Gift, AlertCircle } from 'lucide-react';
import { audioService } from '../services/audio';

interface VipSpinWheelProps {
  isOpen: boolean;
  user: User;
  onClose: () => void;
  onRewardClaimed: (updatedUser: Partial<User>) => void;
}

export const VipSpinWheel: React.FC<VipSpinWheelProps> = ({
  isOpen,
  user,
  onClose,
  onRewardClaimed
}) => {
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [rotationDegree, setRotationDegree] = useState<number>(0);
  const [wonPrize, setWonPrize] = useState<VipPrize | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<string>('');
  const [canSpin, setCanSpin] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Check 24-Hour cooldown
  useEffect(() => {
    const checkCooldown = () => {
      const lastSpin = user.lastVipSpinAt || 0;
      const cooldownMs = 24 * 60 * 60 * 1000;
      const nextSpinTime = lastSpin + cooldownMs;
      const diff = nextSpinTime - Date.now();

      if (diff <= 0 || !lastSpin) {
        setCanSpin(true);
        setTimeRemaining('');
      } else {
        setCanSpin(false);
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        setTimeRemaining(
          `${hours.toString().padStart(2, '0')}:${minutes
            .toString()
            .padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
        );
      }
    };

    checkCooldown();
    const interval = setInterval(checkCooldown, 1000);
    return () => clearInterval(interval);
  }, [user.lastVipSpinAt]);

  // Draw the Lucky Spin Wheel Canvas
  useEffect(() => {
    if (!isOpen) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = width / 2 - 18;

    ctx.clearRect(0, 0, width, height);

    const totalSegments = VIP_SPIN_PRIZES.length;
    const arcSize = (2 * Math.PI) / totalSegments;

    // Outer glow ring
    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius + 8, 0, 2 * Math.PI);
    ctx.lineWidth = 10;
    ctx.strokeStyle = '#eab308';
    ctx.shadowColor = '#eab308';
    ctx.shadowBlur = 18;
    ctx.stroke();
    ctx.restore();

    // Draw Wheel Segments
    VIP_SPIN_PRIZES.forEach((prize, idx) => {
      const startAngle = idx * arcSize;
      const endAngle = startAngle + arcSize;

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.closePath();

      // Alternate luxurious gradient tones
      const isEven = idx % 2 === 0;
      ctx.fillStyle = isEven ? '#1e1c14' : '#141416';
      ctx.fill();

      ctx.lineWidth = 2;
      ctx.strokeStyle = '#ca8a04';
      ctx.stroke();

      // Segment text and icon
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(startAngle + arcSize / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = prize.color;
      ctx.font = 'bold 13px "Outfit", sans-serif';
      ctx.shadowColor = prize.color;
      ctx.shadowBlur = 6;
      ctx.fillText(prize.label, radius - 24, 5);

      // Inner decorative pip
      ctx.beginPath();
      ctx.arc(radius - 10, 0, 3, 0, 2 * Math.PI);
      ctx.fillStyle = '#facc15';
      ctx.fill();

      ctx.restore();
      ctx.restore();
    });

    // Outer bulb lights
    const bulbCount = 24;
    for (let i = 0; i < bulbCount; i++) {
      const angle = (i * 2 * Math.PI) / bulbCount;
      const bx = centerX + (radius + 8) * Math.cos(angle);
      const by = centerY + (radius + 8) * Math.sin(angle);
      ctx.beginPath();
      ctx.arc(bx, by, 3, 0, 2 * Math.PI);
      ctx.fillStyle = i % 2 === 0 ? '#fef08a' : '#f59e0b';
      ctx.shadowColor = '#facc15';
      ctx.shadowBlur = 8;
      ctx.fill();
    }

    // Center golden hub
    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, 32, 0, 2 * Math.PI);
    const hubGrad = ctx.createRadialGradient(centerX - 6, centerY - 6, 2, centerX, centerY, 32);
    hubGrad.addColorStop(0, '#fef08a');
    hubGrad.addColorStop(0.5, '#eab308');
    hubGrad.addColorStop(1, '#854d0e');
    ctx.fillStyle = hubGrad;
    ctx.shadowColor = '#ca8a04';
    ctx.shadowBlur = 12;
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#ffffff';
    ctx.stroke();
    ctx.restore();

    // Center icon/text
    ctx.save();
    ctx.fillStyle = '#0f172a';
    ctx.font = 'bold 11px "Chakra Petch", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('VIP', centerX, centerY - 5);
    ctx.font = 'bold 9px "Chakra Petch", sans-serif';
    ctx.fillText('SPIN', centerX, centerY + 8);
    ctx.restore();
  }, [isOpen]);

  if (!isOpen) return null;

  const isVipEligible = (user.vipLevel || 0) >= 1;

  const handleSpinClick = async () => {
    if (isSpinning || !canSpin || !isVipEligible) return;
    setErrorMsg(null);
    setIsSpinning(true);

    try {
      audioService.playFlightStart();
      const res = await fetch('/api/vip/spin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user.id
        }
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        setIsSpinning(false);
        setErrorMsg(data.error || 'VIP Spin failed. Please try again later.');
        return;
      }

      const { prizeIndex, prize, newPromoWallet, nextSpinAt } = data;

      // Wheel segment calculation
      const totalSegments = VIP_SPIN_PRIZES.length;
      const segmentAngle = 360 / totalSegments;

      // In standard top pointer at 270 degrees:
      // Target segment angle center:
      // Pointer is fixed at 270 deg (top). To land on segment i:
      // (rotation + i * segmentAngle + segmentAngle / 2) % 360 = 270
      const extraSpins = 5 * 360; // 5 full rotations for drama
      const targetSegmentCenter = prizeIndex * segmentAngle + segmentAngle / 2;
      const finalDeg = extraSpins + (270 - targetSegmentCenter);

      setRotationDegree(finalDeg);

      // Play audio ticks during rotation
      let tickCount = 0;
      const tickInterval = setInterval(() => {
        if (tickCount++ < 16) {
          audioService.playTick();
        } else {
          clearInterval(tickInterval);
        }
      }, 200);

      // Stop after 4.2 seconds transition
      setTimeout(() => {
        setIsSpinning(false);
        setWonPrize(prize);
        audioService.playCashOut();
        onRewardClaimed({
          promoWallet: newPromoWallet,
          lastVipSpinAt: nextSpinAt - 24 * 60 * 60 * 1000
        });
      }, 4200);
    } catch (e: any) {
      setIsSpinning(false);
      setErrorMsg(e.message || 'Network connection failed.');
    }
  };

  return (
    <div
      id="vip-spin-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto"
    >
      <div
        id="vip-spin-container"
        className="relative w-full max-w-md max-w-[calc(100vw-20px)] max-h-[92vh] overflow-y-auto overflow-x-hidden bg-[#131418] border border-amber-500/40 rounded-2xl shadow-[0_0_50px_rgba(234,179,8,0.25)] flex flex-col items-center p-4 sm:p-6"
      >
        {/* Top Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3.5 right-3.5 w-8 h-8 rounded-full bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition cursor-pointer z-20"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex flex-col items-center text-center mb-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold uppercase tracking-wider mb-1.5 shadow-[0_0_12px_rgba(234,179,8,0.2)]">
            <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span>VIP Milestone Loyalty Wheel</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white font-['Chakra_Petch'] tracking-wide">
            LUCKY REWARD WHEEL
          </h2>
          <p className="text-xs text-neutral-400 max-w-xs">
            {isVipEligible
              ? `Unlocked for VIP Tier ${user.vipLevel || 1} Pilots • 1 Free Daily Spin`
              : 'Requires VIP Level ≥ 1 to unlock daily rewards. Deposit to advance your tier!'}
          </p>
        </div>

        {/* Ineligibility Warning if VIP 0 */}
        {!isVipEligible && (
          <div className="w-full bg-amber-950/40 border border-amber-500/40 rounded-xl p-3 mb-4 flex items-start gap-2.5 text-amber-200 text-xs">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-amber-300">VIP Level 1 Required</p>
              <p className="text-[11px] text-amber-200/80 mt-0.5">
                Complete your first ₹100 deposit to achieve VIP Tier 1 (Bronze) and unlock daily zero-risk milestone rewards.
              </p>
            </div>
          </div>
        )}

        {/* Spin Wheel Stage */}
        <div className="relative my-2 w-[280px] h-[280px] sm:w-[310px] sm:h-[310px] flex items-center justify-center">
          {/* Static Top Pointer Needle */}
          <div className="absolute -top-3 z-30 flex flex-col items-center">
            <div className="w-0 h-0 border-l-[14px] border-l-transparent border-r-[14px] border-r-transparent border-t-[24px] border-t-amber-400 filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]" />
            <div className="w-2.5 h-2.5 rounded-full bg-white -mt-5 shadow-[0_0_8px_rgba(255,255,255,0.9)]" />
          </div>

          {/* Rotating Wheel Container */}
          <div
            style={{
              transform: `rotate(${rotationDegree}deg)`,
              transition: isSpinning ? 'transform 4.2s cubic-bezier(0.12, 0.8, 0.22, 1)' : 'none'
            }}
            className="w-full h-full flex items-center justify-center"
          >
            <canvas
              ref={canvasRef}
              width={310}
              height={310}
              className="w-full h-full"
            />
          </div>
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="w-full mt-2 p-2.5 bg-rose-950/60 border border-rose-500/40 rounded-xl text-rose-300 text-xs text-center font-bold">
            {errorMsg}
          </div>
        )}

        {/* Bottom Action Area */}
        <div className="w-full mt-3 flex flex-col items-center gap-2">
          {isVipEligible ? (
            canSpin ? (
              <button
                id="vip-wheel-spin-btn"
                onClick={handleSpinClick}
                disabled={isSpinning}
                className={`w-full py-3 px-6 rounded-xl font-black text-sm font-['Chakra_Petch'] tracking-wider uppercase transition cursor-pointer flex items-center justify-center gap-2 shadow-lg ${
                  isSpinning
                    ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
                    : 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 shadow-[0_0_25px_rgba(234,179,8,0.4)] border border-yellow-200'
                }`}
              >
                <Sparkles className="w-4 h-4 text-neutral-950" />
                <span>{isSpinning ? 'Spinning Wheel...' : 'Spin For Free'}</span>
              </button>
            ) : (
              <div className="w-full py-2.5 px-4 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-neutral-400">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>Next Free VIP Spin:</span>
                </div>
                <span className="font-mono font-bold text-amber-300 text-sm">{timeRemaining}</span>
              </div>
            )
          ) : (
            <button
              onClick={onClose}
              className="w-full py-2.5 px-6 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs transition"
            >
              Deposit to Unlock VIP 1
            </button>
          )}

          <div className="text-[11px] text-neutral-400 flex items-center gap-1.5">
            <Gift className="w-3.5 h-3.5 text-amber-400" />
            <span>Guaranteed zero-liability low margin reward matrix</span>
          </div>
        </div>

        {/* Won Prize Celebration Modal Overlay */}
        {wonPrize && (
          <div className="absolute inset-0 z-40 bg-black/90 backdrop-blur-md rounded-2xl flex flex-col items-center justify-center p-6 text-center animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center shadow-[0_0_30px_rgba(234,179,8,0.5)] mb-3 animate-bounce">
              <Gift className="w-8 h-8 text-amber-300" />
            </div>

            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
              VIP Loyalty Reward
            </span>
            <h3 className="text-2xl font-black text-white font-['Chakra_Petch'] mt-1">
              CONGRATULATIONS!
            </h3>
            <p className="text-3xl font-black mt-2 font-['Chakra_Petch']" style={{ color: wonPrize.color }}>
              {wonPrize.label}
            </p>
            <p className="text-xs text-neutral-300 mt-1 max-w-xs">{wonPrize.description}</p>

            <button
              onClick={() => setWonPrize(null)}
              className="mt-5 py-2.5 px-8 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-neutral-950 font-black text-xs font-['Chakra_Petch'] uppercase tracking-wider hover:brightness-110 transition shadow-[0_0_20px_rgba(234,179,8,0.4)] cursor-pointer"
            >
              Claim & Close
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
