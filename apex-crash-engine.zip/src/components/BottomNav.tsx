import React from 'react';
import { Gamepad2, Wallet, Users, Headphones, Crown, User as UserIcon, ShieldCheck } from 'lucide-react';
import { User, getVipConfig } from '../types';

export type BottomNavTab = 'lobby' | 'vip' | 'wallet' | 'invite' | 'profile' | 'support';

interface BottomNavProps {
  currentTab?: BottomNavTab;
  activeTab?: BottomNavTab;
  onSelectTab?: (tab: BottomNavTab) => void;
  onTabChange?: (tab: BottomNavTab) => void;
  user?: User | null;
  onOpenCashier?: (tab: 'deposit' | 'withdraw') => void;
  onOpenReferrals?: () => void;
  onOpenSupport?: () => void;
  onOpenProfile?: () => void;
  onOpenVip?: () => void;
  onOpenAdmin?: () => void;
  isSuperAdmin?: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab: propCurrentTab,
  activeTab: propActiveTab,
  onSelectTab,
  onTabChange,
  user,
  onOpenCashier,
  onOpenReferrals,
  onOpenSupport,
  onOpenProfile,
  onOpenVip,
  onOpenAdmin,
  isSuperAdmin
}) => {
  const currentTab = propCurrentTab || propActiveTab || 'lobby';
  const handleSelect = onSelectTab || onTabChange || (() => {});
  const userVip = getVipConfig(user?.lifetimeDeposit || 0);

  const handleTabClick = (tab: BottomNavTab) => {
    handleSelect(tab);
    if (tab === 'vip' && onOpenVip) {
      onOpenVip();
    } else if (tab === 'wallet' && onOpenCashier) {
      onOpenCashier('deposit');
    } else if (tab === 'invite' && onOpenReferrals) {
      onOpenReferrals();
    } else if (tab === 'profile' && onOpenProfile) {
      onOpenProfile();
    } else if (tab === 'support' && onOpenSupport) {
      onOpenSupport();
    }
  };

  return (
    <nav
      id="persistent-bottom-nav"
      className="fixed bottom-0 left-0 right-0 w-full max-w-full overflow-hidden z-[999] bg-[#1b1c1d]/90 backdrop-blur-md border-t border-[#2a2c35]/80 px-1.5 sm:px-2 py-1.5 shadow-[0_-8px_25px_rgba(0,0,0,0.6)] select-none safe-area-bottom"
    >
      <div className="max-w-lg w-full mx-auto grid grid-cols-5 sm:grid-cols-6 gap-1 items-center">
        {/* Tab 1: Lobby */}
        <button
          id="bottom-nav-lobby"
          type="button"
          onClick={() => handleTabClick('lobby')}
          className={`flex flex-col items-center justify-center py-1 px-1 sm:px-2 rounded-xl transition-all duration-200 cursor-pointer group ${
            currentTab === 'lobby'
              ? 'text-rose-500 scale-105'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#25272b]'
          }`}
        >
          <div className="relative">
            <Gamepad2
              className={`w-5 h-5 transition-transform duration-200 group-hover:-translate-y-0.5 ${
                currentTab === 'lobby' ? 'text-rose-500 stroke-[2.5]' : 'text-neutral-400'
              }`}
            />
            {currentTab === 'lobby' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-rose-500 shadow-[0_0_8px_#f43f5e]" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] font-bold tracking-tight mt-1 font-['Chakra_Petch']">
            Lobby
          </span>
        </button>

        {/* Tab 2: VIP Club & Lucky Spin */}
        <button
          id="bottom-nav-vip"
          type="button"
          onClick={() => handleTabClick('vip')}
          className={`flex flex-col items-center justify-center py-1 px-1 sm:px-2 rounded-xl transition-all duration-200 cursor-pointer relative group ${
            currentTab === 'vip'
              ? 'text-purple-400 scale-105'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#25272b]'
          }`}
        >
          <div className="relative">
            <Crown
              className={`w-5 h-5 transition-transform duration-200 group-hover:-translate-y-0.5 ${
                currentTab === 'vip' ? 'text-purple-400 stroke-[2.5]' : 'text-neutral-400'
              }`}
            />
            {/* VIP Level Badge */}
            <span className="absolute -top-1.5 -right-3 text-[8px] sm:text-[9px] font-mono font-black px-1 rounded-sm bg-gradient-to-r from-purple-500 to-amber-400 text-black shadow-sm">
              {userVip.label}
            </span>
            {currentTab === 'vip' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-purple-400 shadow-[0_0_8px_#c084fc]" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] font-bold tracking-tight mt-1 font-['Chakra_Petch']">
            VIP Club
          </span>
        </button>

        {/* Tab 3: Wallet */}
        <button
          id="bottom-nav-wallet"
          type="button"
          onClick={() => handleTabClick('wallet')}
          className={`flex flex-col items-center justify-center py-1 px-1 sm:px-2 rounded-xl transition-all duration-200 cursor-pointer relative group ${
            currentTab === 'wallet'
              ? 'text-amber-400 scale-105'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#25272b]'
          }`}
        >
          <div className="relative">
            <Wallet
              className={`w-5 h-5 transition-transform duration-200 group-hover:-translate-y-0.5 ${
                currentTab === 'wallet' ? 'text-amber-400 stroke-[2.5]' : 'text-neutral-400'
              }`}
            />
            {currentTab === 'wallet' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-amber-400 shadow-[0_0_8px_#fbbf24]" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] font-bold tracking-tight mt-1 font-['Chakra_Petch']">
            Wallet
          </span>
        </button>

        {/* Tab 4: Invite & Earn */}
        <button
          id="bottom-nav-invite"
          type="button"
          onClick={() => handleTabClick('invite')}
          className={`flex flex-col items-center justify-center py-1 px-1 sm:px-2 rounded-xl transition-all duration-200 cursor-pointer group ${
            currentTab === 'invite'
              ? 'text-emerald-400 scale-105'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#25272b]'
          }`}
        >
          <div className="relative">
            <Users
              className={`w-5 h-5 transition-transform duration-200 group-hover:-translate-y-0.5 ${
                currentTab === 'invite' ? 'text-emerald-400 stroke-[2.5]' : 'text-neutral-400'
              }`}
            />
            <span className="absolute -top-1 -right-2 text-[8px] font-bold px-1 rounded-full bg-emerald-500 text-black animate-pulse">
              +0.02%
            </span>
            {currentTab === 'invite' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] font-bold tracking-tight mt-1 font-['Chakra_Petch']">
            Invite
          </span>
        </button>

        {/* Tab 5: Profile Dashboard */}
        <button
          id="bottom-nav-profile"
          type="button"
          onClick={() => handleTabClick('profile')}
          className={`flex flex-col items-center justify-center py-1 px-1 sm:px-2 rounded-xl transition-all duration-200 cursor-pointer group ${
            currentTab === 'profile'
              ? 'text-cyan-400 scale-105'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#25272b]'
          }`}
        >
          <div className="relative">
            <UserIcon
              className={`w-5 h-5 transition-transform duration-200 group-hover:-translate-y-0.5 ${
                currentTab === 'profile' ? 'text-cyan-400 stroke-[2.5]' : 'text-neutral-400'
              }`}
            />
            {user && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-[#1b1c1d]" />
            )}
            {currentTab === 'profile' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] font-bold tracking-tight mt-1 font-['Chakra_Petch']">
            Profile
          </span>
        </button>

        {/* Tab 6 (Optional / Super Admin): Controller shortcut */}
        {isSuperAdmin && onOpenAdmin && (
          <button
            id="bottom-nav-admin"
            type="button"
            onClick={onOpenAdmin}
            className="hidden sm:flex flex-col items-center justify-center py-1 px-2 rounded-xl text-red-400 hover:text-red-300 hover:bg-red-950/40 transition-all cursor-pointer"
            title="Super Admin Controller"
          >
            <ShieldCheck className="w-5 h-5 text-red-500" />
            <span className="text-[10px] sm:text-[11px] font-bold tracking-tight mt-1 font-['Chakra_Petch']">
              Admin
            </span>
          </button>
        )}
      </div>
    </nav>
  );
};
