import React from 'react';
import { HelpCircle, X, ShieldCheck, Zap, Percent, Gift } from 'lucide-react';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div id="rules-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md">
      <div
        id="rules-modal-container"
        className="w-full max-w-lg max-w-[calc(100vw-20px)] bg-[#18191d] border border-[#2d303b] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="flex items-center justify-between px-5 py-3.5 bg-[#141518] border-b border-[#262830]">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-rose-500" />
            <h2 className="text-base font-bold text-white font-['Chakra_Petch']">
              HOW TO PLAY & SYSTEM RULES
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-[#202229] hover:bg-[#2c2f38] text-neutral-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-4 text-xs text-neutral-300">
          <div className="bg-[#121316] border border-[#282a33] p-3.5 rounded-xl space-y-2">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Crash Flight Mechanics (2.7s Progression Rule)</span>
            </h3>
            <p>
              Place your bet during the 5-second countdown. Once airborne, the multiplier ascends smoothly according to the server-side piecewise mathematical engine:
            </p>
            <ul className="list-disc list-inside space-y-1 text-neutral-400 pl-1 font-mono text-[11px]">
              <li><strong>Phase 1 (0.0s to 2.7s):</strong> Linear progression reaching exactly 2.00x at 2.7s: M(t) = 1.00 + t × (1.00 / 2.7)</li>
              <li><strong>Phase 2 (Post 2.7s):</strong> Explosive exponential velocity: M(t) = 2.00 + 0.15 × (t - 2.7)^1.5</li>
            </ul>
            <p className="text-amber-300">
              Cash out anytime before the flyer crashes to secure your winnings (Stake × Multiplier)!
            </p>
          </div>

          <div className="bg-[#121316] border border-[#282a33] p-3.5 rounded-xl space-y-2">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Gift className="w-4 h-4 text-rose-400" />
              <span>Two-Tier Referral & 0.02% Lifetime Rebate</span>
            </h3>
            <ul className="list-disc list-inside space-y-1 text-neutral-400 pl-1">
              <li><strong>₹20 Instant Bounty:</strong> Credited to your promotional wallet when your referred friend completes their first valid manual deposit.</li>
              <li><strong>0.02% Lifetime Betting Rebate:</strong> For every single bet placed by your referred friend, 0.02% of the total stake is credited to your wallet in real-time.</li>
            </ul>
          </div>

          <div className="bg-[#121316] border border-[#282a33] p-3.5 rounded-xl space-y-2">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Zero-Leakage Anti-Fraud Policy</span>
            </h3>
            <p className="text-neutral-400">
              To guarantee zero financial leakage, device fingerprints and IP records are cross-checked. Duplicate accounts or fake self-referral attempts trigger an instant lock across both profiles.
            </p>
            <p className="text-neutral-400">
              Welcome bonus credits require standard 1.5x wagering turnover before shifting to withdrawable cash.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
