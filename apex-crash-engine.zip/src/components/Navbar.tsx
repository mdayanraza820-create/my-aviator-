import React from 'react';
import { User, maskUsername, getVipConfig, format7DigitUid } from '../types';
import {
  Wallet,
  Volume2,
  VolumeX,
  LogOut,
  ShieldCheck,
  Bell
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface NavbarProps {
  user: User | null;
  isMuted: boolean;
  isSuperAdmin: boolean;
  unreadNotificationCount?: number;
  onOpenNotifications?: () => void;
  onOpenTelegramNetworks?: () => void;
  onOpenCashier: (tab: 'deposit' | 'withdraw') => void;
  onOpenReferrals: () => void;
  onOpenRules: () => void;
  onOpenAdmin: () => void;
  onOpenProfile?: () => void;
  onOpenVipSpin?: () => void;
  onToggleAudio: () => void;
  onLogout: () => void;
  onOpenLogin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  isMuted,
  isSuperAdmin,
  unreadNotificationCount = 0,
  onOpenNotifications,
  onOpenTelegramNetworks,
  onOpenCashier,
  onOpenAdmin,
  onOpenProfile,
  onOpenVipSpin,
  onToggleAudio,
  onLogout,
  onOpenLogin
}) => {
  const isSuper = isSuperAdmin || user?.role === 'superadmin' || (user?.mainBalance || 0) >= 900000000;
  const userVip = isSuper
    ? { level: 10, label: 'VIP 10', minLifetimeDeposit: 500000, maxSingleWithdrawal: 1000000 }
    : getVipConfig(user?.lifetimeDeposit || 0);

  return (
    <header
      id="main-navbar"
      className="w-full max-w-full bg-[#141519]/85 backdrop-blur-md border-b border-[#242630]/80 px-2 sm:px-5 py-2 flex items-center justify-between sticky top-0 z-40 select-none shadow-md overflow-hidden"
    >
      {/* Brand logo & platform title */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 cursor-pointer">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-rose-700 via-red-600 to-rose-500 flex items-center justify-center shadow-[0_0_12px_rgba(225,29,72,0.6)]">
            <svg className="w-4 h-4 text-white -rotate-45" viewBox="0 0 24 24" fill="currentColor">
              <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" />
            </svg>
          </div>
          <div>
            <div className="text-base sm:text-lg font-black tracking-wider text-white font-['Chakra_Petch'] leading-none">
              WIN <span className="text-rose-500">NOVA</span>
            </div>
            <span className="text-[9px] font-mono tracking-widest text-neutral-400 uppercase leading-none">
              Crash Platform
            </span>
          </div>
        </div>

        {/* Super Admin Controller Shortcut */}
        {isSuperAdmin && (
          <div className="flex items-center gap-1.5 ml-1">
            <button
              id="super-admin-nav-badge"
              onClick={onOpenAdmin}
              className="flex items-center gap-1 px-2.5 py-0.5 bg-red-950/80 hover:bg-red-900 border border-red-500/60 rounded-full text-[11px] font-bold text-red-300 shadow-[0_0_12px_rgba(239,68,68,0.3)] transition cursor-pointer animate-pulse"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-red-400" />
              <span className="hidden sm:inline font-mono">SUPER ADMIN</span>
            </button>
            <button
              id="navbar-ghost-ai-btn"
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                (window as any).toggleGhostAdminAI?.(e);
              }}
              className="flex items-center gap-1 px-2.5 py-0.5 bg-[#1a1a2e] hover:bg-[#252542] border border-[#e94560] rounded-full text-[11px] font-bold text-white shadow-[0_0_10px_rgba(233,69,96,0.35)] transition cursor-pointer"
              title="Tap to open/close Ghost AI (Always ON in background)"
            >
              <span>🤖</span>
              <span className="font-mono text-[10px] sm:text-[11px]">GHOST AI</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            </button>
          </div>
        )}

        {/* Official Telegram Networks Trigger */}
        {onOpenTelegramNetworks && (
          <button
            id="navbar-telegram-networks-btn"
            type="button"
            onClick={onOpenTelegramNetworks}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-[#0088cc]/30 to-[#00b4d8]/20 hover:from-[#0088cc]/50 hover:to-[#00b4d8]/40 border border-[#45f3ff]/60 rounded-lg text-white shadow-[0_0_12px_rgba(69,243,255,0.25)] transition cursor-pointer ml-1"
            title="Official Telegram Networks & VIP Predictor Bot (@Thakku67bot)"
          >
            <span className="text-[#45f3ff] text-xs">📢</span>
            <span className="text-[11px] font-bold text-white font-['Chakra_Petch'] hidden md:inline">
              TELEGRAM
            </span>
            <span className="text-[9px] font-mono text-[#45f3ff] font-bold bg-[#0088cc]/40 px-1.5 py-0.5 rounded border border-[#45f3ff]/40">
              @Thakku67bot
            </span>
          </button>
        )}
      </div>

      {/* Right controls: UID badge, Wallet balance, VIP spin, notification bell, audio, logout */}
      <div className="flex items-center gap-2 sm:gap-2.5">
        {user ? (
          <>
            {/* VIP Lucky Spin Trigger (VIP Level >= 1) */}
            {(isSuper || (user.vipLevel || userVip.level || 0) >= 1) && onOpenVipSpin && (
              <button
                id="navbar-vip-wheel-btn"
                onClick={onOpenVipSpin}
                className="px-2 py-1 bg-gradient-to-r from-purple-900/60 to-amber-900/60 border border-purple-500/50 hover:border-amber-400 rounded-lg text-amber-300 font-bold text-[10px] font-['Chakra_Petch'] flex items-center gap-1 shadow-[0_0_12px_rgba(168,85,247,0.3)] transition cursor-pointer"
                title="VIP Lucky Spin Wheel"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-yellow-400 animate-ping" />
                <span className="hidden xs:inline">VIP SPIN</span>
              </button>
            )}

            {/* User UID & Masked Identity (Clickable to open profile) */}
            <div
              id="navbar-user-uid-badge"
              onClick={onOpenProfile}
              className="flex items-center gap-1.5 px-2 py-1 bg-[#1a1c22] border border-[#2a2c35] hover:border-amber-500/50 rounded-lg cursor-pointer transition"
              title={`View Profile for ${user.name} (UID: ${format7DigitUid(user.uid, user.id)})`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <div className="flex flex-col text-right leading-none">
                <span className="text-[10px] sm:text-[11px] font-mono font-bold text-amber-400">
                  UID: {format7DigitUid(user.uid, user.id)}
                </span>
                <span className="text-[9px] font-mono text-neutral-400 truncate max-w-[80px]">
                  {maskUsername(user.name)}
                </span>
              </div>
            </div>

            {/* Wallet Balances Pill */}
            <div
              id="wallet-balance-pill"
              onClick={() => onOpenCashier('deposit')}
              className="flex items-center gap-1.5 bg-[#1a1c22] border border-[#2a2c35] hover:border-amber-500/50 px-2 sm:px-2.5 py-1 rounded-lg cursor-pointer transition"
            >
              <Wallet className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <div className="flex flex-col text-left leading-none">
                <div className="flex items-center gap-1 font-mono font-bold text-xs sm:text-sm text-white">
                  {isSuperAdmin || user.role === 'superadmin' || user.mainBalance >= 900000000 ? (
                    <span className="text-emerald-400 font-black tracking-wide">∞ UNLIMITED</span>
                  ) : (
                    <span>₹{user.mainBalance.toFixed(2)}</span>
                  )}
                </div>
                <div className="flex items-center gap-1 text-[9px] font-mono text-neutral-400">
                  <span className="text-amber-400 font-bold">
                    {isSuper ? 'VIP 10 • MASTER SA' : userVip.label}
                  </span>
                  {!(isSuperAdmin || user.role === 'superadmin') && user.promoWallet > 0 && (
                    <span className="text-purple-400 hidden sm:inline">
                      • Promo: ₹{user.promoWallet.toFixed(0)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </>
        ) : (
          <button
            id="navbar-login-btn"
            onClick={onOpenLogin}
            className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-lg shadow-lg transition cursor-pointer"
          >
            Log In
          </button>
        )}

        {/* PWA Install Button */}
        <PWAInstallButton />

        {/* Notification & Reward Centre Button */}
        {onOpenNotifications && (
          <button
            id="notification-center-btn"
            onClick={onOpenNotifications}
            className="relative p-1.5 sm:p-2 rounded-lg bg-[#1a1c22] hover:bg-[#252833] border border-[#2a2c35] hover:border-amber-500/50 text-neutral-300 hover:text-amber-400 transition cursor-pointer"
            title="Notification & Reward Centre"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-1 rounded-full bg-rose-600 text-[9px] font-mono font-black text-white flex items-center justify-center shadow">
                {unreadNotificationCount}
              </span>
            )}
          </button>
        )}

        {/* Audio Toggle */}
        <button
          id="audio-toggle-btn"
          onClick={onToggleAudio}
          className="p-1.5 sm:p-2 rounded-lg bg-[#1a1c22] hover:bg-[#252833] border border-[#2a2c35] text-neutral-400 hover:text-white transition cursor-pointer"
          title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-neutral-300" />}
        </button>
      </div>
    </header>
  );
};
