import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  initializeFirestore,
  doc,
  getDoc,
  collection,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  setDoc,
  addDoc,
  updateDoc,
  runTransaction,
  getDocs,
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { getFunctions, httpsCallable } from 'firebase/functions';
import firebaseConfig from '../firebase-applet-config.json';
import { 
  UpiAccount,
  VolumetricTierConfig,
  VolumetricProgressionResult,
  UserWalletDoc,
  WalletTransactionDoc,
  VOLUMETRIC_TIER_MATRIX,
  calculateVolumetricProgression
} from './types';

export type {
  VolumetricTierConfig,
  VolumetricProgressionResult,
  UserWalletDoc,
  WalletTransactionDoc
};
export {
  VOLUMETRIC_TIER_MATRIX,
  calculateVolumetricProgression
};

const existingApps = getApps();
export const app = (!existingApps || existingApps.length === 0)
  ? initializeApp(firebaseConfig)
  : getApp();

/* CRITICAL: The app will break without specifying firestoreDatabaseId */
export const db = (() => {
  try {
    return firebaseConfig.firestoreDatabaseId
      ? initializeFirestore(app, {
          experimentalForceLongPolling: true,
          ignoreUndefinedProperties: true
        }, firebaseConfig.firestoreDatabaseId)
      : initializeFirestore(app, {
          experimentalForceLongPolling: true,
          ignoreUndefinedProperties: true
        });
  } catch {
    return firebaseConfig.firestoreDatabaseId
      ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
      : getFirestore(app);
  }
})();

export const auth = getAuth(app);
export const functions = getFunctions(app);
export const googleProvider = new GoogleAuthProvider();
export { onAuthStateChanged, doc, onSnapshot };

export async function loginWithGoogle(): Promise<FirebaseUser> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

export async function logoutFirebase(): Promise<void> {
  await signOut(auth);
}

// ==========================================
// ERROR HANDLING (MANDATORY FIRESTORE SPEC)
// ==========================================
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// ==========================================
// CONNECTION TEST (BOOTSTRAP VALIDATION)
// ==========================================
export async function testConnection() {
  try {
    const testPromise = getDoc(doc(db, 'test', 'connection'));
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Connection check timeout')), 2500)
    );
    await Promise.race([testPromise, timeoutPromise]);
  } catch {
    // Client operates gracefully with local persistence and offline cache
  }
}

// Run connection validation
if (typeof window !== 'undefined') {
  testConnection();
}

// ==========================================
// TYPES FOR SCHEMA PROVISIONING
// ==========================================
export interface FirestoreUserDoc {
  balance: number;
  email: string;
  role: 'player' | 'admin' | 'super_admin';
  name?: string;
  phone?: string;
  promoWallet?: number;
  vipPoints?: number;
  vipTier?: string;
  cumulativeVolume?: number;
  percentageProgress?: number;
  nextTierDelta?: number;
  totalLifetimeDeposits?: number;
  totalLifetimeWithdrawals?: number;
  referralCode?: string;
  referredBy?: string;
  referralCount?: number;
  totalReferralBonus?: number;
  isFrozen?: boolean;
  currentSessionId?: string;
  createdAt: any;
}

export interface FirestoreBetDoc {
  userId: string;
  gameId: string;
  betAmount: number;
  autoCashoutMultiplier?: number;
  cashoutMultiplier: number;
  winAmount: number;
  status: 'placed' | 'cashed_out' | 'busted';
  timestamp: any;
}

export interface FirestoreGameHistoryDoc {
  crashMultiplier: number;
  totalBets: number;
  totalPayout: number;
  startedAt: any;
  endedAt: any;
}

export interface FirestoreBalanceHistoryDoc {
  userId: string;
  type: 'deposit' | 'withdrawal' | 'bet_placed' | 'bet_won' | 'admin_adjustment';
  amount: number;
  previousBalance: number;
  newBalance: number;
  timestamp: any;
}

export interface FirestoreAdminLogDoc {
  adminId: string;
  action: string;
  targetUserId?: string;
  details?: Record<string, any>;
  timestamp: any;
}

export interface FirestoreGameControlDoc {
  currentMultiplier: number;
  status: 'waiting' | 'flying' | 'crashed' | 'ended';
  crashMultiplier?: number;
  finalMultiplier?: number;
  rtpConfig?: number;
  roundId?: string;
  roundName?: string;
  roundNumber?: number;
}

// ==========================================
// REAL-TIME LISTENERS & CLIENT HELPERS
// ==========================================

// Singleton multiplexer state for game_control/current_game to prevent duplicate listeners
const gameControlSubscribers = new Set<(data: FirestoreGameControlDoc) => void>();
let gameControlUnsubscribe: (() => void) | null = null;
let lastGameControlHash = '';

/**
 * Subscribe to real-time game engine synchronization using a single shared Firestore listener
 */
export function subscribeToGameControl(
  onUpdate: (data: FirestoreGameControlDoc) => void,
  onError?: (err: any) => void
) {
  gameControlSubscribers.add(onUpdate);

  if (!gameControlUnsubscribe) {
    const controlRef = doc(db, 'game_control', 'current_game');
    gameControlUnsubscribe = onSnapshot(
      controlRef,
      (snap) => {
        if (!snap.exists()) return;
        const data = snap.data() as FirestoreGameControlDoc;
        const hash = `${data.roundId || ''}:${data.status}:${data.crashMultiplier ?? data.finalMultiplier ?? data.currentMultiplier ?? 1}`;
        if (hash === lastGameControlHash) return;
        lastGameControlHash = hash;
        gameControlSubscribers.forEach((cb) => cb(data));
      },
      (error) => {
        if (onError) {
          onError(error);
          return;
        }
        try {
          handleFirestoreError(error, OperationType.GET, 'game_control/current_game');
        } catch (err) {
          console.warn('[subscribeToGameControl] Listener notice:', err);
        }
      }
    );
  }

  return () => {
    gameControlSubscribers.delete(onUpdate);
    if (gameControlSubscribers.size === 0 && gameControlUnsubscribe) {
      gameControlUnsubscribe();
      gameControlUnsubscribe = null;
      lastGameControlHash = '';
    }
  };
}

/**
 * Subscribe to recent game history (crash multipliers ticker)
 */
export function subscribeToGameHistory(
  maxCount = 20,
  onUpdate: (history: (FirestoreGameHistoryDoc & { id: string })[]) => void,
  onError?: (err: any) => void
) {
  const path = 'game_history';
  const historyQuery = query(collection(db, 'game_history'), limit(maxCount));
  return onSnapshot(
    historyQuery,
    (snap) => {
      const items: (FirestoreGameHistoryDoc & { id: string })[] = [];
      snap.forEach((d) => {
        items.push({ id: d.id, ...(d.data() as FirestoreGameHistoryDoc) });
      });
      onUpdate(items);
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

/**
 * Subscribe to player's active and past bets in real-time
 */
export function subscribeToUserBets(
  userId: string,
  onUpdate: (bets: (FirestoreBetDoc & { id: string })[]) => void,
  onError?: (err: any) => void
) {
  if (!userId) return () => {};
  const path = 'bets';
  const betsQuery = query(collection(db, 'bets'), where('userId', '==', userId), limit(50));
  return onSnapshot(
    betsQuery,
    (snap) => {
      const bets: (FirestoreBetDoc & { id: string })[] = [];
      snap.forEach((d) => {
        bets.push({ id: d.id, ...(d.data() as FirestoreBetDoc) });
      });
      onUpdate(bets);
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

const lastSyncedUserSignature = new Map<string, string>();

/**
 * Sync user profile to Firestore (only executes if authenticated in Firebase and payload changed)
 * CRITICAL GUARDRAIL: Players are NEVER allowed to update their balances directly from the frontend.
 */
export async function syncUserToFirestore(userId: string, userData: Partial<FirestoreUserDoc>) {
  if (!auth.currentUser) return;

  const currentUid = auth.currentUser.uid;
  const isAuthorizedAdmin =
    auth.currentUser.email === 'mdfaisalraza7777@gmail.com' ||
    auth.currentUser.email === 'mdfaisalraza9771@gmail.com';
  const targetId = (isAuthorizedAdmin || userId === currentUid) ? userId : currentUid;

  const sanitizedData = { ...userData };
  if (!isAuthorizedAdmin) {
    delete sanitizedData.balance;
    delete sanitizedData.promoWallet;
  }

  // Deduplicate redundant writes to prevent listener loops
  const signature = JSON.stringify({ targetId, ...sanitizedData });
  if (lastSyncedUserSignature.get(targetId) === signature) {
    return;
  }
  lastSyncedUserSignature.set(targetId, signature);

  const path = `users/${targetId}`;
  try {
    const userRef = doc(db, 'users', targetId);
    if (isAuthorizedAdmin) {
      await setDoc(
        userRef,
        {
          ...sanitizedData,
          createdAt: sanitizedData.createdAt || serverTimestamp(),
        },
        { merge: true }
      );
    } else {
      const existingSnap = await getDoc(userRef);
      if (!existingSnap.exists()) {
        await setDoc(userRef, {
          balance: 0,
          email: auth.currentUser.email || sanitizedData.email || `${targetId}@winnova.play`,
          role: 'player',
          name: sanitizedData.name || auth.currentUser.displayName || 'Player',
          phone: sanitizedData.phone || '',
          createdAt: serverTimestamp()
        });
      } else {
        const updatePayload: Record<string, any> = {
          lastLoginAt: serverTimestamp()
        };
        if (typeof sanitizedData.name === 'string') updatePayload.name = sanitizedData.name;
        if (typeof sanitizedData.phone === 'string') updatePayload.phone = sanitizedData.phone;
        await setDoc(userRef, updatePayload, { merge: true });
      }
    }
  } catch (error) {
    lastSyncedUserSignature.delete(targetId);
    console.warn('[syncUserToFirestore] Sync deferred:', error);
  }
}

/**
 * SECURE BACKEND TRANSACTION: placeBet(betAmount, autoCashoutMultiplier)
 */
export async function callPlaceBetFunction(params: {
  betAmount: number;
  autoCashoutMultiplier?: number;
  gameId?: string;
}): Promise<{ success: boolean; betId: string; newBalance: number; status: string }> {
  try {
    const placeBetCallable = httpsCallable(functions, 'placeBet');
    const result = await placeBetCallable(params);
    return result.data as { success: boolean; betId: string; newBalance: number; status: string };
  } catch (cfErr: any) {
    const idToken = auth.currentUser ? await auth.currentUser.getIdToken().catch(() => null) : null;
    const res = await fetch('/api/functions/placeBet', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(idToken ? { 'Authorization': `Bearer ${idToken}` } : {})
      },
      body: JSON.stringify({
        userId: auth.currentUser?.uid,
        ...params
      })
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || data.error || cfErr?.message || 'Failed to place bet transaction');
    }
    return data;
  }
}

/**
 * SECURE BACKEND TRANSACTION: cashOut(betId, exactMultiplierAtCashout)
 */
export async function callCashOutFunction(params: {
  betId: string;
  exactMultiplierAtCashout: number;
}): Promise<{
  success: boolean;
  betId: string;
  winAmount: number;
  newBalance: number;
  cashoutMultiplier: number;
  status: string;
}> {
  try {
    const cashOutCallable = httpsCallable(functions, 'cashOut');
    const result = await cashOutCallable(params);
    return result.data as {
      success: boolean;
      betId: string;
      winAmount: number;
      newBalance: number;
      cashoutMultiplier: number;
      status: string;
    };
  } catch (cfErr: any) {
    const idToken = auth.currentUser ? await auth.currentUser.getIdToken().catch(() => null) : null;
    const res = await fetch('/api/functions/cashOut', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(idToken ? { 'Authorization': `Bearer ${idToken}` } : {})
      },
      body: JSON.stringify({
        userId: auth.currentUser?.uid,
        ...params
      })
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.message || data.error || cfErr?.message || 'Failed to cash out transaction');
    }
    return data;
  }
}

// ==========================================
// SINGLE SESSION TRACKING (FIREBASE & FIRESTORE)
// ==========================================

const TAB_SESSION_KEY = 'apex_tab_session_id';
let memoryTabSessionId: string | null = null;

/**
 * Returns or generates a unique session ID for the current browser tab.
 */
export function getTabSessionId(): string {
  if (typeof window === 'undefined') return 'server_session';
  if (memoryTabSessionId) {
    try {
      if (!sessionStorage.getItem(TAB_SESSION_KEY)) {
        sessionStorage.setItem(TAB_SESSION_KEY, memoryTabSessionId);
      }
    } catch {}
    return memoryTabSessionId;
  }
  let sId: string | null = null;
  try {
    sId = sessionStorage.getItem(TAB_SESSION_KEY);
  } catch {}
  if (!sId) {
    sId = `sess_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    try {
      sessionStorage.setItem(TAB_SESSION_KEY, sId);
    } catch {}
  }
  memoryTabSessionId = sId;
  return sId;
}

/**
 * Forces regeneration of a brand-new unique session ID for this browser tab.
 */
export function generateNewTabSessionId(): string {
  if (typeof window === 'undefined') return 'server_session';
  const sId = `sess_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  memoryTabSessionId = sId;
  try {
    sessionStorage.setItem(TAB_SESSION_KEY, sId);
  } catch {}
  return sId;
}

const lastSyncedSessionMap = new Map<string, string>();

/**
 * Overwrites currentSessionId in users/{userId} Firestore document with deduplication.
 */
export async function updateUserSessionInFirestore(userId: string, sessionId: string): Promise<boolean> {
  if (!auth.currentUser) return false;

  const currentUid = auth.currentUser.uid;
  const isAuthorizedAdmin =
    auth.currentUser.email === 'mdfaisalraza7777@gmail.com' ||
    auth.currentUser.email === 'mdfaisalraza9771@gmail.com';
  const targetId = (isAuthorizedAdmin || userId === currentUid) ? userId : currentUid;

  if (lastSyncedSessionMap.get(targetId) === sessionId) {
    return true;
  }
  lastSyncedSessionMap.set(targetId, sessionId);

  const path = `users/${targetId}`;
  try {
    const userRef = doc(db, 'users', targetId);
    await setDoc(userRef, { currentSessionId: sessionId }, { merge: true });
    return true;
  } catch (error) {
    lastSyncedSessionMap.delete(targetId);
    console.warn(`[FIRESTORE SESSION] Failed to write currentSessionId to ${path}:`, error);
    return false;
  }
}

/**
 * Subscribes in real-time to the user's Firestore document to detect multi-tab session takeover.
 */
export function subscribeToUserSession(
  userId: string,
  onSessionChange: (activeSessionId: string | null) => void
): () => void {
  if (!auth.currentUser) {
    return () => {};
  }
  const currentUid = auth.currentUser.uid;
  const isAuthorizedAdmin =
    auth.currentUser.email === 'mdfaisalraza7777@gmail.com' ||
    auth.currentUser.email === 'mdfaisalraza9771@gmail.com';
  const targetId = (isAuthorizedAdmin || userId === currentUid) ? userId : currentUid;

  const path = `users/${targetId}`;
  let lastSessionId: string | null | undefined = undefined;
  try {
    const userRef = doc(db, 'users', targetId);
    return onSnapshot(userRef, (snapshot) => {
      const nextSessionId = snapshot.exists()
        ? ((snapshot.data() as FirestoreUserDoc).currentSessionId || null)
        : null;
      if (nextSessionId !== lastSessionId) {
        lastSessionId = nextSessionId;
        onSessionChange(nextSessionId);
      }
    }, (error) => {
      console.warn(`[FIRESTORE SESSION LISTENER] Error on ${path}:`, error);
    });
  } catch (error) {
    console.warn(`[FIRESTORE SESSION] Listener setup failed for ${path}:`, error);
    return () => {};
  }
}

/**
 * Direct check: Verifies if the client's current session ID matches the active currentSessionId in Firestore.
 */
export async function verifySessionInFirestore(
  userId: string,
  clientSessionId: string
): Promise<{ valid: boolean; activeSessionId: string | null }> {
  if (!auth.currentUser) {
    return { valid: true, activeSessionId: clientSessionId };
  }
  const currentUid = auth.currentUser.uid;
  const isAuthorizedAdmin =
    auth.currentUser.email === 'mdfaisalraza7777@gmail.com' ||
    auth.currentUser.email === 'mdfaisalraza9771@gmail.com';
  const targetId = (isAuthorizedAdmin || userId === currentUid) ? userId : currentUid;

  const path = `users/${targetId}`;
  try {
    const userRef = doc(db, 'users', targetId);
    const snap = await getDoc(userRef);
    if (!snap.exists()) {
      await setDoc(userRef, { currentSessionId: clientSessionId }, { merge: true });
      return { valid: true, activeSessionId: clientSessionId };
    }
    const data = snap.data() as FirestoreUserDoc;
    const activeSessionId = data.currentSessionId || null;
    if (!activeSessionId) {
      await setDoc(userRef, { currentSessionId: clientSessionId }, { merge: true });
      return { valid: true, activeSessionId: clientSessionId };
    }
    return {
      valid: activeSessionId === clientSessionId,
      activeSessionId
    };
  } catch (error) {
    console.warn(`[FIRESTORE SESSION VERIFICATION] Error checking ${path}:`, error);
    return { valid: true, activeSessionId: clientSessionId };
  }
}

// =========================================================================
// SECURE SUPER ADMIN WALLET & FIRESTORE STORAGE ENGINE
// =========================================================================

/**
 * Subscribe to real-time wallet document: /wallets/{userId}
 * Guaranteed strictly verified fields: deposited_balance, bonus_balance, gift_balance, total_balance
 */
export function subscribeToUserWallet(
  userId: string,
  onUpdate: (wallet: UserWalletDoc | null) => void,
  onError?: (err: any) => void
) {
  if (!userId) return () => {};
  const walletRef = doc(db, 'wallets', userId);
  return onSnapshot(
    walletRef,
    (snap) => {
      if (snap.exists()) {
        const data = snap.data() as UserWalletDoc;
        onUpdate({
          userId,
          deposited_balance: Number(data.deposited_balance || 0),
          bonus_balance: Number(data.bonus_balance || 0),
          gift_balance: Number(data.gift_balance || 0),
          total_balance: Number(data.total_balance || 0),
          updatedAt: data.updatedAt
        });
      } else {
        onUpdate(null);
      }
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.GET, `wallets/${userId}`);
    }
  );
}

/**
 * Subscribe to real-time transactions sub-collection: /wallets/{userId}/transactions
 */
export function subscribeToWalletTransactions(
  userId: string,
  onUpdate: (txs: WalletTransactionDoc[]) => void,
  onError?: (err: any) => void
) {
  if (!userId) return () => {};
  const txsRef = collection(db, 'wallets', userId, 'transactions');
  return onSnapshot(
    txsRef,
    (snap) => {
      const txs: WalletTransactionDoc[] = [];
      snap.forEach((d) => {
        const data = d.data();
        txs.push({
          id: d.id,
          type: data.type || 'admin_credit',
          amount: Number(data.amount || 0),
          balance_type: data.balance_type || 'deposited_balance',
          previous_balance: Number(data.previous_balance || 0),
          new_balance: Number(data.new_balance || 0),
          credited_by: data.credited_by || 'super_admin',
          note: data.note || '',
          timestamp: data.timestamp
        });
      });
      // Sort newest first
      txs.sort((a, b) => {
        const tA = a.timestamp?.toMillis ? a.timestamp.toMillis() : (a.timestamp ? new Date(a.timestamp).getTime() : 0);
        const tB = b.timestamp?.toMillis ? b.timestamp.toMillis() : (b.timestamp ? new Date(b.timestamp).getTime() : 0);
        return tB - tA;
      });
      onUpdate(txs);
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, `wallets/${userId}/transactions`);
    }
  );
}

/**
 * Super Admin Credit Operation:
 * Atomic Firestore Transaction that increments deposited_balance, bonus_balance, or gift_balance,
 * calculates total_balance, and records an accountable log in /wallets/{userId}/transactions/{txId}.
 */
export async function superAdminCreditWalletInFirestore(params: {
  userId: string;
  amount: number;
  balanceType: 'deposited_balance' | 'bonus_balance' | 'gift_balance';
  note?: string;
  adminId?: string;
}): Promise<{ success: boolean; newWallet: UserWalletDoc; txId: string; message: string }> {
  const { userId, amount, balanceType, note, adminId } = params;
  if (!userId || amount <= 0) {
    throw new Error('Valid User ID and positive amount are required.');
  }

  const walletRef = doc(db, 'wallets', userId);
  const txColRef = collection(db, 'wallets', userId, 'transactions');
  const newTxDocRef = doc(txColRef);

  try {
    const result = await runTransaction(db, async (transaction) => {
      const snap = await transaction.get(walletRef);
      let dep = 0;
      let bon = 0;
      let gift = 0;

      if (snap.exists()) {
        const existing = snap.data();
        dep = Number(existing.deposited_balance || 0);
        bon = Number(existing.bonus_balance || 0);
        gift = Number(existing.gift_balance || 0);
      }

      const prevTotal = dep + bon + gift;

      if (balanceType === 'deposited_balance') dep += amount;
      else if (balanceType === 'bonus_balance') bon += amount;
      else if (balanceType === 'gift_balance') gift += amount;

      const newTotal = dep + bon + gift;

      const walletPayload: UserWalletDoc = {
        userId,
        deposited_balance: dep,
        bonus_balance: bon,
        gift_balance: gift,
        total_balance: newTotal,
        updatedAt: serverTimestamp()
      };

      transaction.set(walletRef, walletPayload, { merge: true });

      const txPayload: WalletTransactionDoc = {
        type: 'admin_credit',
        amount,
        balance_type: balanceType,
        previous_balance: prevTotal,
        new_balance: newTotal,
        credited_by: adminId || auth.currentUser?.email || auth.currentUser?.uid || 'super_admin',
        note: note || `Super Admin credited ₹${amount} (${balanceType})`,
        timestamp: serverTimestamp()
      };

      transaction.set(newTxDocRef, txPayload);

      return {
        wallet: walletPayload,
        txId: newTxDocRef.id
      };
    });

    return {
      success: true,
      newWallet: result.wallet,
      txId: result.txId,
      message: `Successfully credited ₹${amount} (${balanceType}) to user ${userId}`
    };
  } catch (error: any) {
    // If client-side rules reject or session is not direct Super Admin in Firebase Auth,
    // invoke secure backend proxy endpoint with server admin authority
    try {
      const res = await fetch('/api/superadmin/credit-wallet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          amount,
          balanceType,
          note,
          adminId: adminId || auth.currentUser?.uid || 'super_admin'
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        return {
          success: true,
          newWallet: data.wallet,
          txId: data.txId,
          message: data.message
        };
      }
      throw new Error(data.error || error.message);
    } catch (fallbackErr: any) {
      handleFirestoreError(error, OperationType.WRITE, `wallets/${userId}`);
      throw error;
    }
  }
}

/**
 * Exploitation Security Test:
 * Deliberately attempts to directly write unauthorized balance to /wallets/{userId}
 * Proves that firestore.rules blocks non-super_admin direct writes with PERMISSION_DENIED.
 */
export async function testUnauthorizedWalletWrite(userId: string): Promise<{ success: boolean; error?: string }> {
  const walletRef = doc(db, 'wallets', userId);
  try {
    await setDoc(walletRef, {
      total_balance: 999999,
      deposited_balance: 999999,
      bonus_balance: 0,
      gift_balance: 0,
      updatedAt: serverTimestamp()
    }, { merge: true });
    return { success: true };
  } catch (err: any) {
    return {
      success: false,
      error: err.code || err.message || 'Permission Denied by Firestore Security Rules'
    };
  }
}

// =========================================================================
// MULTI-CLOUD STANDALONE PERSISTENCE & TELEMETRY LAYER EXPORTS
// (Ensures Netlify / Vercel / Cloud Run zero-reset synchronization)
// =========================================================================
export {
  GlobalLiveSyncLogger,
  safeInitializeUserProfile,
  recordAdminAuditSnapshot,
  createDepositNodeWithDeepLink,
  resolvedFirebaseConfig
} from './services/firebaseCloudSync';

export {
  DeepAuditSystem
} from './services/deepAuditSystem';

export {
  superAdminModifyUserBalance,
  updateGlobalSystemUpi,
  subscribeToGlobalSystemConfig,
  subscribeToActiveUserRealtime
} from './services/superAdminOverrides';

export {
  generateDynamicUpiQr
} from './utils/upiQrGenerator';




