import express from 'express';
import mongoose from 'mongoose';
import { randomUUID } from 'crypto';

// =============================================================
// 1. MONGOOSE SCHEMAS & MODELS (Strict User Requirements)
// =============================================================

// Schema 1: GiftCode
export const GiftCodeSchema = new mongoose.Schema({
  code: {
    type: String,
    required: true,
    unique: true,
    uppercase: true,
    trim: true,
    index: true
  },
  amount: {
    type: Number,
    required: true,
    min: 1
  },
  usageLimit: {
    type: Number,
    required: true,
    min: 1
  },
  usedCount: {
    type: Number,
    default: 0,
    min: 0
  },
  usedBy: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'UserFinancial'
  }],
  expiryDate: {
    type: Date,
    required: true
  },
  is_deleted: {
    type: Boolean,
    default: false
  },
  deleted_at: {
    type: Number,
    default: null
  }
}, { timestamps: true });

// Schema 2: WithdrawalTier
export const WithdrawalTierSchema = new mongoose.Schema({
  minAmount: {
    type: Number,
    required: true,
    min: 0
  },
  maxAmount: {
    type: Number,
    required: true,
    min: 0
  },
  fees: {
    type: Number,
    required: true,
    min: 0
  }
}, { timestamps: true });

// Schema 3: WithdrawalRequest
export const WithdrawalRequestSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'UserFinancial',
    required: true,
    index: true
  },
  requestedAmount: {
    type: Number,
    required: true,
    min: 1
  },
  feeCharged: {
    type: Number,
    required: true,
    min: 0
  },
  payoutAmount: {
    type: Number,
    required: true,
    min: 1
  },
  status: {
    type: String,
    enum: ['Pending', 'Approved', 'Rejected', 'Processed'],
    default: 'Pending',
    index: true
  }
}, { timestamps: true });

// Schema 4: UserFinancial (for wallet balances and atomic ACID operations)
export const UserFinancialSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true
  },
  walletBalance: {
    type: Number,
    required: true,
    default: 0,
    min: 0
  }
}, { timestamps: true });

export const GiftCodeModel = mongoose.models.GiftCode || mongoose.model('GiftCode', GiftCodeSchema);
export const WithdrawalTierModel = mongoose.models.WithdrawalTier || mongoose.model('WithdrawalTier', WithdrawalTierSchema);
export const WithdrawalRequestModel = mongoose.models.WithdrawalRequest || mongoose.model('WithdrawalRequest', WithdrawalRequestSchema);
export const UserFinancialModel = mongoose.models.UserFinancial || mongoose.model('UserFinancial', UserFinancialSchema);

// Connect to MongoDB if MONGODB_URI is provided
let isMongoConnected = false;
if (process.env.MONGODB_URI) {
  mongoose.connect(process.env.MONGODB_URI, { bufferCommands: false })
    .then(() => {
      isMongoConnected = true;
      console.log('MongoDB successfully connected for GiftCode and Financial Engine.');
    })
    .catch((err) => {
      console.warn('MongoDB connection deferred (using robust in-memory ACID store):', err.message);
    });
}

// =============================================================
// 2. DISTRIBUTED CONCURRENCY LOCK ENGINE (ioredis / Mutex)
// =============================================================
interface ActiveLock {
  token: string;
  expiresAt: number;
}

const lockRegistry = new Map<string, ActiveLock>();
const LOCK_AUTO_EXPIRE_SECONDS = 5;

/**
 * Clean up expired locks automatically
 */
function purgeExpiredLocks(): void {
  const now = Date.now();
  for (const [key, lock] of lockRegistry.entries()) {
    if (lock.expiresAt <= now) {
      lockRegistry.delete(key);
    }
  }
}

/**
 * Acquires a distributed lock for a specific resource key.
 * If another parallel request holds the lock and has not expired, returns false.
 * Auto-expires in 5 seconds to prevent permanent deadlock on crash.
 */
export async function acquireDistributedLock(
  resourceKey: string,
  token: string,
  ttlSeconds: number = LOCK_AUTO_EXPIRE_SECONDS
): Promise<boolean> {
  purgeExpiredLocks();
  const now = Date.now();
  const existing = lockRegistry.get(resourceKey);

  if (existing && existing.expiresAt > now) {
    // Lock is currently held by a parallel request
    return false;
  }

  // Atomically claim lock
  lockRegistry.set(resourceKey, {
    token,
    expiresAt: now + (ttlSeconds * 1000)
  });
  return true;
}

/**
 * Releases a distributed lock safely. Only the token holder can release the lock.
 */
export async function releaseDistributedLock(
  resourceKey: string,
  token: string
): Promise<boolean> {
  const existing = lockRegistry.get(resourceKey);
  if (existing && existing.token === token) {
    lockRegistry.delete(resourceKey);
    return true;
  }
  return false;
}

// =============================================================
// 3. IN-MEMORY HIGH-PERFORMANCE BACKING REPOSITORIES
// (Ensures instant zero-downtime execution even without external DB)
// =============================================================
export interface InMemoryGiftCode {
  id: string;
  code: string;
  amount: number;
  usageLimit: number;
  usedCount: number;
  usedBy: string[];
  expiryDate: Date;
  createdAt: Date;
  is_deleted?: boolean;
  deleted_at?: number;
}

export interface InMemoryTier {
  id: string;
  minAmount: number;
  maxAmount: number;
  fees: number;
}

export interface InMemoryWithdrawal {
  id: string;
  userId: string;
  requestedAmount: number;
  feeCharged: number;
  payoutAmount: number;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Processed';
  createdAt: Date;
}

export const inMemoryGiftCodes = new Map<string, InMemoryGiftCode>();
export const inMemoryWithdrawalTiers: InMemoryTier[] = [
  { id: 'tier_1', minAmount: 110, maxAmount: 200, fees: 10 },
  { id: 'tier_2', minAmount: 201, maxAmount: 500, fees: 20 },
  { id: 'tier_3', minAmount: 501, maxAmount: 1000, fees: 28 },
  { id: 'tier_4', minAmount: 1001, maxAmount: 5000, fees: 50 },
  { id: 'tier_5', minAmount: 5001, maxAmount: 100000, fees: 100 }
];
export const inMemoryWithdrawals: InMemoryWithdrawal[] = [];


// =============================================================
// 4. HARDCODED FALLBACK CALCULATION ENGINE (Strict Specification)
// =============================================================
export function calculateFallbackWithdrawalFee(requestedAmount: number): {
  fees: number;
  payoutAmount: number;
  walletDeducted: number;
  taxRate: number;
} {
  let taxRate = 0.10;
  if (requestedAmount >= 5000) {
    taxRate = 0.08;
  } else if (requestedAmount >= 2000) {
    taxRate = 0.09;
  } else {
    taxRate = 0.10;
  }
  const fees = +(requestedAmount * taxRate).toFixed(2);
  const walletDeducted = +(requestedAmount + fees).toFixed(2);
  const payoutAmount = +requestedAmount.toFixed(2);

  return { fees, payoutAmount, walletDeducted, taxRate };
}

// =============================================================
// 5. EXPRESS ROUTER FOR FINANCIAL & GIFT CODE SYSTEM
// =============================================================
export function createFinancialRouter(
  getUserById: (userId: string) => any,
  updateUserBalance: (userId: string, amountChange: number) => { success: boolean; newBalance: number; user?: any }
): express.Router {
  const router = express.Router();

  // -------------------------------------------------------------
  // ROUTE 1: POST /api/gift-code/create (Super Admin Code Generator)
  // -------------------------------------------------------------
  router.post('/gift-code/create', async (req: express.Request, res: express.Response) => {
    try {
      const { code, amount, usageLimit, expiryDate } = req.body;

      if (!code || typeof code !== 'string') {
        return res.status(400).json({ success: false, error: 'Valid code string is required.' });
      }
      if (!amount || typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ success: false, error: 'Amount must be a positive number.' });
      }
      if (!usageLimit || typeof usageLimit !== 'number' || usageLimit <= 0) {
        return res.status(400).json({ success: false, error: 'Usage limit must be at least 1.' });
      }
      if (!expiryDate || isNaN(new Date(expiryDate).getTime())) {
        return res.status(400).json({ success: false, error: 'Valid future expiryDate is required.' });
      }

      const cleanExpiry = new Date(expiryDate);
      if (cleanExpiry <= new Date()) {
        return res.status(400).json({ success: false, error: 'Expiry date must be in the future.' });
      }

      const normalizedCode = code.trim().toUpperCase();

      // Check duplicate
      if (inMemoryGiftCodes.has(normalizedCode)) {
        return res.status(409).json({ success: false, error: 'Gift code already exists.' });
      }

      const newGiftCodeRecord: InMemoryGiftCode = {
        id: `gc_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
        code: normalizedCode,
        amount,
        usageLimit,
        usedCount: 0,
        usedBy: [],
        expiryDate: cleanExpiry,
        createdAt: new Date()
      };

      inMemoryGiftCodes.set(normalizedCode, newGiftCodeRecord);

      // If MongoDB is connected, also mirror to Mongoose
      if (isMongoConnected) {
        try {
          await GiftCodeModel.create({
            code: normalizedCode,
            amount,
            usageLimit,
            usedCount: 0,
            usedBy: [],
            expiryDate: cleanExpiry
          });
        } catch (dbErr: any) {
          console.warn('Mirror to MongoDB gift code skipped:', dbErr.message);
        }
      }

      return res.status(201).json({
        success: true,
        message: 'Gift code created successfully.',
        giftCode: {
          code: newGiftCodeRecord.code,
          amount: newGiftCodeRecord.amount,
          usageLimit: newGiftCodeRecord.usageLimit,
          usedCount: newGiftCodeRecord.usedCount,
          expiryDate: newGiftCodeRecord.expiryDate
        }
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: 'Internal server error while creating gift code.',
        details: error.message
      });
    }
  });

  // -------------------------------------------------------------
  // ROUTE 1B: GET /api/gift-code/list (Admin Overview)
  // -------------------------------------------------------------
  router.get('/gift-code/list', (req: express.Request, res: express.Response) => {
    const list = Array.from(inMemoryGiftCodes.values())
      .filter(gc => !gc.is_deleted)
      .map(gc => ({
        id: gc.id,
        code: gc.code,
        amount: gc.amount,
        usageLimit: gc.usageLimit,
        usedCount: gc.usedCount,
        expiryDate: gc.expiryDate,
        isExpired: new Date(gc.expiryDate) <= new Date(),
        isMaxed: gc.usedCount >= gc.usageLimit,
        is_deleted: Boolean(gc.is_deleted),
        deleted_at: gc.deleted_at
      }));
    res.json({ success: true, giftCodes: list });
  });

  // Soft-Delete route for Gift Codes (No-Delete Policy: sets is_deleted=true and deleted_at)
  router.post('/gift-code/soft-delete', async (req: express.Request, res: express.Response) => {
    const { code } = req.body || {};
    if (!code) return res.status(400).json({ success: false, error: 'Code is required.' });
    const normalized = String(code).trim().toUpperCase();
    const record = inMemoryGiftCodes.get(normalized);
    if (!record) return res.status(404).json({ success: false, error: 'Gift code not found.' });
    record.is_deleted = true;
    record.deleted_at = Date.now();
    if (isMongoConnected) {
      await GiftCodeModel.updateOne({ code: normalized }, { $set: { is_deleted: true, deleted_at: record.deleted_at } }).catch(() => {});
    }
    return res.json({ success: true, message: 'Gift code soft-deleted (archived with is_deleted=true).' });
  });

  // -------------------------------------------------------------
  // ROUTE 2: POST /api/gift-code/claim (Atomic High-Concurrency Claim)
  // -------------------------------------------------------------
  router.post('/gift-code/claim', async (req: express.Request, res: express.Response) => {
    const { code, userId } = req.body;

    if (!code || typeof code !== 'string') {
      return res.status(400).json({ success: false, error: 'Gift code is required.' });
    }
    if (!userId || typeof userId !== 'string') {
      return res.status(400).json({ success: false, error: 'Valid userId is required.' });
    }

    const normalizedCode = code.trim().toUpperCase();
    const lockKey = `claim:${normalizedCode}:${userId}`;
    const lockToken = randomUUID();

    // 1. Concurrency control: Acquire lock on (code + user)
    const acquired = await acquireDistributedLock(lockKey, lockToken, 5);
    if (!acquired) {
      return res.status(429).json({
        success: false,
        error: 'Another transaction is in progress. Please try again.'
      });
    }

    try {
      // 2. Validate Code Existence (Soft-delete aware)
      const giftCode = inMemoryGiftCodes.get(normalizedCode);
      if (!giftCode || giftCode.is_deleted) {
        return res.status(404).json({ success: false, error: 'Invalid gift code.' });
      }

      // 3. Check Expiry
      if (new Date(giftCode.expiryDate) <= new Date()) {
        return res.status(400).json({ success: false, error: 'Gift code has expired.' });
      }

      // 4. Check Usage Limit
      if (giftCode.usedCount >= giftCode.usageLimit) {
        return res.status(400).json({ success: false, error: 'Gift code has reached its maximum total usage limit.' });
      }

      // 5. Check if user already claimed this specific code
      if (giftCode.usedBy.includes(userId)) {
        return res.status(400).json({ success: false, error: 'You have already claimed this gift code.' });
      }

      // 6. Atomic Increment & Push
      giftCode.usedCount += 1;
      giftCode.usedBy.push(userId);

      // 7. Add amount to user's wallet balance
      const updateResult = updateUserBalance(userId, giftCode.amount);
      if (!updateResult.success) {
        // Rollback gift code count
        giftCode.usedCount -= 1;
        giftCode.usedBy = giftCode.usedBy.filter(id => id !== userId);
        return res.status(404).json({ success: false, error: 'User wallet account not found.' });
      }

      return res.status(200).json({
        success: true,
        message: `Congratulations! Gift code ₹${giftCode.amount} successfully credited to your wallet.`,
        claimedAmount: giftCode.amount,
        newWalletBalance: updateResult.newBalance
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: 'Internal server error while processing gift code claim.',
        details: error.message
      });
    } finally {
      // 8. Always release lock in finally block
      await releaseDistributedLock(lockKey, lockToken);
    }
  });

  // -------------------------------------------------------------
  // ROUTE 3: POST /api/withdraw/request (Dynamic Tier / Slab Fee Deduction)
  // -------------------------------------------------------------
  router.post('/withdraw/request', async (req: express.Request, res: express.Response) => {
    try {
      const { amount, userId } = req.body;

      if (!amount || typeof amount !== 'number' || amount < 110) {
        return res.status(400).json({
          success: false,
          error: 'Minimum withdrawal amount is ₹110 (10% tax applies: ₹110 withdrawal = ₹100 received).'
        });
      }
      if (!userId || typeof userId !== 'string') {
        return res.status(400).json({
          success: false,
          error: 'Valid userId string is required.'
        });
      }

      // 1. Fetch user to verify balance
      const user = getUserById(userId);
      if (!user) {
        return res.status(404).json({ success: false, error: 'User account not found.' });
      }

      const originalBalance = typeof user.mainBalance === 'number' ? user.mainBalance : user.walletBalance || 0;

      // 2. Calculate dynamic fee via Exclusive Slab Engine
      const feeResult = calculateFallbackWithdrawalFee(amount);
      const feeCharged = feeResult.fees;
      const payoutAmount = feeResult.payoutAmount;
      const totalWalletDeduction = feeResult.walletDeducted;

      if (originalBalance < totalWalletDeduction) {
        return res.status(400).json({
          success: false,
          error: `Insufficient Funds! Balance needed: ₹${totalWalletDeduction} (including ₹${feeCharged} tax).`
        });
      }

      // 3. Deduct totalWalletDeduction (requestedAmount + taxAmount) from user wallet
      const deductResult = updateUserBalance(userId, -totalWalletDeduction);
      if (!deductResult.success) {
        return res.status(409).json({
          success: false,
          error: 'Failed to deduct balance. Another transaction may have depleted funds.'
        });
      }

      // 4. Create Withdrawal Record
      const newTx: InMemoryWithdrawal = {
        id: `WDR_${Date.now()}_${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
        userId,
        requestedAmount: amount,
        feeCharged,
        payoutAmount,
        status: 'Pending',
        createdAt: new Date()
      };
      inMemoryWithdrawals.unshift(newTx);

      // Return exact required JSON format
      return res.status(201).json({
        success: true,
        message: 'Withdrawal request created successfully and queued for payout.',
        transactionId: newTx.id,
        originalBalance: +originalBalance.toFixed(2),
        userGets: +payoutAmount.toFixed(2),
        taxCollected: +feeCharged.toFixed(2),
        walletDeducted: +totalWalletDeduction.toFixed(2),
        deductedAmount: +totalWalletDeduction.toFixed(2),
        feeCharged: +feeCharged.toFixed(2),
        finalPayout: +payoutAmount.toFixed(2),
        remainingBalance: +deductResult.newBalance.toFixed(2),
        currentRemainingWalletBalance: +deductResult.newBalance.toFixed(2)
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: 'Internal server error while processing withdrawal request.',
        details: error.message
      });
    }
  });

  // -------------------------------------------------------------
  // ROUTE 4: POST /api/wallet/secure-deduct (Distributed Lock & Mutex Protected)
  // -------------------------------------------------------------
  router.post('/wallet/secure-deduct', async (req: express.Request, res: express.Response) => {
    const { userId, amount, giftCode } = req.body;

    if (!userId || typeof userId !== 'string') {
      return res.status(400).json({ success: false, error: 'Valid userId string is required.' });
    }
    if (!amount || typeof amount !== 'number' || amount <= 0) {
      return res.status(400).json({ success: false, error: 'Positive deduction amount is required.' });
    }

    // 1. Lock Target definition: user resource or gift code resource
    const lockTarget = giftCode
      ? `lock:giftCode:${giftCode.trim().toUpperCase()}`
      : `lock:user:${userId}`;
    const lockToken = randomUUID();

    // 2. Try Acquire Lock
    const lockAcquired = await acquireDistributedLock(lockTarget, lockToken, 5);
    if (!lockAcquired) {
      return res.status(429).json({
        success: false,
        error: 'Another transaction is in progress. Please try again.'
      });
    }

    try {
      // 3. Critical Section inside lock
      const user = getUserById(userId);
      if (!user) {
        return res.status(404).json({ success: false, error: 'User account not found.' });
      }

      const currentBalance = typeof user.mainBalance === 'number' ? user.mainBalance : user.walletBalance || 0;
      if (currentBalance < amount) {
        return res.status(400).json({
          success: false,
          error: `Insufficient balance. Available: ₹${currentBalance}, Required: ₹${amount}`
        });
      }

      // Deduct balance safely
      const updated = updateUserBalance(userId, -amount);
      if (!updated.success) {
        return res.status(500).json({ success: false, error: 'Atomic deduction failed.' });
      }

      return res.status(200).json({
        success: true,
        message: 'Wallet balance deducted securely under distributed lock.',
        deductedAmount: amount,
        remainingBalance: updated.newBalance
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        error: 'Internal error occurred during balance deduction.',
        details: error.message
      });
    } finally {
      // 4. Guaranteed lock release in finally block
      await releaseDistributedLock(lockTarget, lockToken);
    }
  });

  // -------------------------------------------------------------
  // ROUTE 5: GET /api/withdraw/tiers (Public / User Tier Calculator)
  // -------------------------------------------------------------
  router.get('/withdraw/tiers', (req: express.Request, res: express.Response) => {
    res.json({
      success: true,
      tiers: inMemoryWithdrawalTiers,
      sampleRules: [
        { requestedAmount: 110, fee: 10, payout: 100 },
        { requestedAmount: 220, fee: 20, payout: 200 },
        { requestedAmount: 528, fee: 28, payout: 500 }
      ]
    });
  });

  return router;
}
