import express from 'express';
import { Telegraf } from 'telegraf';
import mongoose from 'mongoose';
import fs from 'fs';
import path from 'path';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const PUBLIC_DIR = path.resolve(process.cwd(), 'public');
const DIST_DIR = path.resolve(process.cwd(), 'dist');

if (fs.existsSync(PUBLIC_DIR)) app.use(express.static(PUBLIC_DIR));
if (fs.existsSync(DIST_DIR)) app.use(express.static(DIST_DIR));

// ==========================================
// ⚙️ CONFIGURATION & HARDLOCKED CREDENTIALS
// ==========================================
const PORT = process.env.PORT || 3000;
const HARDLOCKED_ADMIN_ID = 7939005883; // Supreme Admin (Jack)
const MAIN_BOT_TOKEN = process.env.MAIN_BOT_TOKEN || '8989808450:AAHC3Owc_y3a8WDKLnrGWCVLv_SXldFRlqw';
const NOTIFICATION_BOT_TOKEN = process.env.NOTIFICATION_BOT_TOKEN || MAIN_BOT_TOKEN;
const MONGO_URI = process.env.MONGO_URI || process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/winNovaDB';

const mainBot = new Telegraf(MAIN_BOT_TOKEN);
const isDualBot = Boolean(NOTIFICATION_BOT_TOKEN && NOTIFICATION_BOT_TOKEN !== MAIN_BOT_TOKEN);
const notifyBot = isDualBot ? new Telegraf(NOTIFICATION_BOT_TOKEN) : mainBot;

let winNovaSettingsCache = {
    baseSubRate: 144,
    creditRate: 3,
    taxPercent: 5, // Tax rate in percentage (Dynamic)
    commissionPercent: 10,
    adminUpiId: 'jack@upi',
    dynamicWebsiteUrl: 'http://localhost:3000'
};

const userStates = new Map();
const inMemoryUsers = new Map();
let isAdminNotificationOn = false;

// ==========================================
// 🗄️ MONGOOSE SCHEMAS & STORAGE
// ==========================================
const UserSchema = new mongoose.Schema({
    telegramId: { type: Number, unique: true, required: true },
    username: String,
    activeSubscription: { type: Boolean, default: false },
    creditBalance: { type: Number, default: 0 },
    totalCreditsEarned: { type: Number, default: 0 },
    totalReferrals: { type: Number, default: 0 },
    referralCashBalance: { type: Number, default: 0 },
    referredBy: { type: Number, default: null },
    dailyReferralCount: { type: Number, default: 0 },
    lastClaimDate: { type: String, default: "" },
    isVerified: { type: Boolean, default: true },
    isBanned: { type: Boolean, default: false },
    adminNotifyEnabled: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now }
});
const BotUser = mongoose.models.BotUser || mongoose.model('BotUser', UserSchema);

// ==========================================
// 🛡️ SUB-ADMIN RBAC SCHEMA & STORAGE
// ==========================================
const SubAdminSchema = new mongoose.Schema({
    username: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    token: { type: String, default: "" },
    canManageTelegramBot: { type: Boolean, default: false },
    canManageRates: { type: Boolean, default: false },
    canManageUPI: { type: Boolean, default: false },
    canBroadcast: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now }
});
const SubAdmin = mongoose.models.SubAdmin || mongoose.model('SubAdmin', SubAdminSchema);
const inMemorySubAdmins = new Map();

const SettingsSchema = new mongoose.Schema({
    id: { type: Number, default: 1, unique: true },
    baseSubRate: { type: Number, default: 144 },
    creditRate: { type: Number, default: 3 },
    taxPercent: { type: Number, default: 5 },
    commissionPercent: { type: Number, default: 10 },
    adminUpiId: { type: String, default: 'jack@upi' },
    dynamicWebsiteUrl: { type: String, default: 'http://localhost:3000' }
});
const AdminSettings = mongoose.models.AdminSettings || mongoose.model('AdminSettings', SettingsSchema);

const ClonedBotSchema = new mongoose.Schema({
    token: { type: String, unique: true, required: true },
    botUsername: String,
    botId: Number,
    createdAt: { type: Date, default: Date.now }
});
const ClonedBot = mongoose.models.ClonedBot || mongoose.model('ClonedBot', ClonedBotSchema);
const activeClonedBots = [];

async function refreshMemoryCache() {
    try {
        if (mongoose.connection.readyState === 1) {
            let settings = await AdminSettings.findOne({ id: 1 });
            if (!settings) {
                settings = await AdminSettings.create({
                    id: 1,
                    baseSubRate: winNovaSettingsCache.baseSubRate || 144,
                    creditRate: winNovaSettingsCache.creditRate || 3,
                    taxPercent: winNovaSettingsCache.taxPercent || 5,
                    commissionPercent: winNovaSettingsCache.commissionPercent || 10,
                    adminUpiId: winNovaSettingsCache.adminUpiId || 'jack@upi',
                    dynamicWebsiteUrl: winNovaSettingsCache.dynamicWebsiteUrl || 'http://localhost:3000'
                });
            }
            winNovaSettingsCache = {
                baseSubRate: settings.baseSubRate != null ? settings.baseSubRate : winNovaSettingsCache.baseSubRate,
                creditRate: settings.creditRate != null ? settings.creditRate : winNovaSettingsCache.creditRate,
                taxPercent: settings.taxPercent != null ? settings.taxPercent : winNovaSettingsCache.taxPercent,
                commissionPercent: settings.commissionPercent != null ? settings.commissionPercent : winNovaSettingsCache.commissionPercent,
                adminUpiId: settings.adminUpiId ? settings.adminUpiId : winNovaSettingsCache.adminUpiId,
                dynamicWebsiteUrl: settings.dynamicWebsiteUrl ? settings.dynamicWebsiteUrl : winNovaSettingsCache.dynamicWebsiteUrl
            };
        }
    } catch (err) {
        console.error("Cache Refresh Error:", err.message);
    }
}

// ==========================================
// 🎰 REAL AUTOMATED GAME LOOP & BROADCASTER
// ==========================================
let currentRound = {
    roundId: 1000,
    status: 'WAITING',
    targetMultiplier: 1.00,
    nextRoundMultiplier: null,
    startTime: null,
    durationMs: 0
};

// REAL AVIATOR WEIGHTED PROBABILITY ALGORITHM
function generateRealAviatorMultiplier() {
    const rand = Math.random();
    // 6 rounds out of 10 (~60%) targeted around 1.50x to 1.93x range
    if (rand < 0.60) {
        return parseFloat((1.35 + Math.random() * 0.58).toFixed(2)); 
    } 
    // 4 rounds out of 10 (~40%) targeted around 1.58x to 3.50x range
    else if (rand < 1.00) {
        return parseFloat((1.58 + Math.random() * 2.00).toFixed(2)); 
    }
    return parseFloat((1.01 + Math.random() * 0.20).toFixed(2));
}

// STRICT RULE: ONLY send to VIP users with creditBalance > 0 (NEVER to Admin or 0 credit users unless Admin explicitly turned ON notifications)
async function broadcastToVIPs(message) {
    try {
        let eligibleUsers = [];
        if (mongoose.connection.readyState === 1) {
            eligibleUsers = await BotUser.find({
                activeSubscription: true,
                creditBalance: { $gt: 0 },
                telegramId: { $ne: HARDLOCKED_ADMIN_ID },
                isBanned: false
            });
        } else {
            eligibleUsers = Array.from(inMemoryUsers.values()).filter(
                u => u.activeSubscription === true &&
                     (u.creditBalance || 0) > 0 &&
                     u.telegramId !== HARDLOCKED_ADMIN_ID &&
                     !u.isBanned
            );
        }

        for (const user of eligibleUsers) {
            mainBot.telegram.sendMessage(user.telegramId, message, { parse_mode: 'Markdown' }).catch(() => {});
            for (const clone of activeClonedBots) {
                clone.telegram.sendMessage(user.telegramId, message, { parse_mode: 'Markdown' }).catch(() => {});
            }
        }

        // Send to Admin ONLY IF Admin Notification is turned ON
        if (isAdminNotificationOn) {
            mainBot.telegram.sendMessage(HARDLOCKED_ADMIN_ID, message, { parse_mode: 'Markdown' }).catch(() => {});
        }
    } catch (err) {
        console.error("VIP Broadcast Error:", err.message);
    }
}

async function runAviatorGameLoop() {
    while (true) {
        try {
            currentRound.roundId++;
            currentRound.targetMultiplier = currentRound.nextRoundMultiplier || generateRealAviatorMultiplier();
            currentRound.nextRoundMultiplier = null;
            currentRound.status = 'WAITING';
            
            const prepMessage = `🚀 **ROUND #${currentRound.roundId} STARTING SOON!**\n\n` +
                                `⏱️ Round Starting in 10s\n` +
                                `🎯 Calibrating live telemetry... Place your bets now!`;
            await broadcastToVIPs(prepMessage);
            
            await new Promise(resolve => setTimeout(resolve, 10000));
            
            currentRound.status = 'RUNNING';
            currentRound.startTime = Date.now();
            currentRound.durationMs = Math.max(1000, Math.min(30000, Math.log(currentRound.targetMultiplier + 1) * 5000));
            
            await new Promise(resolve => setTimeout(resolve, currentRound.durationMs));
            
            currentRound.status = 'CRASHED';
            const crashTimeStr = new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
            const crashMessage = `💥 **ROUND #${currentRound.roundId} CRASH ALERT**\n\n` +
                                 `❌ Crashed at ${currentRound.targetMultiplier.toFixed(2)}x\n` +
                                 `🕒 IST Time: \`${crashTimeStr} IST\`\n\n` +
                                 `⏳ Next round starting shortly...`;
            await broadcastToVIPs(crashMessage);
            
            await new Promise(resolve => setTimeout(resolve, 5000));
        } catch (err) {
            console.error("Game loop error:", err.message);
            await new Promise(resolve => setTimeout(resolve, 5000));
        }
    }
}

// ==========================================
// ⌨️ KEYBOARD LAYOUTS (TOTAL 17 BUTTONS)
// ==========================================
const SUPER_ADMIN_KEYBOARD = {
    keyboard: [
        [{ text: '📊 View Live Logs' }, { text: '👥 Total Users' }],
        [{ text: '📢 Global Broadcast' }, { text: '⚙️ Bot Settings' }],
        [{ text: '🏷️ Change Base Rates' }, { text: '💳 Set Admin UPI ID' }],
        [{ text: '👥 Referral Control Panel' }, { text: '🤖 Clone Bot via API' }],
        [{ text: '🖥️ Open Admin Web Dashboard Link' }, { text: '💳 Manual Approval Panel' }]
    ],
    resize_keyboard: true,
    is_persistent: true
};

const PLAYER_KEYBOARD = {
    keyboard: [
        [{ text: '🚀 Fetch Signal (7s Advance)' }],
        [{ text: '🪙 Buy Custom Credits' }, { text: '🎁 Claim Daily 2 Credits' }],
        [{ text: '👑 VIP Plan Activation' }, { text: '💼 My Wallet & Invite' }],
        [{ text: '🏆 Top 10 Leaderboard' }, { text: '🔄 Check Session Status' }]
    ],
    resize_keyboard: true,
    is_persistent: true
};

// ==========================================
// 🤖 CORE BOT ROUTES SETUP
// ==========================================
function setupBotHandlers(bot) {
    // START COMMAND
    bot.start(async (ctx) => {
        const userId = ctx.from.id;
        const textParts = ctx.message?.text ? ctx.message.text.split(' ') : [];
        const startPayload = textParts.length > 1 ? textParts[1] : '';

        try {
            let user = null;
            if (mongoose.connection.readyState === 1) {
                user = await BotUser.findOne({ telegramId: userId });
                if (!user) {
                    let refBy = null;
                    if (startPayload && startPayload.startsWith('ref_')) {
                        refBy = parseInt(startPayload.replace('ref_', ''), 10);
                        if (refBy && refBy !== userId) {
                            await BotUser.findOneAndUpdate({ telegramId: refBy }, { $inc: { dailyReferralCount: 1 } });
                        } else {
                            refBy = null;
                        }
                    }
                    user = await BotUser.create({
                        telegramId: userId,
                        username: ctx.from.username || ctx.from.first_name,
                        referredBy: refBy,
                        activeSubscription: userId === HARDLOCKED_ADMIN_ID,
                        creditBalance: userId === HARDLOCKED_ADMIN_ID ? 99999 : 0,
                        totalCreditsEarned: userId === HARDLOCKED_ADMIN_ID ? 99999 : 0,
                        totalReferrals: 0
                    });
                }
            } else {
                user = inMemoryUsers.get(userId);
                if (!user) {
                    user = {
                        telegramId: userId,
                        username: ctx.from.username || ctx.from.first_name,
                        referredBy: refBy,
                        activeSubscription: userId === HARDLOCKED_ADMIN_ID,
                        creditBalance: userId === HARDLOCKED_ADMIN_ID ? 99999 : 0,
                        totalCreditsEarned: userId === HARDLOCKED_ADMIN_ID ? 99999 : 0,
                        totalReferrals: 0,
                        referralCashBalance: 0,
                        dailyReferralCount: 0,
                        lastClaimDate: "",
                        isVerified: true,
                        isBanned: false
                    };
                    inMemoryUsers.set(userId, user);
                }
            }

            if (user && user.isBanned) return ctx.reply("❌ Your account is permanently banned.");

        } catch (err) {
            console.error("Start Error:", err.message);
        }

        // Clean slate keyboard purge on startup
        await ctx.reply("🔄 Synchronizing WIN NOVA control panel...", { reply_markup: { remove_keyboard: true } }).catch(() => {});

        if (userId === HARDLOCKED_ADMIN_ID) {
            await ctx.reply("👑 **WIN NOVA Supreme Admin Console Active.**", {
                parse_mode: 'Markdown',
                reply_markup: SUPER_ADMIN_KEYBOARD
            });

            // Real-Time Notification Preference Prompt for Admin
            return ctx.reply("🔔 **Real-Time Notifications Settings:**\n\nKya aapko real time round notifications chahiye?", {
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "✅ Haan (ON)", callback_data: "admin_notify_on" },
                            { text: "❌ Nahi (OFF)", callback_data: "admin_notify_off" }
                        ]
                    ]
                }
            });
        }

        return ctx.reply(`🟢 **WIN NOVA Engine Connected.** Welcome ${ctx.from.first_name}!`, {
            parse_mode: 'Markdown',
            reply_markup: PLAYER_KEYBOARD
        });
    });

    // ==========================================
    // 💬 STATE INPUT HANDLER FOR DYNAMIC INPUTS
    // ==========================================
    bot.on('text', async (ctx, next) => {
        const userId = ctx.from.id;
        const state = userStates.get(userId);

        if (!state) return next();

        const text = ctx.message.text?.trim() || '';

        // DYNAMIC PERCENTAGE TAX BILLING BREAKDOWN
        if (state === 'WAITING_FOR_CREDIT_AMOUNT') {
            const qty = parseInt(text, 10);
            if (isNaN(qty) || qty <= 0) return ctx.reply("❌ Please enter a valid credit quantity.");

            userStates.delete(userId);

            const baseAmount = qty * winNovaSettingsCache.creditRate;
            const taxAmount = (baseAmount * winNovaSettingsCache.taxPercent) / 100;
            const totalAmount = baseAmount + taxAmount;
            const upiId = winNovaSettingsCache.adminUpiId;
            const upiUrl = `upi://pay?pa=${upiId}&pn=WinNova&am=${totalAmount.toFixed(2)}`;
            const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiUrl)}`;

            const calcMsg = `🧾 **CREDIT BILLING BREAKDOWN**\n\n` +
                            `🪙 Requested Credits: **${qty}**\n` +
                            `💵 Base Price (${qty} × ₹${winNovaSettingsCache.creditRate}): ₹${baseAmount.toFixed(2)}\n` +
                            `📊 Tax Amount (${winNovaSettingsCache.taxPercent}% dynamic): ₹${taxAmount.toFixed(2)}\n` +
                            `───────────────\n` +
                            `💰 **Total Payable: ₹${totalAmount.toFixed(2)}**\n\n` +
                            `💳 **Admin UPI ID:** \`${upiId}\`\n\n` +
                            `🔗 **Dynamic QR Code:**\n${qrApiUrl}\n\n` +
                            `⚡ *Dynamic percentage tax calculated automatically. No flat fees applied.*\n` +
                            `Send ₹${totalAmount.toFixed(2)} to \`${upiId}\` or scan the dynamic QR code above and share payment proof for instant credit activation!`;

            // Alert Supreme Admin
            try {
                const notifyMsg = `💰 **NEW DEPOSIT PAYMENT INITIATED**\n\n` +
                                  `👤 User ID: \`${userId}\`\n` +
                                  `👤 Username: @${ctx.from.username || 'N/A'}\n` +
                                  `🪙 Quantity: **${qty} Credits**\n` +
                                  `💵 Total Amount: **₹${totalAmount.toFixed(2)}**\n` +
                                  `💳 Merchant UPI: \`${upiId}\``;
                notifyBot.telegram.sendMessage(HARDLOCKED_ADMIN_ID, notifyMsg, { parse_mode: 'Markdown' }).catch(() => {});
            } catch (_) {}

            return ctx.replyWithPhoto({ url: qrApiUrl }, { caption: calcMsg, parse_mode: 'Markdown' }).catch(() => {
                return ctx.reply(calcMsg, { parse_mode: 'Markdown' });
            });
        }

        // 2. VIP Rate Update Handler with Strict Failure Check
        if (state === 'WAITING_FOR_VIP_RATE' && userId === HARDLOCKED_ADMIN_ID) {
            userStates.delete(userId);
            const rate = parseInt(text, 10);
            if (isNaN(rate) || rate <= 0) {
                return ctx.reply("❌🚫 Invalid rate! Valid numeric amount enter karein.");
            }

            try {
                const updated = await AdminSettings.findOneAndUpdate(
                    { id: 1 }, 
                    { baseSubRate: rate }, 
                    { upsert: true, new: true }
                );

                if (!updated) throw new Error("DB write failed.");

                await refreshMemoryCache();
                return ctx.reply(`✅ VIP Rate updated successfully to ₹${rate}`);
            } catch (err) {
                console.error("Rate Save Error:", err);
                return ctx.reply("❌🚫 **Database Error:** Rate save nahi ho paya. Dobara try karein!");
            }
        }

        // 1. UPI ID Update Handler with Strict Failure Check
        if (state === 'WAITING_FOR_UPI_ID' && userId === HARDLOCKED_ADMIN_ID) {
            userStates.delete(userId);
            if (!text.includes('@')) {
                return ctx.reply("❌🚫 Invalid UPI ID format! Data save nahi hua. Sahi format bhejein (jaise: username@ybl).");
            }

            try {
                const updated = await AdminSettings.findOneAndUpdate(
                    { id: 1 }, 
                    { adminUpiId: text }, 
                    { upsert: true, new: true }
                );
                
                if (!updated) {
                    throw new Error("Database write failed or returned null.");
                }

                await refreshMemoryCache();
                return ctx.reply(`✅ Admin UPI ID permanently save aur live ho gayi: \`${text}\``, { parse_mode: 'Markdown' });
            } catch (err) {
                console.error("UPI Save Error:", err);
                return ctx.reply("❌🚫 **Database Error:** UPI ID save nahi ho payi! Dobara koshish karein.");
            }
        }

        if (state === 'WAITING_FOR_BROADCAST_MSG' && userId === HARDLOCKED_ADMIN_ID) {
            userStates.delete(userId);
            let users = [];
            if (mongoose.connection.readyState === 1) {
                users = await BotUser.find({ isBanned: false });
            } else {
                users = Array.from(inMemoryUsers.values()).filter(u => !u.isBanned);
            }
            let sent = 0;
            for (const u of users) {
                try {
                    await mainBot.telegram.sendMessage(u.telegramId, `📢 **ADMIN BROADCAST:**\n\n${text}`, { parse_mode: 'Markdown' });
                    sent++;
                } catch (e) {}
            }
            return ctx.reply(`✅ Broadcast sent to **${sent}** users.`);
        }

        if (state === 'WAITING_FOR_CLONE_TOKEN' && userId === HARDLOCKED_ADMIN_ID) {
            userStates.delete(userId);
            const token = text.trim();
            try {
                // a) Validate token syntax via Telegram getMe API
                const resp = await fetch(`https://api.telegram.org/bot${token}/getMe`);
                const data = await resp.json();
                if (!data || !data.ok) {
                    return ctx.reply("❌ Invalid Bot API Token. Telegram rejected the token. Please verify the token from @BotFather and try again.");
                }

                const botInfo = data.result;

                // b) Save the new clone token into MongoDB 'ClonedBots' database collection
                if (mongoose.connection.readyState === 1) {
                    await ClonedBot.findOneAndUpdate(
                        { token },
                        { token, botUsername: botInfo.username, botId: botInfo.id },
                        { upsert: true }
                    );
                }

                // c) Dynamically instantiate a new Telegraf bot instance attached to shared MongoDB & shared settings
                const clonedBot = new Telegraf(token);

                // d) Immediately attach all 17 physical control buttons, event listeners, signal engine, and notification loops
                setupBotHandlers(clonedBot);
                await clonedBot.telegram.deleteWebhook({ drop_pending_updates: true }).catch(() => {});
                clonedBot.launch({ allowedUpdates: ['message', 'callback_query'], dropPendingUpdates: true })
                    .then(() => console.log(`🤖 Cloned Bot @${botInfo.username} online.`))
                    .catch(err => console.error("Cloned bot launch error:", err.message));
                activeClonedBots.push(clonedBot);

                // e) Reply to Admin
                return ctx.reply(`✅ Clone Bot Activated Successfully! The new bot (@${botInfo.username}) is now live with 100% full Win Nova functionality.`);
            } catch (err) {
                return ctx.reply(`❌ Failed to activate cloned bot: ${err.message}`);
            }
        }

        return next();
    });

    // ==========================================
    // 🎮 ALL PLAYER BUTTON HANDLERS (7 BUTTONS)
    // ==========================================
    bot.hears(/Fetch Signal/i, async (ctx) => {
        const userId = ctx.from.id;
        let user = null;
        if (mongoose.connection.readyState === 1) {
            user = await BotUser.findOne({ telegramId: userId });
        } else {
            user = inMemoryUsers.get(userId);
        }

        if (!user || (!user.activeSubscription && userId !== HARDLOCKED_ADMIN_ID)) {
            return ctx.reply(`👑 **VIP Pass Required**\n\nPrice: ₹${winNovaSettingsCache.baseSubRate}/Month\nClick '👑 VIP Plan Activation' to upgrade.`);
        }
        if (user.creditBalance < 1 && userId !== HARDLOCKED_ADMIN_ID) {
            return ctx.reply("🪙 **Insufficient Credits!**\nBuy credits using '🪙 Buy Custom Credits' or claim daily credits.");
        }

        if (currentRound.status === 'CRASHED') {
            return ctx.reply("⏳ **ROUND CRASHED!**\nPlease wait 3 seconds for the next live round telemetry sync to calibrate.", { parse_mode: 'Markdown' });
        }

        let activeRoundId = currentRound.roundId;
        let activeMultiplier = currentRound.targetMultiplier;
        let telemetrySyncNote = '⚡ Synchronized directly with Live Casino Telemetry.';

        const safeCashout = Math.max(1.05, parseFloat((activeMultiplier * 0.82).toFixed(2)));

        const msg = `🚀 **WIN NOVA REAL TELEMETRY SIGNAL**\n\n` +
                    `🆔 **Round ID:** #${activeRoundId}\n` +
                    `📈 **Estimated Multiplier:** \`${activeMultiplier.toFixed(2)}x\`\n` +
                    `🛡️ **Safe Cashout:** \`${safeCashout.toFixed(2)}x\` *(82% High-Win Safety, min 1.05x)*\n\n` +
                    `${telemetrySyncNote}`;

        await ctx.reply(msg, { parse_mode: 'Markdown' });

        if (userId !== HARDLOCKED_ADMIN_ID) {
            if (mongoose.connection.readyState === 1) {
                await BotUser.findOneAndUpdate({ telegramId: userId }, { $inc: { creditBalance: -1 } });
            } else {
                user.creditBalance = Math.max(0, user.creditBalance - 1);
            }
        }
    });

    // FIXED: DYNAMIC PERCENTAGE-BASED TAX CALCULATOR
    bot.hears(/(Buy Custom Credits|🪙 Buy Custom Credits)/i, (ctx) => {
        userStates.set(ctx.from.id, 'WAITING_FOR_CREDIT_AMOUNT');
        return ctx.reply("✏️ Enter quantity of credits:");
    });

    bot.hears(/Claim Daily 2 Credits/i, async (ctx) => {
        const userId = ctx.from.id;
        const today = new Date().toISOString().split('T')[0];
        let user = null;
        if (mongoose.connection.readyState === 1) {
            user = await BotUser.findOne({ telegramId: userId });
        } else {
            user = inMemoryUsers.get(userId);
        }

        if (!user) return ctx.reply("❌ User record not found.");
        if (user.lastClaimDate === today) return ctx.reply("⏳ You have already claimed your daily 2 credits today. Come back tomorrow!");

        if (user.dailyReferralCount < 1 && userId !== HARDLOCKED_ADMIN_ID) {
            return ctx.reply("⚠️ **Daily Claim Condition:**\nYou need to refer at least 1 user today before claiming daily credits.");
        }

        if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate({ telegramId: userId }, {
                $inc: { creditBalance: 2 },
                lastClaimDate: today,
                dailyReferralCount: 0
            });
        } else {
            user.creditBalance = (user.creditBalance || 0) + 2;
            user.lastClaimDate = today;
            user.dailyReferralCount = 0;
        }

        return ctx.reply("🎉 **2 Credits Claimed Successfully!**");
    });

    bot.hears(/VIP Plan Activation/i, (ctx) => {
        const adminUpiId = winNovaSettingsCache.adminUpiId;
        const totalAmount = winNovaSettingsCache.baseSubRate;
        const upiUrl = `upi://pay?pa=${adminUpiId}&pn=WinNova&am=${totalAmount}`;
        const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiUrl)}`;

        const vipMsg = `👑 **WIN NOVA VIP PLAN ACTIVATION**\n\n` +
                       `💎 Plan: **VIP Monthly Pass (30 Days)**\n` +
                       `💰 Total Amount: **₹${totalAmount}**\n` +
                       `💳 Admin UPI ID: \`${adminUpiId}\`\n\n` +
                       `🔗 **Dynamic QR Code:**\n${qrApiUrl}\n\n` +
                       `Pay ₹${totalAmount} via UPI to \`${adminUpiId}\` or scan the dynamic QR code above and share payment transaction proof for instant VIP activation.`;

        return ctx.replyWithPhoto({ url: qrApiUrl }, { caption: vipMsg, parse_mode: 'Markdown' }).catch(() => {
            return ctx.reply(vipMsg, { parse_mode: 'Markdown' });
        });
    });

    bot.hears(/My Wallet/i, async (ctx) => {
        const userId = ctx.from.id;
        try {
            const user = await BotUser.findOne({ telegramId: userId });
            if (!user) return ctx.reply("❌ User record nahi mila.");

            const totalRef = await BotUser.countDocuments({ referredBy: userId });
            const activeRefsCount = await BotUser.countDocuments({ referredBy: userId, activeSubscription: true });

            const msg = `💼 **MY WALLET & REFERRAL CONTROL PANEL**\n\n` +
                        `👤 Telegram ID: \`${userId}\`\n` +
                        `🪙 Present Credit Balance: **${user.creditBalance}**\n` +
                        `📊 Lifetime Total Credits Earned: **${user.totalCreditsEarned || 0}**\n` +
                        `👑 VIP Status: **${user.activeSubscription ? 'ACTIVE ✅' : 'INACTIVE ❌'}**\n` +
                        `👥 Total Referrals Made: **${totalRef}**\n` +
                        `💎 Active VIP Referrals: **${activeRefsCount}**\n\n` +
                        `🔗 **Aapka Referral Link:**\nhttps://t.me/Thakku67bot?start=ref_${userId}\n\n` +
                        `📌 *Rule: Har successful referral par daily credit claim unlock hota hai.*`;

            return ctx.reply(msg, { parse_mode: 'Markdown' });
        } catch (err) {
            console.error("Wallet Error:", err);
            return ctx.reply("❌🚫 Error fetching wallet and referral details.");
        }
    });

    bot.hears(/Top 10 Leaderboard/i, async (ctx) => {
        let topUsers = [];
        if (mongoose.connection.readyState === 1) {
            topUsers = await BotUser.find({ isBanned: false }).sort({ creditBalance: -1 }).limit(10);
        } else {
            topUsers = Array.from(inMemoryUsers.values()).filter(u => !u.isBanned).sort((a, b) => b.creditBalance - a.creditBalance).slice(0, 10);
        }

        let msg = `🏆 **TOP 10 WIN NOVA PLAYERS**\n\n`;
        topUsers.forEach((u, i) => {
            msg += `${i + 1}. \`${u.username || u.telegramId}\` - 🪙 **${u.creditBalance} Credits**\n`;
        });
        return ctx.reply(msg, { parse_mode: 'Markdown' });
    });

    bot.hears(/Check Session Status/i, (ctx) => {
        return ctx.reply(`🟢 **LIVE TELEMETRY STATUS**\n\n• Active Round ID: **#${currentRound.roundId}**\n• Round Status: **${currentRound.status}**\n• Telemetry Engine: **ONLINE 24/7**`);
    });

    // ==========================================
    // 👑 ALL SUPER ADMIN BUTTON HANDLERS (10 BUTTONS)
    // ==========================================
    bot.hears(/Total Users/i, async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        let users = [];
        if (mongoose.connection.readyState === 1) {
            users = await BotUser.find({}).sort({ creditBalance: -1 }).lean();
        } else {
            users = Array.from(inMemoryUsers.values()).sort((a, b) => (b.creditBalance || 0) - (a.creditBalance || 0));
        }

        const count = users.length;
        const vips = users.filter(u => u.activeSubscription).length;
        const totalSystemCredits = users.reduce((acc, u) => acc + (u.creditBalance || 0), 0);

        let report = `📊 **DETAILED USER AUDIT REPORT**\n\n` +
                     `👥 Total Registered: **${count}** | 👑 VIPs: **${vips}**\n` +
                     `🪙 Total System Credits: **${totalSystemCredits}**\n` +
                     `───────────────────────\n`;

        const displayUsers = users.slice(0, 15);
        displayUsers.forEach((u, i) => {
            const share = totalSystemCredits > 0 ? (((u.creditBalance || 0) / totalSystemCredits) * 100).toFixed(1) : '0.0';
            const status = u.activeSubscription ? '👑 VIP' : '🆓 Free';
            const uname = u.username ? `@${u.username}` : `ID:${u.telegramId}`;
            const earned = u.totalCreditsEarned ?? u.creditBalance ?? 0;
            const refs = u.totalReferrals ?? u.dailyReferralCount ?? 0;

            report += `${i + 1}. **${uname}** (\`${u.telegramId}\`)\n` +
                      `   • Status: ${status} | Balance: 🪙 **${u.creditBalance ?? 0}**\n` +
                      `   • Lifetime Earned: **${earned}** | Pool Share: **${share}%**\n` +
                      `   • Referrals: **${refs}**\n\n`;
        });

        if (users.length > 15) {
            report += `ℹ️ *...and ${users.length - 15} more profiles. Check Web Dashboard for full list.*`;
        }

        return ctx.reply(report, { parse_mode: 'Markdown' });
    });

    bot.hears(/View Live Logs/i, (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        return ctx.reply(`📋 **SYSTEM LIVE LOGS**\n\n• Server Status: **Operational**\n• Round ID: **#${currentRound.roundId}**\n• Current Multiplier Target: **${currentRound.targetMultiplier}x**`);
    });

    bot.hears(/Bot Settings/i, (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        return ctx.reply(`⚙️ **BOT CONFIGURATION**\n\n• VIP Monthly Rate: ₹${winNovaSettingsCache.baseSubRate}\n• Credit Price: ₹${winNovaSettingsCache.creditRate}\n• Tax Rate: ${winNovaSettingsCache.taxPercent}%\n• Referral Commission: ${winNovaSettingsCache.commissionPercent}%\n• Admin UPI ID: \`${winNovaSettingsCache.adminUpiId}\``);
    });

    bot.hears(/(Change Base Rates|🏷️ Change Base Rates)/i, (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        userStates.set(ctx.from.id, 'WAITING_FOR_VIP_RATE');
        return ctx.reply("✏️ Send the new VIP Monthly Pass Rate (in ₹):");
    });

    bot.hears(/(Set Admin UPI ID|💳 Set Admin UPI ID)/i, (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        userStates.set(ctx.from.id, 'WAITING_FOR_UPI_ID');
        return ctx.reply("💳 Send your new Admin UPI ID:");
    });

    bot.hears(/(Global Broadcast|📢 Global Broadcast)/i, (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        userStates.set(ctx.from.id, 'WAITING_FOR_BROADCAST_MSG');
        return ctx.reply("📢 Send broadcast text:");
    });

    bot.hears(/Referral Control Panel/i, (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        return ctx.reply(`👥 **REFERRAL PANEL**\n\n• Commission Percent: ${winNovaSettingsCache.commissionPercent}%\n• Daily Free Credits Reward: 2 Credits / Day`);
    });

    bot.hears(/(Clone Bot via API|🤖 Clone Bot via API)/i, (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        userStates.set(ctx.from.id, 'WAITING_FOR_CLONE_TOKEN');
        return ctx.reply("🤖 Send Bot API Token:");
    });

    bot.hears(/Open Admin Web Dashboard Link/i, (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        return ctx.reply(`🖥️ **ADMIN DASHBOARD LINK:**\n${winNovaSettingsCache.dynamicWebsiteUrl}/admin-control.html`);
    });

    bot.hears(/Manual Approval Panel/i, (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        return ctx.reply("💳 **APPROVAL PANEL:** No pending deposit screenshots in queue.");
    });

    // ==========================================
    // 🔔 ADMIN NOTIFICATION PREFERENCE HANDLERS
    // ==========================================
    bot.action('admin_notify_on', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return ctx.answerCbQuery("Unauthorized!");

        isAdminNotificationOn = true;
        if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate({ telegramId: HARDLOCKED_ADMIN_ID }, { adminNotifyEnabled: true }).catch(() => {});
        }
        await ctx.answerCbQuery();
        return ctx.editMessageText("✅ **Real-Time Notifications ON ho gaye hain.**\n\nIsse OFF karne ke liye kisi bhi waqt `/off` command bhejein.", { parse_mode: 'Markdown' });
    });

    bot.action('admin_notify_off', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return ctx.answerCbQuery("Unauthorized!");

        isAdminNotificationOn = false;
        if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate({ telegramId: HARDLOCKED_ADMIN_ID }, { adminNotifyEnabled: false }).catch(() => {});
        }
        await ctx.answerCbQuery();
        return ctx.editMessageText("❌ **Real-Time Notifications OFF kar diye gaye hain.**\n\nDobara ON karne ke liye `/start` karein.", { parse_mode: 'Markdown' });
    });

    // Direct /off Command Handler
    bot.command('off', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;

        isAdminNotificationOn = false;
        if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate({ telegramId: HARDLOCKED_ADMIN_ID }, { adminNotifyEnabled: false }).catch(() => {});
        }
        return ctx.reply("🔇 **Real-Time Notifications OFF ho chuke hain.**");
    });

    // Master Commands for Supreme Admin
    bot.command('give_credit', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const targetId = Number(args[1]);
        const amount = parseInt(args[2], 10);
        if (!targetId || isNaN(amount)) return ctx.reply("❌ Usage: /give_credit <chatId> <amount>");

        if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate(
                { telegramId: targetId },
                { $inc: { creditBalance: amount, totalCreditsEarned: Math.max(0, amount) } },
                { upsert: true, new: true }
            );
        }
        const u = inMemoryUsers.get(targetId);
        if (u) u.creditBalance = (u.creditBalance || 0) + amount;

        try {
            mainBot.telegram.sendMessage(targetId, `🎁 **System Update:** Admin has added **${amount} Credits** to your account!`, { parse_mode: 'Markdown' }).catch(() => {});
        } catch (_) {}
        return ctx.reply(`✅ Added **${amount} credits** to User \`${targetId}\``);
    });

    bot.command('deduct_credit', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const targetId = Number(args[1]);
        const amount = parseInt(args[2], 10);
        if (!targetId || isNaN(amount)) return ctx.reply("❌ Usage: /deduct_credit <chatId> <amount>");

        if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate(
                { telegramId: targetId },
                { $inc: { creditBalance: -amount } },
                { new: true }
            );
        }
        const u = inMemoryUsers.get(targetId);
        if (u) u.creditBalance = Math.max(0, (u.creditBalance || 0) - amount);

        return ctx.reply(`✅ Deducted **${amount} credits** from User \`${targetId}\``);
    });

    bot.command('set_credit', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const targetId = Number(args[1]);
        const amount = parseInt(args[2], 10);
        if (!targetId || isNaN(amount)) return ctx.reply("❌ Usage: /set_credit <chatId> <amount>");

        if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate(
                { telegramId: targetId },
                { creditBalance: amount },
                { upsert: true, new: true }
            );
        }
        const u = inMemoryUsers.get(targetId);
        if (u) u.creditBalance = amount;

        return ctx.reply(`✅ Credit balance for User \`${targetId}\` set to **${amount}**`);
    });

    bot.command('set_vip', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const targetId = Number(args[1]);
        const isVip = args[2] === 'true';
        if (!targetId || (args[2] !== 'true' && args[2] !== 'false')) {
            return ctx.reply("❌ Usage: /set_vip <chatId> <true/false>");
        }

        if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate(
                { telegramId: targetId },
                { activeSubscription: isVip },
                { upsert: true, new: true }
            );
        }
        const u = inMemoryUsers.get(targetId);
        if (u) u.activeSubscription = isVip;

        try {
            mainBot.telegram.sendMessage(targetId, `👑 **VIP Status Update:** Your VIP pass is now **${isVip ? "ACTIVE ✅" : "INACTIVE ❌"}**.`, { parse_mode: 'Markdown' }).catch(() => {});
        } catch (_) {}
        return ctx.reply(`✅ User \`${targetId}\` VIP status set to **${isVip}**`);
    });

    bot.command('ban', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const targetId = Number(args[1]);
        if (!targetId) return ctx.reply("❌ Usage: /ban <chatId>");
        if (targetId === HARDLOCKED_ADMIN_ID) return ctx.reply("❌ Cannot ban Supreme Admin");

        if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate({ telegramId: targetId }, { isBanned: true });
        }
        const u = inMemoryUsers.get(targetId);
        if (u) u.isBanned = true;

        return ctx.reply(`🚫 User \`${targetId}\` is now **BANNED**`);
    });

    bot.command('unban', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const targetId = Number(args[1]);
        if (!targetId) return ctx.reply("❌ Usage: /unban <chatId>");

        if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate({ telegramId: targetId }, { isBanned: false });
        }
        const u = inMemoryUsers.get(targetId);
        if (u) u.isBanned = false;

        return ctx.reply(`✅ User \`${targetId}\` is now **UNBANNED**`);
    });

    bot.command('check', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const targetId = Number(args[1]);
        if (!targetId) return ctx.reply("❌ Usage: /check <chatId>");

        let u = null;
        if (mongoose.connection.readyState === 1) {
            u = await BotUser.findOne({ telegramId: targetId }).lean();
        } else {
            u = inMemoryUsers.get(targetId);
        }

        if (!u) return ctx.reply(`❌ User \`${targetId}\` not found in database.`);
        return ctx.reply(
            `👤 **USER AUDIT PROFILE**\n\n` +
            `• ID: \`${u.telegramId}\`\n` +
            `• Username: @${u.username || 'None'}\n` +
            `• VIP Status: ${u.activeSubscription ? '👑 VIP' : '🆓 Free'}\n` +
            `• Balance: 🪙 **${u.creditBalance ?? 0}**\n` +
            `• Lifetime Earned: **${u.totalCreditsEarned ?? 0}**\n` +
            `• Referrals: **${u.totalReferrals ?? 0}**\n` +
            `• Banned: ${u.isBanned ? '🚫 YES' : '✅ NO'}`
        );
    });

    bot.command('set_vip_price', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const rate = parseInt(args[1], 10);
        if (isNaN(rate) || rate <= 0) return ctx.reply("❌ Usage: /set_vip_price <amount>");

        winNovaSettingsCache.baseSubRate = rate;
        if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { baseSubRate: rate }, { upsert: true, new: true });
        }
        return ctx.reply(`✅ VIP Monthly Pass Rate set to **₹${rate}**`);
    });

    bot.command('set_credit_price', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const rate = parseInt(args[1], 10);
        if (isNaN(rate) || rate <= 0) return ctx.reply("❌ Usage: /set_credit_price <amount>");

        winNovaSettingsCache.creditRate = rate;
        if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { creditRate: rate }, { upsert: true, new: true });
        }
        return ctx.reply(`✅ Credit Unit Rate set to **₹${rate}/credit**`);
    });

    bot.command('set_tax', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const tax = parseFloat(args[1]);
        if (isNaN(tax) || tax < 0) return ctx.reply("❌ Usage: /set_tax <percent>");

        winNovaSettingsCache.taxPercent = tax;
        if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { taxPercent: tax }, { upsert: true, new: true });
        }
        return ctx.reply(`✅ Dynamic Tax Rate set to **${tax}%**`);
    });

    bot.command('set_commission', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const comm = parseFloat(args[1]);
        if (isNaN(comm) || comm < 0) return ctx.reply("❌ Usage: /set_commission <percent>");

        winNovaSettingsCache.commissionPercent = comm;
        if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { commissionPercent: comm }, { upsert: true, new: true });
        }
        return ctx.reply(`✅ Referral Commission set to **${comm}%**`);
    });

    bot.command('set_upi', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const upi = args[1]?.trim();
        if (!upi) return ctx.reply("❌ Usage: /set_upi <upiId>");

        winNovaSettingsCache.adminUpiId = upi;
        if (mongoose.connection.readyState === 1) {
            await AdminSettings.findOneAndUpdate({ id: 1 }, { adminUpiId: upi }, { upsert: true, new: true });
        }
        return ctx.reply(`✅ Admin UPI ID updated to: \`${upi}\``);
    });

    bot.command('set_next_mult', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const args = (ctx.message.text || '').trim().split(/\s+/);
        const mult = parseFloat(args[1]);
        if (isNaN(mult) || mult < 1.0) return ctx.reply("❌ Usage: /set_next_mult <multiplier>");

        currentRound.nextRoundMultiplier = mult;
        return ctx.reply(`🎯 Next Round Crash Multiplier overridden to **${mult}x**!`);
    });

    bot.command('broadcast', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        const text = (ctx.message.text || '').replace(/^\/broadcast\s*/i, '').trim();
        if (!text) return ctx.reply("❌ Usage: /broadcast <message>");

        let users = [];
        if (mongoose.connection.readyState === 1) {
            users = await BotUser.find({ isBanned: false });
        } else {
            users = Array.from(inMemoryUsers.values()).filter(u => !u.isBanned);
        }
        let sent = 0;
        for (const u of users) {
            try {
                await mainBot.telegram.sendMessage(u.telegramId, `📢 **ADMIN BROADCAST:**\n\n${text}`, { parse_mode: 'Markdown' });
                sent++;
            } catch (_) {}
        }
        return ctx.reply(`✅ Broadcast sent to **${sent}** users.`);
    });

    bot.command('admin_help', async (ctx) => {
        if (ctx.from.id !== HARDLOCKED_ADMIN_ID) return;
        return ctx.reply(
            `👑 **WIN NOVA MASTER ADMIN TERMINAL**\n──────────────────────────\n` +
            `**User Control:**\n` +
            `• \`/check <chatId>\` - View user data\n` +
            `• \`/give_credit <chatId> <amt>\` - Add credits\n` +
            `• \`/deduct_credit <chatId> <amt>\` - Deduct credits\n` +
            `• \`/set_credit <chatId> <amt>\` - Set exact credits\n` +
            `• \`/set_vip <chatId> <true/false>\` - Toggle VIP\n` +
            `• \`/ban <chatId>\` | \`/unban <chatId>\` - Ban/Unban\n\n` +
            `**System & Telemetry:**\n` +
            `• \`/set_vip_price <amt>\` - VIP price\n` +
            `• \`/set_credit_price <amt>\` - Credit rate\n` +
            `• \`/set_tax <percent>\` - Dynamic tax\n` +
            `• \`/set_commission <percent>\` - Commission\n` +
            `• \`/set_upi <upiId>\` - Admin UPI\n` +
            `• \`/set_next_mult <mult>\` - Force crash multiplier\n` +
            `• \`/broadcast <text>\` - Broadcast immediately\n` +
            `• \`/off\` - Turn off round notifications\n` +
            `──────────────────────────`
        );
    });
}

// Bind handlers
setupBotHandlers(mainBot);
if (isDualBot) {
    setupBotHandlers(notifyBot);
}

// ==========================================
// 🛡️ RECOVERY ENGINE & 24/7 BOOT
// ==========================================
process.on('uncaughtException', (err) => console.error('Uncaught Exception:', err?.message || err));
process.on('unhandledRejection', (reason) => console.error('Unhandled Rejection:', reason?.message || reason));

app.get('/api/live-telemetry', (_req, res) => res.json(currentRound));
app.get('/api/ping', (_req, res) => res.json({ status: 'online', uptime: process.uptime() }));

// ==========================================
// 🛡️ SUB-ADMIN RBAC AUTH MIDDLEWARE
// ==========================================
async function verifyAdminAuth(req, res, requiredPermission) {
    const authHeader = req.headers.authorization || '';
    const adminKey = req.headers['x-admin-key'] || req.query.adminKey || (authHeader.startsWith('Bearer ') ? authHeader.slice(7) : authHeader);

    // Supreme Admin Master Key bypass
    if (adminKey === 'supreme_jack_7939005883' || adminKey === String(HARDLOCKED_ADMIN_ID)) {
        return { isSupreme: true, username: 'Supreme Architect Jack' };
    }

    if (!adminKey) {
        res.status(401).json({ status: 'error', message: 'Authentication token required' });
        return null;
    }

    let subAdmin = null;
    if (mongoose.connection.readyState === 1) {
        subAdmin = await SubAdmin.findOne({ token: adminKey }).lean();
    } else {
        subAdmin = Array.from(inMemorySubAdmins.values()).find(s => s.token === adminKey);
    }

    if (!subAdmin) {
        res.status(403).json({ status: 'error', message: 'Invalid or expired Sub-Admin credentials' });
        return null;
    }

    if (requiredPermission && !subAdmin[requiredPermission]) {
        res.status(403).json({
            status: 'error',
            message: `Permission Denied: '${requiredPermission}' required. Contact Supreme Admin.`
        });
        return null;
    }

    return { isSupreme: false, username: subAdmin.username, permissions: subAdmin };
}

// Sub-Admin Login Endpoint
app.post('/api/admin/login', async (req, res) => {
    try {
        const { username, password } = req.body || {};
        if (!username || !password) return res.status(400).json({ error: 'Username and password required' });

        if (username === 'admin' && password === 'jack7939005883') {
            return res.json({
                success: true,
                token: 'supreme_jack_7939005883',
                role: 'supreme_admin',
                permissions: {
                    canManageTelegramBot: true,
                    canManageRates: true,
                    canManageUPI: true,
                    canBroadcast: true
                }
            });
        }

        let sub = null;
        if (mongoose.connection.readyState === 1) {
            sub = await SubAdmin.findOne({ username, password });
        } else {
            sub = inMemorySubAdmins.get(username);
            if (sub && sub.password !== password) sub = null;
        }

        if (!sub) return res.status(401).json({ error: 'Invalid username or password' });

        const sessionToken = `sub_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
        if (mongoose.connection.readyState === 1) {
            await SubAdmin.findOneAndUpdate({ username }, { token: sessionToken });
        } else {
            sub.token = sessionToken;
            inMemorySubAdmins.set(username, sub);
        }

        return res.json({
            success: true,
            token: sessionToken,
            role: 'sub_admin',
            permissions: {
                canManageTelegramBot: sub.canManageTelegramBot,
                canManageRates: sub.canManageRates,
                canManageUPI: sub.canManageUPI,
                canBroadcast: sub.canBroadcast
            }
        });
    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
});

// Sub-Admin Management (Supreme Admin only)
app.get('/api/admin/sub-admins', async (req, res) => {
    const auth = await verifyAdminAuth(req, res);
    if (!auth) return;
    if (!auth.isSupreme) return res.status(403).json({ error: 'Only Supreme Admin can manage Sub-Admins' });

    let list = [];
    if (mongoose.connection.readyState === 1) {
        list = await SubAdmin.find({}).select('-password').lean();
    } else {
        list = Array.from(inMemorySubAdmins.values()).map(s => {
            const { password, ...rest } = s;
            return rest;
        });
    }
    return res.json({ success: true, subAdmins: list });
});

app.post('/api/admin/sub-admins', async (req, res) => {
    const auth = await verifyAdminAuth(req, res);
    if (!auth) return;
    if (!auth.isSupreme) return res.status(403).json({ error: 'Only Supreme Admin can create/edit Sub-Admins' });

    const { username, password, canManageTelegramBot, canManageRates, canManageUPI, canBroadcast } = req.body || {};
    if (!username) return res.status(400).json({ error: 'Username required' });

    const updateData = {
        canManageTelegramBot: Boolean(canManageTelegramBot),
        canManageRates: Boolean(canManageRates),
        canManageUPI: Boolean(canManageUPI),
        canBroadcast: Boolean(canBroadcast)
    };
    if (password) updateData.password = password;

    if (mongoose.connection.readyState === 1) {
        await SubAdmin.findOneAndUpdate({ username }, { $set: updateData }, { upsert: true, new: true });
    } else {
        const existing = inMemorySubAdmins.get(username) || { username, password: password || 'sub123' };
        Object.assign(existing, updateData);
        inMemorySubAdmins.set(username, existing);
    }

    return res.json({ success: true, message: `Sub-Admin '${username}' updated successfully` });
});

// Web Dashboard API Endpoints for Single Source of Truth
app.get('/api/admin/bot-stats', async (req, res) => {
    try {
        let users = [];
        if (mongoose.connection.readyState === 1) {
            users = await BotUser.find({}).sort({ creditBalance: -1 }).lean();
        } else {
            users = Array.from(inMemoryUsers.values()).sort((a, b) => (b.creditBalance || 0) - (a.creditBalance || 0));
        }

        const totalUsers = users.length;
        const totalSystemCredits = users.reduce((acc, u) => acc + (u.creditBalance || 0), 0);

        // Granular calculations for each user
        const enrichedUsers = users.map(u => ({
            telegramId: u.telegramId,
            username: u.username || 'Anonymous',
            firstName: u.firstName || u.username || 'Pilot',
            activeSubscription: Boolean(u.activeSubscription),
            creditBalance: u.creditBalance || 0,
            totalCreditsEarned: u.totalCreditsEarned ?? u.creditBalance ?? 0,
            totalReferrals: u.totalReferrals ?? u.dailyReferralCount ?? 0,
            poolPercentageShare: totalSystemCredits > 0 ? Number((((u.creditBalance || 0) / totalSystemCredits) * 100).toFixed(2)) : 0,
            isBanned: Boolean(u.isBanned),
            role: Number(u.telegramId) === HARDLOCKED_ADMIN_ID ? 'super_admin' : (u.isBanned ? 'banned' : 'user')
        }));

        return res.json({
            totalUsers,
            totalSystemCredits,
            totalLogs: 120,
            systemMode: 'Live Sync',
            config: winNovaSettingsCache,
            users: enrichedUsers
        });
    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
});

app.post('/api/admin/rates', async (req, res) => {
    const auth = await verifyAdminAuth(req, res, 'canManageRates');
    if (!auth) return;

    try {
        const { subRate, creditRate, upiId, webUrl, taxPercent, commissionPercent } = req.body || {};
        const updates = {};
        if (subRate !== undefined && !isNaN(Number(subRate))) updates.baseSubRate = Number(subRate);
        if (creditRate !== undefined && !isNaN(Number(creditRate))) updates.creditRate = Number(creditRate);
        if (taxPercent !== undefined && !isNaN(Number(taxPercent))) updates.taxPercent = Number(taxPercent);
        if (commissionPercent !== undefined && !isNaN(Number(commissionPercent))) updates.commissionPercent = Number(commissionPercent);
        if (upiId && typeof upiId === 'string' && upiId.trim()) updates.adminUpiId = upiId.trim();
        if (webUrl && typeof webUrl === 'string' && webUrl.trim()) updates.dynamicWebsiteUrl = webUrl.trim();

        if (mongoose.connection.readyState === 1) {
            const updated = await AdminSettings.findOneAndUpdate(
                { id: 1 },
                updates,
                { upsert: true, new: true }
            );
            if (updated) {
                if (updated.baseSubRate != null) winNovaSettingsCache.baseSubRate = updated.baseSubRate;
                if (updated.creditRate != null) winNovaSettingsCache.creditRate = updated.creditRate;
                if (updated.taxPercent != null) winNovaSettingsCache.taxPercent = updated.taxPercent;
                if (updated.commissionPercent != null) winNovaSettingsCache.commissionPercent = updated.commissionPercent;
                if (updated.adminUpiId) winNovaSettingsCache.adminUpiId = updated.adminUpiId;
                if (updated.dynamicWebsiteUrl) winNovaSettingsCache.dynamicWebsiteUrl = updated.dynamicWebsiteUrl;
            }
        } else {
            if (updates.baseSubRate != null) winNovaSettingsCache.baseSubRate = updates.baseSubRate;
            if (updates.creditRate != null) winNovaSettingsCache.creditRate = updates.creditRate;
            if (updates.taxPercent != null) winNovaSettingsCache.taxPercent = updates.taxPercent;
            if (updates.commissionPercent != null) winNovaSettingsCache.commissionPercent = updates.commissionPercent;
            if (updates.adminUpiId) winNovaSettingsCache.adminUpiId = updates.adminUpiId;
            if (updates.dynamicWebsiteUrl) winNovaSettingsCache.dynamicWebsiteUrl = updates.dynamicWebsiteUrl;
        }

        return res.json({ status: 'success', message: 'Settings updated permanently', config: winNovaSettingsCache });
    } catch (err) {
        return res.status(500).json({ status: 'error', message: err.message });
    }
});

app.post('/api/admin/broadcast', async (req, res) => {
    const auth = await verifyAdminAuth(req, res, 'canBroadcast');
    if (!auth) return;

    try {
        const { message } = req.body || {};
        if (!message) return res.status(400).json({ success: false, message: 'Message cannot be empty' });
        let users = [];
        if (mongoose.connection.readyState === 1) {
            users = await BotUser.find({ isBanned: false });
        } else {
            users = Array.from(inMemoryUsers.values()).filter(u => !u.isBanned);
        }
        let sent = 0;
        for (const u of users) {
            try {
                await mainBot.telegram.sendMessage(u.telegramId, `📢 **ADMIN BROADCAST:**\n\n${message}`, { parse_mode: 'Markdown' });
                sent++;
            } catch (_) {}
        }
        return res.json({ success: true, message: `Broadcast sent to ${sent} users` });
    } catch (err) {
        return res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/admin/ban-user', async (req, res) => {
    const auth = await verifyAdminAuth(req, res, 'canManageTelegramBot');
    if (!auth) return;

    try {
        const { telegramId, ban } = req.body || {};
        if (!telegramId) return res.status(400).json({ error: 'telegramId is required' });
        if (Number(telegramId) === HARDLOCKED_ADMIN_ID) return res.status(400).json({ error: 'Cannot ban Supreme Admin' });

        if (mongoose.connection.readyState === 1) {
            await BotUser.findOneAndUpdate({ telegramId }, { isBanned: Boolean(ban) });
        } else {
            const u = inMemoryUsers.get(Number(telegramId));
            if (u) u.isBanned = Boolean(ban);
        }
        return res.json({ success: true, message: `User ${ban ? 'banned' : 'unbanned'} successfully` });
    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
});

// Master User Data Update Endpoint (Credits, VIP, Role, Bans)
app.post('/api/admin/update-user', async (req, res) => {
    const auth = await verifyAdminAuth(req, res, 'canManageTelegramBot');
    if (!auth) return;

    const { telegramId, creditBalance, deltaCredits, activeSubscription, isBanned, role } = req.body || {};
    const numId = Number(telegramId);
    if (!numId) return res.status(400).json({ error: 'Valid telegramId required' });

    try {
        const updateFields = {};
        if (creditBalance !== undefined && !isNaN(Number(creditBalance))) {
            updateFields.creditBalance = Number(creditBalance);
        }
        if (activeSubscription !== undefined) {
            updateFields.activeSubscription = Boolean(activeSubscription);
        }
        if (isBanned !== undefined) {
            updateFields.isBanned = Boolean(isBanned);
        }
        if (role && typeof role === 'string') {
            updateFields.role = role;
        }

        let updatedDoc = null;
        if (mongoose.connection.readyState === 1) {
            if (deltaCredits !== undefined && !isNaN(Number(deltaCredits))) {
                updatedDoc = await BotUser.findOneAndUpdate(
                    { telegramId: numId },
                    { $inc: { creditBalance: Number(deltaCredits), totalCreditsEarned: Math.max(0, Number(deltaCredits)) }, $set: updateFields },
                    { upsert: true, new: true }
                );
            } else {
                updatedDoc = await BotUser.findOneAndUpdate(
                    { telegramId: numId },
                    { $set: updateFields },
                    { upsert: true, new: true }
                );
            }
        }

        const memUser = inMemoryUsers.get(numId);
        if (memUser) {
            if (updateFields.creditBalance !== undefined) memUser.creditBalance = updateFields.creditBalance;
            if (deltaCredits !== undefined) memUser.creditBalance = (memUser.creditBalance || 0) + Number(deltaCredits);
            if (updateFields.activeSubscription !== undefined) memUser.activeSubscription = updateFields.activeSubscription;
            if (updateFields.isBanned !== undefined) memUser.isBanned = updateFields.isBanned;
            if (updateFields.role) memUser.role = updateFields.role;
        }

        return res.json({
            success: true,
            message: `User ${numId} updated successfully`,
            user: updatedDoc || memUser
        });
    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
});

// Telemetry Crash Multiplier Override Endpoint
app.post('/api/admin/set-next-mult', async (req, res) => {
    const auth = await verifyAdminAuth(req, res, 'canManageRates');
    if (!auth) return;

    const { multiplier } = req.body || {};
    const mult = parseFloat(multiplier);
    if (isNaN(mult) || mult < 1.0) {
        return res.status(400).json({ success: false, message: 'Valid multiplier >= 1.0 is required' });
    }

    currentRound.nextRoundMultiplier = mult;
    return res.json({
        success: true,
        message: `Next crash target multiplier overridden to ${mult}x`,
        nextRoundMultiplier: mult
    });
});

// Fallback for SPA
app.get('*', (_req, res) => {
    const distIndex = path.join(DIST_DIR, 'index.html');
    if (fs.existsSync(distIndex)) return res.sendFile(distIndex);
    const publicIndex = path.join(PUBLIC_DIR, 'index.html');
    if (fs.existsSync(publicIndex)) return res.sendFile(publicIndex);
    return res.sendFile(path.join(PUBLIC_DIR, 'admin-control.html'));
});

async function startEngine() {
    try {
        await mongoose.connect(MONGO_URI, { serverSelectionTimeoutMS: 2000 })
            .then(async () => {
                console.log("✅ Universal Database Sync Online.");
                await refreshMemoryCache();
            })
            .catch((err) => {
                console.warn("⚠️ MongoDB deferred, holding hot RAM fallback:", err.message);
            });

        await mainBot.telegram.deleteWebhook({ drop_pending_updates: true }).catch((e) => console.warn("mainBot webhook notice:", e.message));
        if (isDualBot) {
            await notifyBot.telegram.deleteWebhook({ drop_pending_updates: true }).catch((e) => console.warn("notifyBot webhook notice:", e.message));
        }

        mainBot.launch({ allowedUpdates: ['message', 'callback_query'], dropPendingUpdates: true })
            .then(() => console.log("🤖 Main Bot Polling Active."))
            .catch((err) => console.error("⚠️ Main bot launch error:", err.message));

        if (isDualBot) {
            notifyBot.launch({ allowedUpdates: ['message', 'callback_query'], dropPendingUpdates: true })
                .then(() => console.log("🤖 Notification Bot Polling Active."))
                .catch((err) => console.error("⚠️ Notification bot launch error:", err.message));
        }

        // Load and launch all cloned bots saved in DB
        if (mongoose.connection.readyState === 1) {
            try {
                const savedClones = await ClonedBot.find({});
                for (const cloneDoc of savedClones) {
                    try {
                        const cBot = new Telegraf(cloneDoc.token);
                        setupBotHandlers(cBot);
                        await cBot.telegram.deleteWebhook({ drop_pending_updates: true }).catch(() => {});
                        cBot.launch({ allowedUpdates: ['message', 'callback_query'], dropPendingUpdates: true })
                            .then(() => console.log(`🤖 Cloned Bot @${cloneDoc.botUsername} running.`))
                            .catch(err => console.warn(`Cloned bot @${cloneDoc.botUsername} launch warn:`, err.message));
                        activeClonedBots.push(cBot);
                    } catch (err) {
                        console.warn("Could not launch saved clone:", err.message);
                    }
                }
            } catch (err) {
                console.warn("Error loading cloned bots:", err.message);
            }
        }

        runAviatorGameLoop();

        const server = app.listen(PORT, () => console.log(`⚡ Express Listening on Port ${PORT}`));
        server.on('error', (err) => {
            if (err.code === 'EADDRINUSE') {
                console.warn(`Port ${PORT} already bound; running bot worker engine.`);
            } else {
                console.error("Server listen error:", err.message);
            }
        });

        console.log("🟢 WIN NOVA Predictor Engine Operational 24/7.");
    } catch (err) {
        console.error("Boot Error. Retrying in 5s...", err);
        setTimeout(startEngine, 5000);
    }
}

startEngine();

process.once('SIGINT', () => {
    mainBot.stop('SIGINT');
    if (isDualBot) notifyBot.stop('SIGINT');
});
process.once('SIGTERM', () => {
    mainBot.stop('SIGTERM');
    if (isDualBot) notifyBot.stop('SIGTERM');
});
