import { onCall, HttpsError } from "firebase-functions/v2/https";
import { initializeApp, getApps } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";

// Initialize Firebase Admin SDK
if (!getApps().length) {
  initializeApp();
}

// Ensure connection to the dedicated Aviator Firestore database
const FIRESTORE_DATABASE_ID = "ai-studio-apexcrashengine-c6ee56ea-d9f9-4bbb-b555-3f64c5728d2a";
const db = getFirestore(FIRESTORE_DATABASE_ID);

/**
 * 1. placeBet(betAmount, autoCashoutMultiplier):
 *    - Checks if the user is authenticated.
 *    - Fetches the user's document inside a Firestore Transaction.
 *    - Verifies if (user.balance >= betAmount). If false, throws an error ("Insufficient balance").
 *    - Deducts `betAmount` from `users/{userId}/balance`.
 *    - Creates an immutable audit log in `balance_history`.
 *    - Creates a document in `bets` with status = "placed".
 */
export const placeBet = onCall({ cors: true }, async (request) => {
  // 1. Authentication Check
  if (!request.auth || !request.auth.uid) {
    throw new HttpsError("unauthenticated", "User must be authenticated to place a bet.");
  }
  const userId = request.auth.uid;
  const { betAmount, autoCashoutMultiplier, gameId } = request.data || {};

  // 2. Input Validation
  const amount = Number(betAmount);
  if (isNaN(amount) || amount < 10) {
    throw new HttpsError("invalid-argument", "Minimum bet amount is ₹10.");
  }
  if (amount > 100000) {
    throw new HttpsError("invalid-argument", "Maximum bet amount is ₹100,000.");
  }

  const parsedAutoCashout = autoCashoutMultiplier ? Number(autoCashoutMultiplier) : 0;
  if (parsedAutoCashout > 0 && parsedAutoCashout < 1.01) {
    throw new HttpsError("invalid-argument", "Auto-cashout multiplier must be at least 1.01x.");
  }

  const resolvedGameId = (typeof gameId === "string" && gameId.trim().length > 0)
    ? gameId.trim()
    : `round_${Date.now()}`;

  // 3. Firestore Transaction to guarantee atomic deduction and prevent balance race conditions
  try {
    const result = await db.runTransaction(async (transaction) => {
      const userRef = db.collection("users").doc(userId);
      const userDoc = await transaction.get(userRef);

      if (!userDoc.exists) {
        throw new HttpsError("not-found", "User profile not found.");
      }

      const userData = userDoc.data() || {};
      if (userData.isFrozen) {
        throw new HttpsError("permission-denied", "Account is frozen. Please contact support.");
      }

      const currentBalance = Number(userData.balance ?? 0);
      if (isNaN(currentBalance) || currentBalance < amount) {
        throw new HttpsError("failed-precondition", "Insufficient balance");
      }

      // Deduct betAmount from user balance
      const newBalance = Math.round((currentBalance - amount) * 100) / 100;
      transaction.update(userRef, {
        balance: newBalance,
        updatedAt: FieldValue.serverTimestamp()
      });

      // Create new bet document in 'bets' collection
      const betRef = db.collection("bets").doc();
      const betPayload = {
        id: betRef.id,
        userId,
        gameId: resolvedGameId,
        betAmount: amount,
        autoCashoutMultiplier: parsedAutoCashout,
        cashoutMultiplier: 0,
        winAmount: 0,
        status: "placed",
        createdAt: FieldValue.serverTimestamp(),
        timestamp: new Date().toISOString()
      };
      transaction.set(betRef, betPayload);

      // Create log in 'balance_history'
      const historyRef = db.collection("balance_history").doc();
      transaction.set(historyRef, {
        userId,
        type: "bet_placed",
        amount,
        previousBalance: currentBalance,
        newBalance,
        betId: betRef.id,
        timestamp: FieldValue.serverTimestamp()
      });

      return {
        success: true,
        betId: betRef.id,
        newBalance,
        status: "placed"
      };
    });

    return result;
  } catch (err: any) {
    if (err instanceof HttpsError) {
      throw err;
    }
    console.error("[CLOUD FUNCTION: placeBet ERROR]", err);
    throw new HttpsError("internal", err.message || "Failed to place bet transaction.");
  }
});

/**
 * 2. cashOut(betId, exactMultiplierAtCashout):
 *    - Fetches the active game state and the player's bet document inside a transaction.
 *    - Verifies the game status is still "flying" and that exactMultiplierAtCashout is lower than the actual server-side crash multiplier.
 *    - Calculates winAmount = betAmount * exactMultiplierAtCashout.
 *    - Credits winAmount back to users/{userId}/balance.
 *    - Updates bets/{betId} status to "cashed_out", recording the winAmount and cashoutMultiplier.
 *    - Logs the transaction in balance_history.
 *
 * Strict Error Handling & Anti-Double-Spending Protection:
 * - Rejects any attempt to cash out an already cashed out or busted bet.
 * - Handles high-frequency button spamming safely inside the atomic transaction.
 */
export const cashOut = onCall({ cors: true }, async (request) => {
  // 1. Authentication Check
  if (!request.auth || !request.auth.uid) {
    throw new HttpsError("unauthenticated", "User must be authenticated to cash out.");
  }
  const userId = request.auth.uid;
  const { betId, exactMultiplierAtCashout } = request.data || {};

  // 2. Input Validation
  if (!betId || typeof betId !== "string") {
    throw new HttpsError("invalid-argument", "Missing or invalid bet ID.");
  }
  const multiplier = Number(exactMultiplierAtCashout);
  if (isNaN(multiplier) || multiplier < 1.0) {
    throw new HttpsError("invalid-argument", "Invalid cashout multiplier. Must be >= 1.00x.");
  }

  // 3. Firestore Transaction (atomic check-and-set prevents race conditions and double-spending)
  try {
    const result = await db.runTransaction(async (transaction) => {
      // A. Fetch the player's bet document inside the transaction
      const betRef = db.collection("bets").doc(betId);
      const betDoc = await transaction.get(betRef);

      if (!betDoc.exists) {
        throw new HttpsError("not-found", "Bet document not found.");
      }

      const betData = betDoc.data() || {};

      // Verify ownership
      if (betData.userId !== userId) {
        throw new HttpsError("permission-denied", "Unauthorized: You do not own this bet.");
      }

      // Anti-Double-Spending Lock:
      // If bet status is anything other than 'placed', reject immediately.
      if (betData.status !== "placed") {
        throw new HttpsError(
          "failed-precondition",
          `Double-spend prevented: Bet is already "${betData.status}".`
        );
      }

      // B. Fetch the active game control document inside the transaction
      const gameControlRef = db.collection("game_control").doc("active_round");
      const gameControlDoc = await transaction.get(gameControlRef);

      if (gameControlDoc.exists) {
        const gameData = gameControlDoc.data() || {};
        const gameStatus = (gameData.status || "").toLowerCase();

        // Verify the game status is still "flying"
        if (gameStatus !== "flying") {
          throw new HttpsError(
            "failed-precondition",
            `Cashout rejected: Round status is "${gameStatus}". Cash out is only available while flying.`
          );
        }

        // Verify exactMultiplierAtCashout is lower than the actual server-side crash multiplier
        if (typeof gameData.crashMultiplier === "number" && multiplier >= gameData.crashMultiplier) {
          throw new HttpsError(
            "failed-precondition",
            `Cashout rejected: Multiplier ${multiplier}x exceeds server crash threshold of ${gameData.crashMultiplier}x.`
          );
        }
      }

      // C. Calculate winAmount = betAmount * exactMultiplierAtCashout
      const betAmount = Number(betData.betAmount ?? 0);
      if (isNaN(betAmount) || betAmount <= 0) {
        throw new HttpsError("internal", "Corrupt bet amount detected.");
      }
      const winAmount = Math.round((betAmount * multiplier) * 100) / 100;

      // D. Fetch user's document inside the transaction
      const userRef = db.collection("users").doc(userId);
      const userDoc = await transaction.get(userRef);

      if (!userDoc.exists) {
        throw new HttpsError("not-found", "User account not found.");
      }

      const userData = userDoc.data() || {};
      const currentBalance = Number(userData.balance ?? 0);
      const newBalance = Math.round((currentBalance + winAmount) * 100) / 100;

      // E. Credit winAmount back to users/{userId}/balance
      transaction.update(userRef, {
        balance: newBalance,
        updatedAt: FieldValue.serverTimestamp()
      });

      // F. Update bets/{betId} status to "cashed_out", recording winAmount and cashoutMultiplier
      transaction.update(betRef, {
        status: "cashed_out",
        winAmount,
        cashoutMultiplier: multiplier,
        cashedOutAt: FieldValue.serverTimestamp()
      });

      // G. Log the transaction in balance_history
      const historyRef = db.collection("balance_history").doc();
      transaction.set(historyRef, {
        userId,
        type: "bet_won",
        amount: winAmount,
        previousBalance: currentBalance,
        newBalance,
        betId,
        multiplier,
        timestamp: FieldValue.serverTimestamp()
      });

      return {
        success: true,
        betId,
        winAmount,
        newBalance,
        cashoutMultiplier: multiplier,
        status: "cashed_out"
      };
    });

    return result;
  } catch (err: any) {
    if (err instanceof HttpsError) {
      throw err;
    }
    console.error("[CLOUD FUNCTION: cashOut ERROR]", err);
    throw new HttpsError("internal", err.message || "Failed to process cashout transaction.");
  }
});
