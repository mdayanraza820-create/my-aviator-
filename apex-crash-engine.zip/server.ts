import express from 'express';
import http from 'http';
import fs from 'fs';
import { Server as SocketIOServer } from 'socket.io';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { createRequire } from 'module';
import admin from 'firebase-admin';
import { initializeApp as initAdminApp, getApps as getAdminApps, cert as adminCert } from 'firebase-admin/app';
import { getFirestore as getAdminFirestore, FieldValue as AdminFieldValue } from 'firebase-admin/firestore';

const require = createRequire(import.meta.url);
const TelegramBot: any = require('node-telegram-bot-api');
import type {
  User,
  Bet,
  GameState,
  MultiplierHistoryItem,
  DepositRequest,
  WithdrawalRequest,
  FraudAlert,
  SystemConfig,
  ReferralStat,
  DepositNode,
  ChatMessage,
  FakeChatConfig,
  HighRollerWinner,
  TrendSeedConfig,
  LiabilityAlert,
  CollectiveCashOutTicker,
  LeaderboardEntry,
  LeaderboardTimeframe,
  LeaderboardMetric,
  SubAdminAccount,
  PeakVolumeSchedule,
  VipPrize,
  CheatCrashTimeControl,
  CheatTimeControlMode,
  PlatformNotification
} from './src/types.ts';
import {
  maskPlayerName,
  VIP_SPIN_PRIZES,
  WHALE_STAKE_THRESHOLD,
  evaluateWhaleRisk,
  calculateSlidingWager,
  VOLUMETRIC_TIER_MATRIX,
  calculateVolumetricProgression,
  format7DigitUid,
  calculateWithdrawalTaxBreakdown,
  processExclusiveWithdrawal,
  isWithinLast30Days
} from './src/types.ts';
import { setupTelegramBot } from './src/serverTelegramBot.ts';
import {
  createFinancialRouter,
  inMemoryGiftCodes,
  inMemoryWithdrawalTiers,
  inMemoryWithdrawals
} from './server/financialEngine.ts';
import { connectDatabase, getDatabaseStatus } from './server/database.ts';

const app = express();
const rawPort = process.env.PORT || '3000';
const PORT = parseInt(rawPort, 10) || 3000;
const server = http.createServer(app);

// Enable JSON body parsing with large limit for screenshot upload
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// Auto-persist every mutating API request immediately on response completion
app.use((req, res, next) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && req.path.startsWith('/api/')) {
    res.on('finish', () => {
      if (res.statusCode >= 200 && res.statusCode < 400) {
        scheduleSavePlatformData(`api:${req.method}:${req.path}`);
      }
    });
  }
  next();
});

// Setup Socket.io
const io = new SocketIOServer(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

// ==========================================
// HIDDEN SUPER ADMIN CREDENTIALS & GUARDRAIL
// ==========================================
const SUPER_ADMIN_EMAIL = 'mdfaisalraza9771@gmail.com';
const SUPER_ADMIN_PASSWORD = 'Faisal786';
const SUPER_ADMIN_ID = 'sa_master_001';

// =========================================================================
// PROGRAMMATIC RUNTIME VERIFICATION BLOCK & CLOUD BINDING
// Explicit modules: express, node-telegram-bot-api, firebase-admin
// Root Credentials Token File: firebase-key.json
// =========================================================================
const FIREBASE_KEY_PATH = path.resolve(process.cwd(), 'firebase-key.json');

console.log('⚡ [SYSTEM CORE]: Formulating Programmatic Verification Layer...');
console.log(`📦 [MODULE CHECK]: Express, node-telegram-bot-api, firebase-admin (SDK v${admin.SDK_VERSION || 'active'}) successfully verified.`);
console.log(`🔑 [CREDENTIALS TOKEN CHECK]: Expecting credentials at ${FIREBASE_KEY_PATH}`);

// Initialize Firebase Admin SDK for Secure Firestore Transactions
if (!getAdminApps().length) {
  if (fs.existsSync(FIREBASE_KEY_PATH)) {
    try {
      const serviceAccount = JSON.parse(fs.readFileSync(FIREBASE_KEY_PATH, 'utf8'));
      initAdminApp({
        credential: adminCert(serviceAccount),
        projectId: serviceAccount.project_id || 'ai-studio-apexcrashengine-c6ee56ea-d9f9-4bbb-b555-3f64c5728d2a'
      });
      console.log(`✅ [FIREBASE ADMIN]: Bound credentials from root '${FIREBASE_KEY_PATH}'`);
    } catch (err: any) {
      console.warn(`⚠️ [FIREBASE ADMIN]: Error parsing '${FIREBASE_KEY_PATH}':`, err.message);
      initAdminApp({ projectId: 'ringed-record-nxctm' });
    }
  } else {
    initAdminApp({ projectId: 'ringed-record-nxctm' });
    console.log(`ℹ️ [FIREBASE ADMIN]: Running in container mode with project ringed-record-nxctm. Place 'firebase-key.json' in root directory for dedicated cloud credentials.`);
  }
}
const adminDb = getAdminFirestore('ai-studio-apexcrashengine-c6ee56ea-d9f9-4bbb-b555-3f64c5728d2a');

// In-Memory Secure Store
const users = new Map<string, User>();
const usedUids = new Set<string>(['1000001', '8821045']);

/**
 * Generates a guaranteed unique 7-digit numeric UID for every person (e.g. "7482910")
 */
function generateUnique7DigitUid(): string {
  for (let attempt = 0; attempt < 1000; attempt++) {
    const candidate = String(Math.floor(1000000 + Math.random() * 9000000));
    if (!usedUids.has(candidate)) {
      let collision = false;
      for (const u of users.values()) {
        if (u.uid === candidate || u.uid === `UID-${candidate}`) {
          collision = true;
          break;
        }
      }
      if (!collision) {
        usedUids.add(candidate);
        return candidate;
      }
    }
  }
  const fallback = String(1000000 + (Date.now() % 9000000));
  usedUids.add(fallback);
  return fallback;
}

function normalizeUidInput(raw: string): string {
  if (!raw) return '';
  const cleaned = String(raw).trim().replace(/^UID[-_:\s]*/i, '').replace(/\D/g, '');
  return cleaned;
}

function findUserByIdOrUid(identifier: string): User | undefined {
  if (!identifier) return undefined;
  const trimmed = String(identifier).trim();
  if (users.has(trimmed)) return users.get(trimmed);
  const normUid = normalizeUidInput(trimmed);
  for (const u of users.values()) {
    const uNormUid = normalizeUidInput(u.uid || '');
    if (
      u.id === trimmed ||
      u.uid === trimmed ||
      (normUid.length > 0 && uNormUid === normUid) ||
      u.phone === trimmed ||
      u.email.toLowerCase() === trimmed.toLowerCase() ||
      u.name.toLowerCase() === trimmed.toLowerCase()
    ) {
      return u;
    }
  }
  return undefined;
}

const activeBets = new Map<string, Bet>();
const roundBetsHistory: Bet[] = [];
const deposits: DepositRequest[] = [];
const withdrawals: WithdrawalRequest[] = [];
const fraudAlerts: FraudAlert[] = [];
// 60-Round Autonomous Sequential History Initialization
let roundSerialNumber = 100060;
const seedMultipliers = [
  1.42, 2.85, 1.15, 7.64, 1.98, 12.30, 3.12, 1.05, 4.56, 1.88,
  2.15, 1.34, 15.20, 1.12, 6.70, 2.45, 1.02, 3.89, 1.76, 25.40,
  1.55, 2.05, 1.20, 4.10, 1.67, 10.50, 1.38, 2.92, 1.11, 8.44,
  1.95, 3.40, 1.48, 1.82, 18.90, 1.25, 2.30, 1.09, 5.60, 2.75,
  1.18, 4.80, 1.33, 33.20, 1.62, 2.18, 1.04, 6.15, 1.90, 2.65,
  1.22, 9.80, 1.40, 1.70, 14.10, 1.16, 3.25, 1.85, 2.50, 1.08
];

const multiplierHistory: MultiplierHistoryItem[] = seedMultipliers.map((mult, idx) => {
  const roundNum = 100001 + idx;
  return {
    roundId: `Round No - ${roundNum}`,
    roundName: `Round No - ${roundNum}`,
    roundNumber: roundNum,
    multiplier: mult,
    crashedAt: Date.now() - (60 - idx) * 25000
  };
}).reverse(); // newest first

let systemConfig: SystemConfig = {
  minDeposit: 100,
  minWithdrawal: 110,
  targetHouseWinRate: 0.60,
  turnoverMultiplier: 1.5,
  instantReferralBonus: 20,
  rebatePercent: 0.0002, // 0.02% of referred person's bet amount (betAmount * 0.0002)
  adminUpiId: 'winnova.merchant@upi',
  adminUpiName: 'WIN NOVA Cashier',
  adminQrUrl: '',
  manualOverrideActive: false,
  nextRoundPresetCrash: undefined,
  cheatPercentage: 60, // Default 60%
  crashPercentage: 47, // Default 47%
  smartProfitCapLimit: 3000,
  rotateAfterTransactions: 15,
  activeDepositNodeId: 'node_1',
  fakeChatEnabled: false, // Strict no fake data policy
  fakeChatMinSec: 4,
  fakeChatMaxSec: 10,
  maintenanceModeActive: false,
  maxPlatformLiabilityThreshold: 10000,
  trendSeedConfig: {
    mode: 'NATURAL',
    customSequence: [],
    consecutiveCrashesRemaining: 0,
    autoOverrideOnLiability: true,
    liabilityCrashThreshold: 8000
  },
  posterGirlImageUrl: '/poster_girl.png',
  telegramBotToken: '8828254838:AAEDJDElJPa8ETmhHINPD7PezMrZ9IWgDDU',
  telegramChatId: '7939005883',
  allowAdminRewardDispatch: false
};

let trendSeedConfig: TrendSeedConfig = systemConfig.trendSeedConfig!;

// =========================================================================
// MODULE 7: REAL-TIME COLLECTIVE CASH-OUT TICKER (REAL + SYNTHETIC POOL)
// Cumulative state array during flying frame cycle: Total = Real + Synthetic
// =========================================================================
let totalRoundCashOut = 0;
let realUserCashOut = 0;
let syntheticBotCashOut = 0;

// =========================================================================
// MODULE 12: ASYNCHRONOUS SESSION CONCURRENCY LOCK & EXPIRING TRANSACTION PIPELINES
// Single active WebSocket connection per authenticated user ID
// =========================================================================
const userSocketMap = new Map<string, string>(); // userId -> socketId

// =========================================================================
// ENTERPRISE PERMANENT DATA RETENTION (COMMERCIAL DISPOSITION RULES)
// Enforce an absolute permanent archiving data strategy. Strictly suppress,
// disable, and bypass all automated data-purging hooks, garbage collection loops,
// cleanup scripts, or time-to-live (TTL) collection indexes.
// All transactional historical metrics, historical high scores, and user profile data arrays
// must be preserved permanently in the database state to ensure audited transaction proof
// for asset acquisition verification when the web engine is sold.
// =========================================================================
export const DATA_PERSISTENCE_POLICY = 'permanent_archive_active';
// Automated TTL purging and destructive queue drops are permanently bypassed.
// All deposits, bets, multipliers, and user profiles remain permanently in state.

// =========================================================================
// MODULE 9: AUTOMATED MULTI-TIMEFRAME LEADERBOARD MATRIX
// Persistent indexing for Most Multiplier & Most Win across Daily/Weekly/Yearly
// =========================================================================
interface LeaderboardStore {
  DAILY: { mostMultiplier: LeaderboardEntry[]; mostWin: LeaderboardEntry[] };
  WEEKLY: { mostMultiplier: LeaderboardEntry[]; mostWin: LeaderboardEntry[] };
  YEARLY: { mostMultiplier: LeaderboardEntry[]; mostWin: LeaderboardEntry[] };
}

const leaderboardStore: LeaderboardStore = {
  DAILY: {
    mostMultiplier: [
      { id: 'lb_d_1', username: 'Karan_Bet', anonymizedName: 'Karan******', metricValue: 34.80, multiplier: 34.80, betAmount: 500, payoutAmount: 17400, timeframe: 'DAILY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 3600000, isSynthetic: true },
      { id: 'lb_d_2', username: 'mdfaisalraza', anonymizedName: 'mdfai******', metricValue: 24.50, multiplier: 24.50, betAmount: 1000, payoutAmount: 24500, timeframe: 'DAILY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 7200000, isSynthetic: false },
      { id: 'lb_d_3', username: 'Aman_Pro', anonymizedName: 'Aman_******', metricValue: 18.20, multiplier: 18.20, betAmount: 800, payoutAmount: 14560, timeframe: 'DAILY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 10800000, isSynthetic: true },
      { id: 'lb_d_4', username: 'Vikram_K', anonymizedName: 'Vikra******', metricValue: 15.65, multiplier: 15.65, betAmount: 1200, payoutAmount: 18780, timeframe: 'DAILY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 14400000, isSynthetic: true },
      { id: 'lb_d_5', username: 'Rahul_99', anonymizedName: 'Rahul******', metricValue: 12.40, multiplier: 12.40, betAmount: 2000, payoutAmount: 24800, timeframe: 'DAILY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 18000000, isSynthetic: true }
    ],
    mostWin: [
      { id: 'lb_dw_1', username: 'SuperRoller_IN', anonymizedName: 'Super******', metricValue: 68500, multiplier: 14.70, betAmount: 5000, payoutAmount: 73500, timeframe: 'DAILY', type: 'MOST_WIN', timestamp: Date.now() - 5400000, isSynthetic: true },
      { id: 'lb_dw_2', username: 'mdfaisalraza', anonymizedName: 'mdfai******', metricValue: 44400, multiplier: 14.80, betAmount: 3000, payoutAmount: 47400, timeframe: 'DAILY', type: 'MOST_WIN', timestamp: Date.now() - 8400000, isSynthetic: false },
      { id: 'lb_dw_3', username: 'Deepak_7', anonymizedName: 'Deepa******', metricValue: 32000, multiplier: 9.00, betAmount: 4000, payoutAmount: 36000, timeframe: 'DAILY', type: 'MOST_WIN', timestamp: Date.now() - 12000000, isSynthetic: true },
      { id: 'lb_dw_4', username: 'Kunal_Sky', anonymizedName: 'Kunal******', metricValue: 28500, multiplier: 6.70, betAmount: 5000, payoutAmount: 33500, timeframe: 'DAILY', type: 'MOST_WIN', timestamp: Date.now() - 15600000, isSynthetic: true },
      { id: 'lb_dw_5', username: 'Pooja_Sharma', anonymizedName: 'Pooja******', metricValue: 24100, multiplier: 13.05, betAmount: 2000, payoutAmount: 26100, timeframe: 'DAILY', type: 'MOST_WIN', timestamp: Date.now() - 19200000, isSynthetic: true }
    ]
  },
  WEEKLY: {
    mostMultiplier: [
      { id: 'lb_w_1', username: 'ApexAviator', anonymizedName: 'ApexA******', metricValue: 94.20, multiplier: 94.20, betAmount: 200, payoutAmount: 18840, timeframe: 'WEEKLY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 86400000, isSynthetic: true },
      { id: 'lb_w_2', username: 'Rohit_R', anonymizedName: 'Rohit******', metricValue: 58.70, multiplier: 58.70, betAmount: 500, payoutAmount: 29350, timeframe: 'WEEKLY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 172800000, isSynthetic: true },
      { id: 'lb_w_3', username: 'Harsh_Trader', anonymizedName: 'Harsh******', metricValue: 46.10, multiplier: 46.10, betAmount: 1000, payoutAmount: 46100, timeframe: 'WEEKLY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 259200000, isSynthetic: true },
      { id: 'lb_w_4', username: 'mdfaisalraza', anonymizedName: 'mdfai******', metricValue: 42.00, multiplier: 42.00, betAmount: 1000, payoutAmount: 42000, timeframe: 'WEEKLY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 345600000, isSynthetic: false },
      { id: 'lb_w_5', username: 'Neha_Roy', anonymizedName: 'Neha_******', metricValue: 38.50, multiplier: 38.50, betAmount: 600, payoutAmount: 23100, timeframe: 'WEEKLY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 432000000, isSynthetic: true }
    ],
    mostWin: [
      { id: 'lb_ww_1', username: 'BigWhale_Pro', anonymizedName: 'BigWh******', metricValue: 185000, multiplier: 19.50, betAmount: 10000, payoutAmount: 195000, timeframe: 'WEEKLY', type: 'MOST_WIN', timestamp: Date.now() - 95000000, isSynthetic: true },
      { id: 'lb_ww_2', username: 'Aman_Pro', anonymizedName: 'Aman_******', metricValue: 124000, multiplier: 13.40, betAmount: 10000, payoutAmount: 134000, timeframe: 'WEEKLY', type: 'MOST_WIN', timestamp: Date.now() - 180000000, isSynthetic: true },
      { id: 'lb_ww_3', username: 'mdfaisalraza', anonymizedName: 'mdfai******', metricValue: 98000, multiplier: 15.00, betAmount: 7000, payoutAmount: 105000, timeframe: 'WEEKLY', type: 'MOST_WIN', timestamp: Date.now() - 270000000, isSynthetic: false },
      { id: 'lb_ww_4', username: 'Vikramaditya', anonymizedName: 'Vikra******', metricValue: 86000, multiplier: 9.60, betAmount: 10000, payoutAmount: 96000, timeframe: 'WEEKLY', type: 'MOST_WIN', timestamp: Date.now() - 360000000, isSynthetic: true },
      { id: 'lb_ww_5', username: 'Tarun_Win', anonymizedName: 'Tarun******', metricValue: 74500, multiplier: 8.45, betAmount: 10000, payoutAmount: 84500, timeframe: 'WEEKLY', type: 'MOST_WIN', timestamp: Date.now() - 450000000, isSynthetic: true }
    ]
  },
  YEARLY: {
    mostMultiplier: [
      { id: 'lb_y_1', username: 'MoonShotLegend', anonymizedName: 'MoonS******', metricValue: 482.50, multiplier: 482.50, betAmount: 100, payoutAmount: 48250, timeframe: 'YEARLY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 2500000000, isSynthetic: true },
      { id: 'lb_y_2', username: 'SkyKing_99', anonymizedName: 'SkyKi******', metricValue: 246.80, multiplier: 246.80, betAmount: 250, payoutAmount: 61700, timeframe: 'YEARLY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 5000000000, isSynthetic: true },
      { id: 'lb_y_3', username: 'CryptoRider', anonymizedName: 'Crypt******', metricValue: 188.00, multiplier: 188.00, betAmount: 500, payoutAmount: 94000, timeframe: 'YEARLY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 7500000000, isSynthetic: true },
      { id: 'lb_y_4', username: 'Aman_Pro', anonymizedName: 'Aman_******', metricValue: 154.20, multiplier: 154.20, betAmount: 500, payoutAmount: 77100, timeframe: 'YEARLY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 9000000000, isSynthetic: true },
      { id: 'lb_y_5', username: 'mdfaisalraza', anonymizedName: 'mdfai******', metricValue: 120.00, multiplier: 120.00, betAmount: 1000, payoutAmount: 120000, timeframe: 'YEARLY', type: 'MOST_MULTIPLIER', timestamp: Date.now() - 11000000000, isSynthetic: false }
    ],
    mostWin: [
      { id: 'lb_yw_1', username: 'RoyalKing_IN', anonymizedName: 'Royal******', metricValue: 980000, multiplier: 49.00, betAmount: 20000, payoutAmount: 1000000, timeframe: 'YEARLY', type: 'MOST_WIN', timestamp: Date.now() - 3000000000, isSynthetic: true },
      { id: 'lb_yw_2', username: 'ApexSyndicate', anonymizedName: 'ApexS******', metricValue: 740000, multiplier: 25.60, betAmount: 30000, payoutAmount: 770000, timeframe: 'YEARLY', type: 'MOST_WIN', timestamp: Date.now() - 6000000000, isSynthetic: true },
      { id: 'lb_yw_3', username: 'BigWhale_Pro', anonymizedName: 'BigWh******', metricValue: 560000, multiplier: 19.50, betAmount: 30000, payoutAmount: 590000, timeframe: 'YEARLY', type: 'MOST_WIN', timestamp: Date.now() - 8500000000, isSynthetic: true },
      { id: 'lb_yw_4', username: 'mdfaisalraza', anonymizedName: 'mdfai******', metricValue: 480000, multiplier: 25.00, betAmount: 20000, payoutAmount: 500000, timeframe: 'YEARLY', type: 'MOST_WIN', timestamp: Date.now() - 10500000000, isSynthetic: false },
      { id: 'lb_yw_5', username: 'Sunil_88', anonymizedName: 'Sunil******', metricValue: 395000, multiplier: 16.80, betAmount: 25000, payoutAmount: 420000, timeframe: 'YEARLY', type: 'MOST_WIN', timestamp: Date.now() - 12500000000, isSynthetic: true }
    ]
  }
};

function recordLeaderboardWin(username: string, multiplier: number, betAmount: number, payoutAmount: number, isSynthetic = false) {
  const netWin = Math.round(payoutAmount - betAmount);
  const baseEntry: Omit<LeaderboardEntry, 'id' | 'timeframe' | 'type'> = {
    username,
    anonymizedName: anonymizeUsername(username),
    metricValue: 0,
    multiplier: +multiplier.toFixed(2),
    betAmount,
    payoutAmount: Math.round(payoutAmount),
    timestamp: Date.now(),
    isSynthetic,
    roundId: currentRoundId
  };

  (['DAILY', 'WEEKLY', 'YEARLY'] as LeaderboardTimeframe[]).forEach(tf => {
    // Check Most Multiplier
    const multEntry: LeaderboardEntry = {
      ...baseEntry,
      id: `lb_${tf.toLowerCase()}_m_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      metricValue: +multiplier.toFixed(2),
      timeframe: tf,
      type: 'MOST_MULTIPLIER'
    };
    leaderboardStore[tf].mostMultiplier.push(multEntry);
    leaderboardStore[tf].mostMultiplier.sort((a, b) => b.metricValue - a.metricValue);
    if (leaderboardStore[tf].mostMultiplier.length > 25) leaderboardStore[tf].mostMultiplier.length = 25;

    // Check Most Win
    if (netWin > 0) {
      const winEntry: LeaderboardEntry = {
        ...baseEntry,
        id: `lb_${tf.toLowerCase()}_w_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        metricValue: netWin,
        timeframe: tf,
        type: 'MOST_WIN'
      };
      leaderboardStore[tf].mostWin.push(winEntry);
      leaderboardStore[tf].mostWin.sort((a, b) => b.metricValue - a.metricValue);
      if (leaderboardStore[tf].mostWin.length > 25) leaderboardStore[tf].mostWin.length = 25;
    }
  });
}

// ==========================================
// MODULE 2: AUTOMATED UPI ID ROTATOR ENGINE
// ==========================================
const depositNodes: DepositNode[] = [
  {
    id: 'node_1',
    upiId: 'winnova.merchant@upi',
    displayName: 'WIN NOVA Cashier Node 1',
    qrImageUrl: '',
    maxTransactions: 15,
    currentTransactions: 3,
    isActive: true,
    totalVolume: 4500,
    createdAt: Date.now() - 86400000
  },
  {
    id: 'node_2',
    upiId: 'apexpay.merchant@paytm',
    displayName: 'WIN NOVA Gateway Node 2',
    qrImageUrl: '',
    maxTransactions: 15,
    currentTransactions: 0,
    isActive: true,
    totalVolume: 0,
    createdAt: Date.now() - 86400000
  },
  {
    id: 'node_3',
    upiId: 'fastfund.settle@okaxis',
    displayName: 'WIN NOVA Express Node 3',
    qrImageUrl: '',
    maxTransactions: 15,
    currentTransactions: 0,
    isActive: true,
    totalVolume: 0,
    createdAt: Date.now() - 86400000
  }
];

let activeDepositNodeId = 'node_1';

function getActiveDepositNode(): DepositNode {
  const active = depositNodes.find(n => n.id === activeDepositNodeId && n.isActive);
  if (active) return active;
  const firstActive = depositNodes.find(n => n.isActive);
  if (firstActive) {
    activeDepositNodeId = firstActive.id;
    return firstActive;
  }
  return depositNodes[0];
}

function checkAndRotateDepositNode(amount: number) {
  const currentNode = getActiveDepositNode();
  currentNode.currentTransactions += 1;
  currentNode.totalVolume += amount;

  const threshold = systemConfig.rotateAfterTransactions || currentNode.maxTransactions || 15;
  if (currentNode.currentTransactions >= threshold) {
    const activeList = depositNodes.filter(n => n.isActive);
    if (activeList.length > 1) {
      const currIdx = activeList.findIndex(n => n.id === currentNode.id);
      const nextIdx = (currIdx + 1) % activeList.length;
      activeDepositNodeId = activeList[nextIdx].id;
      systemConfig.activeDepositNodeId = activeDepositNodeId;
      console.log(`[UPI ROTATOR] Auto-rotated active deposit node to: ${activeList[nextIdx].displayName} (${activeList[nextIdx].upiId}) after ${currentNode.currentTransactions} txns.`);
      io.emit('active_upi_node_changed', getActiveDepositNode());
    }
  }
}

// ==========================================
// UPI ACCOUNTS & ROLE CONTROL SYSTEM
// ==========================================
export interface UpiAccountRecord {
  id: number;
  upi_id: string;
  today_received: number;
  max_limit: number;
  status: 'active' | 'pending' | 'completed';
}

let upiAccounts: UpiAccountRecord[] = [
  { id: 1, upi_id: "accountA@upi", today_received: 0, max_limit: 2000, status: "active" },
  { id: 2, upi_id: "accountB@upi", today_received: 0, max_limit: 2000, status: "pending" }
];

function syncUpiAccountsToFirestore() {
  try {
    upiAccounts.forEach(acc => {
      adminDb.collection('upi_accounts').doc(String(acc.id)).set({
        id: acc.id,
        upi_id: acc.upi_id,
        today_received: acc.today_received,
        max_limit: acc.max_limit,
        status: acc.status,
        updatedAt: Date.now()
      }, { merge: true }).catch(() => {});
    });
  } catch (e) {
    // Non-blocking firestore sync
  }
}

// 1. SUPER ADMIN FUNCTION: To change max limit of any account dynamically
// MULTI-ADMIN PRIVILEGE ACCESS ISOLATION:
// Intercept all runtime adjustment payloads directed at modifying global limit variables or account arrays.
// If the user context role is not explicitly 'super_admin', terminate execution immediately with access denial.
function superAdminUpdateLimit(userId: string, role: string, accountId: number, newLimit: number) {
  if (role !== "super_admin" && role !== "superadmin") {
    const deniedMsg = "Access Denied: Only Super Admin can change limits! Standard admin roles are strictly restricted to structural transactional validations and view privileges, with zero permission to alter data limits.";
    console.warn(`[MULTI-ADMIN PRIVILEGE ISOLATION]: Intercepted mutation attempt by non-super_admin role: '${role}' on account ${accountId}`);
    return { 
      success: false, 
      code: "ACCESS_DENIED", 
      message: deniedMsg 
    };
  }
  
  let account = upiAccounts.find(acc => acc.id === accountId);
  if (account) {
    account.max_limit = Number(newLimit) || 2000;
    syncUpiAccountsToFirestore();
    io.emit('upi_accounts_updated', upiAccounts);
    io.emit('active_upi_changed', getActiveUPIForUsers());
    return { 
      success: true, 
      message: `Super Admin successfully updated threshold limit for ${account.upi_id} to ₹${account.max_limit}` 
    };
  }
  return { success: false, message: "Account not found!" };
}

// 2. ADMIN & SUPER ADMIN FUNCTION: Get the currently active UPI ID for Chrome Page
function getActiveUPIForUsers() {
  let activeAccount = upiAccounts.find(acc => acc.status === "active");
  if (!activeAccount) {
    return { success: false, upi_id: null, message: "All account limits filled for today!" };
  }
  return { success: true, upi_id: activeAccount.upi_id, account: activeAccount };
}

// 3. ADMIN FUNCTION: To approve manual deposit and trigger Auto-Switch
// DYNAMIC GATEWAY CASCADING & CEILING ROUTING:
// Monitor active transactional arrays linked to multi-account structural fields.
// Track volume tracking variable (today_received). The absolute instant this variable hits or exceeds
// the user-defined threshold limit (default configuration: 2000), execute an atomic state transition:
// mark the active routing token as "completed" and immediately update the next sequentially index-mapped
// token status to "active" for dynamic UI injection.
function adminApproveDeposit(userId: string, role: string, amountReceived: number) {
  // Both Admin and Super Admin can approve transactional deposits
  if (role !== "admin" && role !== "super_admin" && role !== "superadmin") {
    return { success: false, message: "Unauthorized role! Transactional validation requires admin privilege." };
  }

  let currentAccount = upiAccounts.find(acc => acc.status === "active");
  
  if (currentAccount) {
    currentAccount.today_received = +(currentAccount.today_received + Number(amountReceived)).toFixed(2);
    
    // CHECK TRIGGER: Auto-switch if threshold limit (default configuration: 2000) is reached or exceeded
    const thresholdLimit = currentAccount.max_limit || 2000;
    if (currentAccount.today_received >= thresholdLimit) {
      // Atomic state transition: mark active routing token as "completed"
      currentAccount.status = "completed";
      
      // Immediately update the next sequentially index-mapped token status to "active"
      const currentIndex = upiAccounts.findIndex(acc => acc.id === currentAccount.id);
      let nextAccount = upiAccounts.slice(currentIndex + 1).find(acc => acc.status === "pending")
        || upiAccounts.find(acc => acc.status === "pending");
      
      if (nextAccount) {
        nextAccount.status = "active";
        console.log(`[DYNAMIC GATEWAY CASCADING]: Threshold reached (₹${currentAccount.today_received}/₹${thresholdLimit}). Auto-transitioned ${currentAccount.upi_id} to completed, activated sequential token ${nextAccount.upi_id}`);
      } else {
        console.warn(`[DYNAMIC GATEWAY CASCADING]: All gateway accounts in array have reached maximum ceiling limit.`);
      }
    }
    syncUpiAccountsToFirestore();
    io.emit('upi_accounts_updated', upiAccounts);
    io.emit('active_upi_changed', getActiveUPIForUsers());
    return { 
      success: true, 
      message: `Deposit approved on ${currentAccount.upi_id}. Total today: ₹${currentAccount.today_received}` 
    };
  }
  return { success: false, message: "No active account found to accept deposits!" };
}

// 4. CRON JOB: Midnight reset function (Runs automatically at 12:00 AM)
function midnightBalanceReset() {
  upiAccounts.forEach((acc, index) => {
    acc.today_received = 0;
    acc.status = index === 0 ? "active" : "pending";
  });
  syncUpiAccountsToFirestore();
  io.emit('upi_accounts_updated', upiAccounts);
  io.emit('active_upi_changed', getActiveUPIForUsers());
  console.log("[System Log]: Daily transactional counters reset to zero.");
  return { success: true, message: "Daily transactional counters reset to zero." };
}

// Midnight automatic reset watcher
let lastMidnightResetDate = new Date().toDateString();
setInterval(() => {
  const currentDate = new Date().toDateString();
  if (currentDate !== lastMidnightResetDate) {
    lastMidnightResetDate = currentDate;
    midnightBalanceReset();
  }
}, 30000);

// ==========================================
// MODULE 1: CHAT ENGINE (FAKE CHAT REMOVED)
// ==========================================
const chatMessages: ChatMessage[] = [];

let fakeChatConfig: FakeChatConfig = {
  enabled: false,
  minIntervalSec: 4,
  maxIntervalSec: 10,
  userHandles: [],
  messageTemplates: []
};

const AVATAR_COLORS = [
  'text-rose-400', 'text-amber-400', 'text-emerald-400', 'text-cyan-400',
  'text-indigo-400', 'text-purple-400', 'text-pink-400', 'text-lime-400'
];

function scheduleNextFakeChat() {
  // STRICT USER POLICY: No fake chats or simulated messages. Only real authenticated user chats.
  return;
}
// scheduleNextFakeChat disabled per strict real data mandate

// ==========================================
// MODULE 4: REAL-TIME WINNERS LEADERBOARD
// ==========================================
function anonymizeUsername(name: string): string {
  if (!name) return 'player******';
  const clean = name.replace(/[^a-zA-Z0-9_]/g, '');
  if (clean.length <= 4) return clean + '******';
  return clean.slice(0, 5) + '******';
}

const highRollers: HighRollerWinner[] = [
  {
    id: 'hr_1',
    username: 'mdfaisalraza',
    anonymizedName: 'mdfai******',
    multiplier: 14.80,
    winAmount: 44400,
    timestamp: Date.now() - 120000,
    roundId: 'R-994'
  },
  {
    id: 'hr_2',
    username: 'vikramaditya',
    anonymizedName: 'vikra******',
    multiplier: 18.20,
    winAmount: 36400,
    timestamp: Date.now() - 450000,
    roundId: 'R-989'
  },
  {
    id: 'hr_3',
    username: 'karan_patel',
    anonymizedName: 'karan******',
    multiplier: 15.50,
    winAmount: 31000,
    timestamp: Date.now() - 890000,
    roundId: 'R-972'
  },
  {
    id: 'hr_4',
    username: 'rahul_verma',
    anonymizedName: 'rahul******',
    multiplier: 9.65,
    winAmount: 28950,
    timestamp: Date.now() - 1340000,
    roundId: 'R-992'
  },
  {
    id: 'hr_5',
    username: 'aman_sharma',
    anonymizedName: 'aman_******',
    multiplier: 12.10,
    winAmount: 24200,
    timestamp: Date.now() - 1800000,
    roundId: 'R-981'
  },
  {
    id: 'hr_6',
    username: 'deepak_yadav',
    anonymizedName: 'deepa******',
    multiplier: 11.25,
    winAmount: 22500,
    timestamp: Date.now() - 2500000,
    roundId: 'R-963'
  },
  {
    id: 'hr_7',
    username: 'arjun_kapoor',
    anonymizedName: 'arjun******',
    multiplier: 6.45,
    winAmount: 19350,
    timestamp: Date.now() - 3600000,
    roundId: 'R-986'
  },
  {
    id: 'hr_8',
    username: 'neha_singh',
    anonymizedName: 'neha_******',
    multiplier: 8.40,
    winAmount: 16800,
    timestamp: Date.now() - 4800000,
    roundId: 'R-977'
  },
  {
    id: 'hr_9',
    username: 'rohit_kumar',
    anonymizedName: 'rohit******',
    multiplier: 7.80,
    winAmount: 15600,
    timestamp: Date.now() - 6200000,
    roundId: 'R-968'
  },
  {
    id: 'hr_10',
    username: 'priya_nair',
    anonymizedName: 'priya******',
    multiplier: 5.90,
    winAmount: 11800,
    timestamp: Date.now() - 8400000,
    roundId: 'R-955'
  }
];

function recordHighRoller(username: string, multiplier: number, winAmount: number, roundId?: string) {
  const item: HighRollerWinner = {
    id: `hr_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    username,
    anonymizedName: anonymizeUsername(username),
    multiplier: +multiplier.toFixed(2),
    winAmount: Math.round(winAmount),
    timestamp: Date.now(),
    roundId: roundId || currentRoundId
  };

  highRollers.unshift(item);
  highRollers.sort((a, b) => b.winAmount - a.winAmount);
  if (highRollers.length > 10) highRollers.length = 10;

  io.emit('high_rollers_update', highRollers);
}

// Zero-lag cleanup: Synthetic high-roller background timer disabled per strict real-data & zero-lag policy.

// ==========================================
// MODULE 3: SMART PLAYER LOCK ENGINE TRACKER
// ==========================================
function updateUserSessionProfit(user: User) {
  if (user.sessionInitialBalance === undefined) {
    user.sessionInitialBalance = user.mainBalance;
  }
  user.netSessionProfit = +((user.mainBalance + user.withdrawableBalance) - user.sessionInitialBalance).toFixed(2);

  const limit = systemConfig.smartProfitCapLimit || 3000;
  if (user.netSessionProfit >= limit && !user.smartLockActive) {
    user.smartLockActive = true;
    user.smartLockRoundsLeft = Math.floor(Math.random() * 3) + 3; // 3 to 5 rounds (e.g. 3, 4, or 5)
    user.smartLockTriggeredAt = Date.now();

    fraudAlerts.unshift({
      id: `alert_lock_${Date.now()}`,
      userId: user.id,
      userEmail: user.email,
      userPhone: user.phone,
      reason: 'RAPID_ABUSE',
      deviceFingerprint: user.deviceFingerprint,
      ipAddress: user.lastLoginIp,
      actionTaken: 'FLAGGED',
      timestamp: Date.now()
    });

    console.log(`[SMART LOCK ENGAGED] User ${user.name} net profit ₹${user.netSessionProfit} >= cap ₹${limit}. 100% hard-lose clamped for ${user.smartLockRoundsLeft} rounds.`);
  }
}


// Simulated bot names for vibrant casino atmosphere
const BOT_NAMES = [
  'Rahul_99', 'Vikram_K', 'Aman_Pro', 'Rohit_R', 'Deepak_7', 'Suresh_M',
  'Pooja_Sharma', 'Arjun_V', 'Karan_Bet', 'Aniket_01', 'Aditya_S', 'Neha_Roy',
  'Mohit_Crash', 'Rajat_X', 'Sunil_88', 'Gaurav_King', 'Harsh_Trader', 'Priya_K'
];

// Helper: Calculate Dynamic Registration Bonus
function calculateRegistrationBonus(): number {
  const rand = Math.random() * 100;
  if (rand < 70) {
    // Tier 1: ₹12 to ₹20 (70% probability)
    return Math.floor(Math.random() * (20 - 12 + 1)) + 12;
  } else if (rand < 92) {
    // Tier 2: ₹21 to ₹35 (22% probability)
    return Math.floor(Math.random() * (35 - 21 + 1)) + 21;
  } else {
    // Tier 3: ₹36 to ₹50 (8% probability)
    return Math.floor(Math.random() * (50 - 36 + 1)) + 36;
  }
}

// Helper: Generate Unique Invite Token
function generateReferralCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = 'WN-';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

// Client IP helper
function getClientIp(req: express.Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim();
  }
  return req.socket.remoteAddress || '127.0.0.1';
}

// Seed a sample test user with zero balances and unique 7-digit UID
const sampleUser: User = {
  id: 'usr_sample_101',
  uid: '8821045',
  name: 'Demo Player',
  email: 'player@winnova.com',
  phone: '9876543210',
  role: 'user',
  mainBalance: 0,
  promoWallet: 0,
  bonusBalance: 0,
  withdrawableBalance: 0,
  turnoverRequired: 0,
  turnoverCompleted: 0,
  referralCode: 'WN-WIN777',
  referralRewardStatus: 'released',
  isFrozen: false,
  deviceFingerprint: 'demo_fingerprint_seed',
  registeredIp: '127.0.0.1',
  lastLoginIp: '127.0.0.1',
  createdAt: Date.now() - 86400000
};
users.set(sampleUser.id, sampleUser);

// Seed Super Admin in memory with Unlimited Balance, VIP 10, and 7-digit UID
const initialSuperAdmin: User = {
  id: SUPER_ADMIN_ID,
  uid: '1000001',
  name: 'Super Controller',
  email: SUPER_ADMIN_EMAIL,
  phone: '9999999999',
  role: 'superadmin',
  vipLevel: 10,
  lifetimeDeposit: 500000,
  cumulativeVolume: 1000000,
  mainBalance: 999999999,
  promoWallet: 999999999,
  bonusBalance: 0,
  withdrawableBalance: 999999999,
  turnoverRequired: 0,
  turnoverCompleted: 0,
  referralCode: 'ADMIN-MASTER',
  referralRewardStatus: 'none',
  isFrozen: false,
  deviceFingerprint: 'admin_master_fp',
  registeredIp: '127.0.0.1',
  lastLoginIp: '127.0.0.1',
  createdAt: 1700000000000
};
users.set(initialSuperAdmin.id, initialSuperAdmin);

// ==========================================
// GAME ENGINE & MULTIPLIER TICKER
// ==========================================
let currentRoundId = `Round No - ${roundSerialNumber + 1}`;
let currentRoundName = `Round No - ${roundSerialNumber + 1}`;
let gameStatus: 'WAITING' | 'FLYING' | 'CRASHED' = 'WAITING';
let currentMultiplier = 1.00;
let roundStartTime = 0;
let plannedCrashMultiplier = 2.45;
let plannedFlightDurationSeconds = 0;
let waitingCountdown = 10;
let gameLoopInterval: NodeJS.Timeout | null = null;
let waitingCountdownInterval: NodeJS.Timeout | null = null;

// MODULE 13: Dynamic Server Timing & Atomic Preparation Engine (10.0s window)
const PREPARATION_TIME = 10.0;
let preparationCountdown = PREPARATION_TIME;
let gameState: 'STATE_PREPARATION' | 'STATE_FLYING' | 'STATE_CRASHED' = 'STATE_PREPARATION';
const userBetCountInPrepPhase = new Map<string, number>();

interface QueuedBetItem {
  id: string;
  userId: string;
  amount: number;
  consoleIndex: 0 | 1;
  autoCashout?: number;
  socketId: string;
}
const queuedBetsForNextRound = new Map<string, QueuedBetItem>();

// MODULE 21: Whale Velocity Isolation & Targeted Bait-and-Clamp Sequence (Trigger limit locked to ₹2,000)
interface WhaleSequenceTracker {
  userId: string;
  stage: 1 | 2 | 3;
  lastStakeAmount: number;
  startedAt: number;
}
const activeWhaleSequences = new Map<string, WhaleSequenceTracker>();

// MODULE 15: Dynamic Loss Recovery Buffer & Vault Reserve Safety
let SYSTEM_VAULT_MINIMUM = 50000;
let platformReserveBalance = 145000;

// MODULE 14: Dynamic Margin Schedules (Peak Volume)
let peakSchedules: PeakVolumeSchedule[] = [
  {
    id: 'peak_evening',
    name: 'Peak Evening Concurrency (18:00 - 23:00)',
    startHour: 18,
    endHour: 23,
    forcedCrashProbability: 0.65,
    isActive: true
  }
];

// MODULE 16: Loss Velocity Tracker & Session Auditing
const userConsecutiveLosses = new Map<string, number>();
const userSessionLossAmount = new Map<string, number>();

// MODULE 17: Hidden Sub-Admin Creation & RBAC Store
const subAdmins = new Map<string, SubAdminAccount>();
const sampleSubAdmin: SubAdminAccount = {
  id: 'sub_admin_01',
  name: 'Ops Manager Vikram',
  email: 'vikram.ops@winnova.com',
  token: 'sub_sec_token_991',
  role: 'SUB_ADMIN',
  permissions: {
    canManageWithdrawals: true,
    canViewGameEngine: true,
    canViewMetrics: true,
    canManageDeposits: false
  },
  isActive: true,
  createdAt: Date.now() - 86400000
};
subAdmins.set(sampleSubAdmin.id, sampleSubAdmin);

// ==========================================
// SECURE FIRESTORE TRANSACTION BACKEND ENGINE
// ==========================================

function syncGameControlToFirestore(status: 'waiting' | 'flying' | 'crashed', multiplier: number, crashMultiplier?: number) {
  try {
    const finalVal = crashMultiplier ?? plannedCrashMultiplier;
    const payload = {
      currentMultiplier: multiplier,
      status,
      crashMultiplier: finalVal,
      finalMultiplier: finalVal,
      rtpConfig: (1 - systemConfig.targetHouseWinRate) * 100,
      roundId: currentRoundId,
      roundName: currentRoundName,
      roundNumber: roundSerialNumber,
      updatedAt: AdminFieldValue.serverTimestamp()
    };
    adminDb.collection('game_control').doc('active_round').set(payload, { merge: true }).catch(() => {});
    adminDb.collection('game_control').doc('current_game').set(payload, { merge: true }).catch(() => {});
  } catch (e) {
    // Non-blocking firestore sync
  }
}

/**
 * 1. placeBet(betAmount, autoCashoutMultiplier):
 *    - Checks if the user is authenticated.
 *    - Fetches the user's document inside a Firestore Transaction.
 *    - Verifies if (user.balance >= betAmount). If false, throws an error ("Insufficient balance").
 *    - Deducts betAmount from users/{userId}/balance.
 *    - Creates a log in balance_history.
 *    - Creates a document in bets with status = "placed".
 */
export async function executePlaceBetTransaction(params: {
  userId: string;
  betAmount: number;
  autoCashoutMultiplier?: number;
  gameId?: string;
  consoleIndex?: number;
}) {
  const { userId, betAmount, autoCashoutMultiplier, gameId, consoleIndex } = params;
  if (!userId) {
    throw new Error('Unauthenticated: User ID required');
  }
  const amount = Number(betAmount);
  if (isNaN(amount) || amount < 10) {
    throw new Error('Minimum bet amount is ₹10.');
  }
  if (amount > 100000) {
    throw new Error('Maximum bet amount is ₹100,000.');
  }

  const parsedAuto = autoCashoutMultiplier ? Number(autoCashoutMultiplier) : 0;
  if (parsedAuto > 0 && parsedAuto < 1.01) {
    throw new Error('Auto-cashout multiplier must be at least 1.01x.');
  }

  try {
    return await adminDb.runTransaction(async (transaction) => {
      const userRef = adminDb.collection('users').doc(userId);
      const userDoc = await transaction.get(userRef);

      let currentBalance = 0;
      let currentCumulativeVolume = 0;
      if (userDoc.exists) {
        const uData = userDoc.data() || {};
        if (uData.isFrozen) {
          throw new Error('Account is frozen. Please contact support.');
        }
        currentBalance = Number(uData.balance ?? 0);
        currentCumulativeVolume = Number(uData.cumulativeVolume ?? 0);
      } else {
        const memUser = users.get(userId);
        if (memUser) {
          currentBalance = memUser.mainBalance + memUser.bonusBalance;
          currentCumulativeVolume = Number(memUser.cumulativeVolume ?? 0);
        } else {
          throw new Error('User profile not found.');
        }
      }

      if (isNaN(currentBalance) || currentBalance < amount) {
        throw new Error('Insufficient balance');
      }

      const newBalance = Math.round((currentBalance - amount) * 100) / 100;

      // VOLUMETRIC MATHEMATICAL PROGRESSION ENGINE:
      // Cumulative_Volume = Absolute Sum of All Placed Bets. Progression logic ignores win/loss flags.
      const newCumulativeVolume = +(currentCumulativeVolume + amount).toFixed(2);
      const progression = calculateVolumetricProgression(newCumulativeVolume);

      if (userDoc.exists) {
        transaction.update(userRef, {
          balance: newBalance,
          cumulativeVolume: progression.cumulativeVolume,
          percentageProgress: progression.percentageProgress,
          nextTierDelta: progression.nextTierDelta,
          vipTier: progression.tierName,
          updatedAt: AdminFieldValue.serverTimestamp()
        });
      } else {
        transaction.set(userRef, {
          balance: newBalance,
          cumulativeVolume: progression.cumulativeVolume,
          percentageProgress: progression.percentageProgress,
          nextTierDelta: progression.nextTierDelta,
          vipTier: progression.tierName,
          email: `${userId}@aviator.internal`,
          role: 'player',
          createdAt: AdminFieldValue.serverTimestamp()
        }, { merge: true });
      }

      const betRef = adminDb.collection('bets').doc();
      const resolvedGameId = gameId || currentRoundId || `round_${Date.now()}`;
      const betPayload = {
        id: betRef.id,
        userId,
        gameId: resolvedGameId,
        betAmount: amount,
        autoCashoutMultiplier: parsedAuto,
        cashoutMultiplier: 0,
        winAmount: 0,
        status: 'placed',
        consoleIndex: consoleIndex ?? 0,
        createdAt: AdminFieldValue.serverTimestamp(),
        timestamp: new Date().toISOString()
      };
      transaction.set(betRef, betPayload);

      const historyRef = adminDb.collection('balance_history').doc();
      transaction.set(historyRef, {
        userId,
        type: 'bet_placed',
        amount,
        previousBalance: currentBalance,
        newBalance,
        betId: betRef.id,
        timestamp: AdminFieldValue.serverTimestamp()
      });

      return {
        success: true,
        betId: betRef.id,
        newBalance,
        status: 'placed'
      };
    });
  } catch (dbErr: any) {
    // Graceful fallback to authoritative in-memory state if Cloud Admin IAM/gRPC is unavailable
    const memUser = users.get(userId);
    if (!memUser) {
      throw new Error('User profile not found.');
    }
    if (memUser.isFrozen) {
      throw new Error('Account is frozen. Please contact support.');
    }
    const currentBalance = memUser.mainBalance + (memUser.bonusBalance || 0);
    if (isNaN(currentBalance) || currentBalance < amount) {
      throw new Error('Insufficient balance');
    }
    const newBalance = Math.round((memUser.mainBalance - amount) * 100) / 100;
    memUser.mainBalance = Math.max(0, newBalance);
    const betId = `bet_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    return {
      success: true,
      betId,
      newBalance: memUser.mainBalance,
      status: 'placed'
    };
  }
}

/**
 * 2. cashOut(betId, exactMultiplierAtCashout):
 *    - Fetches active game state and player's bet document inside a transaction.
 *    - Verifies game status is still "flying" and that exactMultiplierAtCashout is lower than server-side crash multiplier.
 *    - Calculates winAmount = betAmount * exactMultiplierAtCashout.
 *    - Credits winAmount back to users/{userId}/balance.
 *    - Updates bets/{betId} status to "cashed_out", recording winAmount and cashoutMultiplier.
 *    - Logs transaction in balance_history.
 *
 * Strict Anti-Double-Spending Protection:
 * - Prevents multiple cashouts on the same bet via atomic check-and-set.
 */
export async function executeCashOutTransaction(params: {
  betId: string;
  userId: string;
  exactMultiplierAtCashout: number;
}) {
  const { betId, userId, exactMultiplierAtCashout } = params;
  if (!betId) throw new Error('Missing betId');
  if (!userId) throw new Error('Unauthenticated: User ID required');
  const multiplier = Number(exactMultiplierAtCashout);
  if (isNaN(multiplier) || multiplier < 1.0) {
    throw new Error('Invalid cashout multiplier. Must be >= 1.00x.');
  }

  try {
    return await adminDb.runTransaction(async (transaction) => {
      // 1. Fetch player's bet document inside transaction
      const betRef = adminDb.collection('bets').doc(betId);
      const betDoc = await transaction.get(betRef);

      let betData: any = null;
      if (betDoc.exists) {
        betData = betDoc.data() || {};
      } else {
        const inMemBet = activeBets.get(betId);
        if (inMemBet) {
          betData = {
            userId: inMemBet.userId,
            betAmount: inMemBet.amount,
            status: inMemBet.cashedOut ? 'cashed_out' : 'placed'
          };
        } else {
          throw new Error('Bet document not found.');
        }
      }

      // Verify ownership
      if (betData.userId !== userId) {
        throw new Error('Unauthorized: You do not own this bet.');
      }

      // Strict Anti-Double-Spending Check
      if (betData.status !== 'placed') {
        throw new Error(`Double-spend prevented: Bet is already "${betData.status}".`);
      }

      // 2. Fetch active game state inside transaction
      const gameControlRef = adminDb.collection('game_control').doc('active_round');
      const gameControlDoc = await transaction.get(gameControlRef);

      if (gameControlDoc.exists) {
        const gData = gameControlDoc.data() || {};
        const status = (gData.status || '').toLowerCase();
        if (status !== 'flying') {
          throw new Error(`Cashout rejected: Flight status is "${status}". Plane is not flying.`);
        }
        if (typeof gData.crashMultiplier === 'number' && multiplier >= gData.crashMultiplier) {
          throw new Error(`Cashout rejected: Multiplier ${multiplier}x exceeds crash threshold of ${gData.crashMultiplier}x.`);
        }
      } else {
        if (gameStatus !== 'FLYING') {
          throw new Error(`Cashout rejected: Flight status is "${gameStatus}".`);
        }
        if (multiplier >= plannedCrashMultiplier) {
          throw new Error(`Cashout rejected: Multiplier ${multiplier}x exceeds crash threshold of ${plannedCrashMultiplier}x.`);
        }
      }

      // 3. Calculate winAmount = betAmount * exactMultiplierAtCashout
      const betAmount = Number(betData.betAmount ?? 0);
      if (isNaN(betAmount) || betAmount <= 0) {
        throw new Error('Corrupt bet amount detected.');
      }
      const winAmount = Math.round((betAmount * multiplier) * 100) / 100;

      // 4. Fetch user document inside transaction
      const userRef = adminDb.collection('users').doc(userId);
      const userDoc = await transaction.get(userRef);

      let currentBalance = 0;
      if (userDoc.exists) {
        const uData = userDoc.data() || {};
        currentBalance = Number(uData.balance ?? 0);
        const newBalance = Math.round((currentBalance + winAmount) * 100) / 100;

        // 5. Credit winAmount back to users/{userId}/balance
        transaction.update(userRef, {
          balance: newBalance,
          updatedAt: AdminFieldValue.serverTimestamp()
        });
      } else {
        const memUser = users.get(userId);
        if (memUser) {
          currentBalance = memUser.mainBalance;
        }
      }

      // 6. Update bets/{betId} status to "cashed_out", recording winAmount and cashoutMultiplier
      if (betDoc.exists) {
        transaction.update(betRef, {
          status: 'cashed_out',
          winAmount,
          cashoutMultiplier: multiplier,
          cashedOutAt: AdminFieldValue.serverTimestamp()
        });
      }

      // 7. Log transaction in balance_history
      const historyRef = adminDb.collection('balance_history').doc();
      transaction.set(historyRef, {
        userId,
        type: 'bet_won',
        amount: winAmount,
        previousBalance: currentBalance,
        newBalance: Math.round((currentBalance + winAmount) * 100) / 100,
        betId,
        multiplier,
        timestamp: AdminFieldValue.serverTimestamp()
      });

      return {
        success: true,
        betId,
        winAmount,
        newBalance: Math.round((currentBalance + winAmount) * 100) / 100,
        cashoutMultiplier: multiplier,
        status: 'cashed_out'
      };
    });
  } catch (dbErr: any) {
    if (gameStatus !== 'FLYING') {
      throw new Error(`Cashout rejected: Flight status is "${gameStatus}".`);
    }
    if (multiplier >= plannedCrashMultiplier) {
      throw new Error(`Cashout rejected: Multiplier ${multiplier}x exceeds crash threshold of ${plannedCrashMultiplier}x.`);
    }
    const memUser = users.get(userId);
    if (!memUser) throw new Error('User profile not found.');
    const inMemBet = activeBets.get(betId);
    if (!inMemBet) throw new Error('Bet document not found.');
    if (inMemBet.userId !== userId) throw new Error('Unauthorized: You do not own this bet.');
    if (inMemBet.cashedOut) throw new Error('Double-spend prevented: Bet is already cashed out.');

    const winAmount = Math.round((inMemBet.amount * multiplier) * 100) / 100;
    inMemBet.cashedOut = true;
    inMemBet.cashedOutMultiplier = multiplier;
    inMemBet.winAmount = winAmount;
    memUser.mainBalance = Math.round((memUser.mainBalance + winAmount) * 100) / 100;

    return {
      success: true,
      betId,
      winAmount,
      newBalance: memUser.mainBalance,
      cashoutMultiplier: multiplier,
      status: 'cashed_out'
    };
  }
}

// ==========================================
// MODULE 18: VIP RANKING & GATEWAY CONTROLLERS
// ==========================================
const VIP_TIERS = [
  { level: 0, minLifetimeDeposit: 0, maxSingleWithdrawal: 120, requiredBetAmount: 0, upgradeReward: 0, monthlyReward: 0, label: 'VIP 0' },
  { level: 1, minLifetimeDeposit: 100, maxSingleWithdrawal: 522, requiredBetAmount: 550, upgradeReward: 22, monthlyReward: 7, label: 'VIP 1' },
  { level: 2, minLifetimeDeposit: 500, maxSingleWithdrawal: 1500, requiredBetAmount: 2000, upgradeReward: 45, monthlyReward: 18, label: 'VIP 2' },
  { level: 3, minLifetimeDeposit: 2000, maxSingleWithdrawal: 6000, requiredBetAmount: 5000, upgradeReward: 85, monthlyReward: 40, label: 'VIP 3' },
  { level: 4, minLifetimeDeposit: 5000, maxSingleWithdrawal: 15000, requiredBetAmount: 10000, upgradeReward: 102, monthlyReward: 60, label: 'VIP 4' },
  { level: 5, minLifetimeDeposit: 10000, maxSingleWithdrawal: 25000, requiredBetAmount: 20000, upgradeReward: 180, monthlyReward: 110, label: 'VIP 5' },
  { level: 6, minLifetimeDeposit: 25000, maxSingleWithdrawal: 50000, requiredBetAmount: 50000, upgradeReward: 350, monthlyReward: 220, label: 'VIP 6' },
  { level: 7, minLifetimeDeposit: 50000, maxSingleWithdrawal: 100000, requiredBetAmount: 100000, upgradeReward: 650, monthlyReward: 450, label: 'VIP 7' },
  { level: 8, minLifetimeDeposit: 100000, maxSingleWithdrawal: 250000, requiredBetAmount: 200000, upgradeReward: 1250, monthlyReward: 850, label: 'VIP 8' },
  { level: 9, minLifetimeDeposit: 250000, maxSingleWithdrawal: 500000, requiredBetAmount: 500000, upgradeReward: 2500, monthlyReward: 1800, label: 'VIP 9' },
  { level: 10, minLifetimeDeposit: 500000, maxSingleWithdrawal: 1000000, requiredBetAmount: 1000000, upgradeReward: 5000, monthlyReward: 3600, label: 'VIP 10' }
];

function getVipConfig(lifetimeDeposit: number = 0) {
  for (let i = VIP_TIERS.length - 1; i >= 0; i--) {
    if (lifetimeDeposit >= VIP_TIERS[i].minLifetimeDeposit) {
      return VIP_TIERS[i];
    }
  }
  return VIP_TIERS[0];
}

// MODULE 18: Multi-Tiered First/Recurring Deposit Bonus Engine
const BASELINE_DEPOSIT_BONUSES = [
  { depositAmount: 100, firstTimeBonus: 22, recurringBonus: 7 },
  { depositAmount: 200, firstTimeBonus: 29, recurringBonus: 11 },
  { depositAmount: 500, firstTimeBonus: 45, recurringBonus: 18 },
  { depositAmount: 1000, firstTimeBonus: 65, recurringBonus: 25 },
  { depositAmount: 2000, firstTimeBonus: 85, recurringBonus: 40 },
  { depositAmount: 5000, firstTimeBonus: 102, recurringBonus: 60 }
];

// MODULE 19: Timed Promotional Campaign Override Matrix
let timedCampaign: {
  isActive: boolean;
  campaignTitle: string;
  durationMinutes: number;
  startsAt: number;
  expiresAt: number;
  overrides: Record<number, { firstTime: number; recurring: number }>;
} = {
  isActive: false,
  campaignTitle: 'VIP Weekend Surge',
  durationMinutes: 60,
  startsAt: 0,
  expiresAt: 0,
  overrides: {}
};

function getActiveCampaign() {
  if (timedCampaign.isActive && timedCampaign.expiresAt > 0) {
    if (Date.now() >= timedCampaign.expiresAt) {
      console.log(`[CAMPAIGN TTL EXPIRED] Auto-reverting deposit overrides to Module 18 baseline.`);
      timedCampaign.isActive = false;
      timedCampaign.overrides = {};
    }
  }
  return timedCampaign;
}

// ==========================================
// 1. UPDATED REFERRAL REBATE CALCULATION
// ==========================================
export function calculateReferralRebate(betAmount: number): number {
  // Old logic was 2% (betAmount * 0.02)
  // New logic is exactly 0.02% of the bet amount (betAmount * 0.0002)
  const rebateRate = 0.0002; 
  return +(betAmount * rebateRate).toFixed(2);
}

// ==========================================
// 2. UPDATED MULTI-TIER DEPOSIT BONUS LOGIC
// ==========================================
export function getDepositBonus(depositAmount: number, depositCount: number, existingWebData: number = 0): number {
  // If it's past the 3rd deposit, return the existing web configuration data safely
  if (depositCount > 3) {
    return existingWebData; 
  }

  // First Deposit Logic
  if (depositCount === 1) {
    if (depositAmount >= 5000) return 877;
    if (depositAmount >= 800) {
      // Logical progression between 800 and 5000
      // Scaling proportionally from 200 bonus at 800 up to ~800 bonus near 5000
      let ratio = (depositAmount - 800) / (5000 - 800);
      return Math.floor(200 + (ratio * (877 - 200)));
    }
    if (depositAmount >= 500) return 137;
    if (depositAmount >= 300) return 97;
    if (depositAmount >= 200) return 67;
    if (depositAmount >= 100) return 37;
    return 0; // No bonus for less than 100
  }

  // Second Deposit Logic (Systematic Drop: First Deposit minus 10)
  if (depositCount === 2) {
    if (depositAmount >= 5000) return 777;
    if (depositAmount >= 800) {
      let ratio = (depositAmount - 800) / (5000 - 800);
      return Math.floor(180 + (ratio * (777 - 180)));
    }
    if (depositAmount >= 500) return 127;
    if (depositAmount >= 300) return 87;
    if (depositAmount >= 200) return 57;
    if (depositAmount >= 100) return 27;
    return 0;
  }

  // Third Deposit Logic (Further Drop: Second Deposit minus 10)
  if (depositCount === 3) {
    if (depositAmount >= 5000) return 677;
    if (depositAmount >= 800) {
      let ratio = (depositAmount - 800) / (5000 - 800);
      return Math.floor(160 + (ratio * (677 - 160)));
    }
    if (depositAmount >= 500) return 117;
    if (depositAmount >= 300) return 77;
    if (depositAmount >= 200) return 47;
    if (depositAmount >= 100) return 17;
    return 0;
  }

  return 0;
}

function calculateDepositBonus(amount: number, isFirstTime: boolean, depositCount?: number): number {
  const activeCamp = getActiveCampaign();
  let existingWebData = 0;
  if (activeCamp.isActive && activeCamp.overrides && activeCamp.overrides[amount]) {
    existingWebData = isFirstTime ? activeCamp.overrides[amount].firstTime : activeCamp.overrides[amount].recurring;
  } else {
    const baseline = BASELINE_DEPOSIT_BONUSES.find(b => b.depositAmount === amount);
    if (baseline) {
      existingWebData = isFirstTime ? baseline.firstTimeBonus : baseline.recurringBonus;
    }
  }

  // When depositCount is provided, use the multi-tier first 3 deposit bonus engine
  const effectiveCount = depositCount !== undefined ? depositCount : (isFirstTime ? 1 : 4);
  return getDepositBonus(amount, effectiveCount, existingWebData);
}

// ==========================================
// MODULE 6: ADVANCED LIVE TRAFFIC DISPLAY
// Dynamic multiplier loop: Displayed Count = (Actual Socket Connections * 35) + SeedValue(Min: 45, Max: 120)
// ==========================================
function getDynamicOnlinePlayerCount(): number {
  const actualSockets = io.engine ? (io.engine.clientsCount || 1) : 1;
  const seed = Math.floor(Math.random() * (120 - 45 + 1)) + 45;
  return (actualSockets * 35) + seed;
}

// =========================================================================
// MODULE: HIGH-GOING ROUND CHEAT PROBABILITY MATRIX (EXACT 6/10 RATIO)
// Strict mathematical 60% probability matrix using a shuffled 10-item deck.
// Exactly 6 out of 10 cheat attempts trigger a crash; 4 resolve normally without crashing.
// =========================================================================
export class HighGoingCheatProbabilityMatrix {
  private deck: boolean[] = [];
  private currentIndex: number = 0;
  public totalAttempts: number = 0;
  public totalCrashes: number = 0;
  public totalNormalResolutions: number = 0;
  private cheatPercentage: number = 60; // Default 60% cheat rate

  constructor(cheatPct = 60) {
    this.cheatPercentage = Math.min(100, Math.max(0, Math.round(cheatPct)));
    this.refillAndShuffle();
  }

  public setCheatPercentage(percentage: number) {
    this.cheatPercentage = Math.min(100, Math.max(0, Math.round(percentage)));
    this.refillAndShuffle();
  }

  public getCheatPercentage(): number {
    return this.cheatPercentage;
  }

  private refillAndShuffle() {
    // Generate 100-card deck based on cheatPercentage
    this.deck = [];
    for (let i = 0; i < 100; i++) {
      this.deck.push(i < this.cheatPercentage);
    }
    // Cryptographically unbiased Fisher-Yates shuffle
    for (let i = this.deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const temp = this.deck[i];
      this.deck[i] = this.deck[j];
      this.deck[j] = temp;
    }
    this.currentIndex = 0;
  }

  public evaluateCheatAttempt(context: string): { shouldCrash: boolean; deckStep: number; lifetimeRatio: string } {
    if (this.currentIndex >= this.deck.length) {
      this.refillAndShuffle();
    }
    const shouldCrash = this.deck[this.currentIndex];
    this.currentIndex++;
    this.totalAttempts++;

    if (shouldCrash) {
      this.totalCrashes++;
    } else {
      this.totalNormalResolutions++;
    }

    const lifetimeRatio = `${this.totalCrashes}/${this.totalAttempts} (${Math.round((this.totalCrashes / Math.max(1, this.totalAttempts)) * 100)}%)`;
    console.log(`[CHEAT PROBABILITY MATRIX] High-Going Cheat Attempt #${this.totalAttempts} [${context}]: outcome = ${shouldCrash ? `FORCED CRASH (${this.cheatPercentage}%)` : `NORMAL RESOLUTION / SUCCESS (${100 - this.cheatPercentage}%)`}. Deck position: ${this.currentIndex}/100. Lifetime: ${lifetimeRatio}`);

    return { shouldCrash, deckStep: this.currentIndex, lifetimeRatio };
  }

  public getStats() {
    return {
      currentDeckStep: this.currentIndex,
      deckRemaining: this.deck.length - this.currentIndex,
      totalAttempts: this.totalAttempts,
      totalCrashes: this.totalCrashes,
      totalNormalResolutions: this.totalNormalResolutions,
      cheatPercentage: this.cheatPercentage,
      programmedCrashRate: `${this.cheatPercentage}%`,
      observedRatio: this.totalAttempts > 0 ? +(this.totalCrashes / this.totalAttempts).toFixed(2) : (this.cheatPercentage / 100)
    };
  }
}

export const highGoingCheatMatrix = new HighGoingCheatProbabilityMatrix();

// =========================================================================
// MODULE: ADMIN ROUND CRASH & DESTINATION ASSURANCE STATE
// Strict assurance: Round does NOT crash immediately upon admin command.
// Prevents all cheats during this phase, safely reaches predefined destination,
// and triggers crash ONLY when target destination is reached.
// =========================================================================
export interface AdminDestinationAssurance {
  active: boolean;
  targetDestination: number;
  scheduledBy: string;
  timestamp: number;
}

export const adminDestinationAssurance: AdminDestinationAssurance = {
  active: false,
  targetDestination: 0,
  scheduledBy: '',
  timestamp: 0
};

// =========================================================================
// SUPER ADMIN TIME-BASED CRASH & CHEAT CONTROLLER + DEVELOPER LOSS PROTECTION
// =========================================================================
let totalRealStakesCollected = 0;
let totalRealPayoutsGiven = 0;

let cheatCrashTimeControl: CheatCrashTimeControl = {
  cheatSystemEnabled: true,
  cheatToggleTimerActive: false,
  cheatToggleDurationMinutes: 30,
  cheatToggleTimerStartedAt: 0,
  cheatToggleTimerExpiresAt: 0,
  cheatToggleTargetState: true,
  lastToggledBy: 'Super Admin',
  mode: 'MANUAL',
  durationMinutes: 30,
  timerActive: false,
  timerStartedAt: 0,
  timerExpiresAt: 0,
  timedCheatPercentage: 85,
  timedCrashPercentage: 80,
  scheduleEnabled: false,
  scheduleStartTime: '18:00',
  scheduleEndTime: '23:00',
  scheduledCheatPercentage: 80,
  scheduledCrashPercentage: 75,
  crashAtFlightSecondsEnabled: false,
  crashAtFlightSeconds: 5.0,
  scheduledExactCrashTime: '',
  devLossProtectionEnabled: true,
  devLossTriggerThreshold: 0, // Triggers whenever developer net profit < 0
  devLossCheatPercentage: 95,
  devLossCrashPercentage: 90,
  devLossMaxCrashMultiplier: 1.35,
  isCurrentlyInDevLoss: false,
  currentDeveloperNetProfit: 0,
  totalRealStakesCollected: 0,
  totalRealPayoutsGiven: 0,
  activeReason: 'Manual Control Mode'
};

function computeDeveloperFinancialSituation() {
  let approvedDeps = 0;
  let approvedWds = 0;
  deposits.forEach(d => { if (d.status === 'APPROVED') approvedDeps += d.amount; });
  withdrawals.forEach(w => { if (w.status === 'APPROVED') approvedWds += w.amount; });

  const gameplayNetProfit = +(totalRealStakesCollected - totalRealPayoutsGiven).toFixed(2);
  const cashierNetProfit = +(approvedDeps - approvedWds).toFixed(2);
  // Developer is in loss if gameplay payouts exceed stakes below threshold, or cashier withdrawals exceed deposits, or vault reserve is in deficit
  const isInLoss =
    gameplayNetProfit < cheatCrashTimeControl.devLossTriggerThreshold ||
    (totalRealPayoutsGiven > totalRealStakesCollected && (totalRealStakesCollected > 0 || totalRealPayoutsGiven > 0)) ||
    (approvedWds > approvedDeps && approvedWds > 0) ||
    platformReserveBalance < SYSTEM_VAULT_MINIMUM;

  cheatCrashTimeControl.currentDeveloperNetProfit = gameplayNetProfit;
  cheatCrashTimeControl.totalRealStakesCollected = +totalRealStakesCollected.toFixed(2);
  cheatCrashTimeControl.totalRealPayoutsGiven = +totalRealPayoutsGiven.toFixed(2);
  cheatCrashTimeControl.isCurrentlyInDevLoss = isInLoss;

  return {
    gameplayNetProfit,
    cashierNetProfit,
    isInLoss
  };
}

function isTimeWithinScheduleWindow(startHHMM: string, endHHMM: string): boolean {
  if (!startHHMM || !endHHMM) return false;
  const now = new Date();
  const currMins = now.getHours() * 60 + now.getMinutes();
  const [sH, sM] = startHHMM.split(':').map(Number);
  const [eH, eM] = endHHMM.split(':').map(Number);
  if (isNaN(sH) || isNaN(eH)) return false;
  const startMins = sH * 60 + (sM || 0);
  const endMins = eH * 60 + (eM || 0);
  if (startMins <= endMins) {
    return currMins >= startMins && currMins <= endMins;
  } else {
    // Overnight window (e.g. 22:00 to 04:00)
    return currMins >= startMins || currMins <= endMins;
  }
}

function isCheatSystemCurrentlyActive(): boolean {
  if (cheatCrashTimeControl.cheatToggleTimerActive && (cheatCrashTimeControl.cheatToggleTimerExpiresAt || 0) > 0) {
    if (Date.now() >= (cheatCrashTimeControl.cheatToggleTimerExpiresAt || 0)) {
      // Timer expired -> automatically flip cheatSystemEnabled to the opposite state
      cheatCrashTimeControl.cheatToggleTimerActive = false;
      cheatCrashTimeControl.cheatToggleTimerExpiresAt = 0;
      cheatCrashTimeControl.cheatSystemEnabled = !cheatCrashTimeControl.cheatSystemEnabled;
      cheatCrashTimeControl.activeReason = cheatCrashTimeControl.cheatSystemEnabled
        ? 'Cheat Timer Expired -> Auto Re-Enabled Cheats (ON)'
        : 'Cheat Timer Expired -> Auto Switched to 100% Fair Mode (OFF)';
      io.emit('admin:cheat_time_control_updated', cheatCrashTimeControl);
    }
  }
  return cheatCrashTimeControl.cheatSystemEnabled !== false;
}

function getEffectiveCheatAndCrashConfig(): {
  cheatPct: number;
  crashPct: number;
  maxCrashCap?: number;
  reason: string;
} {
  const devStatus = computeDeveloperFinancialSituation();
  const cheatActive = isCheatSystemCurrentlyActive();

  // 0. If Master Cheat Switch is OFF -> 100% Fair Play Mode (0% Cheat, natural fair distribution)
  if (!cheatActive) {
    let fairReason = `100% FAIR MODE ACTIVE (All Cheats OFF by ${cheatCrashTimeControl.lastToggledBy || 'Admin'})`;
    if (cheatCrashTimeControl.cheatToggleTimerActive && (cheatCrashTimeControl.cheatToggleTimerExpiresAt || 0) > Date.now()) {
      const minsLeft = Math.max(1, Math.ceil(((cheatCrashTimeControl.cheatToggleTimerExpiresAt || 0) - Date.now()) / 60000));
      fairReason = `100% FAIR MODE (Timed OFF: ${minsLeft}m left before Cheat ON)`;
    }
    cheatCrashTimeControl.activeReason = fairReason;
    if (highGoingCheatMatrix.getCheatPercentage() !== 0) {
      highGoingCheatMatrix.setCheatPercentage(0);
    }
    return {
      cheatPct: 0,
      crashPct: 32, // Natural provably fair baseline (<1.90x rate)
      reason: fairReason
    };
  }

  // 1. Check Developer Loss Situation Auto-Protection first
  if (cheatCrashTimeControl.devLossProtectionEnabled && devStatus.isInLoss) {
    const reason = `DEVELOPER LOSS RECOVERY ACTIVE (Net: ₹${devStatus.gameplayNetProfit.toFixed(2)})`;
    cheatCrashTimeControl.activeReason = reason;
    highGoingCheatMatrix.setCheatPercentage(cheatCrashTimeControl.devLossCheatPercentage);
    return {
      cheatPct: cheatCrashTimeControl.devLossCheatPercentage,
      crashPct: cheatCrashTimeControl.devLossCrashPercentage,
      maxCrashCap: cheatCrashTimeControl.devLossMaxCrashMultiplier,
      reason
    };
  }

  // 2. Check Timed Duration Mode
  if (cheatCrashTimeControl.mode === 'TIMED_DURATION' && cheatCrashTimeControl.timerActive) {
    if (Date.now() < cheatCrashTimeControl.timerExpiresAt) {
      const minsLeft = Math.max(1, Math.ceil((cheatCrashTimeControl.timerExpiresAt - Date.now()) / 60000));
      const reason = `Timed Override Active (${minsLeft}m remaining)`;
      cheatCrashTimeControl.activeReason = reason;
      if (highGoingCheatMatrix.getCheatPercentage() !== cheatCrashTimeControl.timedCheatPercentage) {
        highGoingCheatMatrix.setCheatPercentage(cheatCrashTimeControl.timedCheatPercentage);
      }
      return {
        cheatPct: cheatCrashTimeControl.timedCheatPercentage,
        crashPct: cheatCrashTimeControl.timedCrashPercentage,
        reason
      };
    } else {
      // Timer expired -> auto-revert to AUTO_DYNAMIC or MANUAL
      cheatCrashTimeControl.timerActive = false;
      cheatCrashTimeControl.mode = 'AUTO_DYNAMIC';
      io.emit('admin:cheat_time_control_updated', cheatCrashTimeControl);
    }
  }

  // 3. Check Scheduled Time Window Mode
  if (
    (cheatCrashTimeControl.mode === 'SCHEDULED_WINDOW' || cheatCrashTimeControl.scheduleEnabled) &&
    isTimeWithinScheduleWindow(cheatCrashTimeControl.scheduleStartTime, cheatCrashTimeControl.scheduleEndTime)
  ) {
    const reason = `Scheduled Window (${cheatCrashTimeControl.scheduleStartTime} - ${cheatCrashTimeControl.scheduleEndTime})`;
    cheatCrashTimeControl.activeReason = reason;
    if (highGoingCheatMatrix.getCheatPercentage() !== cheatCrashTimeControl.scheduledCheatPercentage) {
      highGoingCheatMatrix.setCheatPercentage(cheatCrashTimeControl.scheduledCheatPercentage);
    }
    return {
      cheatPct: cheatCrashTimeControl.scheduledCheatPercentage,
      crashPct: cheatCrashTimeControl.scheduledCrashPercentage,
      reason
    };
  }

  // 4. Check Auto Dynamic Mode (AI Cheat decreased by 50%; Admin/SuperAdmin Manual Sliders remain 100% as set)
  if (cheatCrashTimeControl.mode === 'AUTO_DYNAMIC') {
    const activeHumanBets = Array.from(activeBets.values()).filter(b => !b.isBot && !b.cashedOut);
    const roundStake = activeHumanBets.reduce((s, b) => s + b.amount, 0);
    let rawAiCheat = 60;
    let rawAiCrash = 47;
    if (roundStake >= 5000) {
      rawAiCheat = 90;
      rawAiCrash = 82;
    } else if (roundStake >= 1500) {
      rawAiCheat = 78;
      rawAiCrash = 68;
    } else if (roundStake >= 500) {
      rawAiCheat = 68;
      rawAiCrash = 58;
    }
    // 50% decrease applied strictly to AI autonomous percentages
    const autoCheat = Math.max(0, Math.round(rawAiCheat * 0.5));
    const autoCrash = Math.max(0, Math.round(rawAiCrash * 0.5));
    const reason = `Auto Dynamic AI Engine [50% Reduced] (Stake ₹${roundStake} -> AI Cheat ${autoCheat}% / AI Crash ${autoCrash}%)`;
    cheatCrashTimeControl.activeReason = reason;
    if (highGoingCheatMatrix.getCheatPercentage() !== autoCheat) {
      highGoingCheatMatrix.setCheatPercentage(autoCheat);
    }
    return {
      cheatPct: autoCheat,
      crashPct: autoCrash,
      reason
    };
  }

  // 5. Default Manual Mode (Strictly uses exact percentage controlled by Admin / Super Admin)
  const manualCheat = systemConfig.cheatPercentage ?? 60;
  const manualCrash = systemConfig.crashPercentage ?? 47;
  if (highGoingCheatMatrix.getCheatPercentage() !== manualCheat) {
    highGoingCheatMatrix.setCheatPercentage(manualCheat);
  }
  cheatCrashTimeControl.activeReason = `Manual Fixed Mode (Cheat ${manualCheat}% / Crash ${manualCrash}%)`;
  return {
    cheatPct: manualCheat,
    crashPct: manualCrash,
    reason: cheatCrashTimeControl.activeReason
  };
}

function isPeakHourActive(): boolean {
  const currentHour = new Date().getHours();
  return peakSchedules.some(s => s.isActive && currentHour >= s.startHour && currentHour <= s.endHour);
}

function calculateAlgorithmicCrashPoint(): number {
  const distributionRoll = Math.floor(Math.random() * 100) + 1; // 1 to 100
  const cheatActive = isCheatSystemCurrentlyActive();
  const isReserveDeficit = cheatActive && (platformReserveBalance < SYSTEM_VAULT_MINIMUM);
  const isPeak = cheatActive && isPeakHourActive();

  const effective = getEffectiveCheatAndCrashConfig();
  const baseCrashPct = effective.crashPct;
  // AI peak/deficit bump reduced by 50% (+7.5% rounded to +8% instead of +15%), and only applied in AUTO_DYNAMIC AI mode
  const aiExtraBump = (cheatCrashTimeControl.mode === 'AUTO_DYNAMIC' && (isReserveDeficit || isPeak)) ? 8 : 0;
  const lowYieldThreshold = Math.min(98, Math.max(2, baseCrashPct + aiExtraBump));

  let resultMult = 1.85;
  // Phase 1: Crashes before 1.90x based on exact lowYieldThreshold
  if (distributionRoll <= lowYieldThreshold) {
    resultMult = parseFloat((1.01 + Math.random() * 0.88).toFixed(2));
  } else {
    const remaining = 100 - lowYieldThreshold;
    const midThreshold = lowYieldThreshold + Math.ceil(remaining * 0.70);
    if (distributionRoll <= midThreshold) {
      // Phase 2: Modest-Yield Trajectory (1.90x to 5.00x)
      resultMult = parseFloat((1.90 + Math.random() * 3.10).toFixed(2));
    } else {
      // Phase 3: High-Yield Trajectory (5.00x to 25.00x)
      const highThreshold = lowYieldThreshold + Math.ceil(remaining * 0.90);
      if (distributionRoll <= highThreshold) {
        resultMult = parseFloat((5.00 + Math.random() * 20.00).toFixed(2));
      } else {
        // Phase 4: Super-Yield Trajectory (25.00x to 250.00x)
        const superThreshold = lowYieldThreshold + Math.ceil(remaining * 0.98);
        if (distributionRoll <= superThreshold) {
          resultMult = parseFloat((25.00 + Math.random() * 225.00).toFixed(2));
        } else {
          // Phase 5: Rare Moonshot Spike
          const roll = Math.random();
          let megaFlight = 250.00;
          if (roll < 0.75) {
            megaFlight = 250.00 + Math.random() * 750.00;
          } else if (roll < 0.96) {
            megaFlight = 1000.00 + Math.random() * 4000.00;
          } else {
            megaFlight = 5000.00 + Math.random() * 5000.00;
          }
          resultMult = parseFloat(Math.min(10000.00, megaFlight).toFixed(2));
        }
      }
    }
  }

  // If Cheat is OFF (100% Fair Mode), return pure natural multiplier without any clamps
  if (!cheatActive) {
    return resultMult;
  }

  // Enforce Developer Loss Max Crash Ceiling if active
  if (effective.maxCrashCap && effective.maxCrashCap >= 1.01 && resultMult > effective.maxCrashCap) {
    const clampedLossMult = parseFloat((1.01 + Math.random() * Math.max(0.02, effective.maxCrashCap - 1.01)).toFixed(2));
    console.log(`[DEV LOSS PROTECTION] Clamped natural crash ${resultMult}x -> ${clampedLossMult}x (Max Cap: ${effective.maxCrashCap}x)`);
    resultMult = clampedLossMult;
  }

  // Enforce Set Flight Seconds Crash Time if enabled by Super Admin
  if (cheatCrashTimeControl.crashAtFlightSecondsEnabled && cheatCrashTimeControl.crashAtFlightSeconds > 0) {
    const maxMultByTime = getSmoothFlightMultiplier(cheatCrashTimeControl.crashAtFlightSeconds);
    if (resultMult > maxMultByTime) {
      resultMult = Math.max(1.01, maxMultByTime);
    }
  }

  // Enforce Scheduled Exact Crash Wall-Clock Time (HH:MM) if matched
  if (cheatCrashTimeControl.scheduledExactCrashTime) {
    const now = new Date();
    const currentHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    if (currentHHMM === cheatCrashTimeControl.scheduledExactCrashTime) {
      resultMult = +(1.01 + Math.random() * 0.08).toFixed(2);
    }
  }

  return resultMult;
}

// =========================================================================
// AVIATOR 8-SEC 2X EXPONENTIAL ENGINE (CRITICAL TIMING CONSTRAINT)
// Speed Factor: ln(2) / 8 ≈ 0.08664339756999316
// t=0s: 1.00x, t=8s: 2.00x, t≈26.5s: 10.00x, t≈53.1s: 100.00x
// Pure mathematical formula: Multiplier = Math.pow(Math.E, speed_factor * elapsed_seconds)
// =========================================================================
export const AVIATOR_SPEED_FACTOR = 0.06931471805599453; // 20% decreased flight speed (0.08664339756999316 * 0.8)

export function getNaturalDurationForMultiplier(mult: number): number {
  if (mult <= 1.00) return 0;
  return Math.log(mult) / AVIATOR_SPEED_FACTOR;
}

export function getSmoothFlightMultiplier(elapsedSeconds: number): number {
  if (elapsedSeconds <= 0) return 1.00;
  const mult = Math.pow(Math.E, AVIATOR_SPEED_FACTOR * elapsedSeconds);
  const MAX_LIMIT = 10000;
  return parseFloat(Math.min(MAX_LIMIT, mult).toFixed(2));
}

function computeCrashPoint(): number {
  // If Admin Round Crash / Destination Assurance is active, honor target destination and bypass all cheats
  if (adminDestinationAssurance.active && adminDestinationAssurance.targetDestination >= 1.01) {
    console.log(`[DESTINATION ASSURANCE] Predefined target destination preserved: ${adminDestinationAssurance.targetDestination}x. Cheats neutralized.`);
    return adminDestinationAssurance.targetDestination;
  }

  // Preset admin crash override takes precedence if set
  if (systemConfig.nextRoundPresetCrash && systemConfig.nextRoundPresetCrash >= 1.01) {
    const preset = systemConfig.nextRoundPresetCrash;
    systemConfig.nextRoundPresetCrash = undefined;
    return preset;
  }

  if (systemConfig.manualOverrideActive) {
    return 10000.00;
  }

  // If Master Cheat ON/OFF switch is OFF -> 100% Fair Mode! Bypass all cheat traps & trend manipulation
  if (!isCheatSystemCurrentlyActive()) {
    return calculateAlgorithmicCrashPoint();
  }

  // =========================================================================
  // MODULE 5: HISTORY-BASED TREND MANIPULATION ENGINE
  // =========================================================================
  if (trendSeedConfig.consecutiveCrashesRemaining > 0) {
    trendSeedConfig.consecutiveCrashesRemaining -= 1;
    const instantCrash = +(1.01 + Math.random() * 0.09).toFixed(2);
    console.log(`[TREND ENGINE] Forced consecutive instant crash injected (${trendSeedConfig.consecutiveCrashesRemaining} remaining): ${instantCrash}x`);
    return instantCrash;
  }

  if (trendSeedConfig.customSequence && trendSeedConfig.customSequence.length > 0) {
    const nextSeq = trendSeedConfig.customSequence.shift()!;
    console.log(`[TREND ENGINE] Executing custom sequence injected step: ${nextSeq}x`);
    return +nextSeq.toFixed(2);
  }

  // Check active pool liabilities
  const activeHumanBets = Array.from(activeBets.values()).filter(b => !b.isBot && !b.cashedOut);
  const totalHumanStake = activeHumanBets.reduce((sum, b) => sum + b.amount, 0);
  const totalPotentialLiability = activeHumanBets.reduce((sum, b) => sum + (b.amount * (b.autoCashoutMultiplier || 2.5)), 0);

  if (trendSeedConfig.autoOverrideOnLiability && (totalPotentialLiability >= (trendSeedConfig.liabilityCrashThreshold || 8000) || totalHumanStake >= 4000)) {
    if (adminDestinationAssurance.active) {
      console.log(`[DESTINATION ASSURANCE] Pool liability cheat overridden for admin assured flight.`);
    } else if (Math.random() < 0.50) {
      // 50% AI cheat reduction applied to autonomous liability override
      const cheatDecision = highGoingCheatMatrix.evaluateCheatAttempt('Liability Spike Override');
      if (cheatDecision.shouldCrash) {
        const forcedInstant = +(1.01 + Math.random() * 0.09).toFixed(2);
        console.log(`[TREND ENGINE] Total active pool liabilities spiked. Matrix triggered instant crash: ${forcedInstant}x`);
        return forcedInstant;
      }
    }
  }

  // =========================================================================
  // MODULE 23 A: ASYNCHRONOUS AUTO-CASHOUT PREDICTION ENGINE (AI Cheat decreased 50%)
  // =========================================================================
  if (!adminDestinationAssurance.active && Math.random() < 0.50) {
    const COMMON_AUTOCASHOUT_INDICES = [1.50, 2.00, 2.50, 3.00, 4.00, 5.00, 10.00];
    const humanBetsWithAuto = Array.from(activeBets.values()).filter(
      b => !b.isBot && !b.cashedOut && b.autoCashoutMultiplier && b.autoCashoutMultiplier > 1.05
    );

    for (const milestone of COMMON_AUTOCASHOUT_INDICES) {
      const milestoneBets = humanBetsWithAuto.filter(
        b => Math.abs(b.autoCashoutMultiplier! - milestone) <= 0.05
      );
      const milestoneLiability = milestoneBets.reduce((sum, b) => sum + (b.amount * b.autoCashoutMultiplier!), 0);

      if (milestoneLiability >= 1000) {
        const cheatDecision = highGoingCheatMatrix.evaluateCheatAttempt(`Pre-computation Milestone Desync @ ${milestone}x`);
        if (cheatDecision.shouldCrash) {
          const preEmptiveCrash = +(milestone - 0.02).toFixed(2);
          console.log(`[DESYNC ENGINE] Pre-computed desync crash point at ${preEmptiveCrash}x for ${milestone}x peak liability milestone (₹${milestoneLiability.toFixed(2)}).`);
          return preEmptiveCrash;
        }
      }
    }
  }

  // =========================================================================
  // MODULE 3: SMART PLAYER LOCK ENGINE
  // High-going round cheat matrix: 6/10 attempts crash, 4/10 resolve normally
  // =========================================================================
  let lockedUserBetFound = false;
  let minLockedAutoCashout: number | undefined = undefined;

  for (const bet of activeBets.values()) {
    if (!bet.isBot) {
      const user = users.get(bet.userId);
      if (user && user.smartLockActive && (user.smartLockRoundsLeft || 0) > 0) {
        lockedUserBetFound = true;
        if (bet.autoCashoutMultiplier) {
          if (!minLockedAutoCashout || bet.autoCashoutMultiplier < minLockedAutoCashout) {
            minLockedAutoCashout = bet.autoCashoutMultiplier;
          }
        }
      }
    }
  }

  if (lockedUserBetFound) {
    if (adminDestinationAssurance.active) {
      console.log('[DESTINATION ASSURANCE] Active bet by Smart-Locked user detected, but Destination Assurance is ACTIVE. Cheats disabled.');
    } else {
      const cheatDecision = highGoingCheatMatrix.evaluateCheatAttempt('Smart Lock Hard-Lose Clamp');
      if (cheatDecision.shouldCrash) {
        console.log('[SMART LOCK ENGINE] Active bet by Smart-Locked user detected! Enforcing 6/10 Hard-Lose clamp.');
        if (minLockedAutoCashout && minLockedAutoCashout > 1.12) {
          const ceiling = Math.min(1.15, minLockedAutoCashout - 0.10);
          return +(1.03 + Math.random() * (ceiling - 1.03)).toFixed(2);
        }
        return +(1.03 + Math.random() * 0.10).toFixed(2);
      } else {
        console.log('[SMART LOCK ENGINE] 4/10 probability matrix branch granted normal flight without clamping.');
      }
    }
  }

  // =========================================================================
  // MODULE 21: TARGETED BAIT-AND-CLAMP SEQUENCE FOR WHALE STAKES (>= ₹2,000)
  // Stage 1 & 2: High yield (up to 4.5x) to artificially inflate session confidence
  // Stage 3: Evaluates high-going cheat probability matrix (60% crash / 40% pass)
  // =========================================================================
  for (const bet of activeBets.values()) {
    if (!bet.isBot && activeWhaleSequences.has(bet.userId)) {
      const whaleSeq = activeWhaleSequences.get(bet.userId)!;
      if (whaleSeq.stage === 1) {
        // Round 1 of Bait: High-yield lifecycle up to 4.5x
        const baitPoint = +(3.40 + Math.random() * 1.05).toFixed(2); // 3.40x - 4.45x
        whaleSeq.stage = 2;
        console.log(`[WHALE ENGINE] Stage 1 Bait executed for user ${bet.userId} (Stake ₹${bet.amount}). Crash point: ${baitPoint}x`);
        return baitPoint;
      } else if (whaleSeq.stage === 2) {
        // Round 2 of Bait: High-yield lifecycle up to 4.5x
        const baitPoint = +(3.20 + Math.random() * 1.10).toFixed(2); // 3.20x - 4.30x
        whaleSeq.stage = 3;
        console.log(`[WHALE ENGINE] Stage 2 Bait executed for user ${bet.userId} (Stake ₹${bet.amount}). Crash point: ${baitPoint}x`);
        return baitPoint;
      } else if (whaleSeq.stage === 3) {
        activeWhaleSequences.delete(bet.userId);
        if (adminDestinationAssurance.active) {
          console.log(`[DESTINATION ASSURANCE] Whale stage 3 clamp bypassed for admin destination.`);
        } else {
          const cheatDecision = highGoingCheatMatrix.evaluateCheatAttempt('Whale Stage 3 Clamp');
          if (cheatDecision.shouldCrash) {
            // Round 3: HARD-CLAMP strictly below 1.20x (6/10 matrix)
            const clampPoint = +(1.05 + Math.random() * 0.12).toFixed(2); // 1.05x - 1.17x (< 1.20x)
            console.log(`[WHALE ENGINE] Stage 3 Clamp executed (6/10 matrix) for user ${bet.userId} (Stake ₹${bet.amount}). Hard crash point: ${clampPoint}x (<1.20x)`);
            return clampPoint;
          } else {
            console.log(`[WHALE ENGINE] Stage 3 Clamp resolved normally (4/10 matrix) for user ${bet.userId}. Preserving natural flight trajectory.`);
          }
        }
      }
    }
  }

  // Autonomous AI Margin Calculation (47% Rule + Peak Schedules + Loss Recovery Buffer)
  return calculateAlgorithmicCrashPoint();
}

// ==========================================
// NATURAL FAKE BETS GENERATOR FOR AVIATOR ARENA
// ==========================================
export const fakeUsernamesList = [
    "Rahul_99", "Aman_X", "LuckyKing", "AviatorPro", "Deepak77", 
    "Rohit_Vip", "Sameer_07", "CryptoKing", "Zayn_Malik", "Karan_99",
    "Vikash_Op", "Amit_Bet", "Royal_Sahil", "King_Khan", "Nikhil_01"
];

export function generateFakeAviatorBets(onlineRealPlayersCount: number) {
    // Agar real players zyada hain toh 100-200, warna 40-60 fake active bets generate honge
    const targetCount = onlineRealPlayersCount > 50 ? Math.floor(Math.random() * 100) + 100 : Math.floor(Math.random() * 21) + 40;
    const activeFakeBets: Array<{
        username: string;
        betAmount: number;
        cashedOut: boolean;
        multiplier: number | null;
    }> = [];

    for (let i = 0; i < targetCount; i++) {
        const randomName = fakeUsernamesList[Math.floor(Math.random() * fakeUsernamesList.length)];
        const randomBetAmount = Math.floor(Math.random() * 950) + 50; // ₹50 se ₹1000 tak
        const hasCashedOut = Math.random() > 0.3; // 70% chance cashout kar liya ho
        const cashoutAt = hasCashedOut ? parseFloat((1.10 + Math.random() * 2.50).toFixed(2)) : null;

        activeFakeBets.push({
            username: `${randomName}_${Math.floor(Math.random() * 90) + 10}`,
            betAmount: randomBetAmount,
            cashedOut: hasCashedOut,
            multiplier: cashoutAt
        });
    }
    return activeFakeBets;
}

function seedBotBets() {
  const onlineCount = io.engine ? (io.engine.clientsCount || 1) : 1;
  const fakeBets = generateFakeAviatorBets(onlineCount);

  for (let i = 0; i < fakeBets.length; i++) {
    const fake = fakeBets[i];
    const botBetId = `fake_bet_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 6)}`;
    const botBet: Bet = {
      id: botBetId,
      userId: `bot_${i}`,
      uid: `UID-${Math.floor(1000 + Math.random() * 9000)}`,
      userName: fake.username,
      roundId: currentRoundId,
      consoleIndex: (i % 2) as 0 | 1,
      amount: fake.betAmount,
      autoCashoutMultiplier: fake.multiplier || undefined,
      cashedOut: false,
      isBot: true,
      createdAt: Date.now() - Math.floor(Math.random() * 3000)
    };
    activeBets.set(botBet.id, botBet);
  }
}

function getSortedActiveBets(): Bet[] {
  return Array.from(activeBets.values()).sort((a, b) => {
    if (b.amount !== a.amount) return b.amount - a.amount;
    return (a.createdAt || 0) - (b.createdAt || 0);
  });
}

// DETACH STUCK BIDS SAFEGUARD: Forcefully resolve stuck placed bets
async function cleanStuckBetsSafeguard(roundId: string, finalMultiplier: number) {
  try {
    // 1. In-memory cleanup
    for (const [betId, bet] of activeBets.entries()) {
      if (!bet.cashedOut) {
        bet.cashedOut = true;
        (bet as any).status = 'busted';
        (bet as any).crashedAt = finalMultiplier;
        roundBetsHistory.push({ ...bet });

        // Forcefully notify user console to unlock and reset
        io.to(`user_${bet.userId}`).emit('bet_busted', {
          betId: bet.id,
          roundId: bet.roundId || roundId,
          status: 'busted',
          consoleIndex: bet.consoleIndex,
          crashedAt: finalMultiplier
        });
        io.to(`user_${bet.userId}`).emit('bet_resolved', {
          betId: bet.id,
          status: 'busted',
          consoleIndex: bet.consoleIndex
        });
      }
    }

    // 2. Firestore cleaning batch to resolve stuck placed bets (non-blocking fallback)
    try {
      const placedBetsSnapshot = await adminDb.collection('bets')
        .where('status', '==', 'placed')
        .limit(100)
        .get();

      if (!placedBetsSnapshot.empty) {
        const batch = adminDb.batch();
        placedBetsSnapshot.forEach(doc => {
          batch.update(doc.ref, {
            status: 'busted',
            crashedAtMultiplier: finalMultiplier,
            resolvedAt: AdminFieldValue.serverTimestamp(),
            winAmount: 0,
            resolutionReason: 'SAFEGUARD_DETACH_ROUND_CRASH'
          });
        });
        await batch.commit();
        console.log(`[STUCK BIDS SAFEGUARD] Forcefully resolved ${placedBetsSnapshot.size} placed bets to 'busted' for round ${roundId}.`);
      }
    } catch (dbErr: any) {
      // In container sandbox environments without dedicated service account keys,
      // in-memory state and socket events reliably detach all active bets.
    }
  } catch (err: any) {
    // Graceful swallow of non-fatal cleanup exceptions
  }
}

function startWaitingPhase() {
  gameState = 'STATE_PREPARATION';
  gameStatus = 'WAITING';
  preparationCountdown = PREPARATION_TIME;
  waitingCountdown = 10;
  currentMultiplier = 1.00;

  // Detach any stuck bets from previous rounds to guarantee clean pipeline
  cleanStuckBetsSafeguard(currentRoundId, 1.00);

  userBetCountInPrepPhase.clear(); // Reset 10s anti-spam rate limiter
  activeBets.clear();

  // Autonomous Sequential Round Numbering
  roundSerialNumber++;
  currentRoundId = `Round No - ${roundSerialNumber}`;
  currentRoundName = `Round No - ${roundSerialNumber}`;

  syncGameControlToFirestore('waiting', 1.00);
  seedBotBets();

  // Process and activate queued bets placed during previous flight
  if (queuedBetsForNextRound.size > 0) {
    for (const [key, qb] of queuedBetsForNextRound.entries()) {
      if (qb.userId) {
        const user = users.get(qb.userId);
        if (user && !user.isFrozen) {
          const playerUid = user.uid || generateUnique7DigitUid();
          user.uid = playerUid;
        const activatedBet: Bet = {
          id: qb.id,
          userId: user.id,
          uid: playerUid,
          userName: maskPlayerName(user.name),
          roundId: currentRoundId,
          consoleIndex: qb.consoleIndex,
          amount: qb.amount,
          autoCashoutMultiplier: qb.autoCashout && qb.autoCashout >= 1.05 ? +qb.autoCashout : undefined,
          cashedOut: false,
          createdAt: Date.now()
        };
        activeBets.set(activatedBet.id, activatedBet);
        io.to(`user_${user.id}`).emit('bet_placed', {
          bet: activatedBet,
          newBalance: user.mainBalance,
          newBonus: user.bonusBalance,
          turnoverCompleted: user.turnoverCompleted,
          requiredWager: user.requiredWager ?? 0
        });
        }
      }
    }
    queuedBetsForNextRound.clear();
  }

  // Broadcast sorted active bets (highest bettor at the top)
  const sortedBets = getSortedActiveBets();
  io.emit('active_bets_list', sortedBets);
  io.emit('active_bets_update', sortedBets);

  // Reset collective cashout ticker
  totalRoundCashOut = 0;
  realUserCashOut = 0;
  syntheticBotCashOut = 0;
  const initialTicker: CollectiveCashOutTicker = {
    totalVolume: 0,
    realVolume: 0,
    syntheticVolume: 0,
    isCrashed: false
  };
  io.emit('cashout_ticker', initialTicker);

  // Broadcast traffic update & state
  io.emit('online_traffic_update', { onlineCount: getDynamicOnlinePlayerCount() });
  io.emit('game_state', getPublicGameState());

  if (waitingCountdownInterval) clearInterval(waitingCountdownInterval);
  waitingCountdownInterval = setInterval(() => {
    preparationCountdown -= 0.1;
    const timeLeft = parseFloat(Math.max(0, preparationCountdown).toFixed(1));
    waitingCountdown = Math.ceil(timeLeft);

    // Module 13: 100ms dynamic tick broadcast with explicit state
    io.emit('countdown_tick', {
      state: gameState,
      timeLeft,
      countdownSeconds: waitingCountdown,
      roundId: currentRoundId,
      roundName: currentRoundName
    });

    if (preparationCountdown <= 0.05) {
      if (waitingCountdownInterval) clearInterval(waitingCountdownInterval);
      startFlyingPhase();
    }
  }, 100);
}

function startFlyingPhase() {
  gameState = 'STATE_FLYING';
  gameStatus = 'FLYING';
  roundStartTime = Date.now();
  currentMultiplier = 1.00;
  
  plannedCrashMultiplier = computeCrashPoint();
  plannedFlightDurationSeconds = getNaturalDurationForMultiplier(plannedCrashMultiplier);
  
  syncGameControlToFirestore('flying', 1.00, plannedCrashMultiplier);

  io.emit('game_started', { state: gameState });
  io.emit('flight_started', {
    roundId: currentRoundId,
    roundName: currentRoundName,
    startedAt: roundStartTime,
    plannedDurationSeconds: plannedFlightDurationSeconds,
    plannedCrashMultiplier
  });

  if (gameLoopInterval) clearInterval(gameLoopInterval);

  // 25ms high-precision tick execution (40 ticks/second) for zero-lag crash sync
  gameLoopInterval = setInterval(() => {
    if (gameStatus !== 'FLYING') return;

    const elapsedSeconds = (Date.now() - roundStartTime) / 1000;

    // Pure mathematical exponential speed curve
    let nextMultiplier = getSmoothFlightMultiplier(elapsedSeconds);
    const MAX_LIMIT = 10000;
    if (nextMultiplier > MAX_LIMIT) nextMultiplier = MAX_LIMIT;

    // Prevent server multiplier from ever overshooting plannedCrashMultiplier between ticks
    const reachedPlannedCrash =
      nextMultiplier >= plannedCrashMultiplier ||
      (plannedFlightDurationSeconds > 0 && elapsedSeconds >= plannedFlightDurationSeconds);

    currentMultiplier = reachedPlannedCrash
      ? +plannedCrashMultiplier.toFixed(2)
      : +nextMultiplier.toFixed(2);

    // =========================================================================
    // STRICT REAL DATA: Only real user cashouts (no synthetic/fake bots)
    // =========================================================================
    totalRoundCashOut = +realUserCashOut.toFixed(2);

    const tickerUpdate: CollectiveCashOutTicker = {
      totalVolume: totalRoundCashOut,
      realVolume: realUserCashOut,
      syntheticVolume: 0,
      isCrashed: false
    };
    io.emit('cashout_ticker', tickerUpdate);

    // =========================================================================
    // MODULE 10: ASYNCHRONOUS RISK ENGINE & LIABILITY MONITORING
    // Liability = Sum(Real User Bet Sizes * Current Live Multiplier)
    // =========================================================================
    const activeHumanBets = Array.from(activeBets.values()).filter(b => !b.isBot && !b.cashedOut);
    const liveLiability = activeHumanBets.reduce((sum, b) => sum + (b.amount * currentMultiplier), 0);
    const threshold = systemConfig.maxPlatformLiabilityThreshold || 10000;

    if (liveLiability >= threshold) {
      const alert: LiabilityAlert = {
        currentLiability: +liveLiability.toFixed(2),
        threshold,
        activeRealStakes: activeHumanBets.reduce((sum, b) => sum + b.amount, 0),
        liveMultiplier: currentMultiplier,
        recommendation: `CRASH RECOMMENDED: Net real liability ₹${Math.round(liveLiability).toLocaleString('en-IN')} breached safety threshold ₹${threshold.toLocaleString('en-IN')}!`,
        timestamp: Date.now()
      };
      io.emit('admin:liability_spike_alert', alert);
    }

    // =========================================================================
    // DEVELOPER LOSS SITUATION LIVE IN-FLIGHT GUARD & TIMED FLIGHT CRASH
    // If developers are in loss situation or current live payout liability would
    // push developers into loss, crash immediately before players cash out!
    // =========================================================================
    const masterCheatActive = isCheatSystemCurrentlyActive();
    if (masterCheatActive && !adminDestinationAssurance.active && !systemConfig.manualOverrideActive) {
      if (cheatCrashTimeControl.crashAtFlightSecondsEnabled && cheatCrashTimeControl.crashAtFlightSeconds > 0 && elapsedSeconds >= cheatCrashTimeControl.crashAtFlightSeconds) {
        triggerCrash(currentMultiplier);
        return;
      }

      if (cheatCrashTimeControl.devLossProtectionEnabled) {
        const devSit = computeDeveloperFinancialSituation();
        const activeRealNonAdminBets = activeHumanBets.filter(b => b.userId !== SUPER_ADMIN_ID);
        const liveRealExposure = activeRealNonAdminBets.reduce((s, b) => s + (b.amount * currentMultiplier), 0);
        const currentRoundRealStakes = activeRealNonAdminBets.reduce((s, b) => s + b.amount, 0);

        // If developer is already in loss and multiplier reaches max cap, or if live exposure exceeds safe margin
        if (devSit.isInLoss && currentMultiplier >= (cheatCrashTimeControl.devLossMaxCrashMultiplier || 1.35)) {
          console.log(`[DEV LOSS GUARD] Developer in loss situation (Net: ₹${devSit.gameplayNetProfit}). Force-crashing at ${currentMultiplier}x.`);
          triggerCrash(currentMultiplier);
          return;
        }
        if (activeRealNonAdminBets.length > 0 && liveRealExposure > (currentRoundRealStakes + Math.max(0, devSit.gameplayNetProfit)) && currentMultiplier >= 1.15) {
          const cheatRoll = highGoingCheatMatrix.evaluateCheatAttempt('Developer Loss Situation Live Exposure Guard');
          if (cheatRoll.shouldCrash || devSit.isInLoss) {
            console.log(`[DEV LOSS GUARD] Live exposure ₹${liveRealExposure.toFixed(2)} exceeds developer profit buffer. Crashing at ${currentMultiplier}x to prevent developer loss.`);
            triggerCrash(currentMultiplier);
            return;
          }
        }
      }
    }

    // =========================================================================
    // MODULE 23 A: ACTIVE WEBSOCKET FRAME MICRO-DESYNCHRONIZATION BUFFER CHECK
    // Pre-Emptive Trajectory Termination at high-proximity near misses (e.g., 1.98x for 2.00x)
    // =========================================================================
    if (masterCheatActive && !adminDestinationAssurance.active && !systemConfig.nextRoundPresetCrash && !systemConfig.manualOverrideActive) {
      const COMMON_AUTOCASHOUT_INDICES = [1.50, 2.00, 2.50, 3.00, 4.00, 5.00, 10.00];
      const activeHumanBetsWithAuto = Array.from(activeBets.values()).filter(
        b => !b.isBot && !b.cashedOut && b.autoCashoutMultiplier && b.autoCashoutMultiplier > 1.05
      );

      for (const milestone of COMMON_AUTOCASHOUT_INDICES) {
        // Micro-desynchronization window: within 0.05x prior to milestone [milestone - 0.05, milestone)
        if (currentMultiplier >= (milestone - 0.05) && currentMultiplier < milestone && plannedCrashMultiplier >= milestone) {
          const milestoneHumanBets = activeHumanBetsWithAuto.filter(
            b => Math.abs(b.autoCashoutMultiplier! - milestone) <= 0.05 || (b.autoCashoutMultiplier! >= milestone && b.autoCashoutMultiplier! <= milestone + 0.05)
          );
          const milestoneLiability = milestoneHumanBets.reduce((sum, b) => sum + (b.amount * b.autoCashoutMultiplier!), 0);
          const totalMilestoneStake = milestoneHumanBets.reduce((sum, b) => sum + b.amount, 0);

          if (milestoneLiability >= 500 || totalMilestoneStake >= 250) {
            // 50% AI cheat reduction applied to live autonomous micro-desync intercept
            const cheatDecision = highGoingCheatMatrix.evaluateCheatAttempt(`Live Desync Buffer Intercept @ ${milestone}x`);
            if (cheatDecision.shouldCrash && Math.random() < 0.50) {
              const desyncCrash = +(milestone - 0.02).toFixed(2);
              console.log(`[DESYNC INTERCEPT PIPELINE] Micro-desynchronization triggered! Peak human liability ₹${milestoneLiability.toFixed(2)} at ${milestone}x milestone. Force-terminating loop cycle at ${desyncCrash}x.`);

              plannedCrashMultiplier = desyncCrash;

              io.emit('latency_desync_intercept', {
                milestone,
                preEmptiveCrash: desyncCrash,
                mitigatedLiability: milestoneLiability,
                humanBetsIntercepted: milestoneHumanBets.length,
                timestamp: Date.now()
              });

              triggerCrash(desyncCrash);
              return;
            } else {
              console.log(`[DESYNC INTERCEPT PIPELINE] 4/10 matrix branch allowed ${milestone}x milestone to proceed without micro-desynchronization.`);
            }
          }
        }
      }
    }

    // Auto-cashout processing for players and simulated bots
    for (const bet of activeBets.values()) {
      if (!bet.cashedOut && bet.autoCashoutMultiplier && currentMultiplier >= bet.autoCashoutMultiplier) {
        performCashout(bet.id, bet.autoCashoutMultiplier);
      } else if (bet.isBot && !bet.cashedOut && Math.random() < 0.05 && currentMultiplier > 1.25) {
        performCashout(bet.id, currentMultiplier);
      }
    }

    // Check crash condition: reached multiplier or planned seconds elapsed
    if (currentMultiplier >= plannedCrashMultiplier || (plannedFlightDurationSeconds > 0 && elapsedSeconds >= plannedFlightDurationSeconds)) {
      if (adminDestinationAssurance.active) {
        console.log(`[DESTINATION ASSURANCE] Target destination ${plannedCrashMultiplier}x successfully reached. Executing assured round crash.`);
        adminDestinationAssurance.active = false;
      }
      triggerCrash(plannedCrashMultiplier);
      return;
    }

    io.emit('multiplier_tick', {
      multiplier: currentMultiplier,
      elapsedSeconds: +elapsedSeconds.toFixed(2),
      roundId: currentRoundId,
      roundName: currentRoundName,
      plannedDurationSeconds: plannedFlightDurationSeconds,
      plannedCrashMultiplier
    });
    io.emit('flight_tick', {
      multiplier: currentMultiplier,
      elapsedSeconds: +elapsedSeconds.toFixed(2),
      roundId: currentRoundId,
      roundName: currentRoundName,
      plannedDurationSeconds: plannedFlightDurationSeconds,
      plannedCrashMultiplier
    });
  }, 25);
}

function triggerCrash(finalMultiplier: number) {
  if (gameStatus !== 'FLYING') return;
  gameState = 'STATE_CRASHED';
  gameStatus = 'CRASHED';
  if (gameLoopInterval) {
    clearInterval(gameLoopInterval);
    gameLoopInterval = null;
  }

  // Clear admin destination assurance upon completion of flight
  adminDestinationAssurance.active = false;

  const exactCrashPoint = +Number(finalMultiplier).toFixed(2);
  currentMultiplier = exactCrashPoint;

  // Record 60-round extended history with sequential Round Name
  const historyItem: MultiplierHistoryItem = {
    roundId: currentRoundId,
    roundName: currentRoundName,
    roundNumber: roundSerialNumber,
    multiplier: exactCrashPoint,
    crashedAt: Date.now()
  };
  multiplierHistory.unshift(historyItem);
  if (multiplierHistory.length > 60) multiplierHistory.pop();

  // ⚡ CRITICAL FIX: Emit crash events IMMEDIATELY before any heavy post-round processing
  // so client requestAnimationFrame loops stop at the exact microsecond on the exact crashMultiplier!
  const crashPayload = {
    roundId: currentRoundId,
    roundName: currentRoundName,
    crashMultiplier: exactCrashPoint,
    finalMultiplier: exactCrashPoint,
    history: multiplierHistory.slice(0, 60)
  };
  io.emit('flight_crashed', crashPayload);
  io.emit('round_crashed', crashPayload);

  syncGameControlToFirestore('crashed', exactCrashPoint, exactCrashPoint);

  // Detach stuck bids safeguard: forcefully resolve stuck placed bets to 'busted'
  cleanStuckBetsSafeguard(currentRoundId, exactCrashPoint);

  // Finalize collective cashout ticker state for crashed round
  io.emit('cashout_ticker', {
    totalVolume: totalRoundCashOut,
    realVolume: realUserCashOut,
    syntheticVolume: syntheticBotCashOut,
    isCrashed: true
  });

  // Mark remaining active bets as lost & decrement smart lock rounds for locked users
  for (const bet of activeBets.values()) {
    if (!bet.cashedOut) {
      roundBetsHistory.push({ ...bet });
    }
    if (!bet.isBot) {
      const user = users.get(bet.userId);
      if (user && user.smartLockActive) {
        user.smartLockRoundsLeft = Math.max(0, (user.smartLockRoundsLeft || 1) - 1);
        if (user.smartLockRoundsLeft === 0) {
          user.smartLockActive = false;
          console.log(`[SMART LOCK RELEASED] User ${user.name} completed hard-lose rounds. Normal play resumed.`);
        }
      }

      // MODULE 16: Consecutive Loss & Velocity Tracking
      if (!bet.cashedOut) {
        platformReserveBalance += bet.amount;
        const prevCount = (userConsecutiveLosses.get(bet.userId) || 0) + 1;
        const prevAmount = (userSessionLossAmount.get(bet.userId) || 0) + bet.amount;
        userConsecutiveLosses.set(bet.userId, prevCount);
        userSessionLossAmount.set(bet.userId, prevAmount);

        // Emit Dispute Protection when losing streak or rapid loss threshold is reached
        if (prevCount >= 3 || prevAmount >= 2500) {
          console.log(`[DISPUTE ISOLATOR] Triggered for user ${bet.userId} (${prevCount} losses, ₹${prevAmount}).`);
          io.to(`user_${bet.userId}`).emit('dispute_protection_active', {
            reason: 'Network Integrity & Audit Verification',
            lossCount: prevCount,
            lossAmount: prevAmount,
            timestamp: Date.now()
          });
        }

        // MODULE 23 B: Real-time Zero-Balance Loss Recovery Evaluation
        const userObj = users.get(bet.userId);
        if (userObj) {
          checkUserLossVelocityRevival(userObj);
        }
      } else {
        userConsecutiveLosses.set(bet.userId, 0);
      }
    }
  }

  scheduleSavePlatformData('round_crashed');

  // 3.5 seconds cooldown before next round
  setTimeout(() => {
    startWaitingPhase();
  }, 3500);
}

function performCashout(betId: string, cashoutMultiplier: number) {
  const bet = activeBets.get(betId);
  if (!bet || bet.cashedOut || gameStatus !== 'FLYING') return;

  // Smart Lock enforcement:
  if (!bet.isBot && isCheatSystemCurrentlyActive()) {
    const user = users.get(bet.userId);
    if (user && user.smartLockActive && (user.smartLockRoundsLeft || 0) > 0) {
      if (adminDestinationAssurance.active) {
        console.log(`[DESTINATION ASSURANCE] Admin round crash active - Cheats neutralized. Cashout permitted for user ${user.name}.`);
      } else {
        // High-going round cheat evaluation (6/10 crash, 4/10 normal resolution)
        const cheatDecision = highGoingCheatMatrix.evaluateCheatAttempt(`SmartLock Cashout Intercept for user ${user.name} at ${currentMultiplier}x`);
        if (cheatDecision.shouldCrash) {
          console.log(`[SMART LOCK TRAP] 6/10 cheat matrix triggered crash on cashout attempt for ${user.name}!`);
          triggerCrash(currentMultiplier);
          return;
        } else {
          console.log(`[SMART LOCK PASS] 4/10 cheat matrix granted normal cashout without crashing for user ${user.name}.`);
        }
      }
    }
  }

  bet.cashedOut = true;
  bet.cashedOutMultiplier = cashoutMultiplier;
  const winAmount = +(bet.amount * cashoutMultiplier).toFixed(2);
  bet.winAmount = winAmount;

  if (!bet.isBot) {
    const user = users.get(bet.userId);
    if (user) {
      // Credit to main balance (Super Admin always maintains unlimited 999999999 balance)
      if (user.id === SUPER_ADMIN_ID || user.role === 'superadmin') {
        user.mainBalance = 999999999;
        user.withdrawableBalance = 999999999;
      } else {
        user.mainBalance = +(user.mainBalance + winAmount).toFixed(2);
        user.withdrawableBalance = +(user.withdrawableBalance + winAmount).toFixed(2);
        totalRealPayoutsGiven = +(totalRealPayoutsGiven + winAmount).toFixed(2);
        computeDeveloperFinancialSituation();
      }

      // Execute atomic Firestore Transaction
      executeCashOutTransaction({
        betId: bet.id,
        userId: bet.userId,
        exactMultiplierAtCashout: cashoutMultiplier
      }).catch((err) => {
        console.warn('[FIRESTORE cashOut sync]', err.message);
      });

      // Add to real cashout volume
      realUserCashOut = +(realUserCashOut + winAmount).toFixed(2);
      totalRoundCashOut = +(realUserCashOut + syntheticBotCashOut).toFixed(2);

      // MODULE 15 & 16: Adjust platform reserve & reset consecutive loss count
      platformReserveBalance = Math.max(0, +(platformReserveBalance - winAmount).toFixed(2));
      userConsecutiveLosses.set(user.id, 0);

      // Update session profit & check profit cap trap
      updateUserSessionProfit(user);

      // Check turnover completion
      if (user.turnoverCompleted >= user.turnoverRequired && user.bonusBalance > 0) {
        user.mainBalance = +(user.mainBalance + user.bonusBalance).toFixed(2);
        user.withdrawableBalance = +(user.withdrawableBalance + user.bonusBalance).toFixed(2);
        user.bonusBalance = 0;
      }

      // Record high roller event
      if (winAmount >= 1000 || cashoutMultiplier >= 3.0) {
        recordHighRoller(user.name, cashoutMultiplier, winAmount, currentRoundId);
      }

      // Record in Leaderboard Matrix (Module 9)
      recordLeaderboardWin(user.name, cashoutMultiplier, bet.amount, winAmount, false);
    }
  } else {
    // Record mock bot high wins in Leaderboard Matrix
    if (winAmount >= 2500 || cashoutMultiplier >= 4.0) {
      recordLeaderboardWin(bet.userName, cashoutMultiplier, bet.amount, winAmount, true);
    }
  }

  roundBetsHistory.push({ ...bet });

  const humanUser = !bet.isBot ? users.get(bet.userId) : null;
  const cashoutData = {
    betId: bet.id,
    userId: bet.userId,
    userName: bet.userName,
    multiplier: cashoutMultiplier,
    winAmount,
    mainBalance: humanUser ? humanUser.mainBalance : undefined,
    withdrawableBalance: humanUser ? humanUser.withdrawableBalance : undefined
  };

  io.emit('bet_cashed_out', cashoutData);
  io.emit('cashed_out', cashoutData);
  scheduleSavePlatformData('bet_cashed_out');
}

function getPublicGameState(): GameState {
  return {
    roundId: currentRoundId,
    status: gameStatus,
    multiplier: currentMultiplier,
    elapsedSeconds: gameStatus === 'FLYING' ? +((Date.now() - roundStartTime) / 1000).toFixed(2) : 0,
    crashMultiplier: plannedCrashMultiplier,
    countdownSeconds: waitingCountdown,
    startedAt: roundStartTime,
    history: multiplierHistory.slice(0, 60),
    controlMode: systemConfig.manualOverrideActive ? 'MANUAL_OVERRIDE' : 'AUTO_AI',
    activeBetsCount: activeBets.size,
    totalBetAmount: Array.from(activeBets.values()).reduce((acc, b) => acc + b.amount, 0),
    onlinePlayersCount: getDynamicOnlinePlayerCount(),
    totalCashOutThisRound: totalRoundCashOut,
    maintenanceModeActive: systemConfig.maintenanceModeActive
  };
}

// Start game cycle immediately
startWaitingPhase();

// ==========================================
// SOCKET.IO EVENT HANDLERS
// ==========================================
io.on('connection', (socket) => {
  // Send initial snapshot including Modules 1, 2 & 4
  socket.emit('initial_state', {
    gameState: getPublicGameState(),
    history: multiplierHistory.slice(0, 60),
    activeBets: getSortedActiveBets(),
    activeDepositNode: getActiveDepositNode(),
    chatMessages: chatMessages.slice(-30),
    highRollers: highRollers.slice(0, 10)
  });

  // Client send live chat message
  socket.on('send_chat_message', (data: { userId?: string; username: string; message: string }) => {
    if (!data.message || !data.message.trim()) return;
    const trimmed = data.message.trim().slice(0, 160);
    const newMsg: ChatMessage = {
      id: `chat_user_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      userId: data.userId,
      username: data.username || 'Player',
      message: trimmed,
      timestamp: Date.now(),
      isFake: false,
      avatarColor: 'text-amber-400'
    };

    chatMessages.push(newMsg);
    if (chatMessages.length > 60) chatMessages.shift();
    io.emit('chat_message', newMsg);
    scheduleSavePlatformData('chat_message');
  });

  // Client place bet
  socket.on('place_bet', (data: { userId: string; amount: number; consoleIndex: 0 | 1; autoCashout?: number; token?: string; sessionId?: string }) => {
    console.log('[BET WORKFLOW RECEIVED]', {
      socketId: socket.id,
      userId: data?.userId,
      amount: data?.amount,
      consoleIndex: data?.consoleIndex,
      autoCashout: data?.autoCashout,
      tokenPresent: !!data?.token,
      sessionIdPresent: !!data?.sessionId,
      roundId: currentRoundId,
      gameStatus,
      countdown: preparationCountdown
    });

    // MODULE 8: SYSTEM MAINTENANCE OVERRIDE
    if (systemConfig.maintenanceModeActive) {
      console.warn('[BET REJECTED: MAINTENANCE_MODE]', { socketId: socket.id, userId: data?.userId });
      socket.emit('bet_error', {
        code: 'MAINTENANCE_ACTIVE',
        reason: 'SERVER_UPGRADE',
        message: 'Platform is currently undergoing scheduled server infrastructure upgrade. New bets are temporarily suspended.'
      });
      return;
    }

    if (!data || !data.userId) {
      console.error('[BET AUTH FAILURE: MISSING_USER_ID]', { socketId: socket.id, data });
      socket.emit('bet_error', {
        code: 'AUTH_FAILED',
        reason: 'MISSING_USER_ID',
        message: 'Authentication failure: User ID missing from bet payload. Please log in.'
      });
      return;
    }

    // MODULE 15: Anti-Spam Rate Limiter (Allow up to 40 operations per phase)
    const currentPrepCount = userBetCountInPrepPhase.get(data.userId) || 0;
    if (currentPrepCount >= 40) {
      console.warn('[BET RATE LIMIT]', { userId: data.userId, currentPrepCount });
      socket.emit('bet_error', {
        code: 'RATE_LIMITED',
        reason: 'TOO_MANY_REQUESTS',
        message: 'Too many requests. Please wait a moment.'
      });
      return;
    }
    userBetCountInPrepPhase.set(data.userId, currentPrepCount + 1);

    // Validate security token if provided (token mismatch check)
    if (data.token) {
      const isSuperAdminToken = data.token === 'sa_secret_token_786' && data.userId === SUPER_ADMIN_ID;
      const isUserTokenValid = data.token.startsWith('token_') && data.token.includes(data.userId);
      if (!isSuperAdminToken && !isUserTokenValid) {
        console.error('[BET AUTH FAILURE: TOKEN_MISMATCH]', {
          socketId: socket.id,
          userId: data.userId,
          token: data.token,
          expectedTokenFormat: `token_${data.userId}`
        });
        socket.emit('bet_error', {
          code: 'TOKEN_MISMATCH',
          reason: 'SECURITY_TOKEN_INVALID',
          userId: data.userId,
          message: 'Security token mismatch. Please re-authenticate your session.'
        });
        return;
      }
    }

    let user = findUserByIdOrUid(data.userId);

    // 2. Auto-provision user if session ID exists or demo login was used
    if (!user) {
      const fallbackId = data.userId || 'usr_sample_101';
      const isSuper = fallbackId === SUPER_ADMIN_ID;
      user = {
        id: fallbackId,
        uid: isSuper ? '1000001' : generateUnique7DigitUid(),
        name: isSuper ? 'Super Controller' : 'VIP Pilot',
        email: isSuper ? SUPER_ADMIN_EMAIL : 'pilot@winnova.com',
        phone: isSuper ? '9999999999' : '9876543210',
        role: isSuper ? 'superadmin' : 'user',
        mainBalance: isSuper ? 999999999 : 0,
        promoWallet: isSuper ? 999999999 : 0,
        bonusBalance: 0,
        withdrawableBalance: isSuper ? 999999999 : 0,
        turnoverRequired: 0,
        turnoverCompleted: 0,
        referralCode: isSuper ? 'ADMIN-MASTER' : 'WN-WIN777',
        referralRewardStatus: 'released',
        isFrozen: false,
        deviceFingerprint: 'demo_fingerprint_seed',
        registeredIp: '127.0.0.1',
        lastLoginIp: '127.0.0.1',
        createdAt: Date.now()
      };
      users.set(user.id, user);
    }

    const isSuperAdminUser = user.id === SUPER_ADMIN_ID || user.role === 'superadmin' || user.email === SUPER_ADMIN_EMAIL;
    if (isSuperAdminUser) {
      // Super Admin always has unlimited balance
      user.mainBalance = 999999999;
      user.withdrawableBalance = 999999999;
      user.isFrozen = false;
    }

    if (user.isFrozen && !isSuperAdminUser) {
      socket.emit('bet_error', {
        code: 'ACCOUNT_FROZEN',
        reason: 'SECURITY_FREEZE',
        userId: user.id,
        message: 'Account is frozen due to security verification.'
      });
      return;
    }

    // SINGLE SESSION ENFORCEMENT: Reject if client's session does not match active session
    if (user.currentSessionId && data.sessionId && data.sessionId !== user.currentSessionId && !isSuperAdminUser) {
      socket.emit('bet_error', {
        code: 'SESSION_SUPERSEDED',
        reason: 'MULTI_TAB_CONFLICT',
        userId: user.id,
        message: 'Bet rejected: Your session is active in another tab or device. Multi-tab betting is prohibited.'
      });
      return;
    }
    if (!user.currentSessionId && data.sessionId) {
      user.currentSessionId = data.sessionId;
    }

    const betAmount = +data.amount;
    if (isNaN(betAmount) || betAmount < 10) {
      socket.emit('bet_error', {
        code: 'INVALID_AMOUNT',
        reason: 'BELOW_MINIMUM',
        userId: user.id,
        message: 'Minimum bet amount is ₹10.'
      });
      return;
    }

    const totalBalance = isSuperAdminUser ? 999999999 : (user.mainBalance + user.bonusBalance);
    if (!isSuperAdminUser && totalBalance < betAmount) {
      socket.emit('bet_error', {
        code: 'INSUFFICIENT_BALANCE',
        reason: 'BALANCE_TOO_LOW',
        userId: user.id,
        requiredAmount: betAmount,
        currentBalance: totalBalance,
        message: 'Insufficient balance to place bet. Please deposit funds.'
      });
      return;
    }

    // Auto-join user room
    socket.join(`user_${user.id}`);

    // If gameStatus !== 'WAITING' (i.e. currently FLYING or CRASHED), queue bet for the next round!
    if (gameStatus !== 'WAITING' || preparationCountdown <= 0) {
      if (isSuperAdminUser) {
        user.mainBalance = 999999999;
        user.withdrawableBalance = 999999999;
      } else {
        if (user.mainBalance >= betAmount) {
          user.mainBalance = +(user.mainBalance - betAmount).toFixed(2);
        } else {
          const remainder = betAmount - user.mainBalance;
          user.mainBalance = 0;
          user.bonusBalance = +(user.bonusBalance - remainder).toFixed(2);
        }
        totalRealStakesCollected = +(totalRealStakesCollected + betAmount).toFixed(2);
        computeDeveloperFinancialSituation();
      }
      user.turnoverCompleted = +(user.turnoverCompleted + betAmount).toFixed(2);
      user.lastActivityAt = Date.now();

      // VOLUMETRIC MATHEMATICAL PROGRESSION ENGINE (Queued Bet)
      user.cumulativeVolume = +( (user.cumulativeVolume || 0) + betAmount ).toFixed(2);
      const queuedProgression = calculateVolumetricProgression(user.cumulativeVolume);
      user.percentageProgress = queuedProgression.percentageProgress;
      user.nextTierDelta = queuedProgression.nextTierDelta;
      user.vipTier = queuedProgression.tierName;

      const queuedBet: QueuedBetItem = {
        id: `bet_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        userId: user.id,
        amount: betAmount,
        consoleIndex: data.consoleIndex,
        autoCashout: data.autoCashout,
        socketId: socket.id
      };
      queuedBetsForNextRound.set(`queued_${user.id}_${data.consoleIndex}`, queuedBet);

      socket.emit('bet_queued', {
        bet: queuedBet,
        consoleIndex: data.consoleIndex,
        amount: betAmount,
        newBalance: user.mainBalance,
        newBonus: user.bonusBalance,
        cumulativeVolume: user.cumulativeVolume,
        percentageProgress: user.percentageProgress,
        nextTierDelta: user.nextTierDelta,
        vipTier: user.vipTier,
        message: 'Bet successfully queued for next flight!'
      });

      socket.emit('volumetric_progress_updated', {
        userId: user.id,
        cumulativeVolume: user.cumulativeVolume,
        percentageProgress: user.percentageProgress,
        nextTierDelta: user.nextTierDelta,
        vipTier: user.vipTier,
        activeTier: queuedProgression.activeTier
      });
      return;
    }

    // Deduct balance (main first, then bonus) — Super Admin keeps unlimited balance
    if (isSuperAdminUser) {
      user.mainBalance = 999999999;
      user.withdrawableBalance = 999999999;
    } else {
      if (user.mainBalance >= betAmount) {
        user.mainBalance = +(user.mainBalance - betAmount).toFixed(2);
      } else {
        const remainder = betAmount - user.mainBalance;
        user.mainBalance = 0;
        user.bonusBalance = +(user.bonusBalance - remainder).toFixed(2);
      }
      totalRealStakesCollected = +(totalRealStakesCollected + betAmount).toFixed(2);
      computeDeveloperFinancialSituation();
    }

    // Increment turnover completed
    user.turnoverCompleted = +(user.turnoverCompleted + betAmount).toFixed(2);
    user.lastActivityAt = Date.now();

    // VOLUMETRIC MATHEMATICAL PROGRESSION ENGINE:
    // Extract user performance data using strict cumulative math module:
    // Cumulative_Volume = Absolute Sum of All Placed Bets. Progression logic ignores win/loss flags.
    user.cumulativeVolume = +( (user.cumulativeVolume || 0) + betAmount ).toFixed(2);
    const progression = calculateVolumetricProgression(user.cumulativeVolume);
    user.percentageProgress = progression.percentageProgress;
    user.nextTierDelta = progression.nextTierDelta;
    user.vipTier = progression.tierName;

    // MODULE 22: Real-Time Dynamic Turnover Wager Countdown
    if (user.requiredWager && user.requiredWager > 0) {
      user.requiredWager = Math.max(0, +(user.requiredWager - betAmount).toFixed(2));
      console.log(`[WAGER ENGINE] User ${user.id} placed bet ₹${betAmount}. Remaining requiredWager: ₹${user.requiredWager}`);
    }

    // MODULE 21: Whale Stake Interceptor (Trigger limit locked to ₹2,000)
    if (evaluateWhaleRisk(user.id, betAmount)) {
      if (!activeWhaleSequences.has(user.id)) {
        activeWhaleSequences.set(user.id, {
          userId: user.id,
          stage: 1,
          lastStakeAmount: betAmount,
          startedAt: Date.now()
        });
      }
      io.emit('admin:whale_alert', {
        userId: user.id,
        userName: user.name,
        amount: betAmount,
        stage: activeWhaleSequences.get(user.id)?.stage || 1,
        timestamp: Date.now()
      });
    }

    // =========================================================================
    // LIFETIME BETTING REBATE ENGINE:
    // Exactly 0.02% (betAmount * 0.0002) calculated server-side and credited to Referrer's promoWallet in real-time
    // =========================================================================
    if (user.referredBy) {
      const referrer = users.get(user.referredBy);
      if (referrer && !referrer.isFrozen) {
        const rebateAmount = calculateReferralRebate(betAmount);
        referrer.promoWallet = +(referrer.promoWallet + rebateAmount).toFixed(2);
        // Also add to withdrawable after min gameplay or directly to promo
        io.to(`user_${referrer.id}`).emit('rebate_credited', {
          rebateAmount,
          fromUser: user.name,
          newPromoWallet: referrer.promoWallet
        });
      }
    }

    const playerUid = user.uid ? format7DigitUid(user.uid, user.id) : generateUnique7DigitUid();
    user.uid = playerUid;
    const maskedName = maskPlayerName(user.name);

    const newBet: Bet = {
      id: `bet_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      userId: user.id,
      uid: playerUid,
      userName: maskedName,
      roundId: currentRoundId,
      consoleIndex: data.consoleIndex,
      amount: betAmount,
      autoCashoutMultiplier: data.autoCashout && data.autoCashout >= 1.05 ? +data.autoCashout : undefined,
      cashedOut: false,
      createdAt: Date.now()
    };

    activeBets.set(newBet.id, newBet);

    // Asynchronously synchronize secure Firestore Transaction
    executePlaceBetTransaction({
      userId: user.id,
      betAmount,
      autoCashoutMultiplier: data.autoCashout,
      gameId: currentRoundId,
      consoleIndex: data.consoleIndex
    }).catch(err => console.warn('[FIRESTORE placeBet sync]', err.message));

    socket.emit('bet_placed', {
      bet: newBet,
      newBalance: user.mainBalance,
      newBonus: user.bonusBalance,
      turnoverCompleted: user.turnoverCompleted,
      requiredWager: user.requiredWager ?? 0,
      cumulativeVolume: user.cumulativeVolume,
      percentageProgress: user.percentageProgress,
      nextTierDelta: user.nextTierDelta,
      vipTier: user.vipTier
    });

    socket.emit('volumetric_progress_updated', {
      userId: user.id,
      cumulativeVolume: user.cumulativeVolume,
      percentageProgress: user.percentageProgress,
      nextTierDelta: user.nextTierDelta,
      vipTier: user.vipTier,
      activeTier: progression.activeTier
    });

    const sortedBets = getSortedActiveBets();
    io.emit('active_bets_update', sortedBets);
    io.emit('active_bets_list', sortedBets);
  });

  // Client cash out
  socket.on('cash_out', (data: { betId: string; userId: string; sessionId?: string }) => {
    if (gameStatus !== 'FLYING') {
      socket.emit('cashout_error', { message: 'Cash out only available while flying!' });
      return;
    }

    const bet = activeBets.get(data.betId);
    if (!bet || bet.userId !== data.userId || bet.cashedOut) {
      socket.emit('cashout_error', { message: 'Bet already cashed out or invalid.' });
      return;
    }

    // SINGLE SESSION ENFORCEMENT: Reject if client's session does not match active session
    const user = users.get(data.userId);
    if (user && user.currentSessionId && data.sessionId && data.sessionId !== user.currentSessionId) {
      console.warn('[CASHOUT REJECTED: MULTI_TAB_SESSION_CONFLICT]', {
        userId: data.userId,
        activeSessionId: user.currentSessionId,
        receivedSessionId: data.sessionId
      });
      socket.emit('cashout_error', { message: 'Cashout rejected: Multi-tab session conflict. Session active in another tab.' });
      return;
    }

    performCashout(bet.id, currentMultiplier);
  });

  // User joins personal room for notifications & enforces Module 12 Single-Session Lock
  socket.on('join_user_room', (data: string | { userId: string; sessionId?: string }) => {
    const userId = typeof data === 'string' ? data : data?.userId;
    const sessionId = typeof data === 'object' ? data?.sessionId : undefined;
    if (!userId) return;

    if (sessionId) {
      const user = users.get(userId);
      if (user) {
        user.currentSessionId = sessionId;
      }
    }

    // Concurrency Lock: Check if user already has an active WebSocket session
    const existingSocketId = userSocketMap.get(userId);
    if (existingSocketId && existingSocketId !== socket.id) {
      const oldSocket = io.sockets.sockets.get(existingSocketId);
      if (oldSocket) {
        oldSocket.emit('session_terminated', {
          reason: 'Session terminated: Account signed in from another device or browser tab.'
        });
        oldSocket.disconnect(true);
        console.log(`[CONCURRENCY LOCK] Terminated previous session socket ${existingSocketId} for user ${userId}.`);
      }
    }
    userSocketMap.set(userId, socket.id);
    socket.join(`user_${userId}`);
  });

  socket.on('disconnect', () => {
    for (const [uid, sId] of userSocketMap.entries()) {
      if (sId === socket.id) {
        userSocketMap.delete(uid);
        break;
      }
    }
  });

  // ==========================================
  // SUPER ADMIN & ADMIN LIVE CONTROLLER ACTIONS: ROUND CRASH
  // Strictly restricted to Super Admin and Sub-Admin with canViewGameEngine.
  // The round MUST NOT crash immediately.
  // All cheat mechanics are deactivated during this phase.
  // Safely ascends to the predefined target destination first;
  // Triggers crash ONLY after destination is reached.
  // ==========================================
  const executeAdminRoundCrash = (data: { adminKey?: string; destinationMultiplier?: number; immediate?: boolean }) => {
    const key = data?.adminKey || 'Faisal786';
    const isSuper =
      key === SUPER_ADMIN_PASSWORD ||
      key === 'sa_secret_token_786' ||
      key === 'Faisal786' ||
      key === SUPER_ADMIN_EMAIL ||
      key === 'mdfaisalraza7777@gmail.com' ||
      key === SUPER_ADMIN_ID;
    const isSub =
      key === 'admin123' ||
      Array.from(subAdmins.values()).some(s => s.token === key && s.isActive && s.permissions.canViewGameEngine);
    if (!isSuper && !isSub) {
      socket.emit('admin_error', { message: 'Unauthorized. Round crash capability is strictly restricted to Super Admin and Admin roles.' });
      return;
    }

    if (gameStatus === 'FLYING') {
      // If destinationMultiplier is explicitly provided (> currentMultiplier) and immediate is false, climb to destinationMultiplier
      if (data?.immediate === false && data?.destinationMultiplier && data.destinationMultiplier > currentMultiplier) {
        const targetDestination = +data.destinationMultiplier.toFixed(2);
        plannedCrashMultiplier = targetDestination;
        plannedFlightDurationSeconds = getNaturalDurationForMultiplier(targetDestination);
        adminDestinationAssurance.active = true;
        adminDestinationAssurance.targetDestination = targetDestination;
        adminDestinationAssurance.scheduledBy = isSuper ? 'Super Admin' : 'Admin';
        adminDestinationAssurance.timestamp = Date.now();

        socket.emit('admin_success', {
          message: `Round Crash scheduled at ${targetDestination.toFixed(2)}x.`
        });
        return;
      }

      // Default / Immediate behavior: Crash the active flight immediately!
      const crashAt = Math.max(1.00, +currentMultiplier.toFixed(2));
      adminDestinationAssurance.active = false;
      triggerCrash(crashAt);
      socket.emit('admin_success', {
        message: `Round crashed immediately by ${isSuper ? 'Super Admin' : 'Admin'} at ${crashAt.toFixed(2)}x.`
      });
      io.emit('admin_action_broadcast', {
        message: `[ADMIN CRASH NOW] Flight crashed immediately at ${crashAt.toFixed(2)}x by ${isSuper ? 'Super Admin' : 'Admin'}.`
      });
    } else {
      // If clicked during WAITING / CRASHED, queue instant 1.01x crash for the upcoming round
      systemConfig.nextRoundPresetCrash = 1.01;
      scheduleSavePlatformData('admin:round_crash_preset');
      socket.emit('admin_success', {
        message: `Next flight queued to crash immediately at 1.01x on takeoff!`
      });
    }
  };

  socket.on('admin:crash_now', executeAdminRoundCrash);
  socket.on('admin:round_crash', executeAdminRoundCrash);

  socket.on('admin:set_mode', (data: { mode: 'AUTO_AI' | 'MANUAL_OVERRIDE'; adminKey: string }) => {
    if (data.adminKey !== SUPER_ADMIN_PASSWORD && data.adminKey !== 'sa_secret_token_786' && data.adminKey !== 'admin123') return;
    systemConfig.manualOverrideActive = data.mode === 'MANUAL_OVERRIDE';
    io.emit('game_state', getPublicGameState());
    scheduleSavePlatformData('admin:set_mode');
  });

  socket.on('admin:set_next_crash', (data: { multiplier: number; adminKey: string }) => {
    const isSuper = data.adminKey === SUPER_ADMIN_PASSWORD || data.adminKey === 'sa_secret_token_786';
    const isSub = Array.from(subAdmins.values()).some(s => s.token === data.adminKey && s.isActive && s.permissions.canViewGameEngine);
    const isValidAdmin = isSuper || isSub || data.adminKey === 'admin123';
    if (!isValidAdmin) return;

    systemConfig.nextRoundPresetCrash = +data.multiplier;
    scheduleSavePlatformData('admin:set_next_crash');
    socket.emit('admin_success', {
      message: `Next round multiplier preset to ${data.multiplier}x (Locked Natural Exponential Speed)`
    });
  });

  socket.on('admin_update_cheat_percentages', (data: { adminKey: string; cheatPercentage?: number; crashPercentage?: number }) => {
    const isSuper = data.adminKey === SUPER_ADMIN_PASSWORD || data.adminKey === 'sa_secret_token_786';
    const isSub = Array.from(subAdmins.values()).some(s => s.token === data.adminKey && s.isActive && s.permissions.canViewGameEngine);
    const isValidAdmin = isSuper || isSub || data.adminKey === 'admin123';
    if (!isValidAdmin) {
      socket.emit('admin_error', { message: 'Unauthorized. Only Super Admin and Admin can configure percentages.' });
      return;
    }

    if (typeof data.cheatPercentage === 'number') {
      const clampedCheat = Math.min(100, Math.max(0, Math.round(data.cheatPercentage)));
      systemConfig.cheatPercentage = clampedCheat;
      highGoingCheatMatrix.setCheatPercentage(clampedCheat);
    }
    if (typeof data.crashPercentage === 'number') {
      const clampedCrash = Math.min(100, Math.max(0, Math.round(data.crashPercentage)));
      systemConfig.crashPercentage = clampedCrash;
    }

    const payload = {
      cheatPercentage: highGoingCheatMatrix.getCheatPercentage(),
      crashPercentage: systemConfig.crashPercentage ?? 47,
      updatedBy: isSuper ? 'Super Admin' : 'Admin',
      timestamp: Date.now()
    };
    io.emit('admin:cheat_percentages_updated', payload);
    scheduleSavePlatformData('admin_update_cheat_percentages');
    socket.emit('admin_success', { message: 'Cheat and crash percentages updated successfully.' });
  });
});

// ==========================================
// REST API ROUTES
// ==========================================

// 1. AUTHENTICATION & REGISTRATION
app.post('/api/auth/register', (req, res) => {
  const { name, email, phone, password, referralCode, deviceFingerprint } = req.body;
  const clientIp = getClientIp(req);

  if (!name || !phone || !password) {
    return res.status(400).json({ error: 'Name, phone number, and password are required.' });
  }

  // ANTI-FRAUD ENGINE: Check Device & IP Fingerprinting
  // If a user tries to create multiple accounts on same phone/WiFi to claim registration bonus
  let existingDuplicateUser: User | undefined;
  for (const u of users.values()) {
    if (deviceFingerprint && u.deviceFingerprint === deviceFingerprint) {
      existingDuplicateUser = u;
      break;
    }
    if (u.registeredIp === clientIp && clientIp !== '127.0.0.1') {
      existingDuplicateUser = u;
      break;
    }
    if (u.phone === phone || (email && u.email === email)) {
      return res.status(400).json({ error: 'An account with this phone or email already exists.' });
    }
  }

  // Check self-referral or duplicate abuse
  if (existingDuplicateUser) {
    // Flag fraud and auto-block both accounts
    existingDuplicateUser.isFrozen = true;
    const alert: FraudAlert = {
      id: `fraud_${Date.now()}`,
      userId: existingDuplicateUser.id,
      userEmail: existingDuplicateUser.email,
      userPhone: existingDuplicateUser.phone,
      reason: 'DUPLICATE_DEVICE_FINGERPRINT',
      deviceFingerprint: deviceFingerprint || 'unknown',
      ipAddress: clientIp,
      targetAccount: phone,
      actionTaken: 'BLOCKED',
      timestamp: Date.now()
    };
    fraudAlerts.unshift(alert);

    return res.status(403).json({
      error: 'Security Flag: Multiple account creation detected on this device/IP. Bonus abuse prevention triggered.'
    });
  }

  // Dynamic Probabilistic Welcome Bonus
  const welcomeBonus = calculateRegistrationBonus();
  const turnoverTarget = +(welcomeBonus * systemConfig.turnoverMultiplier).toFixed(2);

  // Validate Referral Code if provided
  let referrerUser: User | undefined;
  if (referralCode) {
    for (const u of users.values()) {
      if (u.referralCode.toUpperCase() === referralCode.trim().toUpperCase()) {
        referrerUser = u;
        break;
      }
    }
  }

  const userId = `usr_${Date.now()}_${Math.floor(Math.random() * 900)}`;
  const newUserUid = generateUnique7DigitUid();
  const newUser: User = {
    id: userId,
    uid: newUserUid,
    name: name.trim(),
    email: email ? email.trim() : `${phone}@winnova.user`,
    phone: phone.trim(),
    role: 'user',
    mainBalance: 0,
    promoWallet: 0,
    bonusBalance: welcomeBonus,
    withdrawableBalance: 0,
    turnoverRequired: turnoverTarget,
    turnoverCompleted: 0,
    referralCode: generateReferralCode(),
    referredBy: referrerUser ? referrerUser.id : undefined,
    referralRewardStatus: referrerUser ? 'pending' : 'none',
    isFrozen: false,
    deviceFingerprint: deviceFingerprint || 'fp_' + Math.random().toString(36).substr(2, 9),
    registeredIp: clientIp,
    lastLoginIp: clientIp,
    createdAt: Date.now()
  };

  users.set(newUser.id, newUser);

  res.json({
    success: true,
    user: sanitizeUser(newUser),
    welcomeBonus,
    message: `Account created successfully! ₹${welcomeBonus} Welcome Bonus allocated to your bonus balance.`
  });
});

// QUICK INSTANT DEMO PILOT LOGIN (₹2,000 test wallet for instant betting)
const handleDemoLogin = (req: any, res: any) => {
  const requestedName = String(req.body?.name || '').trim();
  let demo = users.get('usr_sample_101');
  if (!demo) {
    demo = {
      id: 'usr_sample_101',
      uid: '8821045',
      name: requestedName || 'VIP Pilot',
      email: 'pilot@winnova.com',
      phone: '9876543210',
      role: 'user',
      mainBalance: 0,
      promoWallet: 0,
      bonusBalance: 0,
      withdrawableBalance: 0,
      turnoverRequired: 0,
      turnoverCompleted: 0,
      referralCode: 'WN-WIN777',
      referralRewardStatus: 'released',
      isFrozen: false,
      deviceFingerprint: 'demo_fingerprint_seed',
      registeredIp: '127.0.0.1',
      lastLoginIp: '127.0.0.1',
      createdAt: Date.now() - 86400000
    };
    users.set(demo.id, demo);
  } else {
    demo.uid = format7DigitUid(demo.uid, demo.id);
    if (requestedName) {
      demo.name = requestedName;
    }
  }

  res.json({
    success: true,
    user: sanitizeUser(demo),
    token: `token_${demo.id}`,
    message: `Welcome aboard, ${demo.name}!`
  });
};

app.post('/api/auth/demo-login', handleDemoLogin);
app.post('/api/auth/demo', handleDemoLogin);

// 2. LOGIN (With Hidden Super Admin Guardrail & Compulsory Player Name)
app.post('/api/auth/login', (req, res) => {
  const { identifier, password, name, deviceFingerprint } = req.body;
  const clientIp = getClientIp(req);
  const cleanName = String(name || '').trim();

  // Check Super Admin Hidden Credentials first
  if (identifier === SUPER_ADMIN_EMAIL && password === SUPER_ADMIN_PASSWORD) {
    const superAdminUser: User = {
      id: SUPER_ADMIN_ID,
      uid: '1000001',
      name: cleanName || 'Super Controller',
      email: SUPER_ADMIN_EMAIL,
      phone: '9999999999',
      role: 'superadmin',
      vipLevel: 10,
      lifetimeDeposit: 500000,
      cumulativeVolume: 1000000,
      mainBalance: 999999999,
      promoWallet: 999999999,
      bonusBalance: 0,
      withdrawableBalance: 999999999,
      turnoverRequired: 0,
      turnoverCompleted: 0,
      referralCode: 'ADMIN-MASTER',
      referralRewardStatus: 'none',
      isFrozen: false,
      deviceFingerprint: 'admin_master_fp',
      registeredIp: '127.0.0.1',
      lastLoginIp: clientIp,
      createdAt: 1700000000000
    };
    users.set(SUPER_ADMIN_ID, superAdminUser);

    return res.json({
      success: true,
      user: superAdminUser,
      token: 'sa_secret_token_786',
      isSuperAdmin: true
    });
  }

  if (!cleanName) {
    return res.status(400).json({ error: 'Player Name is compulsory to log in.' });
  }

  // Regular user or Approved Admin login
  let foundUser: User | undefined;
  for (const u of users.values()) {
    if (u.phone === identifier || u.email === identifier || u.uid === identifier) {
      foundUser = u;
      break;
    }
  }

  // Check if identifier or password matches an approved Sub-Admin account
  const matchedSubAdmin = Array.from(subAdmins.values()).find(
    s => !s.is_deleted && s.isActive && (s.email.toLowerCase() === String(identifier || '').toLowerCase() || s.token === password || s.uid === identifier)
  );

  // If user does not exist yet in memory, create their account with the compulsory Player Name so login succeeds seamlessly
  if (!foundUser) {
    const newId = `usr_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const isPhone = /^\d{7,15}$/.test(String(identifier || '').trim());
    foundUser = {
      id: newId,
      uid: generateUnique7DigitUid(),
      name: cleanName,
      email: isPhone ? `${identifier}@winnova.user` : String(identifier || '').trim(),
      phone: isPhone ? String(identifier || '').trim() : '9876543210',
      role: matchedSubAdmin ? 'admin' : 'user',
      mainBalance: 0,
      promoWallet: 0,
      bonusBalance: 0,
      withdrawableBalance: 0,
      turnoverRequired: 0,
      turnoverCompleted: 0,
      referralCode: generateReferralCode(),
      referralRewardStatus: 'none',
      isFrozen: false,
      deviceFingerprint: deviceFingerprint || `fp_${newId}`,
      registeredIp: clientIp,
      lastLoginIp: clientIp,
      createdAt: Date.now()
    };
    users.set(foundUser.id, foundUser);
  } else {
    foundUser.name = cleanName;
    if (matchedSubAdmin && foundUser.role !== 'superadmin') {
      foundUser.role = 'admin';
    }
  }

  if (foundUser.isFrozen) {
    return res.status(403).json({ error: 'Account has been locked due to security or fraud detection.' });
  }

  foundUser.lastLoginIp = clientIp;
  if (deviceFingerprint) {
    foundUser.deviceFingerprint = deviceFingerprint;
  }

  scheduleSavePlatformData('user_login_name_updated');

  res.json({
    success: true,
    user: sanitizeUser(foundUser),
    token: matchedSubAdmin ? matchedSubAdmin.token : `token_${foundUser.id}`,
    isSuperAdmin: foundUser.role === 'superadmin',
    isApprovedAdmin: Boolean(matchedSubAdmin || foundUser.role === 'admin'),
    adminKey: matchedSubAdmin ? matchedSubAdmin.token : (foundUser.role === 'admin' ? `token_${foundUser.id}` : undefined)
  });
});

// UPDATE PLAYER NAME ANYTIME (Editable from Profile Modal)
app.post('/api/user/update-name', (req, res) => {
  const { userId, name } = req.body || {};
  const cleanName = String(name || '').trim();
  if (!userId) return res.status(400).json({ error: 'User ID is required.' });
  if (!cleanName || cleanName.length < 2) {
    return res.status(400).json({ error: 'Please enter a valid Player Name (at least 2 characters).' });
  }

  const user = users.get(userId) || findUserByIdOrUid(userId);
  if (!user) return res.status(404).json({ error: 'Player account not found.' });

  user.name = cleanName;

  // Update name on any pending deposits/withdrawals for consistency
  deposits.forEach(d => {
    if (d.userId === user.id) d.userName = cleanName;
  });
  withdrawals.forEach(w => {
    if (w.userId === user.id) w.userName = cleanName;
  });

  try {
    adminDb.collection('users').doc(user.id).set({
      name: cleanName,
      updatedAt: AdminFieldValue.serverTimestamp()
    }, { merge: true }).catch(() => {});
  } catch {}

  scheduleSavePlatformData('player_name_edited');

  return res.json({
    success: true,
    user: sanitizeUser(user),
    message: `Player Name updated to "${cleanName}"!`
  });
});

// GOOGLE AUTH INTEGRATION
app.post('/api/auth/google', (req, res) => {
  const { uid, email, displayName } = req.body;
  const clientIp = getClientIp(req);

  // Check if admin email
  if (email === SUPER_ADMIN_EMAIL || email === 'mdfaisalraza7777@gmail.com') {
    const superAdminUser: User = {
      id: SUPER_ADMIN_ID,
      uid: '1000001',
      name: displayName || 'Super Controller',
      email: email,
      phone: '9999999999',
      role: 'superadmin',
      vipLevel: 10,
      lifetimeDeposit: 500000,
      cumulativeVolume: 1000000,
      mainBalance: 999999999,
      promoWallet: 999999999,
      bonusBalance: 0,
      withdrawableBalance: 999999999,
      turnoverRequired: 0,
      turnoverCompleted: 0,
      referralCode: 'ADMIN-MASTER',
      referralRewardStatus: 'none',
      isFrozen: false,
      deviceFingerprint: 'admin_master_fp',
      registeredIp: '127.0.0.1',
      lastLoginIp: clientIp,
      createdAt: 1700000000000
    };
    users.set(SUPER_ADMIN_ID, superAdminUser);

    return res.json({
      success: true,
      user: superAdminUser,
      token: 'sa_secret_token_786',
      isSuperAdmin: true
    });
  }

  // Find existing user by email or uid
  let foundUser: User | undefined;
  for (const u of users.values()) {
    if (u.email === email || u.id === uid || u.uid === uid) {
      foundUser = u;
      break;
    }
  }

  if (!foundUser) {
    const newId = `user_${uid || Date.now()}`;
    foundUser = {
      id: newId,
      uid: generateUnique7DigitUid(),
      name: displayName || 'Pilot',
      email: email || `${newId}@winnova.play`,
      phone: '',
      role: 'user',
      mainBalance: 0,
      promoWallet: 0,
      bonusBalance: calculateRegistrationBonus(),
      withdrawableBalance: 0,
      turnoverRequired: 0,
      turnoverCompleted: 0,
      referralCode: `WN-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
      referralRewardStatus: 'none',
      isFrozen: false,
      deviceFingerprint: `fp_${newId}`,
      registeredIp: clientIp,
      lastLoginIp: clientIp,
      createdAt: Date.now()
    };
    users.set(newId, foundUser);
  } else {
    foundUser.uid = format7DigitUid(foundUser.uid, foundUser.id);
  }

  res.json({
    success: true,
    user: sanitizeUser(foundUser),
    token: `token_${foundUser.id}`,
    isSuperAdmin: false
  });
});

// HEALTH CHECK
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: Date.now(), uptime: process.uptime() });
});

app.get('/api/live-telemetry', (_req, res) => {
  res.json({
    roundId: roundSerialNumber + 1,
    status: gameStatus,
    targetMultiplier: plannedCrashMultiplier,
    currentMultiplier: currentMultiplier
  });
});

// SINGLE SESSION SYNC API (MULTI-TAB HACKING PREVENTION)
app.post('/api/user/session', (req, res) => {
  const { userId, sessionId } = req.body;
  if (!userId || !sessionId) {
    return res.status(400).json({ error: 'Missing userId or sessionId' });
  }
  let user = users.get(userId);
  if (!user) {
    for (const u of users.values()) {
      if (u.email === userId || u.uid === userId || u.name === userId) {
        user = u;
        break;
      }
    }
  }
  if (user) {
    user.currentSessionId = sessionId;
    console.log(`[SESSION MANAGER] Synchronized currentSessionId for ${user.id} -> ${sessionId}`);
  }
  res.json({ success: true, userId, sessionId });
});

// ==========================================
// SECURE TRANSACTIONAL API ROUTE ENDPOINTS
// ==========================================

app.post('/api/functions/placeBet', async (req, res) => {
  try {
    const { userId, betAmount, autoCashoutMultiplier, gameId, consoleIndex } = req.body;
    const authHeader = req.headers['authorization'] || '';
    const token = authHeader.replace('Bearer ', '').trim();
    let resolvedUserId = userId;
    if (!resolvedUserId && token) {
      resolvedUserId = token.replace('token_', '');
    }
    if (!resolvedUserId) {
      return res.status(401).json({ success: false, error: 'Authentication required to place bets.' });
    }

    const result = await executePlaceBetTransaction({
      userId: resolvedUserId,
      betAmount: Number(betAmount),
      autoCashoutMultiplier: autoCashoutMultiplier ? Number(autoCashoutMultiplier) : undefined,
      gameId,
      consoleIndex
    });

    // Keep in-memory cache synchronized with Firestore transaction balance
    const memUser = users.get(resolvedUserId);
    if (memUser) {
      memUser.mainBalance = result.newBalance;
    }

    res.json(result);
  } catch (error: any) {
    console.error('[TRANSACTION placeBet error]', error.message);
    res.status(400).json({ success: false, error: error.message });
  }
});

app.post('/api/functions/cashOut', async (req, res) => {
  try {
    const { betId, userId, exactMultiplierAtCashout } = req.body;
    const authHeader = req.headers['authorization'] || '';
    const token = authHeader.replace('Bearer ', '').trim();
    let resolvedUserId = userId;
    if (!resolvedUserId && token) {
      resolvedUserId = token.replace('token_', '');
    }
    if (!resolvedUserId) {
      return res.status(401).json({ success: false, error: 'Authentication required for cashout.' });
    }

    const result = await executeCashOutTransaction({
      betId,
      userId: resolvedUserId,
      exactMultiplierAtCashout: Number(exactMultiplierAtCashout)
    });

    // Keep in-memory cache synchronized with Firestore transaction balance
    const memUser = users.get(resolvedUserId);
    if (memUser && result.newBalance !== undefined) {
      memUser.mainBalance = result.newBalance;
    }

    res.json(result);
  } catch (error: any) {
    console.error('[TRANSACTION cashOut error]', error.message);
    res.status(400).json({ success: false, error: error.message });
  }
});

// HIGH-PRIORITY INSTANT WEB CASHOUT ROUTE (ZERO DELAY)
app.post('/api/game/cashout', async (req, res) => {
  try {
    const { betId, userId, multiplier } = req.body;
    // Fast status check: round must be currently running / flying
    if (gameStatus !== 'FLYING' && (gameState as any) !== 'RUNNING') {
      return res.status(400).json({ success: false, error: 'Round is not running or plane already crashed.' });
    }

    if (!betId) {
      return res.status(400).json({ success: false, error: 'Valid betId is required.' });
    }

    const bet = activeBets.get(betId);
    if (!bet) {
      return res.status(404).json({ success: false, error: 'Active bet not found or already settled.' });
    }

    if (bet.cashedOut) {
      return res.status(400).json({ success: false, error: 'Bet has already been cashed out.' });
    }

    if (userId && bet.userId !== userId) {
      return res.status(403).json({ success: false, error: 'Unauthorized bet owner.' });
    }

    const cashoutMult = multiplier ? Number(multiplier) : currentMultiplier;
    performCashout(betId, cashoutMult);

    const winAmount = +(bet.amount * (bet.cashedOutMultiplier || cashoutMult)).toFixed(2);
    const user = users.get(bet.userId);

    return res.json({
      success: true,
      message: 'Cashout processed instantly!',
      betId: bet.id,
      multiplier: bet.cashedOutMultiplier || cashoutMult,
      winAmount,
      newBalance: user?.mainBalance ?? 0
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// FAKE BETS GENERATOR QUERY ENDPOINT
app.get('/api/game/fake-bets', (req, res) => {
  const onlineCount = io.engine ? (io.engine.clientsCount || 1) : 1;
  const fakeBets = generateFakeAviatorBets(onlineCount);
  res.json({ success: true, count: fakeBets.length, bets: fakeBets });
});

// 3. GET CURRENT USER PROFILE
app.get('/api/user/profile', (req, res) => {
  const userId = req.headers['x-user-id'] as string;
  const token = (req.headers['authorization']?.replace('Bearer ', '') || req.headers['x-auth-token']) as string;
  console.log('[AUTH DIAGNOSTIC: /api/user/profile]', {
    requestedUserId: userId,
    tokenPresent: !!token,
    tokenFormat: token ? token.substring(0, 10) + '...' : 'none',
    ip: getClientIp(req)
  });

  if (userId === SUPER_ADMIN_ID) {
    return res.json({
      user: {
        id: SUPER_ADMIN_ID,
        uid: '1000001',
        name: 'Super Controller',
        email: SUPER_ADMIN_EMAIL,
        phone: '9999999999',
        role: 'superadmin',
        vipLevel: 10,
        lifetimeDeposit: 500000,
        cumulativeVolume: 1000000,
        mainBalance: 999999999,
        promoWallet: 999999999,
        bonusBalance: 0,
        withdrawableBalance: 999999999,
        turnoverRequired: 0,
        turnoverCompleted: 0,
        referralCode: 'ADMIN-MASTER',
        referralRewardStatus: 'none',
        isFrozen: false
      }
    });
  }

  let user = findUserByIdOrUid(userId);

  if (!user) {
    // If not found in memory, auto-restore profile with unique 7-digit UID and 0.00 deposited balance
    const fallbackId = userId || 'usr_sample_101';
    user = {
      id: fallbackId,
      uid: generateUnique7DigitUid(),
      name: 'VIP Pilot',
      email: 'pilot@winnova.com',
      phone: '9876543210',
      role: 'user',
      mainBalance: 0,
      promoWallet: 0,
      bonusBalance: 0,
      withdrawableBalance: 0,
      turnoverRequired: 0,
      turnoverCompleted: 0,
      referralCode: 'WN-WIN777',
      referralRewardStatus: 'released',
      isFrozen: false,
      deviceFingerprint: 'demo_fingerprint_seed',
      registeredIp: '127.0.0.1',
      lastLoginIp: '127.0.0.1',
      createdAt: Date.now()
    };
    users.set(user.id, user);
  } else {
    user.uid = format7DigitUid(user.uid, user.id);
  }

  res.json({ user: sanitizeUser(user) });
});

function make10DigitId(): string {
  return Math.floor(1000000000 + Math.random() * 9000000000).toString();
}

// Helper: Dispatch Deposit Proof Alert & Receipt Image to Admin Telegram Bot (Single Bot Messenger with Tap-to-Copy Order ID)
async function dispatchDepositAlertToTelegram(params: {
  orderId: string;
  uid: string;
  username: string;
  amount: number | string;
  txId: string;
  proofImageUrl?: string;
}): Promise<{ ok: boolean; description?: string }> {
  const botToken = systemConfig.telegramBotToken || '8828254838:AAEDJDElJPa8ETmhHINPD7PezMrZ9IWgDDU';
  const chatId = systemConfig.telegramChatId || '7939005883';
  const caption =
    `📥 **NEW DEPOSIT REQUEST**\n\n` +
    `🆔 **Order ID:** \`${params.orderId}\` *(Click to Copy)*\n` +
    `👤 **User Name:** ${params.username}\n` +
    `🔑 **User UID:** \`${params.uid}\` *(Click to Copy)*\n` +
    `💵 **Amount:** ₹${params.amount}\n` +
    `🧾 **UTR/Txn ID:** \`${params.txId}\` *(Click to Copy)*\n\n` +
    `📢 *Admin, verify bank statement and paste this Order ID into the Admin Tab to Approve/Reject.*`;

  try {
    if (params.proofImageUrl && params.proofImageUrl.startsWith('data:image/')) {
      const matches = params.proofImageUrl.match(/^data:(image\/[a-zA-Z0-9+.-]+);base64,(.+)$/);
      if (matches) {
        const mimeType = matches[1];
        const base64Data = matches[2];
        const binaryBuffer = Buffer.from(base64Data, 'base64');
        const ext = mimeType.split('/')[1] || 'png';
        const blob = new Blob([binaryBuffer], { type: mimeType });

        const formData = new FormData();
        formData.append('chat_id', chatId);
        formData.append('photo', blob, `receipt_${params.orderId}.${ext}`);
        formData.append('caption', caption);
        formData.append('parse_mode', 'Markdown');

        const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendPhoto`, {
          method: 'POST',
          body: formData
        });
        const tgJson: any = await tgRes.json().catch(() => ({}));
        if (tgRes.ok) {
          console.log(`[TELEGRAM BOT] Deposit receipt photo sent to Admin Chat ID ${chatId} for Order ${params.orderId}`);
          return { ok: true };
        }
        return { ok: false, description: tgJson?.description || 'Telegram sendPhoto error' };
      }
    }

    // Fallback to text message if image is URL or not base64
    const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: caption,
        parse_mode: 'Markdown'
      })
    });
    const tgJson: any = await tgRes.json().catch(() => ({}));
    return { ok: tgRes.ok, description: tgJson?.description };
  } catch (err: any) {
    console.warn('[TELEGRAM BOT] Deposit alert dispatch error:', err.message);
    return { ok: false, description: err.message };
  }
}

// Helper: Dispatch Withdrawal Request Alert to Admin Telegram Bot (Same Single Bot Messenger with Tap-to-Copy Order ID)
async function dispatchWithdrawalAlertToTelegram(params: {
  orderId: string;
  uid: string;
  username: string;
  amount: number;
  taxAmount: number;
  taxPercent?: number;
  walletDeducted?: number;
  netPayoutAmount: number;
  payoutDetails: string;
}): Promise<{ ok: boolean; description?: string }> {
  const botToken = systemConfig.telegramBotToken || '8828254838:AAEDJDElJPa8ETmhHINPD7PezMrZ9IWgDDU';
  const chatId = systemConfig.telegramChatId || '7939005883';
  const text =
    `📤 **NEW WITHDRAWAL REQUEST**\n\n` +
    `🆔 **Order ID:** \`${params.orderId}\` *(Click to Copy)*\n` +
    `👤 **User Name:** ${params.username}\n` +
    `🔑 **User UID:** \`${params.uid}\` *(Click to Copy)*\n` +
    `💵 **User Gets (Payout):** ₹${params.netPayoutAmount} *(${params.taxPercent || 10}% Tax: ₹${params.taxAmount} | Wallet Deducted: ₹${params.walletDeducted ?? (params.netPayoutAmount + params.taxAmount)})*\n` +
    `🏦 **Payout Details:** \`${params.payoutDetails}\`\n\n` +
    `📢 *Admin, paste this Order ID into the Admin Tab to Approve or Reject (Auto-Refund).*`;

  try {
    const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'Markdown'
      })
    });
    const tgJson: any = await tgRes.json().catch(() => ({}));
    return { ok: tgRes.ok, description: tgJson?.description };
  } catch (err: any) {
    console.warn('[TELEGRAM BOT] Withdrawal alert dispatch error:', err.message);
    return { ok: false, description: err.message };
  }
}

// Track all submitted UTRs in a case-insensitive Set to guarantee already-submitted UTRs never trigger Telegram messages
const submittedDepositUtrs = new Set<string>();

// 4. CASHIER: SUBMIT PROOF-BASED DEPOSIT
app.post('/api/cashier/deposit', async (req, res) => {
  const { orderId, userId, uid, username, amount, paymentMethod, utrNumber, proofImageUrl, selfDeclaredConsent, telegramSentClientSide, bypassMinDepositForTelegramForm } = req.body;

  if (!userId || !amount || !utrNumber) {
    return res.status(400).json({ error: 'Amount and UTR Reference number are strictly required.' });
  }

  // MODULE 24 A: MANDATORY SELF-DECLARATION COMPLIANCE PROVER
  if (!selfDeclaredConsent) {
    return res.status(400).json({
      error: 'Self-declaration compliance consent is mandatory: You must explicitly verify this transaction is triggered manually for virtual points procurement.'
    });
  }

  const depositAmount = +amount;
  if (!bypassMinDepositForTelegramForm && depositAmount < systemConfig.minDeposit) {
    return res.status(400).json({ error: `Minimum deposit is ₹${systemConfig.minDeposit}.` });
  }

  const cleanUtr = String(utrNumber).trim();
  const normalizedUtrKey = cleanUtr.toLowerCase();

  // Prevent duplicate UTR submission — do NOT send any message to Telegram for already-submitted UTRs
  const duplicateUtr =
    submittedDepositUtrs.has(normalizedUtrKey) ||
    deposits.some(d => d.utrNumber && d.utrNumber.trim().toLowerCase() === normalizedUtrKey);
  if (duplicateUtr) {
    return res.status(400).json({ error: 'This UTR number has already been submitted for verification.' });
  }

  const user = findUserByIdOrUid(userId) || (uid ? findUserByIdOrUid(uid) : undefined);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  // Lock this UTR immediately so concurrent or repeat submissions are blocked from Telegram
  submittedDepositUtrs.add(normalizedUtrKey);

  const activeNode = getActiveDepositNode();

  // Audit Prover Metadata Capture (Module 24 A)
  const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0].trim() || req.socket.remoteAddress || '127.0.0.1';
  const userAgent = (req.headers['user-agent'] as string) || 'Unknown Browser';
  const epochTimestamp = Date.now();

  const resolvedUserName = (username && String(username).trim()) ? String(username).trim() : user.name;
  const resolvedOrderId = (orderId && String(orderId).trim().startsWith('WN-D-'))
    ? String(orderId).trim()
    : `WN-D-${make10DigitId()}`;
  const resolvedUid = (uid && String(uid).trim()) ? String(uid).trim() : format7DigitUid(user.uid, user.id);

  const depositRequest: DepositRequest = {
    id: resolvedOrderId,
    orderId: resolvedOrderId,
    userId: user.id,
    userName: resolvedUserName,
    userPhone: user.phone || resolvedUid,
    amount: depositAmount,
    paymentMethod: paymentMethod || 'UPI_QR',
    utrNumber: utrNumber.trim(),
    proofImageUrl: proofImageUrl || '',
    selfDeclaredConsent: true,
    auditMetadata: {
      clientIp,
      userAgent,
      epochTimestamp
    },
    upiNodeId: activeNode.id,
    status: 'PENDING',
    createdAt: Date.now(),
    expiresAt: Date.now() + 20 * 60 * 1000 // 20-minute TTL
  };

  console.log(`[AUDIT PROVER] Cryptographic intent logged for deposit ${depositRequest.id}. User: ${resolvedUserName} (${user.id}), IP: ${clientIp}, Epoch: ${epochTimestamp}`);

  deposits.unshift(depositRequest);

  // Advance counter and check rotation
  checkAndRotateDepositNode(depositAmount);

  // Notify admin via socket
  io.emit('new_deposit_request', depositRequest);

  // Persist to database immediately so no deposit data is ever lost
  scheduleSavePlatformData('new_deposit_request');

  // Forward to Telegram Bot ONLY for this newly accepted, unsubmitted UTR
  let telegramDispatched = Boolean(telegramSentClientSide);
  if (!telegramSentClientSide) {
    const tgResult = await dispatchDepositAlertToTelegram({
      orderId: resolvedOrderId,
      uid: resolvedUid,
      username: resolvedUserName,
      amount: depositAmount,
      txId: cleanUtr,
      proofImageUrl
    }).catch(() => ({ ok: false }));
    telegramDispatched = tgResult.ok;
  }

  res.json({
    success: true,
    orderId: resolvedOrderId,
    telegramDispatched,
    message: `Deposit proof submitted! Order ID: ${resolvedOrderId}`,
    deposit: depositRequest
  });
});

// 5. CASHIER: REQUEST WITHDRAWAL
app.post('/api/cashier/withdraw', (req, res) => {
  const { orderId, userId, uid, username, amount, payoutMethod, upiId, bankAccount, ifscCode, accountHolderName, telegramSentClientSide } = req.body;

  const user = users.get(userId) || findUserByIdOrUid(userId) || (uid ? findUserByIdOrUid(uid) : undefined);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  if (user.isFrozen) {
    return res.status(403).json({ error: 'Account frozen. Contact compliance.' });
  }

  const withdrawAmount = +amount;
  if (!withdrawAmount || isNaN(withdrawAmount) || withdrawAmount < 100) {
    return res.status(400).json({ error: `Minimum withdrawal request is ₹100.` });
  }

  const isSuper = user.id === SUPER_ADMIN_ID || user.role === 'superadmin';

  // MODULE 18: VIP Tier Max Single Withdrawal Enforcement (Super Admin is always VIP 10)
  const userVipConfig = isSuper ? VIP_TIERS[10] : getVipConfig(user.lifetimeDeposit || 0);
  if (!isSuper && withdrawAmount > userVipConfig.maxSingleWithdrawal) {
    return res.status(400).json({
      error: `${userVipConfig.label} maximum single withdrawal limit is ₹${userVipConfig.maxSingleWithdrawal}. Your verified lifetime deposit is ₹${user.lifetimeDeposit || 0}. Deposit more to upgrade your VIP tier.`
    });
  }

  // MODULE 22: Dynamic Wager Lock and Turnover Interceptor
  if (!isSuper && user.requiredWager && user.requiredWager > 0) {
    return res.status(400).json({
      error: `Pehle ₹${user.requiredWager.toFixed(2)} ka khelna baki hai!`,
      requiredWager: user.requiredWager,
      isWagerLocked: true
    });
  }

  // Strict turnover & withdrawable check
  if (!isSuper && user.turnoverCompleted < user.turnoverRequired && user.bonusBalance > 0) {
    return res.status(400).json({
      error: `Turnover requirement not fulfilled. Wagering required: ₹${user.turnoverRequired}, achieved: ₹${user.turnoverCompleted}.`
    });
  }

  // Execute Dynamic Exclusive Withdrawal Tax Slab Calculation:
  // >= 5000 -> 8% tax, >= 2000 -> 9% tax, < 2000 -> 10% tax (added on top of requestedAmount)
  const availableWithdrawable = isSuper ? 999999999 : user.withdrawableBalance;
  const exclusiveCalc = processExclusiveWithdrawal(withdrawAmount, availableWithdrawable);
  if (!exclusiveCalc.success) {
    return res.status(400).json({
      error: exclusiveCalc.message || `Insufficient withdrawable balance. Needed: ₹${exclusiveCalc.walletDeducted} (including ₹${exclusiveCalc.taxCollected} tax).`
    });
  }

  // Deduct totalWalletDeduction (requestedAmount + taxAmount) from withdrawable & main balance
  if (!isSuper) {
    user.withdrawableBalance = Math.max(0, +(user.withdrawableBalance - exclusiveCalc.walletDeducted).toFixed(2));
    user.mainBalance = Math.max(0, +(user.mainBalance - exclusiveCalc.walletDeducted).toFixed(2));
  }

  const resolvedOrderId = (orderId && String(orderId).trim().startsWith('WN-W-'))
    ? String(orderId).trim()
    : `WN-W-${make10DigitId()}`;
  const resolvedUserName = (username && String(username).trim()) ? String(username).trim() : user.name;
  const resolvedUid = (uid && String(uid).trim()) ? String(uid).trim() : format7DigitUid(user.uid, user.id);

  const withdrawRequest: WithdrawalRequest = {
    id: resolvedOrderId,
    orderId: resolvedOrderId,
    userId: user.id,
    userName: resolvedUserName,
    userPhone: user.phone || resolvedUid,
    amount: exclusiveCalc.userGets,
    taxPercent: exclusiveCalc.taxPercent,
    taxAmount: exclusiveCalc.taxCollected,
    netPayoutAmount: exclusiveCalc.userGets,
    walletDeducted: exclusiveCalc.walletDeducted,
    payoutMethod: payoutMethod || 'UPI',
    upiId,
    bankAccount,
    ifscCode,
    accountHolderName,
    status: 'PENDING',
    createdAt: Date.now(),
    is_deleted: false
  };

  withdrawals.unshift(withdrawRequest);

  io.emit('new_withdrawal_request', withdrawRequest);
  broadcastLiveWalletSync(user, 'withdrawal_requested');
  scheduleSavePlatformData('new_withdrawal_request');

  if (!telegramSentClientSide) {
    const payoutSummary = (payoutMethod || 'UPI') === 'UPI'
      ? `UPI: ${upiId || 'N/A'}`
      : `Bank A/C: ${bankAccount || 'N/A'} | IFSC: ${ifscCode || 'N/A'} | Name: ${accountHolderName || resolvedUserName}`;
    dispatchWithdrawalAlertToTelegram({
      orderId: resolvedOrderId,
      uid: resolvedUid,
      username: resolvedUserName,
      amount: exclusiveCalc.userGets,
      taxAmount: exclusiveCalc.taxCollected,
      taxPercent: exclusiveCalc.taxPercent,
      walletDeducted: exclusiveCalc.walletDeducted,
      netPayoutAmount: exclusiveCalc.userGets,
      payoutDetails: payoutSummary
    }).catch(() => {});
  }

  res.json({
    success: true,
    orderId: resolvedOrderId,
    userGets: exclusiveCalc.userGets,
    taxCollected: exclusiveCalc.taxCollected,
    walletDeducted: exclusiveCalc.walletDeducted,
    remainingBalance: user.mainBalance,
    message: `Withdrawal request queued! Order ID: ${resolvedOrderId} (You get: ₹${exclusiveCalc.userGets}, Wallet deducted: ₹${exclusiveCalc.walletDeducted} incl. ₹${exclusiveCalc.taxCollected} tax)`,
    withdrawal: withdrawRequest
  });
});

// 5B. ADMIN QUICK ORDER ID SEARCH & LIVE MANUAL APPROVAL (WN-D-XXXXXXXXXX & WN-W-XXXXXXXXXX)
app.get('/api/admin/order/search', (req, res) => {
  const queryId = String(req.query.orderId || '').trim();
  if (!queryId) return res.status(400).json({ error: 'Please enter an Order ID (WN-D-... or WN-W-...).' });

  const normalized = queryId.toUpperCase();
  const dep = deposits.find(
    d => d.id.toUpperCase() === normalized || d.utrNumber.toUpperCase() === normalized
  );
  if (dep) {
    const u = users.get(dep.userId) || findUserByIdOrUid(dep.userId);
    const uid = u ? format7DigitUid(u.uid, u.id) : dep.userPhone || dep.userId;
    return res.json({
      success: true,
      order: {
        order_id: dep.id,
        uid,
        userId: dep.userId,
        username: dep.userName,
        amount: dep.amount,
        utr: dep.utrNumber,
        status: dep.status,
        proofImageUrl: dep.proofImageUrl,
        type: 'Deposit',
        createdAt: dep.createdAt
      }
    });
  }

  const wd = withdrawals.find(w => w.id.toUpperCase() === normalized);
  if (wd) {
    const u = users.get(wd.userId) || findUserByIdOrUid(wd.userId);
    const uid = u ? format7DigitUid(u.uid, u.id) : wd.userPhone || wd.userId;
    const taxBreakdown = calculateWithdrawalTaxBreakdown(wd.amount);
    return res.json({
      success: true,
      order: {
        order_id: wd.id,
        uid,
        userId: wd.userId,
        username: wd.userName,
        amount: wd.amount,
        taxAmount: wd.taxAmount ?? taxBreakdown.taxAmount,
        netPayoutAmount: wd.netPayoutAmount ?? taxBreakdown.netPayoutAmount,
        payoutMethod: wd.payoutMethod,
        upiId: wd.upiId,
        bankAccount: wd.bankAccount,
        ifscCode: wd.ifscCode,
        accountHolderName: wd.accountHolderName,
        status: wd.status,
        type: 'Withdrawal',
        createdAt: wd.createdAt
      }
    });
  }

  return res.status(404).json({ error: `Order "${queryId}" not found.` });
});

app.post('/api/admin/order/action', (req, res) => {
  const { orderId, status, uid, username, amount, type } = req.body || {};
  const cleanId = String(orderId || '').trim().toUpperCase();
  const isApprove = status === 'Approved' || status === 'APPROVE' || status === 'APPROVED';

  // 1. Check Deposits
  const dep = deposits.find(d => d.id.toUpperCase() === cleanId || d.utrNumber.toUpperCase() === cleanId);
  if (dep) {
    if (dep.status !== 'PENDING') {
      return res.status(400).json({ error: `Deposit Order ${dep.id} is already ${dep.status}.` });
    }
    const updated = executeDepositReviewAction(dep, isApprove ? 'APPROVE' : 'REJECT');
    const u = users.get(dep.userId) || findUserByIdOrUid(dep.userId);
    return res.json({
      success: true,
      type: 'Deposit',
      orderId: dep.id,
      status: updated.status,
      newBalance: u?.mainBalance ?? 0,
      message: isApprove
        ? `Deposit Approved! ₹${dep.amount} credited to ${dep.userName}'s wallet.`
        : `Deposit Order ${dep.id} Rejected.`
    });
  }

  // 2. Check Withdrawals
  const wd = withdrawals.find(w => w.id.toUpperCase() === cleanId);
  if (wd) {
    if (wd.status !== 'PENDING') {
      return res.status(400).json({ error: `Withdrawal Order ${wd.id} is already ${wd.status}.` });
    }
    const u = users.get(wd.userId) || findUserByIdOrUid(wd.userId);
    if (isApprove) {
      wd.status = 'APPROVED';
      wd.adminUtr = `TXN${Date.now()}`;
      wd.reviewedAt = Date.now();
      io.emit('withdrawal_status_changed', wd);
      if (u) broadcastLiveWalletSync(u, 'withdrawal_approved');
      scheduleSavePlatformData('withdrawal_approved_by_order_id');
      return res.json({
        success: true,
        type: 'Withdrawal',
        orderId: wd.id,
        status: 'APPROVED',
        newBalance: u?.mainBalance ?? 0,
        message: `Withdrawal Approved! Net Payout ₹${wd.netPayoutAmount ?? calculateWithdrawalTaxBreakdown(wd.amount).netPayoutAmount} marked paid.`
      });
    } else {
      // Reject Withdrawal -> Permanent Auto-Refund of full deducted amount (including tax) to User's Wallet!
      wd.status = 'REJECTED';
      wd.reviewedAt = Date.now();
      const refundTotal = wd.walletDeducted ?? wd.amount;
      if (u) {
        u.mainBalance = +(u.mainBalance + refundTotal).toFixed(2);
        u.withdrawableBalance = +(u.withdrawableBalance + refundTotal).toFixed(2);
        io.to(`user_${u.id}`).emit('balance_updated', {
          mainBalance: u.mainBalance,
          withdrawableBalance: u.withdrawableBalance,
          promoWallet: u.promoWallet,
          message: `Withdrawal Rejected! ₹${refundTotal} refunded to your wallet.`
        });
        broadcastLiveWalletSync(u, 'withdrawal_rejected_refund');
      }
      io.emit('withdrawal_status_changed', wd);
      scheduleSavePlatformData('withdrawal_rejected_refund');
      return res.json({
        success: true,
        type: 'Withdrawal',
        orderId: wd.id,
        status: 'REJECTED',
        newBalance: u?.mainBalance ?? 0,
        message: `Withdrawal Rejected! ₹${refundTotal} refunded to user's wallet.`
      });
    }
  }

  // 3. Fallback for sessionStorage-only order if submitted directly via client
  if (uid && amount) {
    const u = findUserByIdOrUid(String(uid));
    const numAmt = Math.max(0, Number(amount) || 0);
    if (u && numAmt > 0) {
      if ((type === 'Deposit' && isApprove) || (type === 'Withdrawal' && !isApprove)) {
        u.mainBalance = +(u.mainBalance + numAmt).toFixed(2);
        u.withdrawableBalance = +(u.withdrawableBalance + numAmt).toFixed(2);
        broadcastLiveWalletSync(u, type === 'Deposit' ? 'deposit_approved' : 'withdrawal_rejected_refund');
        scheduleSavePlatformData('fallback_order_credit');
      }
      return res.json({
        success: true,
        type: type || 'Deposit',
        orderId: cleanId,
        status: isApprove ? 'APPROVED' : 'REJECTED',
        newBalance: u.mainBalance,
        message: type === 'Withdrawal' && !isApprove
          ? `Withdrawal Rejected! ₹${numAmt} refunded to user's wallet.`
          : `Order ${cleanId} ${isApprove ? 'Approved' : 'Rejected'}!`
      });
    }
  }

  return res.status(404).json({ error: `Order "${orderId}" not found.` });
});

// 6. GET USER TRANSACTION HISTORY (Filtered to Last 30 Days for Player Display)
app.get('/api/user/transactions', (req, res) => {
  const userId = req.query.userId as string;
  const userDeposits = deposits
    .filter(d => d.userId === userId)
    .filter(d => isWithinLast30Days(d.createdAt));
  const userWithdrawals = withdrawals
    .filter(w => w.userId === userId)
    .filter(w => isWithinLast30Days(w.createdAt));
  res.json({ deposits: userDeposits, withdrawals: userWithdrawals });
});

// 7. GET REFERRAL & REBATE STATS FOR USER
app.get('/api/user/referrals', (req, res) => {
  const userId = req.query.userId as string;
  const user = users.get(userId);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const referredUsers: User[] = [];
  for (const u of users.values()) {
    if (u.referredBy === userId) {
      referredUsers.push(u);
    }
  }

  const referralStats: ReferralStat[] = referredUsers.map(u => {
    // Check if user has any approved deposit
    const hasDeposited = deposits.some(d => d.userId === u.id && d.status === 'APPROVED');
    return {
      userId: u.id,
      userName: u.name,
      userPhone: u.phone.replace(/(\d{3})\d{4}(\d{3})/, '$1****$2'),
      registeredAt: u.createdAt,
      hasDeposited,
      instantBonusStatus: u.referralRewardStatus === 'released' ? 'RELEASED' : 'PENDING',
      rebateGenerated: 0
    };
  });

  res.json({
    referralCode: user.referralCode,
    referralLink: `${req.protocol}://${req.get('host')}/?ref=${user.referralCode}`,
    totalReferrals: referredUsers.length,
    promoWallet: user.promoWallet,
    referralList: referralStats
  });
});

// 7 B. ADMIN REFERRAL PERFORMANCE METRICS (Total Bonuses & Active Referrals)
app.get('/api/admin/referrals/metrics', (_req, res) => {
  const referrerMap = new Map<string, {
    referrerId: string;
    referrerName: string;
    referrerUid: string;
    referralCode: string;
    totalReferrals: number;
    activeReferrals: number;
    totalBonusEarned: number;
    promoWallet: number;
  }>();

  let globalTotalReferrals = 0;
  let globalActiveReferrals = 0;
  let globalTotalBonusesGenerated = 0;

  // Initialize referrers with non-zero promoWallet or users who have referral codes
  for (const u of users.values()) {
    if (u.promoWallet > 0 || u.role === 'admin' || u.role === 'superadmin') {
      if (!referrerMap.has(u.id)) {
        referrerMap.set(u.id, {
          referrerId: u.id,
          referrerName: u.name,
          referrerUid: u.uid || u.id.slice(0, 7),
          referralCode: u.referralCode || `WN-${u.id.slice(0, 4).toUpperCase()}`,
          totalReferrals: 0,
          activeReferrals: 0,
          totalBonusEarned: u.promoWallet || 0,
          promoWallet: u.promoWallet || 0
        });
      }
    }
  }

  // Iterate over all users to count referrals and active depositors
  for (const u of users.values()) {
    if (u.referredBy) {
      globalTotalReferrals++;
      const referrer = users.get(u.referredBy);
      if (referrer) {
        if (!referrerMap.has(referrer.id)) {
          referrerMap.set(referrer.id, {
            referrerId: referrer.id,
            referrerName: referrer.name,
            referrerUid: referrer.uid || referrer.id.slice(0, 7),
            referralCode: referrer.referralCode || `WN-${referrer.id.slice(0, 4).toUpperCase()}`,
            totalReferrals: 0,
            activeReferrals: 0,
            totalBonusEarned: referrer.promoWallet || 0,
            promoWallet: referrer.promoWallet || 0
          });
        }
        const data = referrerMap.get(referrer.id)!;
        data.totalReferrals++;

        const hasDeposited = Array.from(deposits.values ? deposits.values() : deposits).some(
          (d: any) => d.userId === u.id && (d.status === 'APPROVED' || d.status === 'COMPLETED' || d.status === 'Success')
        );

        if (hasDeposited || u.lifetimeDeposit > 0) {
          data.activeReferrals++;
          globalActiveReferrals++;
          data.totalBonusEarned += 20;
          globalTotalBonusesGenerated += 20;
        }
      }
    }
  }

  // If no referrers exist yet, provide realistic telemetry data so the Admin Dashboard displays smoothly
  const referrersList = Array.from(referrerMap.values());
  if (referrersList.length === 0) {
    const demoReferrers = [
      {
        referrerId: 'ref_top_01',
        referrerName: 'Faisal Raza (Master)',
        referrerUid: 'UID-7777',
        referralCode: 'WN-WIN777',
        totalReferrals: 14,
        activeReferrals: 9,
        totalBonusEarned: 380,
        promoWallet: 180
      },
      {
        referrerId: 'ref_vip_02',
        referrerName: 'Developer Jack',
        referrerUid: 'UID-8828',
        referralCode: 'WN-JACK01',
        totalReferrals: 8,
        activeReferrals: 6,
        totalBonusEarned: 220,
        promoWallet: 120
      },
      {
        referrerId: 'ref_vip_03',
        referrerName: 'Pilot Aviator Alpha',
        referrerUid: 'UID-3914',
        referralCode: 'WN-PILOT7',
        totalReferrals: 5,
        activeReferrals: 3,
        totalBonusEarned: 110,
        promoWallet: 50
      }
    ];
    return res.json({
      success: true,
      globalTotalReferrals: 27,
      globalActiveReferrals: 18,
      globalTotalBonusesGenerated: 710,
      referrers: demoReferrers
    });
  }

  return res.json({
    success: true,
    globalTotalReferrals,
    globalActiveReferrals,
    globalTotalBonusesGenerated: Math.max(globalTotalBonusesGenerated, Array.from(referrerMap.values()).reduce((a, b) => a + b.totalBonusEarned, 0)),
    referrers: referrersList
  });
});

// =========================================================================
// MODULE 24 B: PROMOTIONAL COMMISSIONS ESCROW & CONVERSION CONTROLLER
// Transfers funds from isolated promoWallet to main balance
// Restricts settlement to maximum ₹500 per 24-hour cycle directly withdrawable
// Any conversion exceeding ₹500 dynamically inherits a 1x gameplay rollover turnover
// =========================================================================
app.post('/api/wallet/convert-promo', (req, res) => {
  const { userId, amount } = req.body;
  const user = users.get(userId);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  const convertAmount = +amount;
  if (!convertAmount || isNaN(convertAmount) || convertAmount <= 0) {
    return res.status(400).json({ error: 'Please enter a valid transfer amount greater than ₹0.' });
  }

  if ((user.promoWallet || 0) < convertAmount) {
    return res.status(400).json({
      error: `Insufficient promotional vault balance. You currently have ₹${(user.promoWallet || 0).toFixed(2)} available.`
    });
  }

  const now = Date.now();
  const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;

  if (!user.promoConversionHistory) {
    user.promoConversionHistory = [];
  }

  // Calculate total converted in the past 24 hours
  const recentConversions = user.promoConversionHistory.filter(c => (now - c.timestamp) < TWENTY_FOUR_HOURS);
  const convertedInLast24h = recentConversions.reduce((sum, c) => sum + c.amount, 0);

  const availableImmediateCap = Math.max(0, 500 - convertedInLast24h);
  const directPortion = Math.min(convertAmount, availableImmediateCap);
  const excessPortion = Math.max(0, convertAmount - directPortion);

  // Deduct from isolated promo vault
  user.promoWallet = Math.max(0, +(user.promoWallet - convertAmount).toFixed(2));

  // Credit to main balance
  user.mainBalance = +(user.mainBalance + convertAmount).toFixed(2);

  // If conversion exceeds 24h cap of ₹500, excess dynamically inherits a 1x gameplay rollover turnover requirement
  if (excessPortion > 0) {
    user.requiredWager = +( (user.requiredWager || 0) + excessPortion ).toFixed(2);
    user.turnoverRequired = +( (user.turnoverRequired || 0) + excessPortion ).toFixed(2);
    console.log(`[PROMO CONVERSION] User ${user.id} converted ₹${convertAmount} (₹${directPortion} direct, ₹${excessPortion} rollover required). 1x turnover of ₹${excessPortion} appended.`);
  }

  // Update withdrawable balance
  const currentWagerLock = user.requiredWager || 0;
  user.withdrawableBalance = Math.max(0, +(user.mainBalance - currentWagerLock).toFixed(2));

  // Record conversion audit log
  user.promoConversionHistory.push({
    amount: convertAmount,
    convertedToMain: convertAmount,
    rolloverRequired: excessPortion,
    timestamp: now
  });

  // Notify client
  io.to(`user_${user.id}`).emit('balance_updated', {
    mainBalance: user.mainBalance,
    withdrawableBalance: user.withdrawableBalance,
    promoWallet: user.promoWallet,
    requiredWager: user.requiredWager ?? 0,
    vipLevel: user.vipLevel,
    lifetimeDeposit: user.lifetimeDeposit,
    message: `₹${convertAmount.toFixed(2)} transferred from Promo Vault! ${excessPortion > 0 ? `(₹${excessPortion} subject to 1x gameplay turnover)` : ''}`
  });

  res.json({
    success: true,
    transferredAmount: convertAmount,
    directPortion,
    excessPortion,
    rolloverRequired: excessPortion,
    newPromoWallet: user.promoWallet,
    newMainBalance: user.mainBalance,
    newWithdrawableBalance: user.withdrawableBalance,
    remaining24hInstantCap: Math.max(0, +(availableImmediateCap - directPortion).toFixed(2)),
    message: `Successfully transferred ₹${convertAmount.toFixed(2)} to main balance.${excessPortion > 0 ? ` ₹${excessPortion.toFixed(2)} exceeds 24h cap and requires 1x gameplay rollover.` : ''}`
  });
});

// GET PROMO CONVERSION STATUS
app.get('/api/wallet/promo-status', (req, res) => {
  const userId = req.query.userId as string;
  const user = users.get(userId);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  const now = Date.now();
  const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
  const recentConversions = (user.promoConversionHistory || []).filter(c => (now - c.timestamp) < TWENTY_FOUR_HOURS);
  const convertedInLast24h = recentConversions.reduce((sum, c) => sum + c.amount, 0);
  const remaining24hInstantCap = Math.max(0, +(500 - convertedInLast24h).toFixed(2));

  res.json({
    promoWallet: user.promoWallet || 0,
    convertedInLast24h,
    remaining24hInstantCap,
    dailyLimit: 500,
    requiredWager: user.requiredWager || 0,
    history: user.promoConversionHistory || []
  });
});

// ==========================================
// HIGH-CONCURRENCY GIFT CODE & DYNAMIC WITHDRAWAL TIERS ENGINE
// ==========================================
app.use('/api', createFinancialRouter(
  (userId: string) => users.get(userId),
  (userId: string, amountChange: number) => {
    const u = users.get(userId);
    if (!u) return { success: false, newBalance: 0 };
    u.mainBalance = +(u.mainBalance + amountChange).toFixed(2);
    if (amountChange > 0) {
      u.withdrawableBalance = +(u.withdrawableBalance + amountChange).toFixed(2);
    } else {
      u.withdrawableBalance = Math.max(0, +(u.withdrawableBalance + amountChange).toFixed(2));
    }
    return { success: true, newBalance: u.mainBalance, user: u };
  }
));

// =========================================================================
// SECURE SUPER ADMIN WALLET & FIRESTORE STORAGE ENGINE
// =========================================================================
interface BackendUserWallet {
  userId: string;
  deposited_balance: number;
  bonus_balance: number;
  gift_balance: number;
  total_balance: number;
  updatedAt: string;
}

interface BackendWalletTransaction {
  id: string;
  type: 'deposit' | 'bonus' | 'gift_code' | 'admin_credit';
  amount: number;
  balance_type: 'deposited_balance' | 'bonus_balance' | 'gift_balance';
  previous_balance: number;
  new_balance: number;
  credited_by: string;
  note: string;
  timestamp: string;
}

const userWallets = new Map<string, BackendUserWallet>();
const walletTransactions = new Map<string, BackendWalletTransaction[]>();

function getOrCreateWallet(userId: string): BackendUserWallet {
  let w = userWallets.get(userId);
  if (!w) {
    const existingUser = users.get(userId);
    const initialDep = existingUser ? existingUser.mainBalance : 0;
    const initialBon = existingUser ? existingUser.bonusBalance : 0;
    const initialGift = existingUser ? existingUser.promoWallet : 0;
    w = {
      userId,
      deposited_balance: initialDep,
      bonus_balance: initialBon,
      gift_balance: initialGift,
      total_balance: +(initialDep + initialBon + initialGift).toFixed(2),
      updatedAt: new Date().toISOString()
    };
    userWallets.set(userId, w);
  }
  return w;
}

// Super Admin Credit Endpoint
app.post('/api/superadmin/credit-wallet', (req, res) => {
  try {
    const { userId, amount, balanceType, note, adminId } = req.body;
    if (!userId || typeof userId !== 'string') {
      return res.status(400).json({ success: false, error: 'Target User ID is required.' });
    }
    const numAmount = Number(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ success: false, error: 'Credit amount must be a positive number.' });
    }
    const validTypes = ['deposited_balance', 'bonus_balance', 'gift_balance'];
    const chosenType = validTypes.includes(balanceType) ? balanceType : 'deposited_balance';

    // Synchronize with active gameplay user session if present (supports 7-digit UID or userId)
    let activePlayer = findUserByIdOrUid(userId);
    const normInputUid = normalizeUidInput(userId);
    if (!activePlayer && normInputUid.length === 7) {
      // Auto-provision user with this 7-digit UID so Super Admin can credit any 7-digit UID anytime
      const createdId = `usr_uid_${normInputUid}`;
      activePlayer = {
        id: createdId,
        uid: normInputUid,
        name: `Player #${normInputUid}`,
        email: `uid${normInputUid}@winnova.play`,
        phone: normInputUid,
        role: 'user',
        mainBalance: 0,
        promoWallet: 0,
        bonusBalance: 0,
        withdrawableBalance: 0,
        turnoverRequired: 0,
        turnoverCompleted: 0,
        referralCode: generateReferralCode(),
        referralRewardStatus: 'none',
        isFrozen: false,
        deviceFingerprint: `fp_${normInputUid}`,
        registeredIp: '127.0.0.1',
        lastLoginIp: '127.0.0.1',
        createdAt: Date.now()
      };
      usedUids.add(normInputUid);
      users.set(activePlayer.id, activePlayer);
    }

    const resolvedKey = activePlayer ? activePlayer.id : userId;
    const wallet = getOrCreateWallet(resolvedKey);
    const prevTotal = wallet.total_balance;

    if (chosenType === 'deposited_balance') {
      wallet.deposited_balance = +(wallet.deposited_balance + numAmount).toFixed(2);
    } else if (chosenType === 'bonus_balance') {
      wallet.bonus_balance = +(wallet.bonus_balance + numAmount).toFixed(2);
    } else if (chosenType === 'gift_balance') {
      wallet.gift_balance = +(wallet.gift_balance + numAmount).toFixed(2);
    }
    wallet.total_balance = +(wallet.deposited_balance + wallet.bonus_balance + wallet.gift_balance).toFixed(2);
    wallet.updatedAt = new Date().toISOString();

    if (activePlayer) {
      if (chosenType === 'deposited_balance') {
        activePlayer.mainBalance = +(activePlayer.mainBalance + numAmount).toFixed(2);
        activePlayer.withdrawableBalance = +(activePlayer.withdrawableBalance + numAmount).toFixed(2);
      } else if (chosenType === 'bonus_balance') {
        activePlayer.bonusBalance = +(activePlayer.bonusBalance + numAmount).toFixed(2);
      } else if (chosenType === 'gift_balance') {
        activePlayer.promoWallet = +(activePlayer.promoWallet + numAmount).toFixed(2);
      }

      io.to(`user_${activePlayer.id}`).emit('balance_updated', {
        mainBalance: activePlayer.mainBalance,
        withdrawableBalance: activePlayer.withdrawableBalance,
        promoWallet: activePlayer.promoWallet,
        bonusBalance: activePlayer.bonusBalance,
        message: `Super Admin credited ₹${numAmount} to your wallet (UID: ${activePlayer.uid})!`
      });
    }

    const txId = `tx_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const tx: BackendWalletTransaction = {
      id: txId,
      type: 'admin_credit',
      amount: numAmount,
      balance_type: chosenType as any,
      previous_balance: prevTotal,
      new_balance: wallet.total_balance,
      credited_by: adminId || 'super_admin',
      note: note || `Super Admin credited ₹${numAmount} (${chosenType})`,
      timestamp: new Date().toISOString()
    };

    let userTxList = walletTransactions.get(userId);
    if (!userTxList) {
      userTxList = [];
      walletTransactions.set(userId, userTxList);
    }
    userTxList.unshift(tx);

    return res.json({
      success: true,
      wallet,
      txId,
      message: `Successfully credited ₹${numAmount} to user ${userId} (${chosenType}).`
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to credit user wallet.' });
  }
});

// Fetch user wallet state
app.get('/api/superadmin/wallet/:userId', (req, res) => {
  const { userId } = req.params;
  if (!userId) return res.status(400).json({ success: false, error: 'User ID is required.' });
  const wallet = getOrCreateWallet(userId);
  return res.json({ success: true, wallet });
});

// Fetch user wallet transaction history
app.get('/api/superadmin/wallet/:userId/transactions', (req, res) => {
  const { userId } = req.params;
  if (!userId) return res.status(400).json({ success: false, error: 'User ID is required.' });
  const txs = walletTransactions.get(userId) || [];
  return res.json({ success: true, transactions: txs });
});

// Helper: Broadcast Instant Live Wallet Balance Sync to Clients & Database
function broadcastLiveWalletSync(user: User, reason: string = 'wallet_live_sync') {
  const payload = {
    username: user.name,
    uid: user.uid,
    userId: user.id,
    balance: user.mainBalance,
    withdrawableBalance: user.withdrawableBalance,
    promoWallet: user.promoWallet,
    bonusBalance: user.bonusBalance,
    updatedAt: Date.now()
  };

  io.emit('wallet_live_sync', payload);
  io.to(`user_${user.id}`).emit('balance_updated', {
    mainBalance: user.mainBalance,
    withdrawableBalance: user.withdrawableBalance,
    promoWallet: user.promoWallet,
    bonusBalance: user.bonusBalance
  });

  try {
    adminDb.collection('wallets').doc(user.id).set(payload, { merge: true }).catch(() => {});
    if (user.name) {
      adminDb.collection('wallets').doc(user.name).set(payload, { merge: true }).catch(() => {});
    }
  } catch {}

  scheduleSavePlatformData(reason);
}

// SYSTEM 1: Get Live Wallet Balance by Username / UID / UserID
app.get('/api/wallets/:username', (req, res) => {
  const rawKey = (req.params.username || '').trim();
  if (!rawKey) return res.json({ data: { username: '', balance: 0 } });

  const found = findUserByIdOrUid(rawKey);
  if (!found) {
    return res.json({ data: { username: rawKey, balance: 0 } });
  }
  const isSuper = found.id === SUPER_ADMIN_ID || found.role === 'superadmin';
  return res.json({
    data: {
      username: found.name,
      uid: found.uid,
      userId: found.id,
      balance: isSuper ? 999999999 : found.mainBalance
    }
  });
});

// SYSTEM 3: Game Integration Function (Permanent Save & Instant Live Sync)
app.post('/api/wallets/upsert', (req, res) => {
  const { username, userId, balance } = req.body || {};
  const lookupKey = String(userId || username || '').trim();
  if (!lookupKey || balance === undefined || isNaN(Number(balance))) {
    return res.status(400).json({ error: 'Valid username/userId and balance required' });
  }

  const found = findUserByIdOrUid(lookupKey);
  if (!found) {
    return res.status(404).json({ error: 'User not found' });
  }

  if (found.id !== SUPER_ADMIN_ID && found.role !== 'superadmin') {
    const numericBalance = Math.max(0, +Number(balance).toFixed(2));
    found.mainBalance = numericBalance;
    found.withdrawableBalance = Math.max(0, +(numericBalance - (found.requiredWager || 0)).toFixed(2));
  }

  broadcastLiveWalletSync(found, 'update_balance_after_game');
  return res.json({
    success: true,
    data: {
      username: found.name,
      uid: found.uid,
      userId: found.id,
      balance: found.mainBalance
    }
  });
});

// Anti-Exploit Simulation Endpoint (Simulate hacker trying client-side direct write)
app.post('/api/wallet/simulate-unauthorized-write', (req, res) => {
  // Always reject unauthorized client-side direct writes
  return res.status(403).json({
    success: false,
    error: 'PERMISSION_DENIED: Normal users cannot directly write to wallet balances. Write operation blocked by security policy.'
  });
});

// ==========================================
// SUPER ADMIN & SUB-ADMIN RBAC MIDDLEWARE (MODULE 17)
// ==========================================

function getAdminRequesterRole(req: express.Request): { isSuperAdmin: boolean; subAdmin?: SubAdminAccount } {
  const authHeader = req.headers['authorization'];
  const adminKey = req.headers['x-admin-key'] as string;
  const userIdHeader = (req.headers['x-user-id'] as string) || (req.body && req.body.adminId);
  const token = (authHeader && typeof authHeader === 'string' ? authHeader.replace('Bearer ', '') : '') || adminKey;

  if (
    token === 'sa_secret_token_786' ||
    adminKey === SUPER_ADMIN_PASSWORD ||
    token === SUPER_ADMIN_EMAIL ||
    adminKey === SUPER_ADMIN_EMAIL ||
    token === 'mdfaisalraza7777@gmail.com' ||
    adminKey === 'mdfaisalraza7777@gmail.com' ||
    token === SUPER_ADMIN_ID ||
    adminKey === SUPER_ADMIN_ID ||
    userIdHeader === SUPER_ADMIN_ID
  ) {
    return { isSuperAdmin: true };
  }

  const sub = Array.from(subAdmins.values()).find(
    s => !s.is_deleted && (s.token === token || s.token === adminKey || s.email === token || s.email === adminKey || s.id === userIdHeader)
  );
  if (sub && sub.isActive && !sub.is_deleted) {
    return { isSuperAdmin: false, subAdmin: sub };
  }

  // Regular Admin fallback token ('admin123') — strictly NOT Super Admin
  if (token === 'admin123' || adminKey === 'admin123') {
    return {
      isSuperAdmin: false,
      subAdmin: {
        id: 'regular_admin_default',
        name: 'Regular Admin',
        email: 'admin@winnova.com',
        token: 'admin123',
        role: 'SUB_ADMIN',
        permissions: {
          canManageWithdrawals: true,
          canViewGameEngine: true,
          canViewMetrics: true,
          canManageDeposits: false,
          canSendNotifications: true,
          canSendNotificationsWithMoney: Boolean(systemConfig.allowAdminRewardDispatch)
        },
        isActive: true,
        createdAt: 1700000000000
      }
    };
  }

  // Also check if token/adminKey/userId corresponds to an existing user with role superadmin or admin
  for (const u of users.values()) {
    if (
      (u.role === 'superadmin' || u.role === 'admin') &&
      (u.id === token || u.id === adminKey || u.id === userIdHeader || `token_${u.id}` === token || u.email === token || u.email === adminKey)
    ) {
      if (u.role === 'superadmin') return { isSuperAdmin: true };
      return {
        isSuperAdmin: false,
        subAdmin: {
          id: u.id,
          name: u.name,
          email: u.email,
          token: `token_${u.id}`,
          role: 'SUB_ADMIN',
          permissions: {
            canManageWithdrawals: true,
            canViewGameEngine: true,
            canViewMetrics: true,
            canManageDeposits: false
          },
          isActive: true,
          createdAt: u.createdAt
        }
      };
    }
  }

  return { isSuperAdmin: false };
}

// Strictly requires Master Super Admin credentials
function verifyStrictSuperAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const { isSuperAdmin } = getAdminRequesterRole(req);
  if (isSuperAdmin) {
    (req as any).adminRole = 'SUPER_ADMIN';
    return next();
  }
  return res.status(403).json({ error: 'Access Denied: Master Super Admin credentials required.' });
}

// Allows Super Admin OR Sub-Admin with verified permissions
function verifySuperAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const { isSuperAdmin, subAdmin } = getAdminRequesterRole(req);
  if (isSuperAdmin) {
    (req as any).adminRole = 'SUPER_ADMIN';
    return next();
  }
  if (subAdmin) {
    (req as any).adminRole = 'SUB_ADMIN';
    (req as any).subAdmin = subAdmin;
    return next();
  }
  return res.status(403).json({ error: 'Access Denied. Controller authorization required.' });
}

// 8. ADMIN DASHBOARD METRICS
app.get('/api/admin/metrics', verifySuperAdmin, (req, res) => {
  let totalDeposits = 0;
  let totalWithdrawals = 0;

  deposits.forEach(d => {
    if (d.status === 'APPROVED') totalDeposits += d.amount;
  });

  withdrawals.forEach(w => {
    if (w.status === 'APPROVED') totalWithdrawals += w.amount;
  });

  const netProfit = +(totalDeposits - totalWithdrawals).toFixed(2);
  const totalUsers = Array.from(users.values()).filter(u => u.id !== SUPER_ADMIN_ID).length;

  res.json({
    liveConcurrentUsers: io.engine.clientsCount + Math.floor(Math.random() * 8) + 12,
    activeMultiplier: currentMultiplier,
    currentRoundStatus: gameStatus,
    todayNetProfit: netProfit,
    totalDeposits,
    totalWithdrawals,
    totalUsers,
    pendingDepositsCount: deposits.filter(d => d.status === 'PENDING').length,
    pendingWithdrawalsCount: withdrawals.filter(w => w.status === 'PENDING').length,
    flaggedFraudCount: fraudAlerts.length,
    systemConfig
  });
});

// Shared Deposit Approval / Rejection Processor (Used by Admin Dashboard AND Telegram Inline Buttons)
function executeDepositReviewAction(
  deposit: DepositRequest,
  action: 'APPROVE' | 'REJECT',
  rejectionReason?: string
): DepositRequest {
  if (action === 'APPROVE') {
    deposit.status = 'APPROVED';
    deposit.reviewedAt = Date.now();

    const user = users.get(deposit.userId) || findUserByIdOrUid(deposit.userId);
    if (user) {
      user.mainBalance = +(user.mainBalance + deposit.amount).toFixed(2);
      user.withdrawableBalance = +(user.withdrawableBalance + deposit.amount).toFixed(2);
      user.sessionInitialDeposit = +((user.sessionInitialDeposit || 0) + deposit.amount).toFixed(2);
      user.sessionInitialBalance = +((user.sessionInitialBalance || 0) + deposit.amount).toFixed(2);

      // MODULE 18 & 19: Check if this was user's first-time approved deposit
      const priorApproved = deposits.filter(d => d.userId === user.id && d.status === 'APPROVED' && d.id !== deposit.id);
      const isFirstTime = priorApproved.length === 0;

      // Update Lifetime Deposit
      user.lifetimeDeposit = +((user.lifetimeDeposit || 0) + deposit.amount).toFixed(2);

      // Dynamic VIP Tier Evaluation & Upgrade
      const oldVip = user.vipLevel || 0;
      const newVipConfig = getVipConfig(user.lifetimeDeposit);
      user.vipLevel = newVipConfig.level;

      if (user.vipLevel > oldVip) {
        console.log(`[VIP UPGRADE] User ${user.id} upgraded to ${newVipConfig.label} (Lifetime: ₹${user.lifetimeDeposit})`);
        io.to(`user_${user.id}`).emit('vip_level_upgraded', {
          vipLevel: user.vipLevel,
          label: newVipConfig.label,
          maxSingleWithdrawal: newVipConfig.maxSingleWithdrawal,
          lifetimeDeposit: user.lifetimeDeposit
        });
      }

      // Increment user deposit count
      user.depositCount = (user.depositCount || 0) + 1;

      // MODULE 18 & 19: Multi-Tiered Deposit Bonus Calculation (Promo Wallet)
      const bonusCredit = calculateDepositBonus(deposit.amount, isFirstTime, user.depositCount);
      if (bonusCredit > 0) {
        user.promoWallet = +(user.promoWallet + bonusCredit).toFixed(2);
        console.log(`[BONUS ENGINE] Credited ₹${bonusCredit} (${isFirstTime ? 'FIRST_TIME' : 'RECURRING'}) bonus to user ${user.id}`);
        io.to(`user_${user.id}`).emit('bonus_awarded', {
          amount: bonusCredit,
          type: isFirstTime ? 'FIRST_TIME_DEPOSIT_BONUS' : 'RECURRING_DEPOSIT_BONUS',
          newPromoWallet: user.promoWallet
        });
      }

      // MODULE 22: Dynamic Sliding Scale Wager Injection
      const calculatedWager = calculateSlidingWager(deposit.amount);
      user.requiredWager = +((user.requiredWager || 0) + calculatedWager).toFixed(2);
      console.log(`[WAGER ENGINE] User ${user.id} deposited ₹${deposit.amount}. Sliding wager added: ₹${calculatedWager}. Total required: ₹${user.requiredWager}`);

      // =========================================================================
      // ZERO-LEAKAGE ANTI-FRAUD RULE:
      // ₹20 instant referral bonus unlocks ONLY after referred user's first valid deposit
      // =========================================================================
      if (user.referredBy && user.referralRewardStatus === 'pending') {
        const referrer = users.get(user.referredBy);
        if (referrer && !referrer.isFrozen) {
          user.referralRewardStatus = 'released';
          referrer.promoWallet = +(referrer.promoWallet + systemConfig.instantReferralBonus).toFixed(2);
          io.to(`user_${referrer.id}`).emit('referral_bonus_unlocked', {
            amount: systemConfig.instantReferralBonus,
            fromUser: user.name,
            newPromoWallet: referrer.promoWallet
          });
        }
      }

      io.to(`user_${user.id}`).emit('balance_updated', {
        mainBalance: user.mainBalance,
        withdrawableBalance: user.withdrawableBalance,
        promoWallet: user.promoWallet,
        requiredWager: user.requiredWager ?? 0,
        vipLevel: user.vipLevel,
        lifetimeDeposit: user.lifetimeDeposit,
        message: `₹${deposit.amount} successfully credited! ${bonusCredit > 0 ? `Plus ₹${bonusCredit} bonus added to Promo Wallet!` : ''}`
      });
      broadcastLiveWalletSync(user, 'deposit_approved');
    }

    // Trigger UPI accounts deposit approval and auto-switch
    adminApproveDeposit(SUPER_ADMIN_ID, 'super_admin', deposit.amount);
    io.emit('deposit_status_changed', deposit);
    scheduleSavePlatformData('deposit_approved');
    return deposit;
  } else {
    deposit.status = 'REJECTED';
    deposit.rejectionReason = rejectionReason || 'Invalid UTR or payment proof mismatch.';
    deposit.reviewedAt = Date.now();
    io.emit('deposit_status_changed', deposit);
    scheduleSavePlatformData('deposit_rejected');
    return deposit;
  }
}

// =========================================================================
// TELEGRAM WEBHOOK & CALLBACK QUERY HANDLER (APPROVE / REJECT BUTTONS)
// Supports both Webhook POST (/bot<botToken>) and Automatic Polling
// =========================================================================
const TELEGRAM_BOT_TOKEN_DEFAULT = '8828254838:AAEDJDElJPa8ETmhHINPD7PezMrZ9IWgDDU';

async function processTelegramCallbackQuery(callback_query: any) {
  if (!callback_query) return;

  const botToken = systemConfig.telegramBotToken || TELEGRAM_BOT_TOKEN_DEFAULT;
  const queryId = callback_query.id;
  const message = callback_query.message;
  const data: string = callback_query.data || ''; // "approve_txid" ya "reject_txid"
  if (!message) return;

  const chatId = message.chat?.id;
  const messageId = message.message_id;
  const oldCaption: string = message.caption || message.text || '';

  let newCaption = oldCaption;
  let alertText = '';

  // Button click ko process karna
  if (data.startsWith('approve_')) {
    const txId = data.replace('approve_', '').trim();
    if (oldCaption.includes('Status: Pending ⏳')) {
      newCaption = oldCaption.replace('Status: Pending ⏳', 'Status: Approved 🟢 (Verified)');
    } else {
      newCaption = `${oldCaption}\n\n📊 Status: Approved 🟢 (Verified)`;
    }
    alertText = 'Payment Approved Sucessfully!';

    // Also approve matching deposit in platform ledger & credit player wallet
    const matchingDeposit = deposits.find(
      d => d.status === 'PENDING' && (d.utrNumber.trim().toLowerCase() === txId.toLowerCase() || d.id === txId)
    );
    if (matchingDeposit) {
      executeDepositReviewAction(matchingDeposit, 'APPROVE');
      console.log(`[TELEGRAM CALLBACK] Approved deposit ${matchingDeposit.id} (UTR: ${txId}) for user ${matchingDeposit.userName}`);
    }
  } else if (data.startsWith('reject_')) {
    const txId = data.replace('reject_', '').trim();
    if (oldCaption.includes('Status: Pending ⏳')) {
      newCaption = oldCaption.replace('Status: Pending ⏳', 'Status: Rejected 🔴 (Failed)');
    } else {
      newCaption = `${oldCaption}\n\n📊 Status: Rejected 🔴 (Failed)`;
    }
    alertText = 'Payment Rejected!';

    // Also reject matching deposit in platform ledger
    const matchingDeposit = deposits.find(
      d => d.status === 'PENDING' && (d.utrNumber.trim().toLowerCase() === txId.toLowerCase() || d.id === txId)
    );
    if (matchingDeposit) {
      executeDepositReviewAction(matchingDeposit, 'REJECT', 'Rejected by Admin via Telegram Bot');
      console.log(`[TELEGRAM CALLBACK] Rejected deposit ${matchingDeposit.id} (UTR: ${txId}) for user ${matchingDeposit.userName}`);
    }
  } else {
    return;
  }

  try {
    // 1. Telegram par user ko pop-up notification dikhana
    await fetch(`https://api.telegram.org/bot${botToken}/answerCallbackQuery`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        callback_query_id: queryId,
        text: alertText
      })
    });

    // 2. Telegram message ka caption badalna aur buttons ko hatana
    if (message.caption !== undefined) {
      await fetch(`https://api.telegram.org/bot${botToken}/editMessageCaption`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          message_id: messageId,
          caption: newCaption,
          reply_markup: JSON.stringify({ inline_keyboard: [] }) // Buttons hatane ke liye
        })
      });
    } else {
      await fetch(`https://api.telegram.org/bot${botToken}/editMessageText`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          message_id: messageId,
          text: newCaption,
          reply_markup: JSON.stringify({ inline_keyboard: [] })
        })
      });
    }
  } catch (error: any) {
    console.error('Error updating telegram:', error.message);
  }
}

// Telegram Webhook / Callback Query Handler Route
app.post([`/bot${TELEGRAM_BOT_TOKEN_DEFAULT}`, '/bot:botToken', '/api/telegram/webhook'], async (req, res) => {
  const { callback_query } = req.body || {};
  if (callback_query) {
    await processTelegramCallbackQuery(callback_query);
  }
  return res.sendStatus(200);
});

// Background Telegram Callback Query Poller (Ensures Approve/Reject buttons work immediately without needing external webhook setup)
let lastTelegramUpdateOffset = 0;
let telegramPollingActive = false;

async function pollTelegramCallbackQueries() {
  if (telegramPollingActive) return;
  telegramPollingActive = true;
  try {
    const botToken = systemConfig.telegramBotToken || TELEGRAM_BOT_TOKEN_DEFAULT;
    const res = await fetch(
      `https://api.telegram.org/bot${botToken}/getUpdates?offset=${lastTelegramUpdateOffset}&timeout=1&allowed_updates=${encodeURIComponent(JSON.stringify(['callback_query']))}`
    );
    if (res.ok) {
      const data: any = await res.json();
      if (data && data.ok && Array.isArray(data.result)) {
        for (const update of data.result) {
          if (typeof update.update_id === 'number' && update.update_id >= lastTelegramUpdateOffset) {
            lastTelegramUpdateOffset = update.update_id + 1;
          }
          if (update.callback_query) {
            await processTelegramCallbackQuery(update.callback_query);
          }
        }
      }
    }
  } catch {
    // Silent retry on next interval
  } finally {
    telegramPollingActive = false;
  }
}

setInterval(pollTelegramCallbackQueries, 2500);

// 9. ADMIN APPROVE / REJECT DEPOSIT (Allowed for Super Admin & Selected/Approved Admins)
app.post('/api/admin/deposit/action', verifySuperAdmin, (req, res) => {
  const adminRole = (req as any).adminRole;
  const subAdmin = (req as any).subAdmin as SubAdminAccount | undefined;
  if (adminRole === 'SUB_ADMIN' && subAdmin && !subAdmin.permissions.canConfirmOrderIds && !subAdmin.permissions.canManageDeposits) {
    return res.status(403).json({ error: 'Access Denied: This Sub-Admin has not been approved by Super Admin for Deposit Order confirmation.' });
  }

  const { depositId, action, rejectionReason } = req.body;

  const deposit = deposits.find(d => d.id === depositId);
  if (!deposit) return res.status(404).json({ error: 'Deposit request not found.' });

  if (deposit.status !== 'PENDING') {
    return res.status(400).json({ error: 'Deposit has already been reviewed.' });
  }

  const updated = executeDepositReviewAction(
    deposit,
    action === 'APPROVE' ? 'APPROVE' : 'REJECT',
    rejectionReason
  );
  return res.json({ success: true, deposit: updated });
});

// ==========================================
// UPI ACCOUNTS & ROLE CONTROL REST ENDPOINTS
// ==========================================
// Public/User endpoint: Get active UPI ID for deposit
app.get('/api/upi/active', (req, res) => {
  const result = getActiveUPIForUsers();
  return res.json(result);
});

// Admin endpoint: List all UPI accounts
app.get('/api/admin/upi/accounts', (req, res) => {
  return res.json({ success: true, accounts: upiAccounts });
});

// Super Admin endpoint: Update max limit dynamically
// MULTI-ADMIN PRIVILEGE ACCESS ISOLATION:
// Intercept all runtime adjustment payloads directed at modifying global limit variables or account arrays.
// If the user context role is not explicitly 'super_admin', terminate execution immediately.
app.post('/api/admin/upi/update-limit', (req, res) => {
  const { userId, role, accountId, newLimit } = req.body;
  const { isSuperAdmin } = getAdminRequesterRole(req);
  const effectiveRole = isSuperAdmin ? 'super_admin' : role;

  if (effectiveRole !== 'super_admin' && effectiveRole !== 'superadmin') {
    return res.status(403).json({
      success: false,
      code: 'ACCESS_DENIED',
      message: 'Access Denied: Only Super Admin can change limits! Standard admin roles are strictly restricted to structural transactional validations and view privileges, with zero permission to alter data limits.'
    });
  }

  const result = superAdminUpdateLimit(userId || 'admin', effectiveRole, Number(accountId), Number(newLimit));
  if (!result.success) {
    return res.status(403).json(result);
  }
  return res.json(result);
});

// Admin/Super Admin endpoint: Approve manual deposit & trigger auto-switch
app.post('/api/admin/upi/approve-deposit', (req, res) => {
  const { userId, role, amountReceived } = req.body;
  const result = adminApproveDeposit(userId || 'admin', role || (req as any).adminRole || 'admin', Number(amountReceived));
  if (!result.success) {
    return res.status(400).json(result);
  }
  return res.json(result);
});

// Admin endpoint: Midnight reset trigger
app.post('/api/admin/upi/midnight-reset', (req, res) => {
  const result = midnightBalanceReset();
  return res.json(result);
});

// 10. ADMIN APPROVE / REJECT WITHDRAWAL
app.post('/api/admin/withdrawal/action', verifySuperAdmin, (req, res) => {
  const { withdrawalId, action, adminUtr, rejectionReason } = req.body;

  const withdrawal = withdrawals.find(w => w.id === withdrawalId);
  if (!withdrawal) return res.status(404).json({ error: 'Withdrawal not found.' });

  if (withdrawal.status !== 'PENDING') {
    return res.status(400).json({ error: 'Withdrawal already reviewed.' });
  }

  if (action === 'APPROVE') {
    withdrawal.status = 'APPROVED';
    withdrawal.adminUtr = adminUtr || `TXN${Date.now()}`;
    withdrawal.reviewedAt = Date.now();

    io.to(`user_${withdrawal.userId}`).emit('withdrawal_processed', {
      amount: withdrawal.amount,
      status: 'APPROVED',
      utr: withdrawal.adminUtr
    });

    return res.json({ success: true, withdrawal });
  } else {
    withdrawal.status = 'REJECTED';
    withdrawal.rejectionReason = rejectionReason || 'Turnover incomplete or bank details rejected.';
    withdrawal.reviewedAt = Date.now();

    // Refund full deducted amount (requestedAmount + tax) back to user withdrawable balance
    const refundTotal = withdrawal.walletDeducted ?? withdrawal.amount;
    const user = users.get(withdrawal.userId);
    if (user) {
      user.withdrawableBalance = +(user.withdrawableBalance + refundTotal).toFixed(2);
      user.mainBalance = +(user.mainBalance + refundTotal).toFixed(2);

      io.to(`user_${user.id}`).emit('balance_updated', {
        mainBalance: user.mainBalance,
        withdrawableBalance: user.withdrawableBalance,
        message: `Withdrawal of ₹${withdrawal.amount} was rejected and ₹${refundTotal} refunded to your balance.`
      });
    }

    return res.json({ success: true, withdrawal });
  }
});

// 11. ADMIN USER LEDGER (Super Admin strictly hidden!)
app.get('/api/admin/users', verifySuperAdmin, (req, res) => {
  const search = (req.query.search as string || '').toLowerCase().trim();
  const normSearchUid = normalizeUidInput(search);

  const userList = Array.from(users.values())
    // SECURITY GUARDRAIL: Super Admin & Sub-Admins are completely invisible!
    .filter(u => u.id !== SUPER_ADMIN_ID && u.email !== SUPER_ADMIN_EMAIL && u.role !== 'subadmin' && u.role !== 'superadmin')
    .filter(u => {
      u.uid = format7DigitUid(u.uid, u.id);
      if (!search) return true;
      return (
        u.name.toLowerCase().includes(search) ||
        u.phone.includes(search) ||
        u.email.toLowerCase().includes(search) ||
        u.uid.toLowerCase().includes(search) ||
        (normSearchUid.length > 0 && u.uid.includes(normSearchUid)) ||
        u.referralCode.toLowerCase().includes(search)
      );
    })
    .map(sanitizeUser);

  res.json({ users: userList });
});

// LOOKUP PLAYER BY 7-DIGIT UID (OR ID / PHONE)
app.get('/api/admin/user/lookup-uid/:uid', verifySuperAdmin, (req, res) => {
  const rawUid = req.params.uid || '';
  const found = findUserByIdOrUid(rawUid);
  if (!found || found.id === SUPER_ADMIN_ID) {
    return res.json({ found: false, uid: normalizeUidInput(rawUid) });
  }
  found.uid = format7DigitUid(found.uid, found.id);
  return res.json({ found: true, user: sanitizeUser(found) });
});

// 12. ADMIN ADJUST USER BALANCE / FREEZE ACCOUNT (Supports 7-digit UID or userId anytime!)
app.post('/api/admin/user/action', verifySuperAdmin, (req, res) => {
  const { userId, uid, action, amount, note } = req.body;
  const targetIdentifier = uid || userId;

  if (!targetIdentifier) {
    return res.status(400).json({ error: 'User ID or 7-digit UID is required.' });
  }

  let user = findUserByIdOrUid(targetIdentifier);
  const normUid = normalizeUidInput(targetIdentifier);

  // If Super Admin enters a 7-digit UID that does not exist yet in memory, auto-create the player account with that exact 7-digit UID
  if (!user && normUid.length === 7) {
    const newId = `usr_uid_${normUid}`;
    user = {
      id: newId,
      uid: normUid,
      name: `Pilot #${normUid}`,
      email: `pilot${normUid}@winnova.user`,
      phone: normUid,
      role: 'user',
      mainBalance: 0,
      promoWallet: 0,
      bonusBalance: 0,
      withdrawableBalance: 0,
      turnoverRequired: 0,
      turnoverCompleted: 0,
      referralCode: generateReferralCode(),
      referralRewardStatus: 'none',
      isFrozen: false,
      deviceFingerprint: `fp_${normUid}`,
      registeredIp: '127.0.0.1',
      lastLoginIp: '127.0.0.1',
      createdAt: Date.now()
    };
    usedUids.add(normUid);
    users.set(user.id, user);
  }

  if (!user) return res.status(404).json({ error: `Player with UID/ID "${targetIdentifier}" not found.` });

  if (user.id === SUPER_ADMIN_ID || user.role === 'superadmin') {
    user.mainBalance = 999999999;
    user.withdrawableBalance = 999999999;
    return res.json({ success: true, user: sanitizeUser(user), message: 'Super Admin has unlimited balance.' });
  }

  user.uid = format7DigitUid(user.uid, user.id);
  const numAmt = Math.max(0, Number(amount) || 0);
  const beforeBalance = user.mainBalance;

  if (action === 'ADD_BALANCE' || action === 'CREDIT') {
    user.mainBalance = +(user.mainBalance + numAmt).toFixed(2);
    user.withdrawableBalance = +(user.withdrawableBalance + numAmt).toFixed(2);
    io.to(`user_${user.id}`).emit('balance_updated', {
      mainBalance: user.mainBalance,
      withdrawableBalance: user.withdrawableBalance,
      promoWallet: user.promoWallet,
      bonusBalance: user.bonusBalance,
      message: `Super Admin credited ₹${numAmt.toFixed(2)} to your wallet (UID: ${user.uid})! (${note || 'UID Instant Transfer'})`
    });
  } else if (action === 'DEDUCT_BALANCE' || action === 'DEBIT') {
    user.mainBalance = Math.max(0, +(user.mainBalance - numAmt).toFixed(2));
    user.withdrawableBalance = Math.max(0, +(user.withdrawableBalance - numAmt).toFixed(2));
    io.to(`user_${user.id}`).emit('balance_updated', {
      mainBalance: user.mainBalance,
      withdrawableBalance: user.withdrawableBalance,
      promoWallet: user.promoWallet,
      bonusBalance: user.bonusBalance,
      message: `Admin debit: ₹${numAmt.toFixed(2)} deducted (${note || 'Manual adjustment'})`
    });
  } else if (action === 'SET_BALANCE' || action === 'OVERWRITE') {
    user.mainBalance = +numAmt.toFixed(2);
    user.withdrawableBalance = +numAmt.toFixed(2);
    io.to(`user_${user.id}`).emit('balance_updated', {
      mainBalance: user.mainBalance,
      withdrawableBalance: user.withdrawableBalance,
      promoWallet: user.promoWallet,
      bonusBalance: user.bonusBalance,
      message: `Wallet balance set to ₹${numAmt.toFixed(2)} by Super Admin`
    });
  } else if (action === 'ZERO_BALANCE' || action === 'ZERO_OUT') {
    user.mainBalance = 0;
    user.withdrawableBalance = 0;
    user.bonusBalance = 0;
    user.promoWallet = 0;
    io.to(`user_${user.id}`).emit('balance_updated', {
      mainBalance: 0,
      withdrawableBalance: 0,
      promoWallet: 0,
      bonusBalance: 0,
      message: `Wallet balance reset to ₹0.00 by Super Admin`
    });
  } else if (action === 'TOGGLE_FREEZE') {
    user.isFrozen = !user.isFrozen;
  }

  // Keep userWallets in sync
  const w = getOrCreateWallet(user.id);
  w.deposited_balance = user.mainBalance;
  w.bonus_balance = user.bonusBalance;
  w.gift_balance = user.promoWallet;
  w.total_balance = +(user.mainBalance + user.bonusBalance + user.promoWallet).toFixed(2);
  w.updatedAt = new Date().toISOString();

  // Non-blocking Firestore sync for both /users/{id} and /wallets/{id}
  try {
    adminDb.collection('users').doc(user.id).set({
      uid: user.uid,
      balance: user.mainBalance,
      mainBalance: user.mainBalance,
      withdrawableBalance: user.withdrawableBalance,
      bonusBalance: user.bonusBalance,
      promoWallet: user.promoWallet,
      isFrozen: user.isFrozen,
      updatedAt: AdminFieldValue.serverTimestamp()
    }, { merge: true }).catch(() => {});
    adminDb.collection('wallets').doc(user.id).set({
      userId: user.id,
      uid: user.uid,
      deposited_balance: user.mainBalance,
      bonus_balance: user.bonusBalance,
      gift_balance: user.promoWallet,
      total_balance: +(user.mainBalance + user.bonusBalance + user.promoWallet).toFixed(2),
      updatedAt: AdminFieldValue.serverTimestamp()
    }, { merge: true }).catch(() => {});
  } catch {}

  res.json({
    success: true,
    beforeBalance,
    afterBalance: user.mainBalance,
    user: sanitizeUser(user),
    message: `Updated UID ${user.uid} (${user.name}): ₹${beforeBalance.toFixed(2)} -> ₹${user.mainBalance.toFixed(2)}`
  });
});

// 13. ADMIN QUEUES LISTS
app.get('/api/admin/queues', verifySuperAdmin, (req, res) => {
  res.json({
    deposits: deposits.slice(0, 50),
    withdrawals: withdrawals.slice(0, 50),
    fraudAlerts: fraudAlerts.slice(0, 50)
  });
});

// 14. ADMIN UPDATE SYSTEM CONFIG
app.post('/api/admin/config', verifySuperAdmin, (req, res) => {
  const updates = req.body || {};
  systemConfig = { ...systemConfig, ...updates };

  // If admin or super admin updated primary UPI ID / Display Name / QR URL in system config, sync active deposit node too
  if (updates.adminUpiId || updates.adminUpiName || updates.adminQrUrl !== undefined) {
    const activeNode = getActiveDepositNode();
    if (activeNode) {
      if (updates.adminUpiId) activeNode.upiId = String(updates.adminUpiId).trim();
      if (updates.adminUpiName) activeNode.displayName = String(updates.adminUpiName).trim();
      if (updates.adminQrUrl !== undefined) activeNode.qrImageUrl = String(updates.adminQrUrl).trim();
    }
    syncActiveUpiToFirestoreAndClients();
  }

  io.emit('system:config_updated', systemConfig);
  scheduleSavePlatformData('admin_config_updated');
  res.json({ success: true, config: systemConfig, activeNode: getActiveDepositNode() });
});

// ADMIN: UPLOAD POSTER GIRL IMAGE
app.post('/api/admin/upload-poster-girl', verifySuperAdmin, (req, res) => {
  const { imageBase64 } = req.body;
  if (!imageBase64) {
    return res.status(400).json({ error: 'imageBase64 is required' });
  }
  try {
    const matches = imageBase64.match(/^data:image\/([A-Za-z-+\/]+);base64,(.+)$/);
    const buffer = matches ? Buffer.from(matches[2], 'base64') : Buffer.from(imageBase64, 'base64');
    const targetPath = path.join(process.cwd(), 'public', 'poster_girl.png');
    fs.writeFileSync(targetPath, buffer);
    systemConfig.posterGirlImageUrl = `/poster_girl.png?t=${Date.now()}`;
    io.emit('system:config_updated', systemConfig);
    res.json({ success: true, posterGirlImageUrl: systemConfig.posterGirlImageUrl });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save poster girl image', details: err.message });
  }
});

// PUBLIC: GET SYSTEM CONFIG
app.get('/api/public/system-config', (req, res) => {
  res.json({
    minDeposit: systemConfig.minDeposit,
    minWithdrawal: systemConfig.minWithdrawal,
    instantReferralBonus: systemConfig.instantReferralBonus,
    rebatePercent: systemConfig.rebatePercent,
    posterGirlImageUrl: systemConfig.posterGirlImageUrl || '/poster_girl.png',
    maintenanceModeActive: systemConfig.maintenanceModeActive
  });
});

// 15. PUBLIC: GET CURRENT DEPOSIT INFO (ACTIVE NODE)
app.get('/api/public/deposit-info', (req, res) => {
  const activeNode = getActiveDepositNode();
  res.json({
    activeNode,
    minDeposit: systemConfig.minDeposit
  });
});

// 16. PUBLIC: GET HIGH ROLLERS LEADERBOARD
app.get('/api/public/high-rollers', (req, res) => {
  res.json({ highRollers });
});

// 17. PUBLIC: GET CHAT HISTORY
app.get('/api/public/chat-history', (req, res) => {
  res.json({ messages: chatMessages.slice(-35) });
});

// 18. ADMIN: GET / UPDATE FAKE CHAT CONFIG
app.get('/api/admin/chat-config', verifySuperAdmin, (req, res) => {
  res.json({ config: fakeChatConfig });
});

app.post('/api/admin/chat-config', verifySuperAdmin, (req, res) => {
  const { enabled, minIntervalSec, maxIntervalSec, userHandles, messageTemplates } = req.body;
  if (enabled !== undefined) fakeChatConfig.enabled = Boolean(enabled);
  if (minIntervalSec !== undefined) fakeChatConfig.minIntervalSec = Math.max(1, +minIntervalSec);
  if (maxIntervalSec !== undefined) fakeChatConfig.maxIntervalSec = Math.max(2, +maxIntervalSec);
  if (Array.isArray(userHandles)) fakeChatConfig.userHandles = userHandles.filter(Boolean);
  if (Array.isArray(messageTemplates)) fakeChatConfig.messageTemplates = messageTemplates.filter(Boolean);

  res.json({ success: true, config: fakeChatConfig });
});

app.get('/api/admin/fake-chat/settings', verifySuperAdmin, (req, res) => {
  res.json({
    settings: {
      isEnabled: fakeChatConfig.enabled,
      minDelaySeconds: fakeChatConfig.minIntervalSec,
      maxDelaySeconds: fakeChatConfig.maxIntervalSec,
      presetMessages: fakeChatConfig.messageTemplates
    }
  });
});

app.post('/api/admin/fake-chat/settings', verifySuperAdmin, (req, res) => {
  const { isEnabled, minDelaySeconds, maxDelaySeconds, presetMessages } = req.body;
  if (isEnabled !== undefined) fakeChatConfig.enabled = Boolean(isEnabled);
  if (minDelaySeconds !== undefined) fakeChatConfig.minIntervalSec = Math.max(1, +minDelaySeconds);
  if (maxDelaySeconds !== undefined) fakeChatConfig.maxIntervalSec = Math.max(2, +maxDelaySeconds);
  if (Array.isArray(presetMessages)) fakeChatConfig.messageTemplates = presetMessages.filter(Boolean);

  res.json({
    success: true,
    settings: {
      isEnabled: fakeChatConfig.enabled,
      minDelaySeconds: fakeChatConfig.minIntervalSec,
      maxDelaySeconds: fakeChatConfig.maxIntervalSec,
      presetMessages: fakeChatConfig.messageTemplates
    }
  });
});

app.post(['/api/admin/chat-test', '/api/admin/fake-chat/test'], verifySuperAdmin, (req, res) => {
  const { username, message } = req.body || {};
  const handle = username || fakeChatConfig.userHandles[Math.floor(Math.random() * fakeChatConfig.userHandles.length)] || 'Player';
  const text = message || fakeChatConfig.messageTemplates[Math.floor(Math.random() * fakeChatConfig.messageTemplates.length)] || 'Good game!';
  const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

  const testMsg: ChatMessage = {
    id: `chat_test_${Date.now()}`,
    username: handle,
    message: text,
    timestamp: Date.now(),
    isFake: true,
    avatarColor: color
  };

  chatMessages.push(testMsg);
  if (chatMessages.length > 60) chatMessages.shift();
  io.emit('chat_message', testMsg);

  res.json({ success: true, message: testMsg });
});

// CHEAT PROBABILITY MATRIX & DESTINATION ASSURANCE AUDIT ENDPOINTS
app.get('/api/admin/cheat-percentages', (req, res) => {
  const effective = getEffectiveCheatAndCrashConfig();
  res.json({
    cheatPercentage: effective.cheatPct,
    crashPercentage: effective.crashPct,
    matrixStats: highGoingCheatMatrix.getStats(),
    timeControl: cheatCrashTimeControl
  });
});

app.get('/api/admin/cheat-time-control', (req, res) => {
  getEffectiveCheatAndCrashConfig();
  res.json({
    success: true,
    timeControl: cheatCrashTimeControl,
    cheatPercentage: highGoingCheatMatrix.getCheatPercentage(),
    crashPercentage: systemConfig.crashPercentage ?? 47
  });
});

app.post('/api/admin/cheat-time-control', verifySuperAdmin, (req, res) => {
  const updates = req.body || {};
  const requesterRole = (req as any).adminRole === 'SUPER_ADMIN' ? 'Super Admin' : 'Approved Admin';

  // Master Cheat ON / OFF switch + optional timing
  if (updates.cheatSystemEnabled !== undefined) {
    cheatCrashTimeControl.cheatSystemEnabled = Boolean(updates.cheatSystemEnabled);
    cheatCrashTimeControl.lastToggledBy = updates.toggledBy || requesterRole;
  }
  if (updates.cheatToggleDurationMinutes !== undefined) {
    cheatCrashTimeControl.cheatToggleDurationMinutes = Math.max(1, Math.min(1440, Number(updates.cheatToggleDurationMinutes) || 30));
  }
  if (updates.startCheatToggleTimer === true) {
    const now = Date.now();
    const mins = cheatCrashTimeControl.cheatToggleDurationMinutes || 30;
    cheatCrashTimeControl.cheatToggleTimerActive = true;
    cheatCrashTimeControl.cheatToggleTimerStartedAt = now;
    cheatCrashTimeControl.cheatToggleTimerExpiresAt = now + mins * 60 * 1000;
    cheatCrashTimeControl.cheatToggleTargetState = cheatCrashTimeControl.cheatSystemEnabled;
  } else if (updates.stopCheatToggleTimer === true) {
    cheatCrashTimeControl.cheatToggleTimerActive = false;
    cheatCrashTimeControl.cheatToggleTimerExpiresAt = 0;
  }

  if (updates.mode && ['MANUAL', 'TIMED_DURATION', 'SCHEDULED_WINDOW', 'AUTO_DYNAMIC'].includes(updates.mode)) {
    cheatCrashTimeControl.mode = updates.mode as CheatTimeControlMode;
  }

  if (updates.durationMinutes !== undefined) {
    cheatCrashTimeControl.durationMinutes = Math.max(1, Math.min(1440, Number(updates.durationMinutes) || 30));
  }
  if (updates.timedCheatPercentage !== undefined) {
    cheatCrashTimeControl.timedCheatPercentage = Math.min(100, Math.max(0, Math.round(Number(updates.timedCheatPercentage))));
  }
  if (updates.timedCrashPercentage !== undefined) {
    cheatCrashTimeControl.timedCrashPercentage = Math.min(100, Math.max(0, Math.round(Number(updates.timedCrashPercentage))));
  }

  if (updates.startTimer === true || (updates.mode === 'TIMED_DURATION' && updates.timerActive === true)) {
    const now = Date.now();
    cheatCrashTimeControl.mode = 'TIMED_DURATION';
    cheatCrashTimeControl.timerActive = true;
    cheatCrashTimeControl.timerStartedAt = now;
    cheatCrashTimeControl.timerExpiresAt = now + cheatCrashTimeControl.durationMinutes * 60 * 1000;
  } else if (updates.stopTimer === true || updates.timerActive === false) {
    cheatCrashTimeControl.timerActive = false;
    cheatCrashTimeControl.timerExpiresAt = 0;
  }

  if (updates.scheduleEnabled !== undefined) {
    cheatCrashTimeControl.scheduleEnabled = Boolean(updates.scheduleEnabled);
  }
  if (updates.scheduleStartTime !== undefined) {
    cheatCrashTimeControl.scheduleStartTime = String(updates.scheduleStartTime);
  }
  if (updates.scheduleEndTime !== undefined) {
    cheatCrashTimeControl.scheduleEndTime = String(updates.scheduleEndTime);
  }
  if (updates.scheduledCheatPercentage !== undefined) {
    cheatCrashTimeControl.scheduledCheatPercentage = Math.min(100, Math.max(0, Math.round(Number(updates.scheduledCheatPercentage))));
  }
  if (updates.scheduledCrashPercentage !== undefined) {
    cheatCrashTimeControl.scheduledCrashPercentage = Math.min(100, Math.max(0, Math.round(Number(updates.scheduledCrashPercentage))));
  }

  if (updates.crashAtFlightSecondsEnabled !== undefined) {
    cheatCrashTimeControl.crashAtFlightSecondsEnabled = Boolean(updates.crashAtFlightSecondsEnabled);
  }
  if (updates.crashAtFlightSeconds !== undefined) {
    cheatCrashTimeControl.crashAtFlightSeconds = Math.max(0.5, Math.min(120, Number(updates.crashAtFlightSeconds) || 5));
  }
  if (updates.scheduledExactCrashTime !== undefined) {
    cheatCrashTimeControl.scheduledExactCrashTime = String(updates.scheduledExactCrashTime || '');
  }

  if (updates.devLossProtectionEnabled !== undefined) {
    cheatCrashTimeControl.devLossProtectionEnabled = Boolean(updates.devLossProtectionEnabled);
  }
  if (updates.devLossTriggerThreshold !== undefined) {
    cheatCrashTimeControl.devLossTriggerThreshold = Number(updates.devLossTriggerThreshold) || 0;
  }
  if (updates.devLossCheatPercentage !== undefined) {
    cheatCrashTimeControl.devLossCheatPercentage = Math.min(100, Math.max(0, Math.round(Number(updates.devLossCheatPercentage))));
  }
  if (updates.devLossCrashPercentage !== undefined) {
    cheatCrashTimeControl.devLossCrashPercentage = Math.min(100, Math.max(0, Math.round(Number(updates.devLossCrashPercentage))));
  }
  if (updates.devLossMaxCrashMultiplier !== undefined) {
    cheatCrashTimeControl.devLossMaxCrashMultiplier = Math.max(1.01, Math.min(100, Number(updates.devLossMaxCrashMultiplier) || 1.35));
  }

  // Allow simulating or resetting developer loss stats if requested by Super Admin
  if (updates.simulateDevLoss === true) {
    totalRealPayoutsGiven = totalRealStakesCollected + 2500;
  } else if (updates.resetDevLossStats === true) {
    totalRealStakesCollected = 0;
    totalRealPayoutsGiven = 0;
  }

  const effective = getEffectiveCheatAndCrashConfig();
  systemConfig.cheatPercentage = effective.cheatPct;
  systemConfig.crashPercentage = effective.crashPct;
  highGoingCheatMatrix.setCheatPercentage(effective.cheatPct);

  io.emit('admin:cheat_time_control_updated', cheatCrashTimeControl);
  io.emit('admin:cheat_percentages_updated', {
    cheatPercentage: effective.cheatPct,
    crashPercentage: effective.crashPct,
    timeControl: cheatCrashTimeControl,
    timestamp: Date.now()
  });

  res.json({
    success: true,
    timeControl: cheatCrashTimeControl,
    effective
  });
});

app.post('/api/admin/cheat-percentages', (req, res) => {
  const { adminKey, cheatPercentage, crashPercentage } = req.body;
  const isSuper = adminKey === SUPER_ADMIN_PASSWORD || adminKey === 'sa_secret_token_786';
  const isSub = Array.from(subAdmins.values()).some(s => s.token === adminKey && s.isActive && s.permissions.canViewGameEngine);
  const isValidAdmin = isSuper || isSub || adminKey === 'admin123';

  if (!isValidAdmin) {
    res.status(403).json({ error: 'Unauthorized: Access restricted to Super Admin and Admin roles.' });
    return;
  }

  if (typeof cheatPercentage === 'number') {
    const clampedCheat = Math.min(100, Math.max(0, Math.round(cheatPercentage)));
    systemConfig.cheatPercentage = clampedCheat;
    highGoingCheatMatrix.setCheatPercentage(clampedCheat);
  }

  if (typeof crashPercentage === 'number') {
    const clampedCrash = Math.min(100, Math.max(0, Math.round(crashPercentage)));
    systemConfig.crashPercentage = clampedCrash;
  }

  const result = {
    cheatPercentage: highGoingCheatMatrix.getCheatPercentage(),
    crashPercentage: systemConfig.crashPercentage ?? 47,
    updatedBy: isSuper ? 'Super Admin' : 'Admin',
    timestamp: Date.now()
  };

  io.emit('admin:cheat_percentages_updated', result);
  res.json({ success: true, ...result });
});

app.get('/api/admin/cheat-matrix-stats', (req, res) => {
  res.json({
    matrix: highGoingCheatMatrix.getStats(),
    destinationAssurance: adminDestinationAssurance
  });
});

app.post('/api/admin/round-crash', (req, res) => {
  const { adminKey, destinationMultiplier, immediate } = req.body || {};
  const headerKey = (req.headers['x-admin-key'] as string) || adminKey || 'Faisal786';
  const isSuper =
    headerKey === SUPER_ADMIN_PASSWORD ||
    headerKey === 'sa_secret_token_786' ||
    headerKey === 'Faisal786' ||
    headerKey === SUPER_ADMIN_EMAIL ||
    headerKey === 'mdfaisalraza7777@gmail.com' ||
    headerKey === SUPER_ADMIN_ID;
  const isSub =
    headerKey === 'admin123' ||
    Array.from(subAdmins.values()).some(s => s.token === headerKey && s.isActive && s.permissions.canViewGameEngine);
  if (!isSuper && !isSub) {
    res.status(403).json({ error: 'Unauthorized. Round crash capability is strictly restricted to Super Admin and Admin roles.' });
    return;
  }

  if (gameStatus === 'FLYING') {
    if (immediate === false && destinationMultiplier && destinationMultiplier > currentMultiplier) {
      const targetDestination = +Number(destinationMultiplier).toFixed(2);
      plannedCrashMultiplier = targetDestination;
      plannedFlightDurationSeconds = getNaturalDurationForMultiplier(targetDestination);
      adminDestinationAssurance.active = true;
      adminDestinationAssurance.targetDestination = targetDestination;
      adminDestinationAssurance.scheduledBy = isSuper ? 'Super Admin' : 'Admin';
      adminDestinationAssurance.timestamp = Date.now();

      return res.json({
        success: true,
        message: `Round Crash scheduled at ${targetDestination.toFixed(2)}x`,
        destinationAssurance: adminDestinationAssurance
      });
    }

    const crashAt = Math.max(1.00, +currentMultiplier.toFixed(2));
    adminDestinationAssurance.active = false;
    triggerCrash(crashAt);
    io.emit('admin_action_broadcast', {
      message: `[ADMIN CRASH NOW] Flight crashed immediately at ${crashAt.toFixed(2)}x by ${isSuper ? 'Super Admin' : 'Admin'}.`
    });
    return res.json({
      success: true,
      crashedAt: crashAt,
      message: `Round crashed immediately at ${crashAt.toFixed(2)}x`
    });
  } else {
    systemConfig.nextRoundPresetCrash = 1.01;
    scheduleSavePlatformData('admin:round_crash_preset');
    return res.json({
      success: true,
      queuedNextCrash: 1.01,
      message: 'Flight is currently waiting — queued immediate 1.01x crash for takeoff!'
    });
  }
});

// 19. ADMIN: UPI DEPOSIT NODES MANAGEMENT (Supports both /deposit-nodes and /upi-nodes)
app.get(['/api/admin/deposit-nodes', '/api/admin/upi-nodes'], verifySuperAdmin, (req, res) => {
  res.json({
    nodes: depositNodes,
    activeNodeId: activeDepositNodeId,
    activeNode: getActiveDepositNode(),
    rotateAfterTransactions: systemConfig.rotateAfterTransactions || 15
  });
});

app.post('/api/admin/upi-nodes/upload-qr', verifySuperAdmin, (req, res) => {
  const { imageBase64, nodeId } = req.body || {};
  if (!imageBase64) {
    return res.status(400).json({ error: 'imageBase64 is required' });
  }
  try {
    const matches = String(imageBase64).match(/^data:image\/([A-Za-z-+\/]+);base64,(.+)$/);
    const ext = matches && matches[1] ? matches[1].replace('jpeg', 'jpg') : 'png';
    const buffer = matches ? Buffer.from(matches[2], 'base64') : Buffer.from(imageBase64, 'base64');
    const fileName = `upi_qr_${nodeId || Date.now()}.${ext}`;
    const publicDir = path.join(process.cwd(), 'public');
    if (!fs.existsSync(publicDir)) fs.mkdirSync(publicDir, { recursive: true });
    fs.writeFileSync(path.join(publicDir, fileName), buffer);
    const qrUrl = `/${fileName}?t=${Date.now()}`;

    if (nodeId) {
      const target = depositNodes.find(n => n.id === nodeId);
      if (target) {
        target.qrImageUrl = qrUrl;
      }
    }
    syncActiveUpiToFirestoreAndClients();
    scheduleSavePlatformData('upi_qr_uploaded');
    res.json({ success: true, qrImageUrl: qrUrl, activeNode: getActiveDepositNode() });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save UPI QR image', details: err.message });
  }
});

app.post('/api/admin/upi-nodes', verifySuperAdmin, (req, res) => {
  const { nodes, rotateAfterTransactions, activateNodeId } = req.body || {};
  if (rotateAfterTransactions !== undefined) {
    systemConfig.rotateAfterTransactions = Math.max(1, Number(rotateAfterTransactions) || 10);
  }
  if (Array.isArray(nodes) && nodes.length > 0) {
    const prevIds = new Set(depositNodes.map(n => n.id));
    depositNodes.length = 0;
    nodes.forEach((n: DepositNode) => {
      depositNodes.push({
        ...n,
        upiId: String(n.upiId || '').trim(),
        displayName: String(n.displayName || 'WIN NOVA Merchant').trim(),
        qrImageUrl: n.qrImageUrl || '',
        currentTransactions: Number(n.currentTransactions || 0),
        maxTransactions: Number(n.maxTransactions || n.maxLimit || 15),
        maxLimit: Number(n.maxLimit || 100000),
        totalVolume: Number(n.totalVolume || 0)
      });
    });

    // Determine which node should be active:
    // 1. Explicitly requested activateNodeId
    // 2. A newly added node (whose ID wasn't in prevIds)
    // 3. A node marked isActive === true
    // 4. Existing activeDepositNodeId if still present, else first node
    const newlyAdded = depositNodes.find(n => !prevIds.has(n.id));
    const explicitlyActive = activateNodeId
      ? depositNodes.find(n => n.id === activateNodeId)
      : newlyAdded || depositNodes.find(n => n.isActive);

    if (explicitlyActive) {
      activeDepositNodeId = explicitlyActive.id;
    } else if (!depositNodes.some(n => n.id === activeDepositNodeId)) {
      activeDepositNodeId = depositNodes[0].id;
    }

    depositNodes.forEach(n => {
      n.isActive = n.id === activeDepositNodeId;
    });
    systemConfig.activeDepositNodeId = activeDepositNodeId;
    syncActiveUpiToFirestoreAndClients();
  }
  scheduleSavePlatformData('upi_nodes_updated');
  res.json({
    success: true,
    nodes: depositNodes,
    activeNodeId: activeDepositNodeId,
    activeNode: getActiveDepositNode(),
    rotateAfterTransactions: systemConfig.rotateAfterTransactions
  });
});

app.post('/api/admin/upi-nodes/set-active', verifySuperAdmin, (req, res) => {
  const { nodeId, id } = req.body || {};
  const targetId = nodeId || id;
  const node = depositNodes.find(n => n.id === targetId);
  if (!node) return res.status(404).json({ error: 'Node not found.' });
  depositNodes.forEach(n => { n.isActive = n.id === node.id; });
  activeDepositNodeId = node.id;
  systemConfig.activeDepositNodeId = node.id;
  syncActiveUpiToFirestoreAndClients();
  scheduleSavePlatformData('upi_node_set_active');
  res.json({ success: true, activeNode: node, activeNodeId: activeDepositNodeId, nodes: depositNodes });
});

app.post('/api/admin/upi-nodes/reset-counter', verifySuperAdmin, (req, res) => {
  const { nodeId, id } = req.body || {};
  const targetId = nodeId || id;
  const node = depositNodes.find(n => n.id === targetId);
  if (!node) return res.status(404).json({ error: 'Node not found.' });
  node.currentTransactions = 0;
  scheduleSavePlatformData('upi_node_reset_counter');
  res.json({ success: true, node });
});

app.post('/api/admin/deposit-node/add', verifySuperAdmin, (req, res) => {
  const { upiId, displayName, qrImageUrl, maxTransactions, setActiveNow } = req.body || {};
  if (!upiId || !displayName) {
    return res.status(400).json({ error: 'UPI ID and Display Name are required.' });
  }

  const newNode: DepositNode = {
    id: `node_${Date.now()}`,
    upiId: String(upiId).trim(),
    displayName: String(displayName).trim(),
    qrImageUrl: qrImageUrl || '',
    maxTransactions: maxTransactions ? +maxTransactions : 15,
    currentTransactions: 0,
    isActive: true,
    totalVolume: 0,
    createdAt: Date.now()
  };

  // Make newly added UPI node active immediately (unless explicitly false)
  if (setActiveNow !== false) {
    depositNodes.forEach(n => { n.isActive = false; });
    activeDepositNodeId = newNode.id;
    systemConfig.activeDepositNodeId = newNode.id;
  }

  depositNodes.push(newNode);
  syncActiveUpiToFirestoreAndClients();
  scheduleSavePlatformData('deposit_node_add');
  res.json({ success: true, node: newNode, activeNodeId: activeDepositNodeId, nodes: depositNodes });
});

app.post('/api/admin/deposit-node/edit', verifySuperAdmin, (req, res) => {
  const { id, upiId, displayName, qrImageUrl, maxTransactions, maxLimit, isActive } = req.body || {};
  const node = depositNodes.find(n => n.id === id);
  if (!node) return res.status(404).json({ error: 'Deposit node not found.' });

  if (upiId !== undefined && String(upiId).trim()) node.upiId = String(upiId).trim();
  if (displayName !== undefined && String(displayName).trim()) node.displayName = String(displayName).trim();
  if (qrImageUrl !== undefined) node.qrImageUrl = qrImageUrl;
  if (maxTransactions !== undefined) node.maxTransactions = +maxTransactions;
  if (maxLimit !== undefined) node.maxLimit = +maxLimit;
  if (isActive !== undefined) {
    node.isActive = Boolean(isActive);
    if (node.isActive) {
      depositNodes.forEach(n => { n.isActive = n.id === node.id; });
      activeDepositNodeId = node.id;
      systemConfig.activeDepositNodeId = node.id;
    }
  }

  syncActiveUpiToFirestoreAndClients();
  scheduleSavePlatformData('deposit_node_edit');
  res.json({ success: true, node, activeNodeId: activeDepositNodeId, nodes: depositNodes });
});

app.post('/api/admin/deposit-node/delete', verifySuperAdmin, (req, res) => {
  const { id } = req.body || {};
  if (depositNodes.length <= 1) {
    return res.status(400).json({ error: 'Cannot delete the only remaining deposit node.' });
  }

  const idx = depositNodes.findIndex(n => n.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Node not found.' });

  depositNodes.splice(idx, 1);
  if (activeDepositNodeId === id) {
    activeDepositNodeId = depositNodes[0].id;
    depositNodes[0].isActive = true;
    systemConfig.activeDepositNodeId = activeDepositNodeId;
  }

  syncActiveUpiToFirestoreAndClients();
  scheduleSavePlatformData('deposit_node_delete');
  res.json({ success: true, nodes: depositNodes, activeNodeId: activeDepositNodeId });
});

app.post('/api/admin/deposit-node/set-active', verifySuperAdmin, (req, res) => {
  const { id, nodeId } = req.body || {};
  const targetId = id || nodeId;
  const node = depositNodes.find(n => n.id === targetId);
  if (!node) return res.status(404).json({ error: 'Node not found.' });

  depositNodes.forEach(n => { n.isActive = n.id === node.id; });
  activeDepositNodeId = node.id;
  systemConfig.activeDepositNodeId = node.id;
  syncActiveUpiToFirestoreAndClients();
  scheduleSavePlatformData('deposit_node_set_active');

  res.json({ success: true, activeNode: node, activeNodeId: activeDepositNodeId, nodes: depositNodes });
});

app.post('/api/admin/deposit-node/reset-counter', verifySuperAdmin, (req, res) => {
  const { id, nodeId } = req.body || {};
  const targetId = id || nodeId;
  const node = depositNodes.find(n => n.id === targetId);
  if (!node) return res.status(404).json({ error: 'Node not found.' });

  node.currentTransactions = 0;
  scheduleSavePlatformData('deposit_node_reset_counter');
  res.json({ success: true, node });
});

// 20. ADMIN: TRIGGER OR RELEASE SMART LOCK FOR USER
app.post('/api/admin/user/smart-lock', verifySuperAdmin, (req, res) => {
  const { userId, active, rounds } = req.body;
  const user = users.get(userId);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  user.smartLockActive = Boolean(active);
  if (user.smartLockActive) {
    user.smartLockRoundsLeft = rounds ? +rounds : 4;
    user.smartLockTriggeredAt = Date.now();
  } else {
    user.smartLockRoundsLeft = 0;
  }

  res.json({ success: true, user: sanitizeUser(user) });
});

// 21. MODULE 9: MULTI-TIMEFRAME LEADERBOARD
app.get('/api/leaderboard', (req, res) => {
  const timeframe = (req.query.timeframe as LeaderboardTimeframe) || 'DAILY';
  const metric = (req.query.metric as LeaderboardMetric) || 'MOST_MULTIPLIER';
  const validTf = ['DAILY', 'WEEKLY', 'YEARLY'].includes(timeframe) ? timeframe : 'DAILY';
  const records = metric === 'MOST_WIN' ? leaderboardStore[validTf].mostWin : leaderboardStore[validTf].mostMultiplier;
  res.json({ timeframe: validTf, metric, records: records.slice(0, 20) });
});

// 22. ADMIN: SEED SYNTHETIC LEADERBOARD RECORD (MODULE 9)
app.post('/api/admin/seed-leaderboard', verifySuperAdmin, (req, res) => {
  const { username, multiplier, betAmount, payoutAmount, timeframe, type } = req.body;
  const tf = (timeframe as LeaderboardTimeframe) || 'DAILY';
  const metricType = (type as LeaderboardMetric) || 'MOST_MULTIPLIER';
  const mult = +multiplier || 10.00;
  const bet = +betAmount || 500;
  const payout = +payoutAmount || Math.round(bet * mult);
  const netWin = payout - bet;

  const entry: LeaderboardEntry = {
    id: `lb_seed_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    username: username || 'HighRoller_IN',
    anonymizedName: anonymizeUsername(username || 'HighRoller_IN'),
    metricValue: metricType === 'MOST_WIN' ? netWin : mult,
    multiplier: mult,
    betAmount: bet,
    payoutAmount: payout,
    timeframe: tf,
    type: metricType,
    timestamp: Date.now(),
    isSynthetic: true
  };

  if (metricType === 'MOST_WIN') {
    leaderboardStore[tf].mostWin.unshift(entry);
    leaderboardStore[tf].mostWin.sort((a, b) => b.metricValue - a.metricValue);
    if (leaderboardStore[tf].mostWin.length > 25) leaderboardStore[tf].mostWin.length = 25;
  } else {
    leaderboardStore[tf].mostMultiplier.unshift(entry);
    leaderboardStore[tf].mostMultiplier.sort((a, b) => b.metricValue - a.metricValue);
    if (leaderboardStore[tf].mostMultiplier.length > 25) leaderboardStore[tf].mostMultiplier.length = 25;
  }

  res.json({ success: true, entry });
});

// 23. ADMIN: TREND SEED CONFIGURATION (MODULE 5)
app.post('/api/admin/trend-seed', verifySuperAdmin, (req, res) => {
  const { mode, consecutiveCrashes, customSequence, autoOverrideOnLiability, liabilityCrashThreshold } = req.body;
  if (mode) trendSeedConfig.mode = mode;
  if (consecutiveCrashes !== undefined) trendSeedConfig.consecutiveCrashesRemaining = Math.max(0, +consecutiveCrashes);
  if (customSequence && Array.isArray(customSequence)) {
    trendSeedConfig.customSequence = customSequence.map(Number).filter(n => !isNaN(n) && n >= 1.01);
  }
  if (autoOverrideOnLiability !== undefined) trendSeedConfig.autoOverrideOnLiability = Boolean(autoOverrideOnLiability);
  if (liabilityCrashThreshold !== undefined) trendSeedConfig.liabilityCrashThreshold = +liabilityCrashThreshold;

  systemConfig.trendSeedConfig = { ...trendSeedConfig };
  res.json({ success: true, trendSeedConfig });
});

// 24. ADMIN: INJECT ARBITRARY SEQUENCE RECORD INTO HISTORY (MODULE 5)
app.post('/api/admin/history/inject', verifySuperAdmin, (req, res) => {
  const { multiplier, roundId } = req.body;
  const mult = +multiplier;
  if (isNaN(mult) || mult < 1.01) return res.status(400).json({ error: 'Valid multiplier >= 1.01 required.' });

  const item: MultiplierHistoryItem = {
    roundId: roundId || `R-INJ-${Math.floor(100 + Math.random() * 900)}`,
    multiplier: mult,
    crashedAt: Date.now()
  };
  multiplierHistory.unshift(item);
  if (multiplierHistory.length > 60) multiplierHistory.pop();

  io.emit('round_crashed', {
    roundId: item.roundId,
    crashMultiplier: mult,
    history: multiplierHistory.slice(0, 60)
  });

  res.json({ success: true, injected: item, history: multiplierHistory.slice(0, 60) });
});

// 25. ADMIN: SYSTEM MAINTENANCE OVERRIDE TOGGLE (MODULE 8)
app.post('/api/admin/maintenance', verifySuperAdmin, (req, res) => {
  const { active } = req.body;
  systemConfig.maintenanceModeActive = active !== undefined ? Boolean(active) : !systemConfig.maintenanceModeActive;
  io.emit('maintenance_status', { active: systemConfig.maintenanceModeActive });
  res.json({ success: true, maintenanceModeActive: systemConfig.maintenanceModeActive });
});

// 26. ADMIN: CONFIGURE LIABILITY THRESHOLD (MODULE 10)
app.post('/api/admin/liability-settings', verifySuperAdmin, (req, res) => {
  const { threshold } = req.body;
  if (threshold) {
    systemConfig.maxPlatformLiabilityThreshold = +threshold;
  }
  res.json({ success: true, threshold: systemConfig.maxPlatformLiabilityThreshold });
});

// 27. READ-ONLY ANALYTICAL HISTORY LOGS (MODULE 9: MY HISTORY TAB)
app.get('/api/user/analytics-history', (req, res) => {
  const userId = req.query.userId as string;
  if (!userId) return res.status(400).json({ error: 'userId is required' });

  const user = users.get(userId);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const userDeposits = deposits.filter(d => d.userId === userId);
  const userWithdrawals = withdrawals.filter(w => w.userId === userId);
  const userBets = roundBetsHistory.filter(b => b.userId === userId);

  const logs: Array<{ id: string; type: 'DEPOSIT' | 'WITHDRAWAL' | 'BET'; title: string; amount: number; status: string; timestamp: number; details?: string }> = [];

  userDeposits.forEach(d => {
    logs.push({
      id: d.id,
      type: 'DEPOSIT',
      title: `Manual Deposit (${d.paymentMethod})`,
      amount: d.amount,
      status: d.status,
      timestamp: d.createdAt,
      details: `UTR: ${d.utrNumber}`
    });
  });

  userWithdrawals.forEach(w => {
    logs.push({
      id: w.id,
      type: 'WITHDRAWAL',
      title: `Payout Withdrawal (${w.payoutMethod})`,
      amount: w.amount,
      status: w.status,
      timestamp: w.createdAt,
      details: w.adminUtr ? `Ref: ${w.adminUtr}` : (w.upiId || w.bankAccount)
    });
  });

  userBets.forEach(b => {
    logs.push({
      id: b.id,
      type: 'BET',
      title: b.cashedOut ? `Win @ ${b.cashedOutMultiplier}x` : `Lost @ Round ${b.roundId}`,
      amount: b.cashedOut ? (b.winAmount || 0) : -b.amount,
      status: b.cashedOut ? 'WON' : 'CRASHED',
      timestamp: b.createdAt,
      details: `Stake: ₹${b.amount}`
    });
  });

  logs.sort((a, b) => b.timestamp - a.timestamp);
  res.json({ logs: logs.slice(0, 50) });
});

// =========================================================================
// MODULE 14: PEAK VOLUME DYNAMIC MARGIN SCHEDULES
// =========================================================================
app.get('/api/admin/schedules', verifySuperAdmin, (req, res) => {
  res.json({ schedules: peakSchedules });
});

app.post('/api/admin/schedules/update', verifyStrictSuperAdmin, (req, res) => {
  const { schedules } = req.body;
  if (!Array.isArray(schedules)) {
    return res.status(400).json({ error: 'Schedules must be an array.' });
  }
  peakSchedules = schedules.map((s: any) => ({
    id: s.id || `sched_${Date.now()}_${Math.floor(Math.random() * 900)}`,
    name: s.name || 'Custom Margin Drop Schedule',
    startHour: Math.max(0, Math.min(23, Number(s.startHour) || 0)),
    endHour: Math.max(0, Math.min(23, Number(s.endHour) || 23)),
    forcedCrashProbability: Math.max(0.47, Math.min(0.95, Number(s.forcedCrashProbability) || 0.65)),
    isActive: Boolean(s.isActive)
  }));
  console.log('[MARGIN ENGINE] Updated Peak Concurrency schedules:', peakSchedules);
  res.json({ success: true, schedules: peakSchedules });
});

// =========================================================================
// MODULE 15: GLOBAL LOSS RECOVERY & SYSTEM VAULT STATUS
// =========================================================================
app.get('/api/admin/vault', verifySuperAdmin, (req, res) => {
  res.json({
    systemVaultMinimum: SYSTEM_VAULT_MINIMUM,
    platformReserveBalance,
    isDeficitActive: platformReserveBalance < SYSTEM_VAULT_MINIMUM
  });
});

app.post('/api/admin/vault/update', verifyStrictSuperAdmin, (req, res) => {
  const { systemVaultMinimum, platformReserveBalance: newReserve } = req.body;
  if (systemVaultMinimum !== undefined) {
    SYSTEM_VAULT_MINIMUM = Math.max(1000, Number(systemVaultMinimum));
  }
  if (newReserve !== undefined) {
    platformReserveBalance = Math.max(0, Number(newReserve));
  }
  res.json({
    success: true,
    systemVaultMinimum: SYSTEM_VAULT_MINIMUM,
    platformReserveBalance,
    isDeficitActive: platformReserveBalance < SYSTEM_VAULT_MINIMUM
  });
});

// =========================================================================
// MODULE 17: HIDDEN SUB-ADMIN CREATION & RBAC DELEGATION (WITH SOFT DELETE)
// =========================================================================
app.get('/api/admin/staff/list', verifySuperAdmin, (req, res) => {
  const staffList = Array.from(subAdmins.values()).filter(s => !s.is_deleted);
  res.json({
    staff: staffList,
    allowAdminRewardDispatch: Boolean(systemConfig.allowAdminRewardDispatch)
  });
});

app.post('/api/admin/staff/create', verifyStrictSuperAdmin, (req, res) => {
  const { name, email, uid, permissions } = req.body;
  const cleanEmailOrUid = String(email || uid || '').trim();
  if (!name && !cleanEmailOrUid) {
    return res.status(400).json({ error: 'Name and email (or 7-digit UID) are required for Admin approval.' });
  }

  const matchedUser = cleanEmailOrUid ? findUserByIdOrUid(cleanEmailOrUid) : undefined;
  if (matchedUser && matchedUser.role !== 'superadmin') {
    matchedUser.role = 'admin';
  }

  const staffId = `sub_${Date.now()}_${Math.floor(Math.random() * 900)}`;
  const token = `sub_sec_${Math.random().toString(36).substring(2, 12)}_${Date.now()}`;
  const newStaff: SubAdminAccount = {
    id: staffId,
    uid: matchedUser ? format7DigitUid(matchedUser.uid, matchedUser.id) : (uid ? String(uid).trim() : undefined),
    name: (name && String(name).trim()) || matchedUser?.name || 'Approved Admin',
    email: matchedUser?.email || cleanEmailOrUid || `admin_${staffId}@winnova.com`,
    token,
    role: 'SUB_ADMIN',
    permissions: {
      canManageWithdrawals: permissions?.canManageWithdrawals ?? true,
      canViewGameEngine: permissions?.canViewGameEngine ?? true,
      canViewMetrics: permissions?.canViewMetrics ?? true,
      canManageDeposits: permissions?.canManageDeposits ?? true,
      canConfirmOrderIds: permissions?.canConfirmOrderIds ?? true,
      canSendNotifications: permissions?.canSendNotifications ?? true,
      canSendNotificationsWithMoney: Boolean(permissions?.canSendNotificationsWithMoney)
    },
    isActive: true,
    createdAt: Date.now(),
    is_deleted: false
  };

  subAdmins.set(newStaff.id, newStaff);
  scheduleSavePlatformData('staff_created');
  console.log(`[STAFF RBAC] Approved Admin: ${newStaff.name} (${newStaff.id}) with Order ID confirmation access.`);
  res.json({ success: true, staff: newStaff });
});

app.post('/api/admin/staff/update', verifyStrictSuperAdmin, (req, res) => {
  const { id, isActive, permissions } = req.body;
  const staff = subAdmins.get(id);
  if (!staff || staff.is_deleted) return res.status(404).json({ error: 'Staff account not found.' });

  if (isActive !== undefined) staff.isActive = Boolean(isActive);
  if (permissions) {
    staff.permissions = {
      ...staff.permissions,
      ...permissions
    };
  }
  scheduleSavePlatformData('staff_updated');

  res.json({ success: true, staff });
});

app.post('/api/admin/staff/delete', verifyStrictSuperAdmin, (req, res) => {
  const { id } = req.body;
  const staff = subAdmins.get(id);
  if (!staff) return res.status(404).json({ error: 'Staff account not found.' });
  // Enforce Soft Delete Policy (is_deleted + deleted_at instead of mutating/deleting rows)
  staff.is_deleted = true;
  staff.deleted_at = Date.now();
  staff.isActive = false;
  res.json({
    success: true,
    message: 'Staff member soft-deleted (is_deleted=true, deleted_at recorded).'
  });
});

// =========================================================================
// NOTIFICATION & REWARD CENTRE + STRICT SUPER ADMIN VS ADMIN PERMISSION ENFORCEMENT
// =========================================================================
const platformNotifications: PlatformNotification[] = [
  {
    id: 'notif_welcome_seed_1',
    targetUserId: 'ALL',
    title: 'Welcome to WIN NOVA Official Crash Arena',
    message: 'Minimum withdrawal is ₹110 with 10% platform tax (₹110 withdrawal receives ₹100 net arrival). Submit deposit UTR proofs for instant dual Telegram & Website verification!',
    rewardAmount: 0,
    type: 'SYSTEM',
    senderRole: 'SUPER_ADMIN',
    senderName: 'Super Admin',
    isClaimed: false,
    claimedBy: [],
    isRead: false,
    readBy: [],
    createdAt: Date.now() - 3600000,
    is_deleted: false
  }
];

const notificationClaimLocks = new Set<string>();

// 1. Get active (non-soft-deleted) notifications for a user
app.get('/api/notifications/:userId', (req, res) => {
  const { userId } = req.params;
  const user = users.get(userId) || findUserByIdOrUid(userId);
  const effectiveUid = user ? format7DigitUid(user.uid, user.id) : '';

  const list = platformNotifications
    .filter(n => !n.is_deleted)
    .filter(n => n.targetUserId === 'ALL' || n.targetUserId === userId || (effectiveUid && n.targetUserId === effectiveUid))
    .map(n => ({
      ...n,
      isClaimed: n.targetUserId === 'ALL' ? Boolean(n.claimedBy?.includes(userId)) : Boolean(n.isClaimed || n.claimedBy?.includes(userId)),
      isRead: n.targetUserId === 'ALL' ? Boolean(n.readBy?.includes(userId)) : Boolean(n.isRead || n.readBy?.includes(userId))
    }))
    .sort((a, b) => b.createdAt - a.createdAt);

  res.json({
    success: true,
    notifications: list
  });
});

// 2. Mark notification as read
app.post('/api/notifications/:id/read', (req, res) => {
  const { id } = req.params;
  const { userId } = req.body || {};
  const notif = platformNotifications.find(n => n.id === id && !n.is_deleted);
  if (!notif) return res.status(404).json({ error: 'Notification not found.' });

  if (userId) {
    if (!notif.readBy) notif.readBy = [];
    if (!notif.readBy.includes(userId)) notif.readBy.push(userId);
  }
  if (notif.targetUserId !== 'ALL') {
    notif.isRead = true;
  }
  res.json({ success: true });
});

// 3. Atomic Claim Reward from Notification Centre
app.post('/api/notifications/:id/claim', (req, res) => {
  const { id } = req.params;
  const { userId } = req.body || {};
  if (!userId) return res.status(400).json({ error: 'userId is required.' });

  const lockKey = `${id}:${userId}`;
  if (notificationClaimLocks.has(lockKey)) {
    return res.status(429).json({ error: 'Claim already in progress.' });
  }
  notificationClaimLocks.add(lockKey);

  try {
    const notif = platformNotifications.find(n => n.id === id && !n.is_deleted);
    if (!notif) return res.status(404).json({ error: 'Notification not found or archived.' });

    const user = users.get(userId) || findUserByIdOrUid(userId);
    if (!user) return res.status(404).json({ error: 'User account not found.' });

    const effectiveUid = format7DigitUid(user.uid, user.id);
    if (notif.targetUserId !== 'ALL' && notif.targetUserId !== user.id && notif.targetUserId !== effectiveUid) {
      return res.status(403).json({ error: 'This reward notification belongs to another player.' });
    }

    if (!notif.rewardAmount || notif.rewardAmount <= 0) {
      return res.status(400).json({ error: 'This notification does not contain a monetary reward.' });
    }

    if (!notif.claimedBy) notif.claimedBy = [];
    if (notif.claimedBy.includes(user.id) || (notif.targetUserId !== 'ALL' && notif.isClaimed)) {
      return res.status(400).json({ error: 'Reward has already been claimed.' });
    }

    // Atomically mark claimed
    notif.claimedBy.push(user.id);
    if (notif.targetUserId !== 'ALL') {
      notif.isClaimed = true;
      notif.claimedAt = Date.now();
    }
    if (!notif.readBy) notif.readBy = [];
    if (!notif.readBy.includes(user.id)) notif.readBy.push(user.id);
    if (notif.targetUserId !== 'ALL') notif.isRead = true;

    // Credit user wallet
    const reward = +Number(notif.rewardAmount).toFixed(2);
    user.mainBalance = +(user.mainBalance + reward).toFixed(2);
    user.withdrawableBalance = +(user.withdrawableBalance + reward).toFixed(2);

    io.to(`user_${user.id}`).emit('balance_updated', {
      mainBalance: user.mainBalance,
      withdrawableBalance: user.withdrawableBalance,
      promoWallet: user.promoWallet,
      message: `🎁 Claimed ₹${reward.toFixed(2)} from Notification Centre!`
    });
    broadcastLiveWalletSync(user, 'notification_reward_claimed');
    scheduleSavePlatformData('notification_reward_claimed');

    return res.json({
      success: true,
      claimedAmount: reward,
      newBalance: user.mainBalance,
      message: `₹${reward.toFixed(2)} credited to your wallet!`
    });
  } finally {
    notificationClaimLocks.delete(lockKey);
  }
});

// 4. Soft-Delete Notification (Strict No-Delete Policy: sets is_deleted=true and deleted_at)
app.post('/api/notifications/:id/soft-delete', (req, res) => {
  const { id } = req.params;
  const { userId } = req.body || {};
  const notif = platformNotifications.find(n => n.id === id);
  if (!notif) return res.status(404).json({ error: 'Notification not found.' });

  notif.is_deleted = true;
  notif.deleted_at = Date.now();
  notif.deletedBy = userId || 'user';
  scheduleSavePlatformData('notification_soft_deleted');

  res.json({
    success: true,
    message: 'Notification archived via Soft Delete policy (is_deleted=true, deleted_at set).'
  });
});

// 5. Admin / Super Admin: List all Notification Centre dispatches & toggle state
app.get('/api/admin/notifications', verifySuperAdmin, (req, res) => {
  const activeList = platformNotifications.filter(n => !n.is_deleted).sort((a, b) => b.createdAt - a.createdAt);
  const softDeletedCount = platformNotifications.filter(n => n.is_deleted).length;
  res.json({
    success: true,
    notifications: activeList,
    softDeletedCount,
    allowAdminRewardDispatch: Boolean(systemConfig.allowAdminRewardDispatch),
    requesterRole: (req as any).adminRole
  });
});

// 6. STRICT SUPER ADMIN ONLY: Toggle whether Regular Admins can access/execute "Send Money/Rewards to Notification Centre"
app.post('/api/super-admin/toggle-admin-reward-permission', verifyStrictSuperAdmin, (req, res) => {
  const { allowAdminRewardDispatch } = req.body || {};
  systemConfig.allowAdminRewardDispatch = Boolean(allowAdminRewardDispatch);
  scheduleSavePlatformData('toggle_admin_reward_permission');
  io.emit('admin:reward_permission_toggled', {
    allowAdminRewardDispatch: systemConfig.allowAdminRewardDispatch,
    updatedAt: Date.now()
  });
  console.log(`[SECURITY AUDIT] Super Admin set allowAdminRewardDispatch = ${systemConfig.allowAdminRewardDispatch}`);
  res.json({
    success: true,
    allowAdminRewardDispatch: systemConfig.allowAdminRewardDispatch,
    message: systemConfig.allowAdminRewardDispatch
      ? 'Regular Admins are now permitted to send Money/Rewards to Notification Centre.'
      : 'Regular Admins are now STRICTLY BLOCKED from sending Money/Rewards to Notification Centre.'
  });
});

// 7. Send Money / Rewards / Alerts to Notification Centre (With Strict Super Admin vs Admin Enforcement)
app.post('/api/admin/notifications/send', verifySuperAdmin, (req, res) => {
  const { targetUserId, title, message, rewardAmount, type } = req.body || {};
  const adminRole = (req as any).adminRole as 'SUPER_ADMIN' | 'SUB_ADMIN';
  const subAdmin = (req as any).subAdmin as SubAdminAccount | undefined;

  const numericReward = Math.max(0, Number(rewardAmount) || 0);
  const isMonetaryDispatch = numericReward > 0 || type === 'REWARD';

  // CRITICAL SECURITY ENFORCEMENT (Directive 3):
  // Ensure that under NO circumstances can a regular Admin access or execute the
  // "Send Money/Rewards to Notification Centre" route if the Super Admin toggle status is turned off.
  if (adminRole !== 'SUPER_ADMIN') {
    if (!systemConfig.allowAdminRewardDispatch) {
      console.warn(`[SECURITY BLOCK] Regular Admin (${subAdmin?.name || 'Admin'}) attempted to access Send Money/Rewards to Notification Centre while Super Admin toggle is OFF.`);
      return res.status(403).json({
        error: 'SECURITY BLOCK: Super Admin has turned OFF "Send Money/Rewards to Notification Centre" for regular Admins. Access denied.'
      });
    }
    if (isMonetaryDispatch && subAdmin && !subAdmin.permissions.canSendNotificationsWithMoney) {
      console.warn(`[SECURITY BLOCK] Sub-Admin (${subAdmin.name}) attempted monetary reward dispatch without canSendNotificationsWithMoney permission.`);
      return res.status(403).json({
        error: 'SECURITY BLOCK: Your Admin role does not have permission to attach money/rewards to Notification Centre dispatches.'
      });
    }
  }

  if (!title || !String(title).trim() || !message || !String(message).trim()) {
    return res.status(400).json({ error: 'Notification title and message are required.' });
  }

  let resolvedTarget = String(targetUserId || 'ALL').trim();
  if (resolvedTarget.toUpperCase() !== 'ALL') {
    const targetUser = findUserByIdOrUid(resolvedTarget);
    if (targetUser) {
      resolvedTarget = targetUser.id;
    }
  } else {
    resolvedTarget = 'ALL';
  }

  const newNotif: PlatformNotification = {
    id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    targetUserId: resolvedTarget,
    title: String(title).trim(),
    message: String(message).trim(),
    rewardAmount: numericReward,
    type: numericReward > 0 ? 'REWARD' : (type || 'SYSTEM'),
    senderRole: adminRole === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : 'ADMIN',
    senderName: adminRole === 'SUPER_ADMIN' ? 'Super Admin' : (subAdmin?.name || 'Admin'),
    isClaimed: false,
    claimedBy: [],
    isRead: false,
    readBy: [],
    createdAt: Date.now(),
    is_deleted: false
  };

  platformNotifications.unshift(newNotif);
  scheduleSavePlatformData('notification_sent');

  if (resolvedTarget === 'ALL') {
    io.emit('notification_received', newNotif);
  } else {
    io.to(`user_${resolvedTarget}`).emit('notification_received', newNotif);
  }

  res.json({
    success: true,
    notification: newNotif,
    message: numericReward > 0
      ? `Dispatched ₹${numericReward} reward notification to ${resolvedTarget === 'ALL' ? 'All Players' : resolvedTarget}!`
      : `Dispatched notification to ${resolvedTarget === 'ALL' ? 'All Players' : resolvedTarget}!`
  });
});

// =========================================================================
// MODULE 19: TIMED PROMOTIONAL CAMPAIGN OVERRIDES & TTL MATRIX
// =========================================================================
app.get('/api/promotions/active', (req, res) => {
  res.json({
    campaign: getActiveCampaign(),
    baseline: BASELINE_DEPOSIT_BONUSES
  });
});

app.get('/api/admin/promotions/active', verifyStrictSuperAdmin, (req, res) => {
  res.json({
    campaign: getActiveCampaign(),
    baseline: BASELINE_DEPOSIT_BONUSES
  });
});

app.post('/api/admin/promotions/override', verifyStrictSuperAdmin, (req, res) => {
  const { campaignTitle, durationMinutes, overrides } = req.body;
  const mins = Math.max(1, Math.min(1440, Number(durationMinutes) || 60));
  const now = Date.now();

  timedCampaign = {
    isActive: true,
    campaignTitle: (campaignTitle || 'VIP Weekend Surge').trim(),
    durationMinutes: mins,
    startsAt: now,
    expiresAt: now + (mins * 60 * 1000),
    overrides: overrides || {}
  };

  console.log(`[CAMPAIGN OVERRIDE ACTIVATED] "${timedCampaign.campaignTitle}" for ${mins} mins. Expires at: ${new Date(timedCampaign.expiresAt).toISOString()}`);
  io.emit('campaign_updated', timedCampaign);

  res.json({
    success: true,
    campaign: timedCampaign,
    message: `Campaign active for ${mins} minutes with real-time TTL countdown.`
  });
});

app.post('/api/admin/promotions/revert', verifyStrictSuperAdmin, (req, res) => {
  timedCampaign.isActive = false;
  timedCampaign.overrides = {};
  timedCampaign.expiresAt = 0;
  console.log(`[CAMPAIGN OVERRIDE REVERTED] Reverted to Module 18 baseline parameters.`);
  io.emit('campaign_updated', timedCampaign);

  res.json({
    success: true,
    campaign: timedCampaign,
    message: 'Campaign reverted to original baseline indices.'
  });
});

// =========================================================================
// MODULE 20: VIP MILESTONE LUCKY SPIN WHEEL & LIVE VIP ENGINE STATE
// =========================================================================
app.get('/api/vip/state', (req, res) => {
  const userId = (req.headers['x-user-id'] as string) || (req.query.userId as string);
  const user = userId ? findUserByIdOrUid(userId) : undefined;
  const isSuper = user?.id === SUPER_ADMIN_ID || user?.role === 'superadmin' || (user?.mainBalance || 0) >= 900000000;
  const lifetimeDeposit = isSuper ? 500000 : Number(user?.lifetimeDeposit || 0);
  const cumulativeBetVolume = isSuper ? 1000000 : Number(user?.cumulativeVolume ?? user?.turnoverCompleted ?? 0);

  const resolvedConfig = getVipConfig(lifetimeDeposit);
  const userActualVipLevel = isSuper
    ? 10
    : typeof user?.vipLevel === 'number'
    ? Math.max(user.vipLevel, resolvedConfig.level)
    : resolvedConfig.level;

  const activeCamp = getActiveCampaign();

  const vipLevelsData = VIP_TIERS.map((tier, idx) => {
    const reqDeposit = tier.minLifetimeDeposit;
    const reqBet = tier.requiredBetAmount ?? calculateSlidingWager(reqDeposit);
    const baselineMatch = BASELINE_DEPOSIT_BONUSES.find((b) => b.depositAmount === reqDeposit);
    const campaignOverride = activeCamp.isActive && activeCamp.overrides ? activeCamp.overrides[reqDeposit] : undefined;

    const upgradeReward = campaignOverride?.firstTime ?? baselineMatch?.firstTimeBonus ?? tier.upgradeReward ?? 0;
    const monthlyReward = campaignOverride?.recurring ?? baselineMatch?.recurringBonus ?? tier.monthlyReward ?? 0;
    const isUnlocked = idx <= userActualVipLevel || lifetimeDeposit >= reqDeposit;

    const nextTier = VIP_TIERS[Math.min(VIP_TIERS.length - 1, idx + 1)];
    const targetForBar = idx === 0 ? nextTier.minLifetimeDeposit : reqDeposit;
    let progressPercentage = 0;
    if (isSuper || idx <= userActualVipLevel || targetForBar <= 0) {
      progressPercentage = 100;
    } else {
      progressPercentage = Math.min(100, Math.max(0, Math.floor((lifetimeDeposit / targetForBar) * 100)));
    }

    return {
      level: idx,
      levelName: `VIP${idx}`,
      requiredDeposit: reqDeposit,
      requiredBetAmount: reqBet,
      currentAccumulated: lifetimeDeposit,
      currentBetAccumulated: cumulativeBetVolume,
      upgradeReward,
      monthlyReward,
      dailyWithdrawLimit: tier.maxSingleWithdrawal,
      progressPercentage,
      isLocked: !isUnlocked
    };
  });

  res.json({
    success: true,
    vipState: {
      currentViewingIndex: userActualVipLevel,
      userActualVipLevel,
      lifetimeDeposit,
      cumulativeBetVolume,
      vipLevelsData
    }
  });
});

app.get('/api/vip/spin/status', (req, res) => {
  const userId = (req.headers['x-user-id'] as string) || (req.query.userId as string);
  const user = users.get(userId) || findUserByIdOrUid(userId);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  const isSuper = user.id === SUPER_ADMIN_ID || user.role === 'superadmin';
  const vipLevel = isSuper ? 10 : (user.vipLevel ?? getVipConfig(user.lifetimeDeposit || 0).level);
  const lastSpin = user.lastVipSpinAt || 0;
  const cooldown = 24 * 60 * 60 * 1000;
  const nextSpinAt = lastSpin + cooldown;
  const canSpin = vipLevel >= 1 && (Date.now() >= nextSpinAt || !lastSpin);

  res.json({
    vipLevel,
    canSpin,
    lastVipSpinAt: lastSpin,
    nextSpinAt
  });
});

app.post('/api/vip/spin', (req, res) => {
  const userId = (req.headers['x-user-id'] as string) || req.body.userId;
  const user = users.get(userId) || findUserByIdOrUid(userId);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  if (user.isFrozen) {
    return res.status(403).json({ error: 'Account is frozen.' });
  }

  const isSuper = user.id === SUPER_ADMIN_ID || user.role === 'superadmin';
  const vipLevel = isSuper ? 10 : (user.vipLevel ?? getVipConfig(user.lifetimeDeposit || 0).level);
  if (vipLevel < 1) {
    return res.status(403).json({
      error: 'VIP Level ≥ 1 required to access the Lucky Wheel. Deposit to advance your tier!'
    });
  }

  const now = Date.now();
  const cooldown = 24 * 60 * 60 * 1000;
  if (user.lastVipSpinAt && now - user.lastVipSpinAt < cooldown) {
    const diff = user.lastVipSpinAt + cooldown - now;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const mins = Math.floor((diff % (1000 * 60 * 60)) / 60000);
    return res.status(400).json({
      error: `Daily free spin already claimed. Next free spin available in ${hours}h ${mins}m.`
    });
  }

  // Server-side Structural RNG over VIP_SPIN_PRIZES weights (Zero-Risk Margin Optimization)
  const totalWeight = VIP_SPIN_PRIZES.reduce((sum, p) => sum + p.probabilityWeight, 0);
  let randomVal = Math.random() * totalWeight;
  let prizeIndex = 0;

  for (let i = 0; i < VIP_SPIN_PRIZES.length; i++) {
    if (randomVal < VIP_SPIN_PRIZES[i].probabilityWeight) {
      prizeIndex = i;
      break;
    }
    randomVal -= VIP_SPIN_PRIZES[i].probabilityWeight;
  }

  const wonPrize = VIP_SPIN_PRIZES[prizeIndex];

  // Credit reward safely
  if (wonPrize.type === 'PROMO_WALLET') {
    user.promoWallet = +(user.promoWallet + wonPrize.amount).toFixed(2);
  } else if (wonPrize.type === 'BONUS_CHIP') {
    user.bonusBalance = +(user.bonusBalance + wonPrize.amount).toFixed(2);
  }

  user.lastVipSpinAt = now;
  user.lastActivityAt = now;

  console.log(`[VIP SPIN] User ${user.id} (VIP ${vipLevel}) landed on ${wonPrize.label} (Index ${prizeIndex})`);

  // Broadcast balance update
  io.to(`user_${user.id}`).emit('balance_updated', {
    mainBalance: user.mainBalance,
    withdrawableBalance: user.withdrawableBalance,
    promoWallet: user.promoWallet,
    requiredWager: user.requiredWager ?? 0,
    vipLevel: user.vipLevel,
    lifetimeDeposit: user.lifetimeDeposit,
    message: wonPrize.amount > 0 ? `Won ${wonPrize.label} from VIP Lucky Wheel!` : undefined
  });

  res.json({
    success: true,
    prizeIndex,
    prize: wonPrize,
    newPromoWallet: user.promoWallet,
    newBonusBalance: user.bonusBalance,
    nextSpinAt: now + cooldown
  });
});

// =========================================================================
// MODULE 20 & 21: AUTOMATED RE-ENGAGEMENT & WALLET DORMANCY RE-ABSORPTION
// 48h Inactivity -> Scarcity PWA Push Payload linked to Timed Campaigns
// 30d Inactivity -> Silent ₹10 Maintenance Fee Deduction from Promo Wallet + Warning Push
// =========================================================================
function runDormancyAndRetentionCheck(): { processed: number; dormantDeductions: number; retentionAlerts: number } {
  const now = Date.now();
  const FORTY_EIGHT_HOURS = 48 * 60 * 60 * 1000;
  const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;

  let processed = 0;
  let dormantDeductions = 0;
  let retentionAlerts = 0;

  for (const user of users.values()) {
    processed++;
    const lastActive = user.lastActivityAt || user.createdAt || (now - 1000);
    const inactiveDuration = now - lastActive;

    // 1. Silent Monthly Asset Recovery Fee (30-Day Window)
    if (inactiveDuration >= THIRTY_DAYS && (user.promoWallet || 0) > 0) {
      const deduction = Math.min(10, user.promoWallet);
      user.promoWallet = Math.max(0, +(user.promoWallet - deduction).toFixed(2));
      dormantDeductions++;
      console.log(`[DORMANCY CRON] Silent ₹${deduction} maintenance fee deducted from dormant user ${user.id}. Remaining promoWallet: ₹${user.promoWallet}`);

      // Push Proximity Warning Alert
      io.to(`user_${user.id}`).emit('push_notification', {
        title: '⚠️ Wallet Inactivity Notice',
        body: `₹10 monthly maintenance fee applied due to 30 days of inactivity. Log in now to protect your balance.`,
        tag: 'wallet-dormancy',
        url: '/'
      });
    }

    // 2. Automated Session Re-Engagement Dispatcher (48-Hour Inactivity Window)
    else if (inactiveDuration >= FORTY_EIGHT_HOURS && inactiveDuration < THIRTY_DAYS) {
      retentionAlerts++;
      const campaignTitle = timedCampaign.isActive ? timedCampaign.campaignTitle : 'VIP Weekend Surge';
      const timeLeftMins = timedCampaign.isActive ? Math.max(1, Math.round((timedCampaign.expiresAt - now) / 60000)) : 45;

      io.to(`user_${user.id}`).emit('push_notification', {
        title: `⚡ ${campaignTitle} Ending Soon!`,
        body: `Urgent: Your exclusive bonus surge window expires in ${timeLeftMins} minutes! Return now to claim and multiply your bets.`,
        tag: 'session-reengagement',
        url: '/'
      });
    }
  }

  return { processed, dormantDeductions, retentionAlerts };
}

// Background cron executing every hour
setInterval(() => {
  runDormancyAndRetentionCheck();
}, 60 * 60 * 1000);

// =========================================================================
// MODULE 23 B: SYSTEM-WIDE AUTOMATED RE-ACTIVATION LEDGER
// Zero-Balance Loss Tracker & Restricted Revival Credit (₹18)
// =========================================================================
function checkUserLossVelocityRevival(user: User, now: number = Date.now()): boolean {
  if (user.role === 'admin' || user.role === 'superadmin') return false;

  // Zero-balance condition: wallet evaluates to exactly ₹0.00
  if (user.mainBalance !== 0 || (user.withdrawableBalance && user.withdrawableBalance > 0)) {
    return false;
  }

  // Net session loss condition: exceeding threshold (>= ₹500 within 24h cycle)
  const sessionLoss = userSessionLossAmount.get(user.id) || 0;
  const isLossThresholdMet =
    (user.netSessionProfit !== undefined && user.netSessionProfit <= -500) ||
    (user.sessionInitialBalance !== undefined && user.sessionInitialBalance >= 500 && user.mainBalance === 0) ||
    sessionLoss >= 500;

  if (!isLossThresholdMet) return false;

  // Check 24-hour compensation cooldown
  const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
  if (user.lastRevivalCreditAt && (now - user.lastRevivalCreditAt) < TWENTY_FOUR_HOURS) {
    return false;
  }

  // Inject hardcoded, low-tier promo token asset (₹18) back into auxiliary profile ledger (promoWallet)
  const REVIVAL_TOKEN_AMOUNT = 18;
  user.promoWallet = +((user.promoWallet || 0) + REVIVAL_TOKEN_AMOUNT).toFixed(2);
  user.lastRevivalCreditAt = now;
  user.revivalCreditsTotal = (user.revivalCreditsTotal || 0) + 1;

  console.log(`[REVIVAL CRON] User ${user.id} (${user.name}) zero-balance turnaround triggered. Injected ₹${REVIVAL_TOKEN_AMOUNT} revival credit into promoWallet.`);

  // Transmit localized push alert notification utilizing Module 19 visual campaign assets
  io.to(`user_${user.id}`).emit('push_notification', {
    title: '🔥 Zero-Balance Revival Credit: ₹18 Injected!',
    body: 'Exclusive loss-recovery token activated! ₹18 has been deposited into your Promo Vault to restart your flight engines. Jump back into the cockpit now!',
    tag: 'loss-velocity-revival',
    campaignBannerUrl: '/revival-promo.png',
    url: '/'
  });

  io.to(`user_${user.id}`).emit('revival_credit_awarded', {
    amount: REVIVAL_TOKEN_AMOUNT,
    newPromoWallet: user.promoWallet,
    timestamp: now,
    message: '₹18 Revival Credit injected into your Promo Vault!'
  });

  io.to(`user_${user.id}`).emit('balance_updated', {
    mainBalance: user.mainBalance,
    withdrawableBalance: user.withdrawableBalance,
    promoWallet: user.promoWallet,
    requiredWager: user.requiredWager ?? 0,
    vipLevel: user.vipLevel,
    lifetimeDeposit: user.lifetimeDeposit,
    message: '₹18 emergency revival token credited to your Promo Vault!'
  });

  return true;
}

function runLossVelocityRevivalAudit(): { processed: number; compensated: number } {
  const now = Date.now();
  let processed = 0;
  let compensated = 0;

  for (const user of users.values()) {
    processed++;
    if (checkUserLossVelocityRevival(user, now)) {
      compensated++;
    }
  }

  return { processed, compensated };
}

// Daily database routine parsing historical session documents
setInterval(() => {
  runLossVelocityRevivalAudit();
}, 24 * 60 * 60 * 1000);

// Proactive hourly check for zero-balance users
setInterval(() => {
  runLossVelocityRevivalAudit();
}, 60 * 60 * 1000);

app.post('/api/admin/cron/run-revival', verifyStrictSuperAdmin, (req, res) => {
  const result = runLossVelocityRevivalAudit();
  res.json({
    success: true,
    message: `Executed loss velocity revival routine across ${result.processed} accounts. Injected ₹18 revival tokens for ${result.compensated} eligible zero-balance users.`,
    ...result
  });
});

// User self-service revival claim endpoint
app.post('/api/user/claim-revival', (req, res) => {
  const { userId } = req.body;
  const user = users.get(userId);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  const eligible = checkUserLossVelocityRevival(user);
  if (eligible) {
    return res.json({
      success: true,
      amount: 18,
      newPromoWallet: user.promoWallet,
      message: '₹18 Revival Credit successfully added to your Promo Vault!'
    });
  } else {
    const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
    const cooldownRemaining = user.lastRevivalCreditAt ? Math.max(0, TWENTY_FOUR_HOURS - (Date.now() - user.lastRevivalCreditAt)) : 0;
    return res.status(400).json({
      error: cooldownRemaining > 0
        ? `Revival credit already claimed within the last 24 hours. Cooldown active for ${Math.round(cooldownRemaining / 60000)} minutes.`
        : 'Eligibility criteria not met. Must have zero balance (₹0.00) and net session losses ≥ ₹500.'
    });
  }
});

app.post('/api/admin/cron/run-dormancy', verifyStrictSuperAdmin, (req, res) => {
  const result = runDormancyAndRetentionCheck();
  res.json({
    success: true,
    message: `Executed dormancy and session retention audit on ${result.processed} accounts.`,
    ...result
  });
});

// Domain Masking / Wildcard Gateway Route (Module 10)
app.use(['/gateway', '/api/gateway'], (req, res, next) => {
  res.header('X-Platform-Mask', 'WIN-NOVA-SHIELD-V4');
  next();
});

// Helper: Sanitize user object to never leak sensitive tokens and ensure 7-digit unique UID
function sanitizeUser(u: User): Partial<User> {
  const isSuper = u.id === SUPER_ADMIN_ID || u.role === 'superadmin' || u.email === SUPER_ADMIN_EMAIL;
  const cleanUid = isSuper ? '1000001' : format7DigitUid(u.uid, u.id);
  u.uid = cleanUid;
  return {
    id: u.id,
    uid: cleanUid,
    name: u.name,
    email: u.email,
    phone: u.phone,
    role: u.role,
    mainBalance: isSuper ? 999999999 : u.mainBalance,
    promoWallet: isSuper ? 999999999 : (u.promoWallet || 0),
    bonusBalance: u.bonusBalance,
    withdrawableBalance: isSuper ? 999999999 : u.withdrawableBalance,
    turnoverRequired: u.turnoverRequired,
    turnoverCompleted: u.turnoverCompleted,
    vipLevel: isSuper ? 10 : (u.vipLevel ?? getVipConfig(u.lifetimeDeposit || 0).level),
    lifetimeDeposit: isSuper ? Math.max(500000, u.lifetimeDeposit || 0) : (u.lifetimeDeposit ?? 0),
    cumulativeVolume: isSuper ? Math.max(1000000, u.cumulativeVolume || 0) : (u.cumulativeVolume ?? 0),
    requiredWager: isSuper ? 0 : (u.requiredWager ?? 0),
    lastVipSpinAt: u.lastVipSpinAt,
    lastActivityAt: u.lastActivityAt,
    referralCode: u.referralCode,
    referredBy: u.referredBy,
    referralRewardStatus: u.referralRewardStatus,
    isFrozen: u.isFrozen,
    sessionInitialDeposit: u.sessionInitialDeposit,
    sessionInitialBalance: u.sessionInitialBalance,
    netSessionProfit: u.netSessionProfit,
    smartLockActive: u.smartLockActive,
    smartLockRoundsLeft: u.smartLockRoundsLeft,
    lastRevivalCreditAt: u.lastRevivalCreditAt,
    revivalCreditsTotal: u.revivalCreditsTotal || 0,
    promoConversionHistory: u.promoConversionHistory || [],
    createdAt: u.createdAt
  };
}

// =========================================================================
// PERMANENT FULL-STATE DATABASE PERSISTENCE ENGINE (DISK + FIRESTORE)
// Stores EVERY SINGLE piece of platform data so nothing is ever lost on restart
// =========================================================================
const DATA_DIR = path.join(process.cwd(), 'data');
const PLATFORM_DB_PATH = path.join(DATA_DIR, 'platform_database.json');
const userSavedPayoutDetails = new Map<string, { upiId?: string; accName?: string; accNo?: string; ifsc?: string; updatedAt: number }>();

let saveDebounceTimer: NodeJS.Timeout | null = null;

function syncActiveUpiToFirestoreAndClients() {
  const activeNode = getActiveDepositNode();
  if (!activeNode) return;

  systemConfig.activeDepositNodeId = activeNode.id;
  systemConfig.adminUpiId = activeNode.upiId;
  systemConfig.adminUpiName = activeNode.displayName;
  if (activeNode.qrImageUrl !== undefined) {
    systemConfig.adminQrUrl = activeNode.qrImageUrl;
  }

  io.emit('active_upi_node_changed', activeNode);
  io.emit('system:config_updated', systemConfig);

  try {
    adminDb.collection('system_config').doc('global').set({
      upiId: activeNode.upiId,
      qrCodeUrl: activeNode.qrImageUrl || '',
      merchantName: activeNode.displayName,
      activeDepositNodeId: activeNode.id,
      minDeposit: systemConfig.minDeposit,
      minWithdrawal: systemConfig.minWithdrawal,
      instantReferralBonus: systemConfig.instantReferralBonus,
      turnoverMultiplier: systemConfig.turnoverMultiplier,
      posterGirlImageUrl: systemConfig.posterGirlImageUrl || '/poster_girl.png',
      updatedBy: SUPER_ADMIN_ID,
      updatedAt: AdminFieldValue.serverTimestamp()
    }, { merge: true }).catch(() => {});

    adminDb.collection('deposit_nodes').doc('active_upi').set({
      id: activeNode.id,
      upiId: activeNode.upiId,
      qrImageUrl: activeNode.qrImageUrl || '',
      displayName: activeNode.displayName,
      isActive: true,
      updatedBy: SUPER_ADMIN_ID,
      updatedAt: AdminFieldValue.serverTimestamp()
    }, { merge: true }).catch(() => {});
  } catch {}
}

function saveAllPlatformData(reason: string = 'manual') {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    const snapshot = {
      savedAt: Date.now(),
      reason,
      roundSerialNumber,
      systemConfig,
      trendSeedConfig,
      cheatCrashTimeControl,
      activeDepositNodeId,
      depositNodes,
      users: Array.from(users.entries()),
      usedUids: Array.from(usedUids),
      deposits,
      withdrawals,
      fraudAlerts,
      multiplierHistory: multiplierHistory.slice(0, 60),
      roundBetsHistory: roundBetsHistory.slice(-500),
      chatMessages: chatMessages.slice(-100),
      fakeChatConfig,
      highRollers: highRollers.slice(0, 50),
      leaderboardStore,
      peakSchedules,
      SYSTEM_VAULT_MINIMUM,
      platformReserveBalance,
      subAdmins: Array.from(subAdmins.entries()),
      timedCampaign,
      userWallets: Array.from(userWallets.entries()),
      walletTransactions: Array.from(walletTransactions.entries()),
      inMemoryGiftCodes: Array.from(inMemoryGiftCodes.entries()),
      inMemoryWithdrawalTiers,
      inMemoryWithdrawals,
      userSavedPayoutDetails: Array.from(userSavedPayoutDetails.entries())
    };

    fs.writeFileSync(PLATFORM_DB_PATH, JSON.stringify(snapshot, null, 2), 'utf-8');

    // Mirror core state to Firestore asynchronously
    try {
      adminDb.collection('platform_state').doc('master_snapshot').set({
        savedAt: snapshot.savedAt,
        reason,
        roundSerialNumber,
        systemConfig,
        cheatCrashTimeControl,
        activeDepositNodeId,
        depositNodes,
        timedCampaign,
        fakeChatConfig,
        peakSchedules,
        SYSTEM_VAULT_MINIMUM,
        platformReserveBalance
      }, { merge: true }).catch(() => {});
    } catch {}
  } catch (err) {
    console.error('[PERSISTENCE ENGINE] Save error:', err);
  }
}

function scheduleSavePlatformData(reason: string = 'auto') {
  if (saveDebounceTimer) clearTimeout(saveDebounceTimer);
  saveDebounceTimer = setTimeout(() => {
    saveAllPlatformData(reason);
  }, 150);
}

async function loadAllPlatformData() {
  try {
    let data: any = null;
    if (fs.existsSync(PLATFORM_DB_PATH)) {
      const raw = fs.readFileSync(PLATFORM_DB_PATH, 'utf-8');
      data = JSON.parse(raw);
      console.log(`[PERSISTENCE ENGINE] Loaded platform database from disk (${PLATFORM_DB_PATH}).`);
    } else {
      try {
        const docSnap = await adminDb.collection('platform_state').doc('master_snapshot').get();
        if (docSnap.exists) {
          data = docSnap.data();
          console.log('[PERSISTENCE ENGINE] Loaded platform state from Firestore master_snapshot.');
        }
      } catch {}
    }

    if (!data) {
      // Save initial seed state immediately
      syncActiveUpiToFirestoreAndClients();
      saveAllPlatformData('initial_seed');
      return;
    }

    if (typeof data.roundSerialNumber === 'number' && data.roundSerialNumber > roundSerialNumber) {
      roundSerialNumber = data.roundSerialNumber;
    }
    if (data.systemConfig && typeof data.systemConfig === 'object') {
      systemConfig = { ...systemConfig, ...data.systemConfig, minWithdrawal: 110 };
    }
    if (data.trendSeedConfig && typeof data.trendSeedConfig === 'object') {
      trendSeedConfig = { ...trendSeedConfig, ...data.trendSeedConfig };
      systemConfig.trendSeedConfig = trendSeedConfig;
    }
    if (data.cheatCrashTimeControl && typeof data.cheatCrashTimeControl === 'object') {
      Object.assign(cheatCrashTimeControl, data.cheatCrashTimeControl);
    }
    if (Array.isArray(data.depositNodes) && data.depositNodes.length > 0) {
      depositNodes.length = 0;
      data.depositNodes.forEach((n: DepositNode) => depositNodes.push(n));
    }
    if (data.activeDepositNodeId && depositNodes.some(n => n.id === data.activeDepositNodeId)) {
      activeDepositNodeId = data.activeDepositNodeId;
      systemConfig.activeDepositNodeId = activeDepositNodeId;
      depositNodes.forEach(n => { n.isActive = n.id === activeDepositNodeId; });
    }
    if (Array.isArray(data.usedUids)) {
      data.usedUids.forEach((u: string) => usedUids.add(u));
    }
    if (Array.isArray(data.users)) {
      data.users.forEach(([k, v]: [string, User]) => {
        if (k && v) users.set(k, v);
      });
      // Ensure Super Admin remains present
      users.set(SUPER_ADMIN_ID, initialSuperAdmin);
    }
    if (Array.isArray(data.deposits)) {
      deposits.length = 0;
      data.deposits.forEach((d: DepositRequest) => {
        deposits.push(d);
        if (d?.utrNumber) {
          submittedDepositUtrs.add(String(d.utrNumber).trim().toLowerCase());
        }
      });
    }
    if (Array.isArray(data.withdrawals)) {
      withdrawals.length = 0;
      data.withdrawals.forEach((w: WithdrawalRequest) => withdrawals.push(w));
    }
    if (Array.isArray(data.fraudAlerts)) {
      fraudAlerts.length = 0;
      data.fraudAlerts.forEach((f: FraudAlert) => fraudAlerts.push(f));
    }
    if (Array.isArray(data.multiplierHistory) && data.multiplierHistory.length > 0) {
      multiplierHistory.length = 0;
      data.multiplierHistory.slice(0, 60).forEach((m: MultiplierHistoryItem) => multiplierHistory.push(m));
    }
    if (Array.isArray(data.roundBetsHistory)) {
      roundBetsHistory.length = 0;
      data.roundBetsHistory.forEach((b: Bet) => roundBetsHistory.push(b));
    }
    chatMessages.length = 0;
    fakeChatConfig.enabled = false;
    if (Array.isArray(data.highRollers) && data.highRollers.length > 0) {
      highRollers.length = 0;
      data.highRollers.forEach((h: HighRollerWinner) => highRollers.push(h));
    }
    if (data.leaderboardStore && typeof data.leaderboardStore === 'object') {
      if (data.leaderboardStore.DAILY) leaderboardStore.DAILY = data.leaderboardStore.DAILY;
      if (data.leaderboardStore.WEEKLY) leaderboardStore.WEEKLY = data.leaderboardStore.WEEKLY;
      if (data.leaderboardStore.YEARLY) leaderboardStore.YEARLY = data.leaderboardStore.YEARLY;
    }
    if (Array.isArray(data.peakSchedules) && data.peakSchedules.length > 0) {
      peakSchedules = data.peakSchedules;
    }
    if (typeof data.SYSTEM_VAULT_MINIMUM === 'number') {
      SYSTEM_VAULT_MINIMUM = data.SYSTEM_VAULT_MINIMUM;
    }
    if (typeof data.platformReserveBalance === 'number') {
      platformReserveBalance = data.platformReserveBalance;
    }
    if (Array.isArray(data.subAdmins)) {
      data.subAdmins.forEach(([k, v]: [string, SubAdminAccount]) => {
        if (k && v) subAdmins.set(k, v);
      });
    }
    if (data.timedCampaign && typeof data.timedCampaign === 'object') {
      timedCampaign = { ...timedCampaign, ...data.timedCampaign };
    }
    if (Array.isArray(data.userWallets)) {
      data.userWallets.forEach(([k, v]: [string, any]) => {
        if (k && v) userWallets.set(k, v);
      });
    }
    if (Array.isArray(data.walletTransactions)) {
      data.walletTransactions.forEach(([k, v]: [string, any[]]) => {
        if (k && Array.isArray(v)) walletTransactions.set(k, v);
      });
    }
    if (Array.isArray(data.inMemoryGiftCodes)) {
      const FAKE_CODES_BLACKLIST = new Set([
        'WINNOVA100',
        'VIPPOSTERGIRL',
        'BONUS100',
        'SUPER500',
        'VIP1000',
        'AVIATOR777',
        'WELCOME50'
      ]);
      data.inMemoryGiftCodes.forEach(([k, v]: [string, any]) => {
        const norm = String(k || '').trim().toUpperCase();
        if (norm && v && !FAKE_CODES_BLACKLIST.has(norm)) {
          inMemoryGiftCodes.set(norm, v);
        }
      });
    }
    if (Array.isArray(data.inMemoryWithdrawalTiers) && data.inMemoryWithdrawalTiers.length > 0) {
      inMemoryWithdrawalTiers.length = 0;
      data.inMemoryWithdrawalTiers.forEach((t: any) => {
        if (t && t.id) inMemoryWithdrawalTiers.push(t);
      });
    }
    if (Array.isArray(data.inMemoryWithdrawals)) {
      inMemoryWithdrawals.length = 0;
      data.inMemoryWithdrawals.forEach((w: any) => {
        if (w && w.id) inMemoryWithdrawals.push(w);
      });
    }
    if (Array.isArray(data.userSavedPayoutDetails)) {
      data.userSavedPayoutDetails.forEach(([k, v]: [string, any]) => {
        if (k && v) userSavedPayoutDetails.set(k, v);
      });
    }

    syncActiveUpiToFirestoreAndClients();
  } catch (err) {
    console.error('[PERSISTENCE ENGINE] Load error:', err);
  }
}

// Endpoint for saving/loading user withdrawal payout details (UPI ID & Bank Account)
app.get('/api/user/payout-details', (req, res) => {
  const userId = (req.headers['x-user-id'] as string) || (req.query.userId as string);
  if (!userId) return res.status(400).json({ error: 'userId required' });
  const details = userSavedPayoutDetails.get(userId) || null;
  res.json({ success: true, details });
});

app.post('/api/user/payout-details', (req, res) => {
  const { userId, upiId, accName, accNo, ifsc } = req.body || {};
  if (!userId) return res.status(400).json({ error: 'userId required' });
  const existing = userSavedPayoutDetails.get(userId) || { updatedAt: Date.now() };
  const updated = {
    upiId: upiId !== undefined ? String(upiId).trim() : existing.upiId,
    accName: accName !== undefined ? String(accName).trim() : existing.accName,
    accNo: accNo !== undefined ? String(accNo).trim() : existing.accNo,
    ifsc: ifsc !== undefined ? String(ifsc).trim().toUpperCase() : existing.ifsc,
    updatedAt: Date.now()
  };
  userSavedPayoutDetails.set(userId, updated);
  scheduleSavePlatformData('user_payout_details');
  res.json({ success: true, details: updated });
});

// Global Process Shielding
process.on('uncaughtException', (err: any) => {
  console.error('🛡️ [WIN NOVA PROCESS SHIELD] Uncaught Exception trapped:', err?.message || err);
});
process.on('unhandledRejection', (reason: any) => {
  console.error('🛡️ [WIN NOVA PROCESS SHIELD] Unhandled Rejection trapped:', reason);
});

// ==========================================
// ASYNC SERVER INITIALIZATION & LIFECYCLE GATEWAY
// ==========================================
async function initServer() {
  // 1. Immediately bind port 3000 so Cloud Run and container startup probes succeed with 0ms latency
  server.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      console.warn(`⚠️ [SERVER WARNING]: Port ${PORT} already bound or in use.`);
    } else {
      console.error('❌ [SERVER ERROR]:', err);
    }
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 [SERVER ONLINE]: WIN NOVA Hybrid Engine successfully listening on http://0.0.0.0:${PORT}`);
  });

  // 2. Anti-sleep ping route & background keep-alive loop
  app.get('/api/ping', (_req, res) => {
    res.status(200).json({
      status: 'online',
      brand: 'WIN NOVA',
      uptime: Math.floor(process.uptime()),
      timestamp: Date.now()
    });
  });

  // Internal Event Loop Keep-Alive Pulse: Touches memory & timers continuously, independent of network
  setInterval(() => {
    const mem = process.memoryUsage();
    if (mem.heapUsed === 0) console.log('Heartbeat memory pulse');
  }, 10000);

  setInterval(() => {
    http.get(`http://localhost:${PORT}/api/ping`, (res) => {
      res.resume();
    }).on('error', () => {});
  }, 120000);

  console.log('⏳ [INITIALIZATION]: Verifying database connection layer...');
  
  // 3. Database verification
  const dbStatus = await connectDatabase({ timeoutMs: 3500 });
  console.log(`📊 [DATABASE VERIFIED]: ReadyState: ${dbStatus.readyState} | Connected: ${dbStatus.connected} | Source: ${dbStatus.source}`);

  // 4. Load platform state & local caches
  await loadAllPlatformData();

  // 5. Initialize Telegram Prediction Bot & Webhook Gateway with mounted app
  console.log('🤖 [BOT INITIALIZATION]: Initializing Telegram Prediction Bot & Webhook Gateway...');
  setupTelegramBot(app, {
    getNextGameMultiplier: () => plannedCrashMultiplier || 2.45,
    getActiveUpiDetails: () => {
      const active = getActiveDepositNode();
      return {
        upiId: active?.upiId || 'vpa@upi',
        displayName: active?.displayName || 'Win Nova Official'
      };
    }
  });

  // 6. Mount Vite middleware or production static asset handlers
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  console.log(`📡 [NETWORK PROTOCOL]: Engine online. Database: ${dbStatus.connected ? 'Connected' : 'Standalone Mode'}. Ready for live traffic.`);
}

// Graceful process termination handlers
process.on('SIGTERM', () => {
  console.log('🛑 [SIGTERM]: Shutting down server gracefully...');
  server.close(() => {
    process.exit(0);
  });
});

initServer();
